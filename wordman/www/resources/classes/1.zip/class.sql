INSERT INTO word VALUES ('7d4df19b25f04327a33aa76dd884f193','let out','[let aut]','http://res.iciba.com/resource/amp3/0/0/af/4b/af4bf7de5a0e47c710664d07e9d0ba22.mp3','放掉, 泄露','','');----
INSERT INTO classwords VALUES ('126cd88fe987488fbaa982e148fd8776','7d4df19b25f04327a33aa76dd884f193','141');----
INSERT INTO word VALUES ('5788edde9372435ebc1785490baa8ecb','put away','[put əˈwei]','http://res.iciba.com/resource/amp3/0/0/f6/ae/f6aebbee4163169a82fd337d49ba149e.mp3','储存','','');----
INSERT INTO classwords VALUES ('e7da43ea51d94ecea7a3b4bf983e5ba6','5788edde9372435ebc1785490baa8ecb','141');----
INSERT INTO word VALUES ('73737894506846b89b1b4dd10b68c794','go on doing.....','[put əˈwei]','','继续干某事，不停地干某事','','');----
INSERT INTO classwords VALUES ('f394c4d264eb474ea8e1817e510284ab','73737894506846b89b1b4dd10b68c794','141');----
INSERT INTO word VALUES ('65bf469e1f274383ae9e77328c3089c2','by and by','[bai ænd bai]','http://res.iciba.com/resource/amp3/0/0/b2/39/b239eb281c171927761398cfdea950dc.mp3','不久以后，逐渐地','','');----
INSERT INTO classwords VALUES ('e7353800ae314b2791baeee5d655c795','65bf469e1f274383ae9e77328c3089c2','141');----
INSERT INTO word VALUES ('e86535d4ab184a0b960979e508b03b28','set down','[set daun]','http://res.iciba.com/resource/amp3/0/0/fd/1b/fd1bfbbfb8b86174eb0efb7630b362fc.mp3','放下','','');----
INSERT INTO classwords VALUES ('d21863a5c8bc4630adbc7ae6929e2f90','e86535d4ab184a0b960979e508b03b28','141');----
INSERT INTO word VALUES ('3d1fac1e1fb34962a0681a8955a134d0','write down','[rait daun]','http://res.iciba.com/resource/amp3/1/0/6d/7b/6d7bde8ccf1a2876a85e6d0db303a1ea.mp3','写下，记下','','');----
INSERT INTO classwords VALUES ('76384767b6ae4457b8e8f5f276118b7c','3d1fac1e1fb34962a0681a8955a134d0','141');----
INSERT INTO word VALUES ('01387cbe7da64fc2a8bda943cfacb277','earn one''s li...','[ə:n wʌnz ˈliviŋ]','http://res.iciba.com/resource/amp3/0/0/f6/6d/f66d7ddb97986031aedf69cb5f372435.mp3','谋生','','');----
INSERT INTO classwords VALUES ('f5e8d6351805448d92ec104f695b1bd4','01387cbe7da64fc2a8bda943cfacb277','141');----
INSERT INTO word VALUES ('fa505add59f140799c608ccc6c1a50bb','go in for','[ɡəu in fɔ:]','http://res.iciba.com/resource/amp3/0/0/dd/bc/ddbc2b6f300ea55fedefe363850687e8.mp3','参加，喜欢','','');----
INSERT INTO classwords VALUES ('fa8e2f8f2e62433aa19b9155c5476831','fa505add59f140799c608ccc6c1a50bb','141');----
INSERT INTO word VALUES ('0db14e21e44a43df8cfd899f935153ee','depend on (up...','[ɡəu in fɔ:]','','依靠，相信，信赖','','');----
INSERT INTO classwords VALUES ('6c0b22e9b7724b3fb881aa6630278a3e','0db14e21e44a43df8cfd899f935153ee','141');----
INSERT INTO word VALUES ('a862f8396788411fb6e9c640a25da1e2','send out','[send aut]','http://res.iciba.com/resource/amp3/0/0/e9/d0/e9d07bd968483d687722ad328570d08e.mp3','发出，派遣','','');----
INSERT INTO classwords VALUES ('8524c75882954e2fb572c2430b4cd57a','a862f8396788411fb6e9c640a25da1e2','141');----
INSERT INTO word VALUES ('b68316cc20374565aea0e18533d5a959','in a hurry','[in ə ˈhʌri]','http://res.iciba.com/resource/amp3/0/0/44/75/44751e53cf7ae2150b00b65fe3eb0e53.mp3','匆忙，很快地','','');----
INSERT INTO classwords VALUES ('986dbf2c0ad940278b29544cc50d416c','b68316cc20374565aea0e18533d5a959','141');----
INSERT INTO word VALUES ('a039837c237e4b21ab52d32a08bc0e71','in a word','[in ə wə:d]','http://res.iciba.com/resource/amp3/0/0/1a/5a/1a5ae76a4eedd87f85669c2950ebbfb9.mp3','简言之，总之','','');----
INSERT INTO classwords VALUES ('577f50a40769450b92099ad4cc49a551','a039837c237e4b21ab52d32a08bc0e71','141');----
INSERT INTO word VALUES ('5fa884feecdb405e81f1ab8747274a2d','get along wit...','[ɡet əˈlɔŋ wið]','http://res.iciba.com/resource/amp3/0/0/d3/28/d328cf7a311e10c31fdbe1dd52e8b5d6.mp3','与……相处','','');----
INSERT INTO classwords VALUES ('e10d7e33fda944429cd0301b5907f745','5fa884feecdb405e81f1ab8747274a2d','141');----
INSERT INTO word VALUES ('64b6fb3fc00548eeb9d7d98342014bf6','lead to','[li:d tu:]','http://res.iciba.com/resource/amp3/0/0/c1/9a/c19a08e132073ccc42091dc309da8631.mp3','导致，导向','','');----
INSERT INTO classwords VALUES ('1752f07d16bd402ebf65f6530559f6e1','64b6fb3fc00548eeb9d7d98342014bf6','141');----
INSERT INTO word VALUES ('756c9501016847af81790ec35cc06591','so far as','[səʊ fɑ: æz]','http://res.iciba.com/resource/amp3/0/0/8c/a4/8ca41b11fe464a0c930f12416a9af961.mp3','（表示程度，范围）就……，尽……','','');----
INSERT INTO classwords VALUES ('54a30ca4218b431abb86c5b6fdd63a03','756c9501016847af81790ec35cc06591','141');----
INSERT INTO word VALUES ('47331aa58ed14441a80bcc7d94f4048d','in need of','[in ni:d ɔv]','http://res.iciba.com/resource/amp3/0/0/e8/18/e818baf4ba9e825fea07d3a666cb5ea9.mp3','需要，缺少','','');----
INSERT INTO classwords VALUES ('9b12a3c7964d40edb2d54eb9971e0b56','47331aa58ed14441a80bcc7d94f4048d','141');----
INSERT INTO word VALUES ('56baaca7b43f4978bada9d183b84e02c','on foot','[ɔn fut]','http://res.iciba.com/resource/amp3/0/0/f1/8b/f18b10e99f79e4336552ef0789bf6803.mp3','走路，步行','','');----
INSERT INTO classwords VALUES ('9a79c44809f748b8aab7e18dedf0a4ca','56baaca7b43f4978bada9d183b84e02c','141');----
INSERT INTO word VALUES ('6157cdb023014f5a88b0721fa1fb145c','come about','[kʌm əˈbaut]','http://res.iciba.com/resource/amp3/0/0/ec/9b/ec9b2350dc9e6184af175d996f68aa23.mp3','发生，产生','','');----
INSERT INTO classwords VALUES ('e026f8094dbb46d282a2aa9ff042729c','6157cdb023014f5a88b0721fa1fb145c','141');----
INSERT INTO word VALUES ('2a1125ddb225435cbd45fd52332f8e3e','get together','[ɡet təˈɡeðə]','http://res.iciba.com/resource/amp3/0/0/b9/e1/b9e14d45cf990c9d2c27e14ae7961810.mp3','聚会，联欢','','');----
INSERT INTO classwords VALUES ('93c2c09e73f143d6990cb395328d5829','2a1125ddb225435cbd45fd52332f8e3e','141');----
INSERT INTO word VALUES ('4db6d73e6e0b42b2922fab5a4ab56d75','check out','[tʃek aut]','http://res.iciba.com/resource/amp3/0/0/8b/81/8b81d9aa118c0c3f760799dcbc9b81c1.mp3','查明; 结账','','');----
INSERT INTO classwords VALUES ('4996461835194a6f860eff7900118791','4db6d73e6e0b42b2922fab5a4ab56d75','141');----
INSERT INTO word VALUES ('524e6237180a4851a1e4dc110fd63380','send for','[send fɔ:]','http://res.iciba.com/resource/amp3/0/0/89/ca/89cab114aff61e28530067c8c876103a.mp3','派人去叫（请）','','');----
INSERT INTO classwords VALUES ('da02b7af895248289ee3f21e2060fd2d','524e6237180a4851a1e4dc110fd63380','141');----
INSERT INTO word VALUES ('9230f1ab8dd0475f94f269e6c86f086f','spend...on','','http://res-tts.iciba.com/8/1/4/814ff9557adbebd02186ecab27e08b51.mp3','在……花钱','','');----
INSERT INTO classwords VALUES ('04d3b93460df4ecfb3d08ea854ec8819','9230f1ab8dd0475f94f269e6c86f086f','141');----
INSERT INTO word VALUES ('14f668262226494f836907328d38d863','get off','[ɡet ɔf]','http://res.iciba.com/resource/amp3/0/0/25/c3/25c3ada1387b1c6b2c855a0facf5ef3a.mp3','脱下（衣服等）；下车','','');----
INSERT INTO classwords VALUES ('322a9a30985e42b794e26ee43bc248da','14f668262226494f836907328d38d863','141');----
INSERT INTO word VALUES ('2e0d8505b85349b480867408c1e49e73','make up of','[meik ʌp ɔv]','http://res.iciba.com/resource/amp3/0/0/9b/bd/9bbda06a23ed1b22a9b597d1b95edf40.mp3','由……组成，构成','','');----
INSERT INTO classwords VALUES ('edfb8cbb58cd40208e1fb211d8aebb33','2e0d8505b85349b480867408c1e49e73','141');----
INSERT INTO word VALUES ('5c335edde47f47e7b4238d2bf9199966','hold on','[həuld ɔn]','http://res.iciba.com/resource/amp3/0/0/45/c1/45c194a91bfef734109bb8ecaffa5561.mp3','等一等（别挂电话）','','');----
INSERT INTO classwords VALUES ('f29102e2102940e0b2b4742ed659475e','5c335edde47f47e7b4238d2bf9199966','141');----
INSERT INTO word VALUES ('ba62725b4902436baa06f6fd64d4bcd8','in the end','[in ðə end]','http://res.iciba.com/resource/amp3/0/0/a6/a3/a6a3b11134c4bc7538bb79454ce5ea31.mp3','最后，终于','','');----
INSERT INTO classwords VALUES ('d7e0c7a4160e4f7bb75101525e273e1c','ba62725b4902436baa06f6fd64d4bcd8','141');----
INSERT INTO word VALUES ('b3d1d5a3129c4ddd9e9e7c23f4e27c13','stand for','[stænd fɔ:]','http://res.iciba.com/resource/amp3/0/0/c2/91/c291452d4077260e22b5996663975ae4.mp3','代表，象征','','');----
INSERT INTO classwords VALUES ('b5513e5188d64cf08585b5ce01c239f2','b3d1d5a3129c4ddd9e9e7c23f4e27c13','141');----
INSERT INTO word VALUES ('7f7606db74e24c709007a9f8d261a73c','dozens of','','http://res-tts.iciba.com/1/d/5/1d5c6dd343acbf5b5989a74bc68d1346.mp3','几十','','');----
INSERT INTO classwords VALUES ('23aab45739994f55905d3f7b7822c008','7f7606db74e24c709007a9f8d261a73c','141');----
INSERT INTO word VALUES ('22bc3ac3df104898b75f689ded4bfb72','or else','[ɔ: els]','http://res.iciba.com/resource/amp3/0/0/f2/80/f28035166a9889f3c27b266611c0358c.mp3','否则，要不然','','');----
INSERT INTO classwords VALUES ('76d9246edbb2466d8f36114cef970418','22bc3ac3df104898b75f689ded4bfb72','141');----
INSERT INTO word VALUES ('3ea87440616a42c98bb2176d8485775d','come across','[kʌm əˈkrɔs]','http://res.iciba.com/resource/amp3/0/0/6d/af/6daf350034e01ceff031200e2fc32f2c.mp3','(偶然)遇见(或发现）','','');----
INSERT INTO classwords VALUES ('2f1f56928e104065b3657afde35771fe','3ea87440616a42c98bb2176d8485775d','141');----
INSERT INTO word VALUES ('6bad0911569f4c4a8cd8e6140b293c2b','feel like doi...','[fi:l laik ˈdu:ɪŋ]','http://res-tts.iciba.com/9/8/3/9832edcd0d97315c02e18c05e1ab598b.mp3','想要…, 感觉要…','','');----
INSERT INTO classwords VALUES ('8749b6b183de4bfb954dafe9f63743d7','6bad0911569f4c4a8cd8e6140b293c2b','141');----
INSERT INTO word VALUES ('aa9dbbf6a1774059917b1f00fdf99355','be strict wit...','[bi: strikt wið]','http://res-tts.iciba.com/3/a/d/3ade0973b5d44523a62ff0cb6526e132.mp3','对……严格要求','','');----
INSERT INTO classwords VALUES ('df468c258fe94be4bb8c24c4970a05d4','aa9dbbf6a1774059917b1f00fdf99355','141');----
INSERT INTO word VALUES ('959d8aabb9be417d909029b88645d811','cut off','[kʌt ɔf]','http://res.iciba.com/resource/amp3/1/0/cc/64/cc64e77e65d232d2741f5e62efa3faee.mp3','切断','','');----
INSERT INTO classwords VALUES ('27d87d269ced41a793f847af757a8430','959d8aabb9be417d909029b88645d811','141');----
INSERT INTO word VALUES ('d4f90ef044ac4a20b2871f37bbdb7814','in peace','[in pi:s]','http://res.iciba.com/resource/amp3/0/0/18/cf/18cf642f9eea7ec484e9a6853e3e1938.mp3','安静，宁静','','');----
INSERT INTO classwords VALUES ('b709bc52d118428bb5ba59737b7bec7f','d4f90ef044ac4a20b2871f37bbdb7814','141');----
INSERT INTO word VALUES ('f6fd937109554b2987593ce33c7eba10','make a face','[meik ə feis]','http://res.iciba.com/resource/amp3/0/0/f9/08/f908e0e91862b1b4fcd68129ee94b5fd.mp3','做鬼脸，做苦脸','','');----
INSERT INTO classwords VALUES ('a6610758cc714a74b625391e7a0b2135','f6fd937109554b2987593ce33c7eba10','141');----
INSERT INTO word VALUES ('c2478a7787e446579d7b115f6e33c9d4','think about','[θiŋk əˈbaut]','http://res-tts.iciba.com/3/e/e/3eecef3ee37002c553a48e7e9974b75d.mp3','考虑（是否去做）','','');----
INSERT INTO classwords VALUES ('0899677186e64e95b8e44c83c01b0b9a','c2478a7787e446579d7b115f6e33c9d4','141');----
INSERT INTO word VALUES ('0e72c342ca2d400881a7180b8f970ac3','arrive at (in...','[θiŋk əˈbaut]','','到达某地','','');----
INSERT INTO classwords VALUES ('5be2e34ff063435985772d30235fb87e','0e72c342ca2d400881a7180b8f970ac3','141');----
INSERT INTO word VALUES ('dce076c881354ad4b3d90a7846703989','go on','[ɡəu ɔn]','http://res.iciba.com/resource/amp3/0/0/4f/e6/4fe62855e964d07c63617d5ac8c5b88a.mp3','继续','','');----
INSERT INTO classwords VALUES ('0a3439b62e73426ba43d4d0097bd7db7','dce076c881354ad4b3d90a7846703989','141');----
INSERT INTO word VALUES ('2fa936217f594e81b0813e4adeb2ead5','on (the, an) ...','[ɡəu ɔn]','','平均，按平均数计算','','');----
INSERT INTO classwords VALUES ('0fdc3205cb724bc8b9d4a07efa72151e','2fa936217f594e81b0813e4adeb2ead5','141');----
INSERT INTO word VALUES ('0c610e6f74be4f71a3e76e984669a9d1','give back','[ɡiv bæk]','http://res.iciba.com/resource/amp3/0/0/d5/38/d538fbd83e4531b493c4a268cafdc97e.mp3','归还；送回','','');----
INSERT INTO classwords VALUES ('37e631ce4019433fa0f908c0948d8aa1','0c610e6f74be4f71a3e76e984669a9d1','141');----
INSERT INTO word VALUES ('c2136cc82f8b4cb590f57c9c5b981739','laugh at','[lɑ:f æt]','http://res.iciba.com/resource/amp3/0/0/1a/ec/1aecc42e226fb222c0f74ab686311d04.mp3','嘲笑','','');----
INSERT INTO classwords VALUES ('5460e9711c064bdead3113118fbbb33c','c2136cc82f8b4cb590f57c9c5b981739','141');----
INSERT INTO word VALUES ('18f91a112300449593a53b454d3f0acc','all kinds of','','http://res.iciba.com/resource/amp3/0/0/71/8c/718c0bf22971db0f7bbce83c4de05fbd.mp3','各种各样的','','');----
INSERT INTO classwords VALUES ('aa8847b524cf4f89895bf2085db03823','18f91a112300449593a53b454d3f0acc','141');----
INSERT INTO word VALUES ('4fea7baeda254efe872826665ad61c6a','look for','[luk fɔ:]','http://res.iciba.com/resource/amp3/0/0/80/95/8095d87fe84e9c5288bccd590976964e.mp3','寻找','','');----
INSERT INTO classwords VALUES ('35e0e334b4ba41fdbfff0382e6a4def4','4fea7baeda254efe872826665ad61c6a','141');----
INSERT INTO word VALUES ('67453e543f1b4acb9929aca5041da65f','go out','[ɡəu aut]','http://res.iciba.com/resource/amp3/0/0/f0/eb/f0ebc176acb87aaf3b7165173a057106.mp3','出去, 熄灭','','');----
INSERT INTO classwords VALUES ('e2644118bdbf42e1903d1562b3db0605','67453e543f1b4acb9929aca5041da65f','141');----
INSERT INTO word VALUES ('e6e473dc99574087b049921ac044a7ce','pay for','[pei fɔ:]','http://res.iciba.com/resource/amp3/0/0/d5/22/d52299dfff4ae51adc2f883011389cc0.mp3','付款','','');----
INSERT INTO classwords VALUES ('87d8248662c94d0f9b060e0aae4dd94b','e6e473dc99574087b049921ac044a7ce','141');----
INSERT INTO word VALUES ('e93f21345a9d44a7bfd1c4108019b8b2','so far','[səʊ fɑ:]','http://res.iciba.com/resource/amp3/0/0/49/6b/496b1a892afca979499eeb40a2f24c44.mp3','到目前为止','','');----
INSERT INTO classwords VALUES ('95a7e28bcdc44e84a235df0bcc13136f','e93f21345a9d44a7bfd1c4108019b8b2','141');----
INSERT INTO word VALUES ('6c7691c207ee4e3bb17ae75428d89874','help oneself ...','[help wʌnˈself tu:]','http://res.iciba.com/resource/amp3/0/0/31/50/3150c7faf8441558e5951429f2aa8522.mp3','请随便吃点','','');----
INSERT INTO classwords VALUES ('5948aae0c11840fcb39b6e0d5fa500f9','6c7691c207ee4e3bb17ae75428d89874','141');----
INSERT INTO word VALUES ('be369ee6b62848a296b90db37adf03d0','get up','[ɡet ʌp]','http://res.iciba.com/resource/amp3/0/0/c6/ec/c6ec1bb206e0f89e1798208abe061ae6.mp3','起床','','');----
INSERT INTO classwords VALUES ('c617e48785c24669b1901e48a83b5c8f','be369ee6b62848a296b90db37adf03d0','141');----
INSERT INTO word VALUES ('e87957407e914caa932205f708298a5d','a great deal','[ə ɡreit di:l]','http://res-tts.iciba.com/7/b/5/7b5c6cf6aff9277d15c01c64d0d8a6ba.mp3','大量，许多','','');----
INSERT INTO classwords VALUES ('f17e5b9a9ffc4ce08a1a06056006259c','e87957407e914caa932205f708298a5d','141');----
INSERT INTO word VALUES ('afd8557f75cf44b880db197ce3245ece','no longer','','http://res.iciba.com/resource/amp3/0/0/29/2d/292dede7b52cc12cd7a666823620001a.mp3','不再','','');----
INSERT INTO classwords VALUES ('d396d129b86c42c780b4f1ac60edb709','afd8557f75cf44b880db197ce3245ece','141');----
INSERT INTO word VALUES ('3dfd071a64624881a5096a874735f574','keep doing st...','','','继续做某事','','');----
INSERT INTO classwords VALUES ('0c84c368a5164c7088bed1003a9ab20b','3dfd071a64624881a5096a874735f574','141');----
INSERT INTO word VALUES ('c717f7d60d0f4078af19f4817fe08a53','put up with','[put ʌp wið]','http://res.iciba.com/resource/amp3/0/0/04/17/0417fdbdca7b77e693428fe35265711f.mp3','忍受','','');----
INSERT INTO classwords VALUES ('a0f26825211c48ba908c37ab8f7d2fc1','c717f7d60d0f4078af19f4817fe08a53','141');----
INSERT INTO word VALUES ('4214dbe4daab44a5ba72376708342f66','on show','[ɔn ʃəu]','http://res.iciba.com/resource/amp3/0/0/33/be/33be8345a32226b7ffde4460c5d82c9b.mp3','展出，在上演（放映）','','');----
INSERT INTO classwords VALUES ('535f49f382754459a6b5393fb15e2718','4214dbe4daab44a5ba72376708342f66','141');----
INSERT INTO word VALUES ('e7a51be5003242d5a620c44e258c7e2a','turn on','[tə:n ɔn]','http://res.iciba.com/resource/amp3/1/0/b1/97/b197375d9ebab835d23fd69d05cf3eb6.mp3','打开（水、电视、收音机、灯、煤气等）','','');----
INSERT INTO classwords VALUES ('4a3df61cfc834c17b732226f9792e9f7','e7a51be5003242d5a620c44e258c7e2a','141');----
INSERT INTO word VALUES ('00a46b98e6d04bb0ada7b4ec029e1efb','on duty','[ɔn ˈdju:ti]','http://res.iciba.com/resource/amp3/0/0/bc/66/bc66bd161e10618607e147174d03e72f.mp3','值日，值班','','');----
INSERT INTO classwords VALUES ('ae31632a5f6044d38b948a7d9fa037e4','00a46b98e6d04bb0ada7b4ec029e1efb','141');----
INSERT INTO word VALUES ('f532023a4db7441ca1f3c28d09d0fc38','hundreds of','','http://res-tts.iciba.com/4/b/d/4bde493da4b8ed0d05b9499392f62e4e.mp3','几百，成百上千','','');----
INSERT INTO classwords VALUES ('6c3d3b6fa6e741969928d7debf71a2e3','f532023a4db7441ca1f3c28d09d0fc38','141');----
INSERT INTO word VALUES ('beee46ee994046abbf53f662089e51e1','right now','[rait nau]','http://res.iciba.com/resource/amp3/0/0/4b/c3/4bc3954b03f53c00f11a5d99e7263bd6.mp3','立即，马上','','');----
INSERT INTO classwords VALUES ('29e9048a61c44edfa934e6eb063c3a87','beee46ee994046abbf53f662089e51e1','141');----
INSERT INTO word VALUES ('b9f09a531c2e4a379dfdc1f44d5c466d','work out','[wə:k aut]','http://res.iciba.com/resource/amp3/1/0/64/45/6445838221dd01d60743ccb8da88407e.mp3','算出，解决','','');----
INSERT INTO classwords VALUES ('e6564df27ef74573ab54cd980c36f8c0','b9f09a531c2e4a379dfdc1f44d5c466d','141');----
INSERT INTO word VALUES ('f05562c2b83c49fbbd3f5736e0cee80f','in danger','[in ˈdeindʒə]','http://res.iciba.com/resource/amp3/0/0/00/21/002125b1a358b3ce4972376722d4e800.mp3','处在危险状态','','');----
INSERT INTO classwords VALUES ('9d39118906dc41689c946f3565d75d3f','f05562c2b83c49fbbd3f5736e0cee80f','141');----
INSERT INTO word VALUES ('91c7fca9edda4b4ba2d30509edd9e266','go for a walk...','[ɡəu fɔ: ə wɔ:k]','http://res.iciba.com/resource/amp3/0/0/f8/f4/f8f47e27973f90f1f3068903a4e58b58.mp3','散步','','');----
INSERT INTO classwords VALUES ('e1f4f4a9e4d044f7add1aed5feb5df49','91c7fca9edda4b4ba2d30509edd9e266','141');----
INSERT INTO word VALUES ('a9688a3436b342139bca6e208517fe89','sentence...to...','[ɡəu fɔ: ə wɔ:k]','','判处死刑','','');----
INSERT INTO classwords VALUES ('a6fbe001a535400bbc6c308ebd7fb97c','a9688a3436b342139bca6e208517fe89','141');----
INSERT INTO word VALUES ('c71e954157c24e73938a5d15186993f1','save one''s li...','[ɡəu fɔ: ə wɔ:k]','','挽救某人生命','','');----
INSERT INTO classwords VALUES ('83ec6da4d18947d18850d6c338841fc0','c71e954157c24e73938a5d15186993f1','141');----
INSERT INTO word VALUES ('bbdacbf0aa4f40b4963720069a53e9a8','run away','[rʌn əˈwei]','http://res.iciba.com/resource/amp3/0/0/c9/7d/c97da3c65a68a1c8068f311b3752b3d1.mp3','逃跑, 失控','','');----
INSERT INTO classwords VALUES ('5d0b103f569043568c6f6b81c3f700ee','bbdacbf0aa4f40b4963720069a53e9a8','141');----
INSERT INTO word VALUES ('5170a56730744819b74991dc473a3f83','figure out','[ˈfiɡə aut]','http://res.iciba.com/resource/amp3/0/0/2d/76/2d7672dee811764e19ae620bd33e3d07.mp3','理解，想明白','','');----
INSERT INTO classwords VALUES ('57fe702b72e146938367855a92f770f6','5170a56730744819b74991dc473a3f83','141');----
INSERT INTO word VALUES ('6391c96517a747d59441a638e49027c7','a little','[ə ˈlitl]','http://res-tts.iciba.com/2/2/5/225ca0b4604f639c163e0aa77dfd8b58.mp3','一点，少许','','');----
INSERT INTO classwords VALUES ('6ac389ec464f420c8249bc52e76f6d2d','6391c96517a747d59441a638e49027c7','141');----
INSERT INTO word VALUES ('c67fafa11fee45c692f9435923886786','stop doing st...','','http://res-tts.iciba.com/a/f/d/afd12a2e57b73e35a4e2bfc3d44bc61d.mp3','停止做某事','','');----
INSERT INTO classwords VALUES ('939d777a225c424fafc9aa462148dd34','c67fafa11fee45c692f9435923886786','141');----
INSERT INTO word VALUES ('600eff1fac864bec98824932725f79a5','go through','[ɡəu θru:]','http://res.iciba.com/resource/amp3/0/0/45/60/456032ca6aaecf560ef92adf5acc6ee2.mp3','浏览; 翻阅，通过','','');----
INSERT INTO classwords VALUES ('c0791fd0143b44f19f08dc8a2fe42fc5','600eff1fac864bec98824932725f79a5','141');----
INSERT INTO word VALUES ('ceb50317b16d4beeb742c08ffd3dee2e','refer to','[riˈfə: tu:]','http://res.iciba.com/resource/amp3/0/0/d6/87/d6876c7aadc3629552b3db734c615db5.mp3','提到，涉及，有关','','');----
INSERT INTO classwords VALUES ('b4254f576ae74210b77bdc3ab7eda8cd','ceb50317b16d4beeb742c08ffd3dee2e','141');----
INSERT INTO word VALUES ('de124e5c1428460c9eaaa52e70012118','make friends ...','','http://res.iciba.com/resource/amp3/0/0/93/f4/93f49508669d93663eccada08bd27e54.mp3','与……交朋友','','');----
INSERT INTO classwords VALUES ('f875880deb55461090a3ea668fa09b9a','de124e5c1428460c9eaaa52e70012118','141');----
INSERT INTO word VALUES ('1321460c5ff24ba6929d1ca9067e3313','connect to','[kəˈnekt tu:]','http://res-tts.iciba.com/0/7/4/074481cdbfb1b31384a05eff275e00bf.mp3','连接，相连','','');----
INSERT INTO classwords VALUES ('4a51f188c97a4da4bf9e145432a1c565','1321460c5ff24ba6929d1ca9067e3313','141');----
INSERT INTO word VALUES ('2740976b07d04889b0b08c575764b4f4','in time','[in taim]','http://res.iciba.com/resource/amp3/0/0/6d/6d/6d6d79c57c8e833a6b82a9bff8f7f736.mp3','及时，来得及','','');----
INSERT INTO classwords VALUES ('bfff31efd8e54951a00844be5dcb69c0','2740976b07d04889b0b08c575764b4f4','141');----
INSERT INTO word VALUES ('b8b9495a37284dfa9663fe43cbab7fd7','not only ... ...','','http://res.iciba.com/resource/amp3/0/0/b9/a8/b9a82c1c7c7e6b72a7e5c035406b5447.mp3','不仅…而且…','','');----
INSERT INTO classwords VALUES ('6db597b6d90f4d6b9fc305f16668ceab','b8b9495a37284dfa9663fe43cbab7fd7','141');----
INSERT INTO word VALUES ('08112bec4cfa425c8e2f281ad863d614','bring in','[briŋ in]','http://res.iciba.com/resource/amp3/0/0/1c/f4/1cf447e6230970ae01f9fa844f4f69d9.mp3','引来，引进，吸收','','');----
INSERT INTO classwords VALUES ('035116023a76443b8414cec95ab44eb0','08112bec4cfa425c8e2f281ad863d614','141');----
INSERT INTO word VALUES ('4867453ddfd3402ea76541b73e102e0e','set out','[set aut]','http://res.iciba.com/resource/amp3/0/0/47/97/479742c1eb280b2bce596b8dc7eb9b13.mp3','出发; 开始','','');----
INSERT INTO classwords VALUES ('369caebb597546d5a10719d981e77b2d','4867453ddfd3402ea76541b73e102e0e','141');----
INSERT INTO word VALUES ('18952861e7814225a3a7983d756203fc','take up','[teik ʌp]','http://res.iciba.com/resource/amp3/0/0/90/70/90709b4878b07a9b6e669e3b53bbb1b2.mp3','占去，占据（时间、地位等）','','');----
INSERT INTO classwords VALUES ('5057b9a78ab84d4394c5e3e2fb5eef21','18952861e7814225a3a7983d756203fc','141');----
INSERT INTO word VALUES ('b200e433c2fb461db493ed5ff43329f1','ring up','[riŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/34/55/3455986d98f74c6e54d1b0c32db456cb.mp3','打电话给','','');----
INSERT INTO classwords VALUES ('435065698cb1417796f832cf6cb07865','b200e433c2fb461db493ed5ff43329f1','141');----
INSERT INTO word VALUES ('feaec0b57492428e8a76c89c02cf9cae','after class','[ˈɑ:ftə klɑ:s]','http://res-tts.iciba.com/5/3/1/531cad3e444c6974610074d112e5bce9.mp3','课后','','');----
INSERT INTO classwords VALUES ('bceb644a845046ac84ec7f17f5787b5f','feaec0b57492428e8a76c89c02cf9cae','141');----
INSERT INTO word VALUES ('53b34cf91820485397e6b5ed27d38baa','take off','[teik ɔf]','http://res.iciba.com/resource/amp3/0/0/e5/4f/e54f0f6c95f9f9bd43ea0e266b0ef4ca.mp3','脱下，起飞','','');----
INSERT INTO classwords VALUES ('8be295151a354092a259d259648a7302','53b34cf91820485397e6b5ed27d38baa','141');----
INSERT INTO word VALUES ('9f787d2890354b329cf17ef92ee974d6','day and night...','[dei ænd nait]','http://res-tts.iciba.com/f/1/b/f1bd884ad5b81c4c3238e0025054aa30.mp3','日日夜夜','','');----
INSERT INTO classwords VALUES ('cfcd6b53415043b59fc6a3aa71cc62a3','9f787d2890354b329cf17ef92ee974d6','141');----
INSERT INTO word VALUES ('d75daa50c84543aa9f8e0f0862e66efa','fall asleep','[fɔ:l əˈsli:p]','http://res.iciba.com/resource/amp3/0/0/b3/8a/b38a2bc60138c2c7c9b6f4a240863d74.mp3','入睡','','');----
INSERT INTO classwords VALUES ('2a29de340890472b80f989d05d12bcd9','d75daa50c84543aa9f8e0f0862e66efa','141');----
INSERT INTO word VALUES ('faba4741da4847849ebc06e7eb6af499','after all','[ˈɑ:ftə ɔ:l]','http://res.iciba.com/resource/amp3/0/0/d9/bf/d9bf78346b9f609a594e5b7510e2dd0d.mp3','毕竟，终究','','');----
INSERT INTO classwords VALUES ('163d8d877abb46a8892aa6810aa441b9','faba4741da4847849ebc06e7eb6af499','141');----
INSERT INTO word VALUES ('436f5615a3104e9fb66a31b632c28dcc','hand in','[hænd in]','http://res.iciba.com/resource/amp3/0/0/04/bc/04bc3505649bdc0ce315aa8ac68ef86e.mp3','上交; 交纳','','');----
INSERT INTO classwords VALUES ('c9c972b99740423195f13fd39d064f32','436f5615a3104e9fb66a31b632c28dcc','141');----
INSERT INTO word VALUES ('edb3834b5b6c4856ba68cf124cc85e25','hold one''s br...','','http://res.iciba.com/resource/amp3/0/0/0f/3d/0f3d1d3597485f323812a82fec67eabb.mp3','不出气,屏住呼吸','','');----
INSERT INTO classwords VALUES ('275f69ff977442848caf93f464d9f85f','edb3834b5b6c4856ba68cf124cc85e25','141');----
INSERT INTO word VALUES ('ec11b11c654747eaaadf90a6cb10c9e8','get in','[ɡet in]','http://res.iciba.com/resource/amp3/0/0/ad/b2/adb2733c99aee6038538aba3b9672f6a.mp3','进入, 收获，达到','','');----
INSERT INTO classwords VALUES ('914d24ccc4d34101a6b1338a09b5cd35','ec11b11c654747eaaadf90a6cb10c9e8','141');----
INSERT INTO word VALUES ('f35fc299acb7434da1081844a9dd14a6','fill in','[fil in]','http://res.iciba.com/resource/amp3/0/0/da/27/da2770eb7910e1dfae779adb454a45b2.mp3','填充','','');----
INSERT INTO classwords VALUES ('8f4e0eecc3494b56bc8ed0add9f08ff9','f35fc299acb7434da1081844a9dd14a6','141');----
INSERT INTO word VALUES ('7e77770fb93f48018040daf58fa37561','deal with','[di:l wið]','http://res.iciba.com/resource/amp3/1/0/1c/b4/1cb49697bf438bc903ff9704e950a633.mp3','处理，对付','','');----
INSERT INTO classwords VALUES ('40a710af4a794eadb6acead6b0931982','7e77770fb93f48018040daf58fa37561','141');----
INSERT INTO word VALUES ('32668b2bd12a44a39f0d6a8703b8d6b2','get on','[ɡet ɔn]','http://res.iciba.com/resource/amp3/0/0/fc/94/fc94b89254559d145986b854c7b2e2cb.mp3','上车；过活','','');----
INSERT INTO classwords VALUES ('b0f2406cb8fb46729dbba14feff1b140','32668b2bd12a44a39f0d6a8703b8d6b2','141');----
INSERT INTO word VALUES ('dc05fa2adc414e4ba53538f0bd28e6b6','divide up','[diˈvaid ʌp]','http://res.iciba.com/resource/amp3/1/0/b2/7d/b27daf51715232c40113c69bfeee2247.mp3','分配','','');----
INSERT INTO classwords VALUES ('4c881f0b823e4e7c9f4688d18fb02c38','dc05fa2adc414e4ba53538f0bd28e6b6','141');----
INSERT INTO word VALUES ('a0e112c7c27149b4873f0aeec3192a15','get down to','[ɡet daun tu:]','http://res.iciba.com/resource/amp3/0/0/d7/c3/d7c333a895962fe5b174e3e6038bf9b7.mp3','开始认真（做某事）','','');----
INSERT INTO classwords VALUES ('23e8154a605e427bb8a409820fe8a4c3','a0e112c7c27149b4873f0aeec3192a15','141');----
INSERT INTO word VALUES ('6f70cb1ae5814ee2986b2b0c4b5e4c0b','carry off','[ˈkæri ɔf]','http://res.iciba.com/resource/amp3/0/0/ac/2c/ac2c398aabfd21a7b3754aefe665b8c4.mp3','携走，夺走','','');----
INSERT INTO classwords VALUES ('f6885a98d07e464c81e660d5be721fd3','6f70cb1ae5814ee2986b2b0c4b5e4c0b','141');----
INSERT INTO word VALUES ('4263b94600c246819a1de359e308623a','pass by','[pɑ:s bai]','http://res.iciba.com/resource/amp3/0/0/02/21/02212fae7818e725863de3f14eaa94b6.mp3','经过','','');----
INSERT INTO classwords VALUES ('1024af1f8a7c4af0be237dac8cdb8961','4263b94600c246819a1de359e308623a','141');----
INSERT INTO word VALUES ('4a3f29aad2a4490abc14ce921a993e9f','have fun with...','','http://res-tts.iciba.com/a/7/f/a7fae4ff97dc602dc037af360c9fffcd.mp3','玩得高兴','','');----
INSERT INTO classwords VALUES ('52a12665e7aa4abc9e0f318118810ef6','4a3f29aad2a4490abc14ce921a993e9f','141');----
INSERT INTO word VALUES ('7ef8635c444d4df0bebed65d3bd46c8d','agree with sb...','','http://res-tts.iciba.com/5/4/c/54c2ca250447a763d8411b918bbfd949.mp3','同意某人的看法，与某人看法一致','','');----
INSERT INTO classwords VALUES ('d3f3ccd2058346cd98bc1b9bb413e9c7','7ef8635c444d4df0bebed65d3bd46c8d','141');----
INSERT INTO word VALUES ('be511bdead8e4e4a8243646229cfa921','build up','[bild ʌp]','http://res.iciba.com/resource/amp3/0/0/50/e0/50e05d5cf0e374c7b7369326b957d16b.mp3','逐步建立','','');----
INSERT INTO classwords VALUES ('d6f99f89b6e14dfda76016361c3ef0c7','be511bdead8e4e4a8243646229cfa921','141');----
INSERT INTO word VALUES ('8fabb68f1049468c8515de05503aef0a','break off','[breik ɔf]','http://res.iciba.com/resource/amp3/0/0/4e/21/4e21fe61899be58cb5cf1957b99a6bae.mp3','打断; 折断','','');----
INSERT INTO classwords VALUES ('43af68a2977642a2ab41aadfdd9db685','8fabb68f1049468c8515de05503aef0a','141');----
INSERT INTO word VALUES ('d89d2e2b2acf4e03a344eab76fccde96','bring up','[briŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/58/77/5877f75c7f78669372e2159ddd6e85b5.mp3','教育，培养','','');----
INSERT INTO classwords VALUES ('716ab5069c60461488dcfa0b23caebf1','d89d2e2b2acf4e03a344eab76fccde96','141');----
INSERT INTO word VALUES ('405b994e12f94be1bac820f049e65eca','in order','[in ˈɔ:də]','http://res.iciba.com/resource/amp3/0/0/c6/55/c65530c55229fab2e3af0bc9fb1ed124.mp3','按顺序','','');----
INSERT INTO classwords VALUES ('c918466bdb684b47b69eec7dc1884da7','405b994e12f94be1bac820f049e65eca','141');----
INSERT INTO word VALUES ('5950ea7e39604768b7af981eed127d2f','in other word...','','http://res.iciba.com/resource/amp3/0/0/78/0f/780f7b0f52d613efc5678a6a616eb4c7.mp3','换句话说','','');----
INSERT INTO classwords VALUES ('3e1117e60a8c4613937656e9600bb36c','5950ea7e39604768b7af981eed127d2f','141');----
INSERT INTO word VALUES ('a6378f1bdde441a4b380aee858cd5fb0','turn down','[tə:n daun]','http://res.iciba.com/resource/amp3/1/0/87/89/8789270b7a02a169d0a065e3ca03fdf8.mp3','关小，调低','','');----
INSERT INTO classwords VALUES ('8dca4faf601542e5a05c96a21137c89d','a6378f1bdde441a4b380aee858cd5fb0','141');----
INSERT INTO word VALUES ('ac34bbf2c982451d9cf04fb221944612','look down upo...','[luk daun əˈpɔn]','http://res.iciba.com/resource/amp3/0/0/97/5f/975f4d5381cf08d20f0eff8e9fcfb5b2.mp3','看不起，轻视','','');----
INSERT INTO classwords VALUES ('7c9c88e20a71439dbfc7eae2f5094b10','ac34bbf2c982451d9cf04fb221944612','141');----
INSERT INTO word VALUES ('83104bef001345b885e90ef639c25357','ought to','[ˈɔ:t tə]','http://res.iciba.com/resource/amp3/oxford/0/97/bb/97bb0d22013a0cd9bee66e42cf2de9dd.mp3','应该','','');----
INSERT INTO classwords VALUES ('9ebd683f36ba4d12bd1ad38b8ce0232c','83104bef001345b885e90ef639c25357','141');----
INSERT INTO word VALUES ('fe6f5ebcada749c8adb01193db1886bf','stop to do st...','[ˈɔ:t tə]','','停下来做某事','','');----
INSERT INTO classwords VALUES ('b05a4b799a0c4e21bc0ac3547731dfd0','fe6f5ebcada749c8adb01193db1886bf','141');----
INSERT INTO word VALUES ('280b2264e8944c79837bf6f90a359c59','be proud of','[bi: praud ɔv]','http://res.iciba.com/resource/amp3/0/0/1e/90/1e90c729ad3c5fbf9b86fd69266ddde3.mp3','骄傲，自豪','','');----
INSERT INTO classwords VALUES ('6d1ff903ff5e4b08984dcf4c0f578aaa','280b2264e8944c79837bf6f90a359c59','141');----
INSERT INTO word VALUES ('41d644d49cad4f53acfe8a5aef759ee8','come back','[kʌm bæk]','http://res.iciba.com/resource/amp3/0/0/1f/ce/1fce5629baaeaade48f614c18f10626b.mp3','回来，想起来','','');----
INSERT INTO classwords VALUES ('3ea7d88fe6a64ef0b36ed8d04a1f48cb','41d644d49cad4f53acfe8a5aef759ee8','141');----
INSERT INTO word VALUES ('dbbcf54e044546bda1703cb16e6c5719','have a good t...','[hæv ə ɡud taim]','http://res.iciba.com/resource/amp3/0/0/60/bc/60bc0718d1c81013812de7ea467ad975.mp3','玩得高兴，过得愉快','','');----
INSERT INTO classwords VALUES ('4964d73a9b9d421ba93136f275224c81','dbbcf54e044546bda1703cb16e6c5719','141');----
INSERT INTO word VALUES ('9deeab72a61447b0b96604040d437910','as if','[æz if]','http://res.iciba.com/resource/amp3/0/0/ad/32/ad3203e31be3977b9108254cdb7a07aa.mp3','好像，仿佛','','');----
INSERT INTO classwords VALUES ('591e21b890e2465e810cb0ca02b86ae0','9deeab72a61447b0b96604040d437910','141');----
INSERT INTO word VALUES ('7b81e008ef5f427da67371b8c38e9396','all in all','[ɔ:l in ɔ:l]','http://res.iciba.com/resource/amp3/0/0/55/53/5553f74713ecef912082b1189fbade16.mp3','总的来说，总计','','');----
INSERT INTO classwords VALUES ('f61b4e81fc874463910fa468aa183089','7b81e008ef5f427da67371b8c38e9396','141');----
INSERT INTO word VALUES ('cbcc51328236476fa0894011efe0af5c','come on','[kʌm ɔn]','http://res.iciba.com/resource/amp3/0/0/b1/9b/b19b704a47b51ae9d8c3ef7101eb9a7e.mp3','来吧，赶快','','');----
INSERT INTO classwords VALUES ('945b9290d6564d4d84031903214be90d','cbcc51328236476fa0894011efe0af5c','141');----
INSERT INTO word VALUES ('b4c291eef4d7491ebe02d618669965d0','hurry up','[ˈhʌri ʌp]','http://res.iciba.com/resource/amp3/0/0/0f/45/0f45cf405da2bb03814883f28cfd4c8c.mp3','赶快，快点','','');----
INSERT INTO classwords VALUES ('b17e8b3bed1946379a1c8701e7f7a8f1','b4c291eef4d7491ebe02d618669965d0','141');----
INSERT INTO word VALUES ('ae1611a8d38f40bab2abf920611277e6','go fishing','[ɡəu ˈfɪʃɪŋ]','http://res.iciba.com/resource/amp3/0/0/3b/43/3b4342f88a82a18e04c9ebbb27b7b6c7.mp3','（去）钓鱼','','');----
INSERT INTO classwords VALUES ('151275136d4346f0b814db824d119557','ae1611a8d38f40bab2abf920611277e6','141');----
INSERT INTO word VALUES ('ca94fba1bc654b839bba4e65d8d5603d','again and aga...','[əˈɡen ænd əˈɡen]','http://res.iciba.com/resource/amp3/0/0/51/52/5152ac16a2540d8a72fdb1e65107fbaa.mp3','反复地，再三地','','');----
INSERT INTO classwords VALUES ('4aae0a21bad84bd8b8e108358ad00263','ca94fba1bc654b839bba4e65d8d5603d','141');----
INSERT INTO word VALUES ('366fd2f979c8495cab0898042636ee24','try out','[trai aut]','http://res.iciba.com/resource/amp3/1/0/f6/07/f607f2a5c3a82ce4f8dab4ae574486af.mp3','试验','','');----
INSERT INTO classwords VALUES ('1b847b225d664977b840dfe6087d1703','366fd2f979c8495cab0898042636ee24','141');----
INSERT INTO word VALUES ('dfe7a5712983453cb3e0c5a82f75eeec','talk about','[tɔ:k əˈbaut]','http://res.iciba.com/resource/amp3/0/0/b0/f9/b0f91942e580a96767c0ccca31c6de46.mp3','谈论，议论','','');----
INSERT INTO classwords VALUES ('b8ed8d5b777f4e31bc9d891722df77e7','dfe7a5712983453cb3e0c5a82f75eeec','141');----
INSERT INTO word VALUES ('ba591a186e574b2dad81488dd81ed513','write to','[rait tu:]','http://res-tts.iciba.com/e/9/e/e9eb435a0792f6fed24b43cdd5662acf.mp3','写信给…','','');----
INSERT INTO classwords VALUES ('b41d138114974a7f96745f9ec0ea883b','ba591a186e574b2dad81488dd81ed513','141');----
INSERT INTO word VALUES ('7decf051384a44b484e6f05f827c3e7d','come from','[kʌm frɔm]','http://res.iciba.com/resource/amp3/0/0/4c/89/4c89cd90affd70a24513f11161dc4167.mp3','出生（于），来自','','');----
INSERT INTO classwords VALUES ('e96db40914374b55a164b1cbd7ee3846','7decf051384a44b484e6f05f827c3e7d','141');----
INSERT INTO word VALUES ('188dfa49d8f8402b861e2f3b0126bd4d','come in','[kʌm in]','http://res.iciba.com/resource/amp3/0/0/e1/99/e199114d6fbbcb354e308561f3723f8e.mp3','进入，进来','','');----
INSERT INTO classwords VALUES ('c70c5c727626465dbaf987a2ac9ee60e','188dfa49d8f8402b861e2f3b0126bd4d','141');----
INSERT INTO word VALUES ('01d87cce842b4a84909dd195f5cb269d','in all','[in ɔ:l]','http://res.iciba.com/resource/amp3/0/0/66/90/6690b31d1f2a51d6e7f6c63dff94261f.mp3','总之','','');----
INSERT INTO classwords VALUES ('3033e088234a422c953c5567930dbb38','01d87cce842b4a84909dd195f5cb269d','141');----
INSERT INTO word VALUES ('18acf428d2884dc0984f45181520b92a','once more','[wʌns mɔ:]','http://res.iciba.com/resource/amp3/0/0/97/f8/97f880f250c33c3af41aa38d48f5a4ae.mp3','再一次','','');----
INSERT INTO classwords VALUES ('36db4fad6d794d51999f94471f24f93f','18acf428d2884dc0984f45181520b92a','141');----
INSERT INTO word VALUES ('91e035db30ae437bbcb2b8bc4f11d5eb','each other','[i:tʃ ˈʌðə(r]','http://res-tts.iciba.com/3/e/e/3eef9039b69cd989f551655ea2103dad.mp3','相互','','');----
INSERT INTO classwords VALUES ('47b27f7111734e01b316cff23847a2c3','91e035db30ae437bbcb2b8bc4f11d5eb','141');----
INSERT INTO word VALUES ('5219fff9345244d09ec02d5b8b1b076b','send up','[send ʌp]','http://res.iciba.com/resource/amp3/0/0/2d/cf/2dcfaf5e68c86024cfbad070a58bf657.mp3','发出, 射出','','');----
INSERT INTO classwords VALUES ('5b13c3bf716b43ffbae58c3b3488e9d0','5219fff9345244d09ec02d5b8b1b076b','141');----
INSERT INTO word VALUES ('10bddf805ca144d8b4a3d507371c1948','see...off','[send ʌp]','','为某人送行','','');----
INSERT INTO classwords VALUES ('848de7e01c34415fa6469e7015f98e14','10bddf805ca144d8b4a3d507371c1948','141');----
INSERT INTO word VALUES ('3271a014ca724407bc7f6f6b2b0cddfd','die out','[dai aut]','http://res.iciba.com/resource/amp3/1/0/db/b7/dbb7f99f26a1c5fc87097cb058531055.mp3','消失，灭亡','','');----
INSERT INTO classwords VALUES ('ba0e1af3abc341d9a42eb228d2c8c823','3271a014ca724407bc7f6f6b2b0cddfd','141');----
INSERT INTO word VALUES ('a1856bade74b4fc99f8241cc4d833bb7','give up','[ɡiv ʌp]','http://res.iciba.com/resource/amp3/0/0/07/8d/078da1f9958e5856d6cdf0741d98c421.mp3','放?','','');----
INSERT INTO classwords VALUES ('3ee77637c94740ed9c7fb15248053c19','a1856bade74b4fc99f8241cc4d833bb7','141');----
INSERT INTO word VALUES ('f6b983f21b9a44d98b5da4671b46d578','in fact','[in fækt]','http://res.iciba.com/resource/amp3/0/0/a6/de/a6deccdb95cbd779293edd17d3fe47ae.mp3','事实上，实际上','','');----
INSERT INTO classwords VALUES ('d570d1e5f1e64ef7a99027480c695816','f6b983f21b9a44d98b5da4671b46d578','141');----
INSERT INTO word VALUES ('9bc65c8e38c847b8b04e62390c419435','even if','[ˈi:vən if]','http://res-tts.iciba.com/d/f/9/df99d2ca8ccbc29caa6628f08dea0ce8.mp3','即使，尽管','','');----
INSERT INTO classwords VALUES ('40ddf60c9b3744ccb905ac375c287673','9bc65c8e38c847b8b04e62390c419435','141');----
INSERT INTO word VALUES ('dd92b8eb71fe4928bc46b50ea1099073','take it easy','[teik it ˈi:zi]','http://res.iciba.com/resource/amp3/0/0/10/7e/107e07983e9f50df860abced64637438.mp3','别着急，别紧张','','');----
INSERT INTO classwords VALUES ('c2f67ce2f91e4dd6a8c6b9e506743743','dd92b8eb71fe4928bc46b50ea1099073','141');----
INSERT INTO word VALUES ('3efbab69e8854b58a3923a4b1cedce6e','in debt','[in det]','http://res.iciba.com/resource/amp3/0/0/aa/5f/aa5f7c7715ffd6aeed32dd70634af2cb.mp3','欠债','','');----
INSERT INTO classwords VALUES ('ee462a759e734e6b9419b64e001f93d7','3efbab69e8854b58a3923a4b1cedce6e','141');----
INSERT INTO word VALUES ('ce2636c1a376444da116cf2f7190514f','put on a perf...','[in det]','','演出','','');----
INSERT INTO classwords VALUES ('db0f7792c04f4958b9cc7853c8f62081','ce2636c1a376444da116cf2f7190514f','141');----
INSERT INTO word VALUES ('75f125bc2d85498ea5d9150f39f78eb8','come up','[kʌm ʌp]','http://res.iciba.com/resource/amp3/0/0/a8/6a/a86a0d634f7bf63a521e986d3bab64f7.mp3','上来，上升，抬头','','');----
INSERT INTO classwords VALUES ('3f9ea6a687df40b2a08c429451eaaf7b','75f125bc2d85498ea5d9150f39f78eb8','141');----
INSERT INTO word VALUES ('7aab6fddfdc34c1ea29c843f1831f45c','grow up','[ɡrəu ʌp]','http://res.iciba.com/resource/amp3/0/0/7a/c3/7ac361505e596dfc8932b526466ff882.mp3','长大成人，成长','','');----
INSERT INTO classwords VALUES ('6a88ad25482e4c61b13d660c9e61e76d','7aab6fddfdc34c1ea29c843f1831f45c','141');----
INSERT INTO word VALUES ('492952bb97c543aca9ec1fc1864fd8fd','get down','[ɡet daun]','http://res.iciba.com/resource/amp3/0/0/9d/9a/9d9a627954fbd2915b2c132c775af471.mp3','降下','','');----
INSERT INTO classwords VALUES ('72e2444eff5e4653815935895e0f76c9','492952bb97c543aca9ec1fc1864fd8fd','141');----
INSERT INTO word VALUES ('c261f0b4d69f4ef9a6bc996e4fa971f8','now and then','[nau ænd ðen]','http://res.iciba.com/resource/amp3/0/0/af/b3/afb348c8eae5841560b39a27bc1dafbe.mp3','不时，偶尔','','');----
INSERT INTO classwords VALUES ('a86d75afef4640f786b09442eefd5f78','c261f0b4d69f4ef9a6bc996e4fa971f8','141');----
INSERT INTO word VALUES ('ce23e16886f9411986558daedb5c7629','one after ano...','[wʌn ˈɑ:ftə əˈnʌðər]','http://res.iciba.com/resource/amp3/0/0/de/b6/deb6c001798c6b3f8a570a6fac6c8fcf.mp3','一个接一个','','');----
INSERT INTO classwords VALUES ('18efa4e149044758a41b5ef54635cd4e','ce23e16886f9411986558daedb5c7629','141');----
INSERT INTO word VALUES ('9432df2e538649288cb92d2f3ada13f8','hand out','[hænd aut]','http://res.iciba.com/resource/amp3/0/0/e8/fb/e8fb10760d6610fa2024e8d38e32a789.mp3','分发','','');----
INSERT INTO classwords VALUES ('0da2182edc084dd8851dc881166830de','9432df2e538649288cb92d2f3ada13f8','141');----
INSERT INTO word VALUES ('2ab4d4887bef479c83c0c640edaad78d','persuade sb. ...','[hænd aut]','','说服','','');----
INSERT INTO classwords VALUES ('4aab20d9ccee40a2a933aa65db347bb6','2ab4d4887bef479c83c0c640edaad78d','141');----
INSERT INTO word VALUES ('7f440e4bda204c8abf30ff9a2177ec2b','turn over','[tə:n ˈəuvə]','http://res.iciba.com/resource/amp3/1/0/08/63/0863e371d7ef2a18ebff815835f1d57a.mp3','翻动，犁翻（土地）','','');----
INSERT INTO classwords VALUES ('e855c5fd0eba4afb973c13a9dd3df17b','7f440e4bda204c8abf30ff9a2177ec2b','141');----
INSERT INTO word VALUES ('2c4f8965b6dd470096f7cd59a6fc370c','from... to','[tə:n ˈəuvə]','','从……到……','','');----
INSERT INTO classwords VALUES ('f0b8d1df64d545a08b329c2eb1dfc9a2','2c4f8965b6dd470096f7cd59a6fc370c','141');----
INSERT INTO word VALUES ('83b9b83ba0b24b069fe91fae2f0cedde','try on','[trai ɔn]','http://res.iciba.com/resource/amp3/1/0/3c/6a/3c6ae4c14bdf6ec8fcaf8e9ccf83741d.mp3','试穿，试试看','','');----
INSERT INTO classwords VALUES ('777bace65fcb4d8f914ae8d9707d10e0','83b9b83ba0b24b069fe91fae2f0cedde','141');----
INSERT INTO word VALUES ('6fa9c12798c943c1b06e00e51f696fc2','keep back','[ki:p bæk]','http://res.iciba.com/resource/amp3/0/0/04/5f/045f55136e98eeb2347633494319e834.mp3','留下','','');----
INSERT INTO classwords VALUES ('e44af21100f24d6994f5c7cec5d9e714','6fa9c12798c943c1b06e00e51f696fc2','141');----
INSERT INTO word VALUES ('572e32688b50417fb2d08d0f83291c15','rather than','','http://res.iciba.com/resource/amp3/0/0/13/3d/133d5a7c747b955dcb621ab1de6dadab.mp3','而不，非','','');----
INSERT INTO classwords VALUES ('ed50522708494c25871f25d5b4eee4c6','572e32688b50417fb2d08d0f83291c15','141');----
INSERT INTO word VALUES ('bb0e6ae2ffd74c65bac5c1795317ba42','both...and','','http://res-tts.iciba.com/6/5/7/6575a8f2a8455b328a36fba21d798ea7.mp3','两个都，既…又…','','');----
INSERT INTO classwords VALUES ('6048d82cb68b49209090d9b339626de1','bb0e6ae2ffd74c65bac5c1795317ba42','141');----
INSERT INTO word VALUES ('79ab38d3e4d040099671214aa4bb1e21','call in','[kɔ:l in]','http://res.iciba.com/resource/amp3/0/0/bf/d5/bfd58bacc1791ffdb1e8ce2fe7278a9b.mp3','召来，召集','','');----
INSERT INTO classwords VALUES ('21f2e33e6c82496196d6d86a3567432c','79ab38d3e4d040099671214aa4bb1e21','141');----
INSERT INTO word VALUES ('6846022c64284a66bd33a2af4fd3fc8d','in front of','[in frʌnt ɔv]','http://res.iciba.com/resource/amp3/0/0/29/17/2917f8743e8dd4d36ae50a74526d28de.mp3','在……前面','','');----
INSERT INTO classwords VALUES ('8f10d80f972e4c56baaec9bf03893899','6846022c64284a66bd33a2af4fd3fc8d','141');----
INSERT INTO word VALUES ('5fe0a77bd3c74f0298562162b14e5560','take away','[teik əˈwei]','http://res.iciba.com/resource/amp3/0/0/6f/63/6f6367d451aa380d8842523467d11a41.mp3','拿走','','');----
INSERT INTO classwords VALUES ('d11b4a615d0e46a88c0634dce4be623e','5fe0a77bd3c74f0298562162b14e5560','141');----
INSERT INTO word VALUES ('1443014c6af14af680e27c14df53f407','as usual','[æz ˈju:ʒuəl]','http://res.iciba.com/resource/amp3/0/0/65/3e/653ee6d5b0670423d7e06481e52ac751.mp3','通常，平常地','','');----
INSERT INTO classwords VALUES ('0c15928440d64064ac3a9740d6a0e4a4','1443014c6af14af680e27c14df53f407','141');----
INSERT INTO word VALUES ('e303384cf3d24bfb8341d25fe9113d3d','open up','[ˈəupən ʌp]','http://res.iciba.com/resource/amp3/0/0/0b/59/0b5932c3721f47c6feefcf767b06b64e.mp3','开启；开创; 开辟','','');----
INSERT INTO classwords VALUES ('4d6cb2818331465d8e20695b8f0ddeac','e303384cf3d24bfb8341d25fe9113d3d','141');----
INSERT INTO word VALUES ('291fb4fd8afe4543af74314c69d448e3','out of order','[aut ɔv ˈɔ:də]','http://res.iciba.com/resource/amp3/0/0/17/35/17356f966aa42919007009984bb87132.mp3','运转不正常，出毛病','','');----
INSERT INTO classwords VALUES ('3fb33bd109d047b08b871960a3c3f09a','291fb4fd8afe4543af74314c69d448e3','141');----
INSERT INTO word VALUES ('72fc78f92b334fbbb39503f6221ff912','a number of','[ə ˈnʌmbə ɔv]','http://res-tts.iciba.com/5/f/9/5f95a07c8848241cfe5076ac69477212.mp3','一些，许多','','');----
INSERT INTO classwords VALUES ('bc141109aedd48aa9cf116ec20d8ef46','72fc78f92b334fbbb39503f6221ff912','141');----
INSERT INTO word VALUES ('5fedb0aaabf44aa8bd680e5efba03a27','the day after...','','http://res.iciba.com/resource/amp3/0/0/70/8c/708cceace22e3cde6e69a9304a6b79c4.mp3','后天','','');----
INSERT INTO classwords VALUES ('46f773f5862447bc92713ee36e618015','5fedb0aaabf44aa8bd680e5efba03a27','141');----
INSERT INTO word VALUES ('2d224b53a75c4c14b5792a7e79828e97','make up one''s...','','http://res.iciba.com/resource/amp3/0/0/ce/46/ce46d880a6977b195d5adb40dc2dfbc5.mp3','下决心','','');----
INSERT INTO classwords VALUES ('1caaf4390b574f2c858de212d84e72c7','2d224b53a75c4c14b5792a7e79828e97','141');----
INSERT INTO word VALUES ('5c1f16a6abf74218b3a06e7800c4cca7','the more...th...','','http://res-tts.iciba.com/6/f/3/6f36811f428e54535b679f4377cc313a.mp3','越…就越…','','');----
INSERT INTO classwords VALUES ('32dc033daf334e6a96b4ca94eecc310c','5c1f16a6abf74218b3a06e7800c4cca7','141');----
INSERT INTO word VALUES ('91bc6e2e33e34c34a04ff2b124e10897','from time to ...','[frɔm taim tu: taim]','http://res.iciba.com/resource/amp3/0/0/c2/ad/c2ad5f6f255616748a0310496d576e8b.mp3','不时，偶尔','','');----
INSERT INTO classwords VALUES ('e89964e8beef45f8be32bc495288d8e5','91bc6e2e33e34c34a04ff2b124e10897','141');----
INSERT INTO word VALUES ('b72fd14d780f47b58a0811db0a60eba0','just now','[dʒʌst nau]','http://res.iciba.com/resource/amp3/0/0/26/54/2654992d78afbd40bad349302a6f2b6a.mp3','现在，刚才','','');----
INSERT INTO classwords VALUES ('c81bcbc4ec124246bdd5060592329f1f','b72fd14d780f47b58a0811db0a60eba0','141');----
INSERT INTO word VALUES ('4d465efddeef476190a91d3db5abcc48','millions of','','http://res-tts.iciba.com/6/d/f/6dfe0e2013068722b91822a1a474efb1.mp3','成百万上千万，数以百万计','','');----
INSERT INTO classwords VALUES ('61a2bd55e98a40d1843eef6f47a9e8a9','4d465efddeef476190a91d3db5abcc48','141');----
INSERT INTO word VALUES ('c2639a24fe8743bf9319fb727460790d','for example','[fɔ: iɡˈzɑ:mpl]','http://res.iciba.com/resource/amp3/0/0/02/3d/023dbce5e060641d09218027704ca4b3.mp3','例如','','');----
INSERT INTO classwords VALUES ('345f54406d6f48839811e5f3a7cd8fb6','c2639a24fe8743bf9319fb727460790d','141');----
INSERT INTO word VALUES ('7337f6689fba41f8a9d74bcbfbf1fc2f','wait for','[weit fɔ:]','http://res-tts.iciba.com/e/3/5/e35031efc5cf102eb14d71f301faa475.mp3','等候，等待','','');----
INSERT INTO classwords VALUES ('587d83194c994f329fb6bc4b7c378a3f','7337f6689fba41f8a9d74bcbfbf1fc2f','141');----
INSERT INTO word VALUES ('17c47fcf6c954aba8bb68d2caf217c4a','thousands of','','http://res-tts.iciba.com/1/f/7/1f741dd5c3c6458071193f208c895e6d.mp3','成千上万，几千','','');----
INSERT INTO classwords VALUES ('5bdc42d22c7f47b9840bb0a48a88722f','17c47fcf6c954aba8bb68d2caf217c4a','141');----
INSERT INTO word VALUES ('9eeb332138cc427d8ddc0ba8900afae7','worry about','[ˈwʌri əˈbaut]','http://res-tts.iciba.com/5/f/e/5fe5dd576111fd6e5e18c3d10bcef64c.mp3','担心，烦恼','','');----
INSERT INTO classwords VALUES ('353bba74f61c469f995e48f05961680d','9eeb332138cc427d8ddc0ba8900afae7','141');----
INSERT INTO word VALUES ('6aca53a409bf4ccbad2eac47328cac2e','a great many','[ə ɡreit ˈmeni]','http://res-tts.iciba.com/1/5/c/15cfccb6d4ed6c872ce70d6329de4cd5.mp3','大量，许多','','');----
INSERT INTO classwords VALUES ('5df7698956324bceacf00ecd918495fc','6aca53a409bf4ccbad2eac47328cac2e','141');----
INSERT INTO word VALUES ('3e97a55d0ee3411fb137ea6dc63b41d8','wrap up','[ræp ʌp]','http://res.iciba.com/resource/amp3/1/0/e5/94/e594ba35385531b78c8252893dd915d9.mp3','包好, 伪装','','');----
INSERT INTO classwords VALUES ('e3f8b51ab18d49d6a0ecc78590c0dd7a','3e97a55d0ee3411fb137ea6dc63b41d8','141');----
INSERT INTO word VALUES ('12bfdaa5b4e14baaa66a2c0902fd9abe','take out','[teik aut]','http://res.iciba.com/resource/amp3/0/0/6d/60/6d60b5b90711ac3669744f550314d52d.mp3','取出','','');----
INSERT INTO classwords VALUES ('f4faf62a087d4091b37dedc3829ef97b','12bfdaa5b4e14baaa66a2c0902fd9abe','141');----
INSERT INTO word VALUES ('566792035c434b74ab56a7662a043f25','according to','','http://res-tts.iciba.com/4/4/0/440a3bbc91716125aef7de35fc6e49ae.mp3','根据，按照','','');----
INSERT INTO classwords VALUES ('c3a450eeea9a488490ce82eae45946c4','566792035c434b74ab56a7662a043f25','141');----
INSERT INTO word VALUES ('de2aae5664c04b52bbb4129a3034fcf4','by day','[bai dei]','http://res.iciba.com/resource/amp3/0/0/d7/10/d7106bda7e75a8ab4dfd96fcb56fb2b6.mp3','日间，在白天','','');----
INSERT INTO classwords VALUES ('804ff1a826ef409a982f3abb5e71920b','de2aae5664c04b52bbb4129a3034fcf4','141');----
INSERT INTO word VALUES ('0ad13bdf0e944905b1f43367eec4a484','let in','[let in]','http://res.iciba.com/resource/amp3/0/0/00/a6/00a6ff3dfbd23c1d8c3bafc3aa38e11a.mp3','让……进来，放进','','');----
INSERT INTO classwords VALUES ('0b1ec1cdc6e2411b9ba2768fbd9b67f3','0ad13bdf0e944905b1f43367eec4a484','141');----
INSERT INTO word VALUES ('a5ef4a95c2314212be90beaab6bc769c','the other day...','[ðə ˈʌðə(r dei]','http://res.iciba.com/resource/amp3/0/0/64/e9/64e9f2bda171874aee42b8e8fe57659d.mp3','前几天，某日','','');----
INSERT INTO classwords VALUES ('fde5a6cac6d24242add47b2b58cb35fc','a5ef4a95c2314212be90beaab6bc769c','141');----
INSERT INTO word VALUES ('bd1956444b9b48d38b750eed0e710ae5','join up','[dʒɔin ʌp]','http://res.iciba.com/resource/amp3/0/0/14/2b/142bd51fd91e810c5bc5b2e242a084be.mp3','联合起来，联结起来','','');----
INSERT INTO classwords VALUES ('2bf5fa2e8f954413820992236b0d6804','bd1956444b9b48d38b750eed0e710ae5','141');----
INSERT INTO word VALUES ('0cd9e4b282164bdfae4c26d20ab59af2','compare with','[kəmˈpɛə wið]','http://res.iciba.com/resource/amp3/0/0/0e/06/0e062bf7d1366cf048b96b419614a399.mp3','与……相比','','');----
INSERT INTO classwords VALUES ('1f5b7d03cca0400bbe3d13d4991f73b1','0cd9e4b282164bdfae4c26d20ab59af2','141');----
INSERT INTO word VALUES ('93fd20a4ad3a40349835320ed171999b','go ahead','[ɡəu əˈhed]','http://res.iciba.com/resource/amp3/0/0/86/7b/867b716ecfc8971b436fbf52f1961a2e.mp3','走在前面，领先；干吧，干下去','','');----
INSERT INTO classwords VALUES ('bab47e2da41a4db0a4d74f841cbdd285','93fd20a4ad3a40349835320ed171999b','141');----
INSERT INTO word VALUES ('b3f14d29a1bc4f2fa09b651b67eb560a','in surprise','[in səˈpraiz]','http://res.iciba.com/resource/amp3/0/0/7d/5c/7d5c332b18f2d6baca2fa1d090874d97.mp3','吃惊，惊讶','','');----
INSERT INTO classwords VALUES ('7face84257714bfba9570ced4867fecd','b3f14d29a1bc4f2fa09b651b67eb560a','141');----
INSERT INTO word VALUES ('3397203190cb4cde8fd51a260089e451','too...to','','http://res-tts.iciba.com/6/4/a/64a2e60ba8cfabb347b75b38644c7540.mp3','太……以至于不……','','');----
INSERT INTO classwords VALUES ('268fec030a6d4525907ac485b4ab3ced','3397203190cb4cde8fd51a260089e451','141');----
INSERT INTO word VALUES ('b5096d12d55e4b3e8d5359bae1219497','care for','[kɛə fɔ:]','http://res.iciba.com/resource/amp3/0/0/11/96/11961689f25c32f0dfffb0aa75e3247a.mp3','喜欢；照顾（病人）','','');----
INSERT INTO classwords VALUES ('47d0110a6d784a5fbd92f62e935da0de','b5096d12d55e4b3e8d5359bae1219497','141');----
INSERT INTO word VALUES ('88b3d1b96f884231b003c02bb04e02eb','put up','[put ʌp]','http://res.iciba.com/resource/amp3/0/0/23/cd/23cd8397e107fc963fb05fefd703a92b.mp3','挂起，举起, 贴（广告等）','','');----
INSERT INTO classwords VALUES ('a2ad0d8cec1b406e92e3443c9a95b78a','88b3d1b96f884231b003c02bb04e02eb','141');----
INSERT INTO word VALUES ('cc36dcf067b14d2591a87a13882fd9bb','hold out','[həuld aut]','http://res.iciba.com/resource/amp3/0/0/93/4f/934ff94692ff719304400953146259bb.mp3','伸出；坚持，维持','','');----
INSERT INTO classwords VALUES ('7f74503928824374b2324aad4a084ef1','cc36dcf067b14d2591a87a13882fd9bb','141');----
INSERT INTO word VALUES ('56f4ae7afa4f412ba9a28ba504b8be4e','do one''s best...','','http://res.iciba.com/resource/amp3/0/0/86/d8/86d814dba6bed684dc03b57f07fe6a10.mp3','尽最大的努力','','');----
INSERT INTO classwords VALUES ('817790463d794e6ca8a0b0ed78c36fc9','56f4ae7afa4f412ba9a28ba504b8be4e','141');----
INSERT INTO word VALUES ('2f2118f701e9420097795628a58c2f70','check in','[tʃek in]','http://res.iciba.com/resource/amp3/0/0/cf/94/cf94356230791d87b214dfe333d6a1ef.mp3','报到，登记','','');----
INSERT INTO classwords VALUES ('af1621263d134f49ad859d8bcb502c31','2f2118f701e9420097795628a58c2f70','141');----
INSERT INTO word VALUES ('8c48c3f657c14676af0c6e8cd8b04e20','as long as','[æz lɔŋ æz]','http://res.iciba.com/resource/amp3/0/0/a7/e1/a7e1918270b582b7707d5003f2fceee6.mp3','只要','','');----
INSERT INTO classwords VALUES ('0c6985790eff44e9b02c02c140352791','8c48c3f657c14676af0c6e8cd8b04e20','141');----
INSERT INTO word VALUES ('901062e6153e4e4a88d538a4791c7eb3','as soon as','[æz su:n æz]','http://res.iciba.com/resource/amp3/0/0/24/f1/24f13ed38651c85860749d97dfe308e8.mp3','一……就……','','');----
INSERT INTO classwords VALUES ('6f8705aba6ff4cc8a0d9834c755a26d4','901062e6153e4e4a88d538a4791c7eb3','141');----
INSERT INTO word VALUES ('d3545b29352b4a4586c31ae630db72d8','from now on','[frɔm nau ɔn]','http://res.iciba.com/resource/amp3/0/0/fa/ad/faad5ad56b8c73bce5eaebf02142edf5.mp3','从今以后，今后','','');----
INSERT INTO classwords VALUES ('7704345026ef44e0b64e15489eac1738','d3545b29352b4a4586c31ae630db72d8','141');----
INSERT INTO word VALUES ('29039c6c243c459bbdaa7670b4ace050','sooner or lat...','[ˈsu:nə ɔ: ˈleitə]','http://res-tts.iciba.com/a/0/c/a0c95377df42ebdde1d92e75882c9f45.mp3','迟早，早晚','','');----
INSERT INTO classwords VALUES ('524e263f53e0419eaf732a47c7f06873','29039c6c243c459bbdaa7670b4ace050','141');----
INSERT INTO word VALUES ('bea5f1d7b4f9406089d2262ef366d98e','so long as','[səʊ lɔŋ æz]','http://res.iciba.com/resource/amp3/0/0/f4/67/f467d6a633756249c727674c59bfee3c.mp3','只要','','');----
INSERT INTO classwords VALUES ('ed141b792334406ba14ed789bcab008e','bea5f1d7b4f9406089d2262ef366d98e','141');----
INSERT INTO word VALUES ('cbc1d45b15c942d28f3f8c57874c72b3','as a result','[æz ə riˈzʌlt]','http://res.iciba.com/resource/amp3/0/0/a8/af/a8af6a2a396546732e6a8f2f80ee9662.mp3','（作为）结果','','');----
INSERT INTO classwords VALUES ('d54e02c4b4ed4886be3125387cb064c8','cbc1d45b15c942d28f3f8c57874c72b3','141');----
INSERT INTO word VALUES ('1c0d9f2bd0914efbadef7dc93e8aca44','carry on','[ˈkæri ɔn]','http://res.iciba.com/resource/amp3/0/0/4a/0e/4a0e02c055688cce77335f7f2c41e58b.mp3','继续下去; 继续开展','','');----
INSERT INTO classwords VALUES ('4b163a500c0e42f89870b40228910166','1c0d9f2bd0914efbadef7dc93e8aca44','141');----
INSERT INTO word VALUES ('a8888db88de64443afa61c4f342fa21f','next to','[nekst tu:]','http://res.iciba.com/resource/amp3/0/0/c9/e2/c9e244f799835714073e72b1921a8704.mp3','紧接着，相邻，次于','','');----
INSERT INTO classwords VALUES ('4614f70fb8444c65bac98e4b7093c769','a8888db88de64443afa61c4f342fa21f','141');----
INSERT INTO word VALUES ('0264b50b559c450182bf85566bdfe985','break away fr...','[breik əˈwei frɔm]','http://res-tts.iciba.com/f/d/6/fd66575b05175e2ad2102658ebda931e.mp3','脱离……','','');----
INSERT INTO classwords VALUES ('5fdf96d8a6d749dd92c73121b68f2b4c','0264b50b559c450182bf85566bdfe985','141');----
INSERT INTO word VALUES ('d36e02642f3942868671fbcfff872dc0','break in','[breik in]','http://res.iciba.com/resource/amp3/0/0/0e/24/0e24b1d22f59c9440ea7133eed842750.mp3','闯入，强行进入，插嘴，打断','','');----
INSERT INTO classwords VALUES ('fd1dd53a608d4643b2adec5f50c3a9fa','d36e02642f3942868671fbcfff872dc0','141');----
INSERT INTO word VALUES ('5099fe82e20b4414b6a2505cf86328a9','fill ... with...','[breik in]','','用……填充','','');----
INSERT INTO classwords VALUES ('7ec3124a93ae4ee78eae100677e4fa0a','5099fe82e20b4414b6a2505cf86328a9','141');----
INSERT INTO word VALUES ('a84e859a8ecf423eb4541999803a79fb','from then on','[frɔm ðen ɔn]','http://res.iciba.com/resource/amp3/0/0/eb/9f/eb9fd3016d12557bdca4e2e199a61499.mp3','从那时起','','');----
INSERT INTO classwords VALUES ('58a728c82255423396e1ba02e330d9a8','a84e859a8ecf423eb4541999803a79fb','141');----
INSERT INTO word VALUES ('dce2dd3c38ce44418e210500b216cdc5','regard... as','[frɔm ðen ɔn]','','把……看作','','');----
INSERT INTO classwords VALUES ('019305da22db4beea650bf4f78840ce2','dce2dd3c38ce44418e210500b216cdc5','141');----
INSERT INTO word VALUES ('a9f7e96fa975434398f7db3e4c08dc6a','face to face','[feis tu: feis]','http://res.iciba.com/resource/amp3/0/0/d3/88/d388edf5afa5fd99c68be208c8595cfa.mp3','面对面','','');----
INSERT INTO classwords VALUES ('f2f7c13a5c2c485086aa850f292f32eb','a9f7e96fa975434398f7db3e4c08dc6a','141');----
INSERT INTO word VALUES ('072b3b01899c40b1a825c76781434fb4','not so...as','[feis tu: feis]','','不像，不如','','');----
INSERT INTO classwords VALUES ('805e9b6ee68b40ddb517d5159791d608','072b3b01899c40b1a825c76781434fb4','141');----
INSERT INTO word VALUES ('9c4ca5a06c2a428db31e738def83cb9e','come up with','[kʌm ʌp wið]','http://res.iciba.com/resource/amp3/0/0/b0/59/b059a9afa191519f6bf63bd3c4669fa8.mp3','追上，赶上；想出（主意）；找出（答案） ...','','');----
INSERT INTO classwords VALUES ('ac7177d75ac6433ead8526b99d33288e','9c4ca5a06c2a428db31e738def83cb9e','141');----
INSERT INTO word VALUES ('8f68cd0eb4c749c7bcc165ed62359250','put off','[put ɔf]','http://res.iciba.com/resource/amp3/0/0/44/ad/44adabc905dfefc327bc915f31262499.mp3','推迟','','');----
INSERT INTO classwords VALUES ('76e7ddb69c31482f9f5846f239700eb2','8f68cd0eb4c749c7bcc165ed62359250','141');----
INSERT INTO word VALUES ('a3cb7341ceda4c28861ea290b11ecbef','help...out','[put ɔf]','','帮助某人解决困难','','');----
INSERT INTO classwords VALUES ('559f1c5bed304254958ebf38a7c532c3','a3cb7341ceda4c28861ea290b11ecbef','141');----
INSERT INTO word VALUES ('a83ff424c3f64dfd9662c1277c8cdda2','hear from','[hiə frɔm]','http://res.iciba.com/resource/amp3/0/0/60/cb/60cb29239d2a7de5159605c75ae38c25.mp3','收到……的来信','','');----
INSERT INTO classwords VALUES ('26786e8d27aa45cba356260df7189403','a83ff424c3f64dfd9662c1277c8cdda2','141');----
INSERT INTO word VALUES ('3edd832f23bb419fbd60b16a25c49120','even though','[ˈi:vən ðəu]','http://res-tts.iciba.com/e/5/8/e5866395d694695aa637d925e97ffb5a.mp3','即使，尽管','','');----
INSERT INTO classwords VALUES ('2993dbefb33b49b4973c453824eaa046','3edd832f23bb419fbd60b16a25c49120','141');----
INSERT INTO word VALUES ('c564fcd91fa2418784731010d93cee72','by air','[bai eə(r)]','http://res.iciba.com/resource/amp3/0/0/49/a9/49a98b981d2e5dab9b9b7d4158256c01.mp3','乘飞机','','');----
INSERT INTO classwords VALUES ('70d831b4a44141cda336392a6e2a242d','c564fcd91fa2418784731010d93cee72','141');----
INSERT INTO word VALUES ('0502393c4a5e4f1881ea38944364bc61','get back','[ɡet bæk]','http://res.iciba.com/resource/amp3/0/0/84/57/84578ce6cf9960f8e409f4911fe947da.mp3','返回; 回来; 回家','','');----
INSERT INTO classwords VALUES ('1e4de571b7804045a4a6974940c7997d','0502393c4a5e4f1881ea38944364bc61','141');----
INSERT INTO word VALUES ('5185bbadc2f1446c8bdc0cddcbc42653','change into','[tʃeindʒ ˈɪntuː]','http://res.iciba.com/resource/amp3/0/0/27/05/2705ca40b2ea0e391db7131182b8cfed.mp3','转换成，把…变成','','');----
INSERT INTO classwords VALUES ('8c9b259913744e44b95e4b05cc2b1649','5185bbadc2f1446c8bdc0cddcbc42653','141');----
INSERT INTO word VALUES ('4b0d08d97751408a8e2862e37f6e44d9','due to','[dju: tu:]','http://res-tts.iciba.com/5/2/2/52240cd4b527c97395eacc1291cb9c26.mp3','由于，因为','','');----
INSERT INTO classwords VALUES ('0db050c6ac8b40d392dd08f05e0bc270','4b0d08d97751408a8e2862e37f6e44d9','141');----
INSERT INTO word VALUES ('40f56579ab8e43549f07ff2cf8d4b1a6','take the plac...','[teik ðə pleis ɔv]','http://res.iciba.com/resource/amp3/0/0/26/e6/26e6f1953748ad7993bec2742e995964.mp3','取代，代替','','');----
INSERT INTO classwords VALUES ('efcbec8304f746bca2991cb2d2bded30','40f56579ab8e43549f07ff2cf8d4b1a6','141');----
INSERT INTO word VALUES ('35a18354d20242b29978d9035ed94e90','put down','[put daun]','http://res.iciba.com/resource/amp3/0/0/e4/c5/e4c5be348abc4b35771019e2bffbccbc.mp3','记下','','');----
INSERT INTO classwords VALUES ('39d0d3fdcd4744c5aa5fd491203da5bc','35a18354d20242b29978d9035ed94e90','141');----
INSERT INTO word VALUES ('cce0cfd62cd048eea5eb671dfd67b7f6','turn up','[tə:n ʌp]','http://res.iciba.com/resource/amp3/1/0/05/52/05527875cf4aae455370251f7c802001.mp3','到达，来到；开大（声音）','','');----
INSERT INTO classwords VALUES ('f9c65ad6efab42e09e858c6bc476adb1','cce0cfd62cd048eea5eb671dfd67b7f6','141');----
INSERT INTO word VALUES ('7f805b524bac4971a57900f0f66b3f4c','go for','[ɡəu fɔ:]','http://res.iciba.com/resource/amp3/0/0/93/87/9387151f8677a651ad0d6fb40111837f.mp3','主张','','');----
INSERT INTO classwords VALUES ('9c6c14ef438b41d29940cbae951de908','7f805b524bac4971a57900f0f66b3f4c','141');----
INSERT INTO word VALUES ('ac25f05ed5ca46508decc0312230b971','in public','[in ˈpʌblik]','http://res.iciba.com/resource/amp3/0/0/09/26/0926b816624b02dc24677af90e917e90.mp3','当众；公开','','');----
INSERT INTO classwords VALUES ('f10d3c8eed1849ac92fce3df02e571f8','ac25f05ed5ca46508decc0312230b971','141');----
INSERT INTO word VALUES ('b0ef03c84ec4480d9b4f256696afb8e8','come down','[kʌm daun]','http://res.iciba.com/resource/amp3/0/0/85/6e/856eb24f8deb24806b0e0347313eba1b.mp3','落，下来','','');----
INSERT INTO classwords VALUES ('d18245271fb844ff9b29b8691604371d','b0ef03c84ec4480d9b4f256696afb8e8','141');----
INSERT INTO word VALUES ('66c520ff4f214c3eadeacf0af9a1ef79','pay back','[pei bæk]','http://res.iciba.com/resource/amp3/0/0/a1/56/a1563907f99b050a167186f34885fe6e.mp3','偿还（借款等）','','');----
INSERT INTO classwords VALUES ('791c0abc63fa43558aa5760ca87e0cc0','66c520ff4f214c3eadeacf0af9a1ef79','141');----
INSERT INTO word VALUES ('9499861b2a194db99a607e0311a89f46','more or less','[mɔ: ɔ: les]','http://res.iciba.com/resource/amp3/0/0/41/dd/41dd4bb13058a0040c57baae65050137.mp3','或多或少','','');----
INSERT INTO classwords VALUES ('e143d047e31c450c84b4e0cf67c7e5b8','9499861b2a194db99a607e0311a89f46','141');----
INSERT INTO word VALUES ('81073b3d78e741d4a80542babd8f378c','a kind of','[ə kaind ɔv]','http://res-tts.iciba.com/5/e/e/5ee16c6f899d372bb3a5d800f2a8e0c9.mp3','一种，一类','','');----
INSERT INTO classwords VALUES ('5764c7b454154a409a22c5fcb7969009','81073b3d78e741d4a80542babd8f378c','141');----
INSERT INTO word VALUES ('97ebe151565d4a7f89589896825bb4c4','pay attention...','[pei əˈtenʃən tu:]','http://res.iciba.com/resource/amp3/0/0/31/5b/315b8d3e829b92b88756600b865fabcf.mp3','注意','','');----
INSERT INTO classwords VALUES ('842a36f1c1c24571beef5b588aa6d91d','97ebe151565d4a7f89589896825bb4c4','141');----
INSERT INTO word VALUES ('16b2fd32960c406da80fe00554a317c6','different fro...','[ˈdifərənt frɔm]','http://res-tts.iciba.com/6/5/4/65439ed619063e1287aa60b756c9eaf3.mp3','与……不同','','');----
INSERT INTO classwords VALUES ('6523d45b0c32468f808ad77a69a1bebd','16b2fd32960c406da80fe00554a317c6','141');----
INSERT INTO word VALUES ('b03ae3aae144414083d3ad9115ea1342','knock at','[nɔk æt]','http://res-tts.iciba.com/c/3/b/c3bf14aa5630ab67a282cd597862c8ef.mp3','敲','','');----
INSERT INTO classwords VALUES ('8d238b8813ec4ca68fb2dba5bf8db252','b03ae3aae144414083d3ad9115ea1342','141');----
INSERT INTO word VALUES ('75de2cc1615b4d30804da71bdea22089','in order to','[in ˈɔ:də tu:]','http://res.iciba.com/resource/amp3/0/0/a3/13/a3138ab4fdbfb1e7a02598d3b004dcc3.mp3','为了','','');----
INSERT INTO classwords VALUES ('37eeafcf47df42c9a3c8fe80a9e7e5af','75de2cc1615b4d30804da71bdea22089','141');----
INSERT INTO word VALUES ('d3e5c6d5508b4cc9b83b90310b7833ef','all right','[ɔ:l rait]','http://res.iciba.com/resource/amp3/0/0/67/78/67787c5a3a7b3a7cea96d77aa1f6d338.mp3','行,好吧，（病）好了','','');----
INSERT INTO classwords VALUES ('f895afc327a14bf7af1ed60bb4d99085','d3e5c6d5508b4cc9b83b90310b7833ef','141');----
INSERT INTO word VALUES ('e67417b1c8d84ccabaa46078538c9e5c','pick up','[pik ʌp]','http://res.iciba.com/resource/amp3/0/0/e3/cf/e3cf48bb1f3593ae49166794aded6d73.mp3','拾起，捡起, 接收；开车去接……','','');----
INSERT INTO classwords VALUES ('6ff2ced593e04e0eaa16f4e2407545f7','e67417b1c8d84ccabaa46078538c9e5c','141');----
INSERT INTO word VALUES ('df868836d48d4816ad2acb3e3bdd8350','set up settle...','','','建立创立 定居，平静下来','','');----
INSERT INTO classwords VALUES ('d43b722c048545d0a18c33b357d45ad5','df868836d48d4816ad2acb3e3bdd8350','141');----
INSERT INTO word VALUES ('11ec44ef08464238a17f32847d1e0772','come out','[kʌm aut]','http://res.iciba.com/resource/amp3/0/0/3f/1b/3f1bd609c8d6081876afedfe0e952b3a.mp3','出来,(书)出版，发行','','');----
INSERT INTO classwords VALUES ('d7e07d4608944e80aed2d61716375565','11ec44ef08464238a17f32847d1e0772','141');----
INSERT INTO word VALUES ('2c299aa97a46427dbb4d39ac5f943076','a piece of','[ə pi:s ɔv]','http://res-tts.iciba.com/7/a/c/7acb053eaebfd283d43b5b1d08613e8d.mp3','一块(张，根，片)','','');----
INSERT INTO classwords VALUES ('7e08f28487874fafadeb73551f4d5199','2c299aa97a46427dbb4d39ac5f943076','141');----
INSERT INTO word VALUES ('4cad3e23d89f4d4b9765e039af1bebd3','talk of','[tɔ:k ɔv]','http://res-tts.iciba.com/0/a/a/0aaeea5185c4918f18c270f42f62fe84.mp3','谈论，议论','','');----
INSERT INTO classwords VALUES ('d0a985f78d1544aba56d6c1e694a78dd','4cad3e23d89f4d4b9765e039af1bebd3','141');----
INSERT INTO word VALUES ('c97cf27f3a74465cbf96226cbb21c0e7','divide...into...','','http://res-tts.iciba.com/f/0/b/f0bc6839bcf9dda4682bd03294b5bac7.mp3','把……分成……','','');----
INSERT INTO classwords VALUES ('2d4ab3fb721d43a4a777cbd5f5ff3310','c97cf27f3a74465cbf96226cbb21c0e7','141');----
INSERT INTO word VALUES ('f1b86b009fbb4adc9ff5e38d9544e566','agree to do s...','','','同意做某事','','');----
INSERT INTO classwords VALUES ('b8caad9e7e5644d993a62b37b2d37a1d','f1b86b009fbb4adc9ff5e38d9544e566','141');----
INSERT INTO word VALUES ('5624a75e63de47e994b35a1addb8b2e9','a pair of','[ə pɛə ɔv]','http://res-tts.iciba.com/1/a/4/1a4e0b4d7f0550f20c8551c339e84694.mp3','一双，一副','','');----
INSERT INTO classwords VALUES ('7b7d82d2d6ca4925be268d715aa72290','5624a75e63de47e994b35a1addb8b2e9','141');----
INSERT INTO word VALUES ('48b35f20c7fe46c38e71092b0413eb86','find out','[faind aut]','http://res.iciba.com/resource/amp3/0/0/5a/d2/5ad2c5b490a54c67c04e0f5b9780a35f.mp3','查明，发现，了解','','');----
INSERT INTO classwords VALUES ('084b7aa071364870b08b1337f0948b3d','48b35f20c7fe46c38e71092b0413eb86','141');----
INSERT INTO word VALUES ('acc4eaaa400c4267908a76df479a9d03','knock into sb...','','','撞上','','');----
INSERT INTO classwords VALUES ('d474eaeb3d7641adb5e32677fda17ebd','acc4eaaa400c4267908a76df479a9d03','141');----
INSERT INTO word VALUES ('3cc51600b8b649b08e9f6b4d8795851b','give in','[ɡiv in]','http://res.iciba.com/resource/amp3/0/0/50/65/506577a183061a715d54a6ce4307ad36.mp3','屈服，让步','','');----
INSERT INTO classwords VALUES ('52c7b581b0454af99cbf527f75590d26','3cc51600b8b649b08e9f6b4d8795851b','141');----
INSERT INTO word VALUES ('e2a3f96efc5b4c9c93eae212590dcd2d','by accident','[bai ˈæksidənt]','http://res.iciba.com/resource/amp3/0/0/e4/f1/e4f13d1238b751c94c365b611bc5af53.mp3','偶然','','');----
INSERT INTO classwords VALUES ('e6bf9238f69245b4896397b1e48f9d17','e2a3f96efc5b4c9c93eae212590dcd2d','141');----
INSERT INTO word VALUES ('cc08fda215c546c1aca94e2d519da5d7','bring on','[briŋ ɔn]','http://res.iciba.com/resource/amp3/0/0/41/52/4152ff948163297b0bfc9c385c8f2c1f.mp3','引起，导致，使前进','','');----
INSERT INTO classwords VALUES ('76413b5ffa474eee89af6cbacc92c581','cc08fda215c546c1aca94e2d519da5d7','141');----
INSERT INTO word VALUES ('420917629da94065b754ad65d8357d3c','have to','[ˈhæv tə]','http://res.iciba.com/resource/amp3/oxford/0/5c/7f/5c7f422788b4b656a9b487eb387d8ed0.mp3','不得不；必须','','');----
INSERT INTO classwords VALUES ('eb46f5682f1a40e6a810cea8bbf3db86','420917629da94065b754ad65d8357d3c','141');----
INSERT INTO word VALUES ('e545c5d4a1dc4a27b81733f6ab56aa6f','a few','[ə fju:]','http://res-tts.iciba.com/d/3/2/d32356ae23a439134548ebfa140807d0.mp3','一些，少量','','');----
INSERT INTO classwords VALUES ('dea68bfda4854fd2a5304dd3be8042c8','e545c5d4a1dc4a27b81733f6ab56aa6f','141');----
INSERT INTO word VALUES ('e22829d34576428fbbbc468c634788db','on time','[ɔn taim]','http://res.iciba.com/resource/amp3/0/0/f8/62/f862d2178ec3e62f06ca531fcdfb5abf.mp3','准时','','');----
INSERT INTO classwords VALUES ('d34a60a93b784924b1532ac1a429285f','e22829d34576428fbbbc468c634788db','141');----
INSERT INTO word VALUES ('4a18b3d292a54035aa48cbfb0e8d8603','go over','[ɡəu ˈəuvə]','http://res.iciba.com/resource/amp3/0/0/4d/ea/4deabe70a30da612c00f421964c15ca4.mp3','仔细检查，复习','','');----
INSERT INTO classwords VALUES ('2a6fd2d3348b4326959f97fb0a077c38','4a18b3d292a54035aa48cbfb0e8d8603','141');----
INSERT INTO word VALUES ('9f6ad77962ec4117be60229f72a58e95','keep up','[ki:p ʌp]','http://res.iciba.com/resource/amp3/0/0/ea/80/ea8021151b3ead7b373e4d21970e8c4a.mp3','保持; 维持; 继续','','');----
INSERT INTO classwords VALUES ('38ad79c661c44791990e4cc9bce11359','9f6ad77962ec4117be60229f72a58e95','141');----
INSERT INTO word VALUES ('f002d27dbe6744d7bd379c5f974a7691','a lot of','[ə lɔt ɔv]','http://res-tts.iciba.com/6/3/a/63af6f4b77006e73ac28fdfac900cb4c.mp3','许多，大量','','');----
INSERT INTO classwords VALUES ('f90b8b35312d46da998e44a1a3b729f1','f002d27dbe6744d7bd379c5f974a7691','141');----
INSERT INTO word VALUES ('6423a70ebf3b4dec9ce0627410bc4a96','prevent ... f...','[ə lɔt ɔv]','','妨碍,,防止,,预防','','');----
INSERT INTO classwords VALUES ('379027471ac04341a9dd134de758e8ed','6423a70ebf3b4dec9ce0627410bc4a96','141');----
INSERT INTO word VALUES ('4f4e11898a464e2e92150b71d808411b','add up to','[æd ʌp tu:]','http://res.iciba.com/resource/amp3/0/0/d8/72/d8721479e748ca3e2e13ac994909c339.mp3','合计达……','','');----
INSERT INTO classwords VALUES ('392713fdf0c64e16a20ba382c9296148','4f4e11898a464e2e92150b71d808411b','141');----
INSERT INTO word VALUES ('9099817247c94045b38faab80a739d4d','get through','[ɡet θru:]','http://res.iciba.com/resource/amp3/0/0/36/7a/367ac5fe6beadc1db90aac6dc9fa3f84.mp3','通过，拨通（电话）','','');----
INSERT INTO classwords VALUES ('fd5bb8b951844870a52f45c7a4582e99','9099817247c94045b38faab80a739d4d','141');----
INSERT INTO word VALUES ('e880d2cd6aec4a8d9773ea0c91b036fe','put on','[put ɔn]','http://res.iciba.com/resource/amp3/0/0/eb/d3/ebd3e097113faefd1925035941e048f0.mp3','穿，戴上，上演','','');----
INSERT INTO classwords VALUES ('349852551f1b414ebefaf2b7d5efff2f','e880d2cd6aec4a8d9773ea0c91b036fe','141');----
INSERT INTO word VALUES ('19ced9c0e3a0477c91645a26136a0f74','out of work','[aut ɔv wə:k]','http://res.iciba.com/resource/amp3/0/0/c3/c2/c3c2d8a855e45f490928e17d0e8065c6.mp3','失业','','');----
INSERT INTO classwords VALUES ('00d79f2bfb324cd0b5d365cae0bcf5bc','19ced9c0e3a0477c91645a26136a0f74','141');----
INSERT INTO word VALUES ('8c11b70069a749e48e90703dcc09abe1','such as','[sʌtʃ æz]','http://res.iciba.com/resource/amp3/0/0/0b/be/0bbe6fca13f94373a18a92d9d72eaa1e.mp3','例如','','');----
INSERT INTO classwords VALUES ('94b39b04728f4568b2c3d8f455e91848','8c11b70069a749e48e90703dcc09abe1','141');----
INSERT INTO word VALUES ('a86a314c6a6b400e83f02789919c082d','live on','[liv ɔn]','http://res.iciba.com/resource/amp3/0/0/93/24/93242002069b2adf658ee1d716b3a0a1.mp3','以…为主食，靠…为生','','');----
INSERT INTO classwords VALUES ('1a14f484042c49a2839746dffaf5c3d2','a86a314c6a6b400e83f02789919c082d','141');----
INSERT INTO word VALUES ('3b021535e266403e98d19f89c8aa230d','used to sth.','','','习惯于','','');----
INSERT INTO classwords VALUES ('eb98b3ee54184e1399baa3b1516859d0','3b021535e266403e98d19f89c8aa230d','141');----
INSERT INTO word VALUES ('9d5c656ee2564868b7b2f610b1f3a5d7','take sb. in t...','','','搂抱','','');----
INSERT INTO classwords VALUES ('ec002dcaa15947c7aa3eba22ec9a9a3f','9d5c656ee2564868b7b2f610b1f3a5d7','141');----
INSERT INTO word VALUES ('90719a28b5bf46cc8034d3a70b423862','have a gift f...','[hæv ə ɡift fɔ:]','http://res.iciba.com/resource/amp3/0/0/8c/93/8c931faaf34907e63671692a8ef1949c.mp3','对……有天赋','','');----
INSERT INTO classwords VALUES ('9f377ffacdf04549b712050d52aaa20f','90719a28b5bf46cc8034d3a70b423862','141');----
INSERT INTO word VALUES ('86a6d704dfae4e6daafe63f14fd32878','connect with','[kəˈnekt wið]','http://res.iciba.com/resource/amp3/0/0/cf/49/cf498faab75ee066b07a546cbaf34aa6.mp3','与……相连','','');----
INSERT INTO classwords VALUES ('dd79efa3b46440b397f73f4df37bd780','86a6d704dfae4e6daafe63f14fd32878','141');----
INSERT INTO word VALUES ('38ae84ee98df4a878b2cb926349e2fb8','hold up','[həuld ʌp]','http://res.iciba.com/resource/amp3/0/0/d9/29/d929c03cb73b773897e1be72d46241fa.mp3','阻挡，使停顿','','');----
INSERT INTO classwords VALUES ('956405928f9341a3945551271ead5334','38ae84ee98df4a878b2cb926349e2fb8','141');----
INSERT INTO word VALUES ('fff058e6d9c148108f2756cec1ddda5e','so...that','','http://res-tts.iciba.com/7/3/8/738a74d88fcad66a03e90cc106179e82.mp3','太……以至于……','','');----
INSERT INTO classwords VALUES ('3bd80ade99c74db6839678fdeacd4fc3','fff058e6d9c148108f2756cec1ddda5e','141');----
INSERT INTO word VALUES ('71b0de5562e447d9bbe43468cbd8f74e','run out of','[rʌn aut ɔv]','http://res.iciba.com/resource/amp3/0/0/22/de/22de1402f5c516aa56a7b4b03d967d56.mp3','用完','','');----
INSERT INTO classwords VALUES ('728a4144da8148a5aee0145ac760ea84','71b0de5562e447d9bbe43468cbd8f74e','141');----
INSERT INTO word VALUES ('947574cf72944514b98fbae54bca2de4','once again','[wʌns əˈɡen]','http://res.iciba.com/resource/amp3/0/0/d8/53/d8531b3941d19ac2fe920c503d3d3d4e.mp3','再一次','','');----
INSERT INTO classwords VALUES ('50dac0367e7643d6b0e4590d449ffafe','947574cf72944514b98fbae54bca2de4','141');----
INSERT INTO word VALUES ('243e9a9c21af43a6bd7627c9362ffbe0','over and over...','','http://res.iciba.com/resource/amp3/0/0/e0/21/e021c7e63887ff4bf77a827929fe7589.mp3','反复，多次重复','','');----
INSERT INTO classwords VALUES ('148172207b054654b4002ec57c0da0b6','243e9a9c21af43a6bd7627c9362ffbe0','141');----
INSERT INTO word VALUES ('66344bf9fe924577b9e356c454feb4fb','have classes','','','上课','','');----
INSERT INTO classwords VALUES ('c49fae919f0c49bfaf9c168b4c2c682f','66344bf9fe924577b9e356c454feb4fb','141');----
INSERT INTO word VALUES ('7ba9df52116547d38c977142f0daa9bf','point to','[pɔint tu:]','http://res.iciba.com/resource/amp3/0/0/99/a1/99a1815243a7c4d9f534c9ed7f0a1634.mp3','指向','','');----
INSERT INTO classwords VALUES ('c9514eab71b547c194828a9feb2ccc4e','7ba9df52116547d38c977142f0daa9bf','141');----
INSERT INTO word VALUES ('dcac28af1ac9458684367c8f600ce7a7','as...as','','http://res-tts.iciba.com/8/5/d/85d1b82309997b057945da1916bfdbad.mp3','像，如同','','');----
INSERT INTO classwords VALUES ('96a6bb3c7c83422189bb374a9c51cb97','dcac28af1ac9458684367c8f600ce7a7','141');----
INSERT INTO word VALUES ('d7fe044e83284191ab52fc0414380afb','do some clean...','','','做扫除（买东西）','','');----
INSERT INTO classwords VALUES ('47354cac9f804a8bb579a2f023bae1f8','d7fe044e83284191ab52fc0414380afb','141');----
INSERT INTO word VALUES ('7f6a1273d50a446fb4d0de81c5a53ffc','come off','[kʌm ɔf]','http://res.iciba.com/resource/amp3/0/0/73/de/73de03fccc931d0c805cc1f80b4da222.mp3','从…离开，脱落','','');----
INSERT INTO classwords VALUES ('b400bbe6a90546bb890772738d54ea55','7f6a1273d50a446fb4d0de81c5a53ffc','141');----
INSERT INTO word VALUES ('61263f38eb9e46d4bdd5351a9e4643df','struggle agai...','[ˈstrʌɡl əˈɡenst]','http://res-tts.iciba.com/7/8/b/78b6da010d48b46c7ad344d7a214f226.mp3','同……作斗争','','');----
INSERT INTO classwords VALUES ('7f3d56c5d6524c75837290af3049a6eb','61263f38eb9e46d4bdd5351a9e4643df','141');----
INSERT INTO word VALUES ('e8166d2a82514d0480ea58aba72a18c6','look out','[luk aut]','http://res.iciba.com/resource/amp3/0/0/fc/22/fc221f09a3353c9ff905d5cae86f4a0a.mp3','留神，当心','','');----
INSERT INTO classwords VALUES ('09ad1923abe14041b6529981beccc7c4','e8166d2a82514d0480ea58aba72a18c6','141');----
INSERT INTO word VALUES ('4fbdf8d2066f44e5bd2b355e775a3efa','call for','[kɔ:l fɔ:]','http://res.iciba.com/resource/amp3/0/0/88/bd/88bd4d0ec2ebb751d1f6b2891891aa1f.mp3','提倡，号召, 需要','','');----
INSERT INTO classwords VALUES ('cac992e4d789436c80140b311cb3691f','4fbdf8d2066f44e5bd2b355e775a3efa','141');----
INSERT INTO word VALUES ('4b895a9a45754583aed83bf85850cf29','out of breath...','[aut ɔv breθ]','http://res.iciba.com/resource/amp3/0/0/39/93/3993f0a15439f30c62fbe29ee8ab336f.mp3','上气不接下气','','');----
INSERT INTO classwords VALUES ('60980733d98d4318aab5cf3612e5b198','4b895a9a45754583aed83bf85850cf29','141');----
INSERT INTO word VALUES ('dd0d7543420544ca8d89030366a5e56c','ahead of','[əˈhed ɔv]','http://res.iciba.com/resource/amp3/0/0/97/92/9792c3e1358b1040a5152a28f54bc3eb.mp3','在……之前','','');----
INSERT INTO classwords VALUES ('0207aaa9c8a343faac6b47efe292e0c7','dd0d7543420544ca8d89030366a5e56c','141');----
INSERT INTO word VALUES ('963a8e00314d404b989a32a75d2720be','all the best','[ɔ:l ðə best]','http://res.iciba.com/resource/amp3/0/0/39/f8/39f8775a67429e4476fd9339431472dc.mp3','一切顺利，万事如意','','');----
INSERT INTO classwords VALUES ('12554b3a8c924988b40220f6e749898d','963a8e00314d404b989a32a75d2720be','141');----
INSERT INTO word VALUES ('ca6b71b99b734a14ab2cf142aa4f31a5','sell out','[sel aut]','http://res.iciba.com/resource/amp3/0/0/f7/91/f7913e55dedd60cb934feb79eadda8b6.mp3','卖完, 出卖','','');----
INSERT INTO classwords VALUES ('af65c66431554d42a5b15461e66718da','ca6b71b99b734a14ab2cf142aa4f31a5','141');----
INSERT INTO word VALUES ('d0b19a796933404da25a74acfc661432','by the way','[bai ðə wei]','http://res.iciba.com/resource/amp3/0/0/ca/d9/cad97f3383c232b08a510ea0fdf75750.mp3','顺便说','','');----
INSERT INTO classwords VALUES ('9f5fbb0e775b494c84281420230e0b7b','d0b19a796933404da25a74acfc661432','141');----
INSERT INTO word VALUES ('a604ab2dce3b4a1084e11b4f3ab41aa4','look through','[luk θru:]','http://res.iciba.com/resource/amp3/0/0/54/0f/540f7b46d806304b8c4f9cdf3ba2ac82.mp3','看穿, 浏览','','');----
INSERT INTO classwords VALUES ('ef7faf9f7fae4707bdeeeede5a025279','a604ab2dce3b4a1084e11b4f3ab41aa4','141');----
INSERT INTO word VALUES ('ea56dfd9b94144d0bdc7d39b8ee0e0cf','far from','[fɑ: frɔm]','http://res.iciba.com/resource/amp3/0/0/b9/ad/b9ad79d9bbb99dc4e851d00328bf783e.mp3','远离','','');----
INSERT INTO classwords VALUES ('c1a8352343f649848688e5a7c8d79636','ea56dfd9b94144d0bdc7d39b8ee0e0cf','141');----
INSERT INTO word VALUES ('cc0c1c787c0a45849a3fc7f7a162a167','as though','[æz ðəu]','http://res.iciba.com/resource/amp3/0/0/2f/af/2faf0cbe7df7b94dcce70a1ffa24ae58.mp3','好像，仿佛','','');----
INSERT INTO classwords VALUES ('3c2e9166af3c451aa5cdc94721db9358','cc0c1c787c0a45849a3fc7f7a162a167','141');----
INSERT INTO word VALUES ('455151fa896d4cf8af7bb4c46a8fb854','side by side','[said bai said]','http://res.iciba.com/resource/amp3/0/0/41/15/41159e627c3a65cf4a9aeba8b762e6d0.mp3','肩并肩，一起','','');----
INSERT INTO classwords VALUES ('c5da65fd7dc44e23b74d319985667781','455151fa896d4cf8af7bb4c46a8fb854','141');----
INSERT INTO word VALUES ('5a70b902f2d24b56bbc4b3f1a8840fd3','help sb. with...','','http://res-tts.iciba.com/8/f/3/8f3af8889abadb6891993031a0e760fd.mp3','帮助某人做某事','','');----
INSERT INTO classwords VALUES ('a54f67a56c7b43c0ae89adcd5590ee5e','5a70b902f2d24b56bbc4b3f1a8840fd3','141');----
INSERT INTO word VALUES ('edde2020d8274bc38dd9059cbf11d4f4','far away','[fɑ: əˈwei]','http://res.iciba.com/resource/amp3/0/0/65/f2/65f2aa14acc55b118fd0bc08cc1b7459.mp3','遥远的','','');----
INSERT INTO classwords VALUES ('8181ad9c5f2a4179be48069a521009cd','edde2020d8274bc38dd9059cbf11d4f4','141');----
INSERT INTO word VALUES ('85526bc4525649dbaeaf2ab36dc0423c','point out','[pɔint aut]','http://res.iciba.com/resource/amp3/0/0/5a/24/5a241a357f672a0a8728d94e25b67d96.mp3','指出','','');----
INSERT INTO classwords VALUES ('a3e5947ad64544c699ab814147e4248a','85526bc4525649dbaeaf2ab36dc0423c','141');----
INSERT INTO word VALUES ('37836c0197c64e7e93aaf76652e8550f','go off','[ɡəu ɔf]','http://res.iciba.com/resource/amp3/0/0/ac/71/ac7111fb2708b55432a8f06f79ee38c2.mp3','走开','','');----
INSERT INTO classwords VALUES ('e1c8f78d7e9b4709b30119f44399c807','37836c0197c64e7e93aaf76652e8550f','141');----
INSERT INTO word VALUES ('ba78aacc059142c4992d10862bde6b4c','take place','[teik pleis]','http://res.iciba.com/resource/amp3/0/0/a4/08/a408ac81cfbc1ed758a18b36a3e725e6.mp3','发生','','');----
INSERT INTO classwords VALUES ('4fbe14ea02f844c2ba0aac76bc38c1b1','ba78aacc059142c4992d10862bde6b4c','141');----
INSERT INTO word VALUES ('a1fc6fa24eb14ab3a3e9f87f5008a025','wake up','[weik ʌp]','http://res.iciba.com/resource/amp3/1/0/4e/60/4e604e908ec2a7de01330cccef6aebf1.mp3','醒来','','');----
INSERT INTO classwords VALUES ('6d191144dd2b4c1a89bc11312dcc7f62','a1fc6fa24eb14ab3a3e9f87f5008a025','141');----
INSERT INTO word VALUES ('06e8c1a892c742218bab45e361b50aad','set off','[set ɔf]','http://res.iciba.com/resource/amp3/0/0/fa/3d/fa3d30cea53d70ad4a1445c2b2dfc4dd.mp3','动身，起程；使爆发','','');----
INSERT INTO classwords VALUES ('baeb27e57325433ba4131317eb63a803','06e8c1a892c742218bab45e361b50aad','141');----
INSERT INTO word VALUES ('b9327a3d0ace4054af140062d65f0e46','cut down','[kʌt daun]','http://res.iciba.com/resource/amp3/1/0/18/22/1822414142adf64fe1cec4969b8bf7d2.mp3','砍倒','','');----
INSERT INTO classwords VALUES ('cd782652bf3c41fa9238b5316d79f8f3','b9327a3d0ace4054af140062d65f0e46','141');----
INSERT INTO word VALUES ('0385d2a96c934a0a9994e7d43bdd47c8','give away','[ɡiv əˈwei]','http://res.iciba.com/resource/amp3/0/0/34/fe/34fe2733c679d1bf71aafe2d028109e3.mp3','分发','','');----
INSERT INTO classwords VALUES ('1d227f2fe5bc4266b2883b8375024d9b','0385d2a96c934a0a9994e7d43bdd47c8','141');----
INSERT INTO word VALUES ('f2ef31a58d48425e9c1d291e8df25353','lots of','','http://res-tts.iciba.com/f/2/3/f23ab6c89fc92b69431c6e0bd83449b8.mp3','许多，大量','','');----
INSERT INTO classwords VALUES ('a6e34132b2094bdd8c2ddf515dc8bb0c','f2ef31a58d48425e9c1d291e8df25353','141');----
INSERT INTO word VALUES ('29d9b157e4da4b7385e28739ea7d4448','ever since','[ˈevə sins]','http://res-tts.iciba.com/7/6/4/7646a57320ea0fc383cce850644da8fd.mp3','自那时起直到现在','','');----
INSERT INTO classwords VALUES ('11611a9ba42d40938b78e0a638c28c68','29d9b157e4da4b7385e28739ea7d4448','141');----
INSERT INTO word VALUES ('aecc7abcbe9d4dd2a3a9fdc90e16aad4','break out','[breik aut]','http://res.iciba.com/resource/amp3/0/0/48/f0/48f03593b0812e6c3d5f20e2d45b9af9.mp3','（战争、火灾等）突然发生，爆发','','');----
INSERT INTO classwords VALUES ('9dca505045e44389be89ca6cef9aaff6','aecc7abcbe9d4dd2a3a9fdc90e16aad4','141');----
INSERT INTO word VALUES ('e7f529268b87404ba1eb0ae31ccfa8da','a bit (of)','[breik aut]','','有一点，一会儿','','');----
INSERT INTO classwords VALUES ('44d1bce08dd14a21b2947088a910958f','e7f529268b87404ba1eb0ae31ccfa8da','141');----
INSERT INTO word VALUES ('22d562f0fac64c3ba1f2d4c896a71827','no doubt','','http://res.iciba.com/resource/amp3/0/0/7d/c8/7dc82bcd2b458b0a9fca5528c6672d60.mp3','无疑地','','');----
INSERT INTO classwords VALUES ('7f46a0c40af440a2b95a09c7888bb8f1','22d562f0fac64c3ba1f2d4c896a71827','141');----
INSERT INTO word VALUES ('5ebf97db52194088b61afda76e98b2a4','throw away','[θrəu əˈwei]','http://res.iciba.com/resource/amp3/1/0/47/07/4707cd69d39a4acad59aef79a15775ae.mp3','扔掉','','');----
INSERT INTO classwords VALUES ('9e2cae8eb50e444587c84ec596d71593','5ebf97db52194088b61afda76e98b2a4','141');----
INSERT INTO word VALUES ('bab0cb6f01804a70830eb982a187cd02','have got to','[hæv gɔt tu:]','http://res-tts.iciba.com/1/b/0/1b0b026d163c8a18e889e73fbdeac5ff.mp3','不得不；必须','','');----
INSERT INTO classwords VALUES ('8c0056f59333432a8f953cbad05f62ee','bab0cb6f01804a70830eb982a187cd02','141');----
INSERT INTO word VALUES ('e3ff6fc307004c9e92abdbb0d6e754b4','either...or','','http://res-tts.iciba.com/3/7/8/378fb3e0b8de2103b19be40aaca6c218.mp3','或者……或者……','','');----
INSERT INTO classwords VALUES ('6f867eb6eb384a8c967129f9afe8c476','e3ff6fc307004c9e92abdbb0d6e754b4','141');----
INSERT INTO word VALUES ('d96457ed599049e5a53506f904dbb2a0','give out','[ɡiv aut]','http://res.iciba.com/resource/amp3/0/0/2d/6e/2d6ea4238eebbb080e08da91499301cc.mp3','分发','','');----
INSERT INTO classwords VALUES ('ca0cdfc937a341818b842816458e2d71','d96457ed599049e5a53506f904dbb2a0','141');----
INSERT INTO word VALUES ('7e02e4d871834741b8b4f3683155f1c7','the day befor...','','http://res.iciba.com/resource/amp3/0/0/86/62/8662dbb265603f8b9efaf78b93b1d088.mp3','前天','','');----
INSERT INTO classwords VALUES ('d47776823cf74b93b84350bf76c18755','7e02e4d871834741b8b4f3683155f1c7','141');----
INSERT INTO word VALUES ('a2c1d2ea7984461eb9f6c788571a9973','not until','[nɔt ənˈtil]','http://res-tts.iciba.com/0/b/6/0b6acf926ae27ff3ab89575078d90700.mp3','直到……才','','');----
INSERT INTO classwords VALUES ('9f960b9af1f04fa196beb64894f8b161','a2c1d2ea7984461eb9f6c788571a9973','141');----
INSERT INTO word VALUES ('f05ec6164461404087c149e6f29ec3b3','make up','[meik ʌp]','http://res.iciba.com/resource/amp3/0/0/2e/9d/2e9d335be8c5d384ed7b6df0a31c9696.mp3','和解，化装','','');----
INSERT INTO classwords VALUES ('6891fe0b0e1b41dcb7087220cc174d14','f05ec6164461404087c149e6f29ec3b3','141');----
INSERT INTO word VALUES ('c6569ecbf6c840688fe38812d8e2e4f4','belong to','[biˈlɔŋ tu:]','http://res.iciba.com/resource/amp3/0/0/6d/e6/6de67cdcae9555b3e7908d4bd29290bd.mp3','属于','','');----
INSERT INTO classwords VALUES ('5271a7ae7bde42959e4028cb8dc39e99','c6569ecbf6c840688fe38812d8e2e4f4','141');----
INSERT INTO word VALUES ('61e096fb6ff64cb89ce5f195d3d47104','hang on','[hæŋ ɔn]','http://res.iciba.com/resource/amp3/0/0/20/df/20df2fb162ce67d279eb0ecef66ae6a3.mp3','（打电话时）不挂断，等待片刻','','');----
INSERT INTO classwords VALUES ('df246e457d4a47f2afb0016f82512312','61e096fb6ff64cb89ce5f195d3d47104','141');----
INSERT INTO word VALUES ('32efd0759367459b932bf0f541d15ac5','of course','[ɔv kɔː(r)s]','http://res.iciba.com/resource/amp3/0/0/0c/a9/0ca964bb74251fce6bb741c97e1cb4b8.mp3','当然','','');----
INSERT INTO classwords VALUES ('78ed7948d53b4097aa9bf647c056209f','32efd0759367459b932bf0f541d15ac5','141');----
INSERT INTO word VALUES ('954b58ff958e43b7acf41081d94d3e50','catch up with...','[kætʃ ʌp wið]','http://res.iciba.com/resource/amp3/0/0/ae/6d/ae6d4336f407e7c76e9884e62e3b60bf.mp3','赶上（或超过）','','');----
INSERT INTO classwords VALUES ('28ff5a03f80945f4a93b1dafba7a8bdf','954b58ff958e43b7acf41081d94d3e50','141');----
INSERT INTO word VALUES ('202fa095ee2f4a0b9c3b59b0cf51d28a','set free','[set fri:]','http://res.iciba.com/resource/amp3/0/0/68/f1/68f16fcf7b18ef04b552377b0abb4f9b.mp3','释放，解放','','');----
INSERT INTO classwords VALUES ('06a118071bab46f3a0a23d4f70d130cd','202fa095ee2f4a0b9c3b59b0cf51d28a','141');----
INSERT INTO word VALUES ('db47f4e9c665456285814534a4e19e6d','answer for','[ˈɑ:nsə fɔ:]','http://res.iciba.com/resource/amp3/0/0/44/43/444320f7d80371a413041df96e96d0c5.mp3','对……负责','','');----
INSERT INTO classwords VALUES ('72527af4639540c3b6be66110c3e8934','db47f4e9c665456285814534a4e19e6d','141');----
INSERT INTO word VALUES ('9e35281cf31a4415bf656fb3e8f634c5','put on weight...','[put ɔn weit]','http://res.iciba.com/resource/amp3/0/0/36/93/3693047ecfef9960be2bcb7c14abb8c6.mp3','发福，增加体重','','');----
INSERT INTO classwords VALUES ('f4b4f7bb6c724e2c8a1094f8176bc15d','9e35281cf31a4415bf656fb3e8f634c5','141');----
INSERT INTO word VALUES ('910d04a7fe02417fa47415630267c4cb','look up','[luk ʌp]','http://res.iciba.com/resource/amp3/0/0/b1/d2/b1d2bfafc04edf0032e087d532e03f40.mp3','查找','','');----
INSERT INTO classwords VALUES ('2d3500b9931d4120b5ff84732f82dd80','910d04a7fe02417fa47415630267c4cb','141');----
INSERT INTO word VALUES ('16f1ccb804af4013a60242ce1cb5a66f','keep off','[ki:p ɔf]','http://res.iciba.com/resource/amp3/0/0/a4/ad/a4ad8f6ddb62584ef754a2a23d29918c.mp3','勿踏; 勿踩','','');----
INSERT INTO classwords VALUES ('5dadaec761a34030b536d186eed4a180','16f1ccb804af4013a60242ce1cb5a66f','141');----
INSERT INTO word VALUES ('59aa4b5cb05840779f29e31e531cdde5','fall ill','[fɔ:l il]','http://res.iciba.com/resource/amp3/0/0/8b/b2/8bb22ec4d0ba3acde4c6123236507a76.mp3','患病，病倒','','');----
INSERT INTO classwords VALUES ('5ffd0d689ba84ac0a14e74041bef404e','59aa4b5cb05840779f29e31e531cdde5','141');----
INSERT INTO word VALUES ('ca01adfa0b674fb680320a357b018c22','as a matter o...','[æz ə ˈmætə ɔv fækt]','http://res.iciba.com/resource/amp3/0/0/e0/8e/e08e1c5605b12e9b0b6b771930742ab6.mp3','事实上，其实','','');----
INSERT INTO classwords VALUES ('b5a6f8f2cfac4e3b86ef9a3d3558e893','ca01adfa0b674fb680320a357b018c22','141');----
INSERT INTO word VALUES ('7ca316294bff4531bdb62879807c252c','call up','[kɔ:l ʌp]','http://res.iciba.com/resource/amp3/0/0/ff/cb/ffcb47b23fb50d501b74f1dd808c0571.mp3','号召，打电话','','');----
INSERT INTO classwords VALUES ('ea67cf3c794949c89b5939dbbc5972f5','7ca316294bff4531bdb62879807c252c','141');----
INSERT INTO word VALUES ('19e5f3ea5ca4464882302444c830d769','come true','[kʌm truː]','http://res.iciba.com/resource/amp3/0/0/e2/c0/e2c0016a803ace116df92b858854159f.mp3','变为现实，成为事实','','');----
INSERT INTO classwords VALUES ('89d71dfc8e49484b83d8cfbbcd3b747a','19e5f3ea5ca4464882302444c830d769','141');----
INSERT INTO word VALUES ('544cc27557434a7a9d0b8b7ad828a9e7','ring back','[riŋ bæk]','http://res.iciba.com/resource/amp3/0/0/ff/c3/ffc351e2a96c7c7fb17cc6f06c064af5.mp3','回电话','','');----
INSERT INTO classwords VALUES ('73b382d978c343278278c084ce1456ad','544cc27557434a7a9d0b8b7ad828a9e7','141');----
INSERT INTO word VALUES ('b6c84b6dca2f4cdeb1a80e9ddc19b6da','pay off','[pei ɔf]','http://res.iciba.com/resource/amp3/0/0/dd/1c/dd1c1db317165e5c585d7dbd318c3536.mp3','偿清(欠款等)','','');----
INSERT INTO classwords VALUES ('35df7679f9264c03809f4980643cb635','b6c84b6dca2f4cdeb1a80e9ddc19b6da','141');----
INSERT INTO word VALUES ('a44a874e269141af9cc491b84521565b','turn off','[tə:n ɔf]','http://res.iciba.com/resource/amp3/1/0/54/6f/546fa8c1eeaa45d4f018b8f53d64bb10.mp3','关掉（水、电、电视、收音机等）','','');----
INSERT INTO classwords VALUES ('666fc680f57f463fa24cd15a87d7772d','a44a874e269141af9cc491b84521565b','141');----
INSERT INTO word VALUES ('e43cf477cda0487aa798febb264c21fb','neither...nor...','','http://res-tts.iciba.com/c/4/7/c4714351d0944a6d311802ff78c52582.mp3','既不……也不……','','');----
INSERT INTO classwords VALUES ('533c63550fa14e498c9b91891306a050','e43cf477cda0487aa798febb264c21fb','141');----
INSERT INTO word VALUES ('d3a68342459842ee816a49833a885d8a','put out','[put aut]','http://res.iciba.com/resource/amp3/0/0/58/82/5882efa990a1c83ed0037a4fe3d54fd4.mp3','扑灭，关熄','','');----
INSERT INTO classwords VALUES ('ee94fb75bdc2486ea45fde1cb80670a0','d3a68342459842ee816a49833a885d8a','141');----
INSERT INTO word VALUES ('bff0135a50344c289da6605dcb9df755','enjoy oneself...','[inˈdʒɔi wʌnˈself]','http://res-tts.iciba.com/d/f/8/df8495bd1a9c3145c280348844de74b2.mp3','过得愉快','','');----
INSERT INTO classwords VALUES ('7d395c65e2534d81a392e7307365e390','bff0135a50344c289da6605dcb9df755','141');----
INSERT INTO word VALUES ('fd32caa79a2b467e9f866203293eca0b','over the radi...','[inˈdʒɔi wʌnˈself]','','通过收音机','','');----
INSERT INTO classwords VALUES ('a9e2105584024ae3a89fd5c579f12036','fd32caa79a2b467e9f866203293eca0b','141');----
INSERT INTO word VALUES ('b799176ee3f74e6ea5d5391a9bef6238','so as to','[səʊ æz tu:]','http://res.iciba.com/resource/amp3/0/0/db/2f/db2f8c1913705fe4f9287f4d953742cd.mp3','以便，为的是','','');----
INSERT INTO classwords VALUES ('6b9113417c4e46df91ed788d67bb6db1','b799176ee3f74e6ea5d5391a9bef6238','141');----
INSERT INTO word VALUES ('e10718f8d06542908434d85d50fedfed','pick out','[pik aut]','http://res.iciba.com/resource/amp3/0/0/3f/86/3f863d9c2a8a55a8b695ac80f4a28f80.mp3','选出','','');----
INSERT INTO classwords VALUES ('b9595eb5a3dc4f8d8f904490b32859a9','e10718f8d06542908434d85d50fedfed','141');----
INSERT INTO word VALUES ('167145b22d7b4e78b6d4bb36338cfc34','first of all','[fə:st ɔv ɔ:l]','http://res.iciba.com/resource/amp3/0/0/e3/e2/e3e26e5b7350bb89a4449424dbcead7f.mp3','首先','','');----
INSERT INTO classwords VALUES ('5559efe18b02496baa9922cb0db830a5','167145b22d7b4e78b6d4bb36338cfc34','141');----
INSERT INTO word VALUES ('280943e291be44adb8ade3436224fc05','up and down','[ʌp ænd daun]','http://res-tts.iciba.com/1/b/7/1b75533ed5a869ff6f3ae0336d0c3320.mp3','上下，来回','','');----
INSERT INTO classwords VALUES ('fcdf2d4845244f39ba902840d06bd23b','280943e291be44adb8ade3436224fc05','141');----
INSERT INTO word VALUES ('c3071ac0531642d9b904928e8cc75728','not any more','[nɔt ˈeni mɔ:]','http://res.iciba.com/resource/amp3/0/0/da/5f/da5f5e7f141e89b7d040d01495996af8.mp3','不再','','');----
INSERT INTO classwords VALUES ('e347377cd8e94e08ac035c4ffd0f51cc','c3071ac0531642d9b904928e8cc75728','141');----
INSERT INTO word VALUES ('86337bb02dab4d968241f5f00264cfb6','used to do st...','[nɔt ˈeni mɔ:]','','过去常常','','');----
INSERT INTO classwords VALUES ('2cb6f41269b94a11852a6670863d8ecb','86337bb02dab4d968241f5f00264cfb6','141');----
INSERT INTO word VALUES ('6b2f67e008a148688e28b7e53decc60d','had better (d...','[nɔt ˈeni mɔ:]','','最好（做）','','');----
INSERT INTO classwords VALUES ('b8d87cf6f35849c298a2f65d9385630d','6b2f67e008a148688e28b7e53decc60d','141');----
INSERT INTO word VALUES ('f4bcd13867454c059a9579cb5507f05b','look after','[luk ˈɑ:ftə]','http://res.iciba.com/resource/amp3/0/0/50/d5/50d5b9b739ca88d298d2badd660d3f45.mp3','照顾','','');----
INSERT INTO classwords VALUES ('a856b407edb143ae8a6866ef7f6e3728','f4bcd13867454c059a9579cb5507f05b','141');----
INSERT INTO word VALUES ('8d14a5a64ae84533a3e4dc713f621f6e','scores of','[skɔ:z ɔv]','http://res-tts.iciba.com/7/9/0/79097afe4c108b3ae8225ed54ed8856c.mp3','许多，大量','','');----
INSERT INTO classwords VALUES ('85310584c0814d5bb766e9e6a6090828','8d14a5a64ae84533a3e4dc713f621f6e','141');----
INSERT INTO word VALUES ('6465f2fb952343c292b0dd4c51819d71','cut up','[kʌt ʌp]','http://res.iciba.com/resource/amp3/1/0/b7/0b/b70bc6b2750b9076a03645246696d286.mp3','齐根割掉，切碎','','');----
INSERT INTO classwords VALUES ('7da75581223642edb21dd02b11b12b58','6465f2fb952343c292b0dd4c51819d71','141');----
INSERT INTO word VALUES ('5761b05daca04066ae2f40ba614316d2','separate...fr...','','http://res-tts.iciba.com/d/b/0/db0f3a90557b5a63bc31a9a5a77f8f64.mp3','分开','','');----
INSERT INTO classwords VALUES ('4733aed9b41047bbaf1240685892786d','5761b05daca04066ae2f40ba614316d2','141');----
INSERT INTO word VALUES ('287cb2b0c11943719a84ecf89420abed','ring off','[riŋ ɔf]','http://res.iciba.com/resource/amp3/0/0/18/9f/189f83252e11d0a4e9787f09bcb31374.mp3','挂断电话，停止讲话','','');----
INSERT INTO classwords VALUES ('68dc8a38ba1a44f48e441b0a4ebd9bfe','287cb2b0c11943719a84ecf89420abed','141');----
INSERT INTO word VALUES ('a0612c82929f42cea1df9d281112cf3e','look forward ...','[luk ˈfɔ:wəd tu:]','http://res.iciba.com/resource/amp3/0/0/7e/64/7e640ae8ee37aa9b36d9f697834edd48.mp3','盼望','','');----
INSERT INTO classwords VALUES ('29c0854311e146829d0e5f17361e671b','a0612c82929f42cea1df9d281112cf3e','141');----
INSERT INTO word VALUES ('48b93fd423304df08d88886800ce38e3','now that','[nau ðæt]','http://res.iciba.com/resource/amp3/0/0/e7/d4/e7d4d861dd506fa668f62035468743dc.mp3','既然','','');----
INSERT INTO classwords VALUES ('8fc9e308ac634628ab0fd5a1ec9baed7','48b93fd423304df08d88886800ce38e3','141');----
INSERT INTO word VALUES ('9e85785a20694a1a99eec25d3d79bfee','congratulate....','[nau ðæt]','','祝贺……','','');----
INSERT INTO classwords VALUES ('24fd05e2ba19455aa8de6253b02efcdc','9e85785a20694a1a99eec25d3d79bfee','141');----
INSERT INTO word VALUES ('e94b2a07751846b7901c7c363c90f0ae','as far as','[æz fɑ: æz]','http://res.iciba.com/resource/amp3/0/0/26/45/2645890eaf982b0dc222673fc86d8ef3.mp3','（表示程度，范围）就……；尽……','','');----
INSERT INTO classwords VALUES ('72fdd88f75be45358958e19784ae1561','e94b2a07751846b7901c7c363c90f0ae','141');----
INSERT INTO word VALUES ('8303d7f7339544c79775e54f9be8007a','for ever','[fɔ: ˈevə]','http://res.iciba.com/resource/amp3/0/0/ce/e2/cee2bad6bc2cc0fa3ae882677315fcba.mp3','永远','','');----
INSERT INTO classwords VALUES ('48c537b790d84346af100fe06a40933c','8303d7f7339544c79775e54f9be8007a','141');----
INSERT INTO word VALUES ('e43db11f49054b3bbebdcb2b9eeff814','in common','[in ˈkɔmən]','http://res.iciba.com/resource/amp3/0/0/2d/44/2d44f214137994bdec8e8fa142f78ff2.mp3','共同，共有','','');----
INSERT INTO classwords VALUES ('41f0e198dd9d47aa8c96b29a81511d65','e43db11f49054b3bbebdcb2b9eeff814','141');----
INSERT INTO word VALUES ('14da937e1b0c4fdeab1e152cac6d18d2','look ahead','[luk əˈhed]','http://res.iciba.com/resource/amp3/0/0/13/22/1322749cc7376eb4fbad645af54c0a1a.mp3','向前看，展望未来','','');----
INSERT INTO classwords VALUES ('3ba0f62151a54c26a6182f50f4ee51f7','14da937e1b0c4fdeab1e152cac6d18d2','141');----
INSERT INTO word VALUES ('430b6a0dae7d4a2b995fd716a9f6bca2','have a cold','[hæv ə kəuld]','http://res.iciba.com/resource/amp3/0/0/f1/bd/f1bdc43e23d9671e610e5f5676c73f1a.mp3','患感冒','','');----
INSERT INTO classwords VALUES ('662fdea942e74b79bf4abd09bbccfa05','430b6a0dae7d4a2b995fd716a9f6bca2','141');----
INSERT INTO word VALUES ('120fc1e7f4dd443d881b7cdc1e76b537','as well','[æz wel]','http://res-tts.iciba.com/a/b/2/ab256241aac70f922e45e2936a5a4770.mp3','也，还有','','');----
INSERT INTO classwords VALUES ('ec5b8faa5697474b9675e41980add9b5','120fc1e7f4dd443d881b7cdc1e76b537','141');----
INSERT INTO word VALUES ('39b6123696144b51a7e8c0c0b69e6370','break down','[breik daun]','http://res.iciba.com/resource/amp3/0/0/a1/7a/a17ab636cff45318af41533e570a1396.mp3','损坏; (把化合物等) 分解，（汽车）抛...','','');----
INSERT INTO classwords VALUES ('d48a574baeb44413930857149e844356','39b6123696144b51a7e8c0c0b69e6370','141');----
INSERT INTO word VALUES ('c605726d8a734ea294427d00cf9dbc03','drop in','[drɔp in]','http://res.iciba.com/resource/amp3/1/0/83/d7/83d776cb280d1dafb6a624b0c776190b.mp3','顺便走访（某人）','','');----
INSERT INTO classwords VALUES ('0d6c1c5a97cd4bf69110b6680c7491a4','c605726d8a734ea294427d00cf9dbc03','141');----
INSERT INTO word VALUES ('8902944eaccc4054a80643b73028ed1e','hear of','[hiə ɔv]','http://res.iciba.com/resource/amp3/0/0/5a/18/5a18dca446a07defdc8fcae673400e5c.mp3','听说，知道','','');----
INSERT INTO classwords VALUES ('b14d2a38d81344c99e34c54413129c3d','8902944eaccc4054a80643b73028ed1e','141');----
INSERT INTO word VALUES ('ba7c7db764f4459ab715d3152847ba84','call on','[kɔ:l ɔn]','http://res.iciba.com/resource/amp3/0/0/f6/a7/f6a7b7e2a8e576a926855b7e45007c70.mp3','拜访，访问','','');----
INSERT INTO classwords VALUES ('939b2f7e4a1e47be86f3add7fb2ccfe0','ba7c7db764f4459ab715d3152847ba84','141');----
INSERT INTO word VALUES ('d38311243d1d48d78b6e845056354be7','tick to','[kɔ:l ɔn]','','坚持','','');----
INSERT INTO classwords VALUES ('93fe380b54f84ec8afbb6e96565ad86c','d38311243d1d48d78b6e845056354be7','141');----
INSERT INTO word VALUES ('c18228168e264ed08a01f2d4d9f3263e','get close (to...','[kɔ:l ɔn]','','接近','','');----
INSERT INTO classwords VALUES ('ea5ee9d8e3c54231ab0f03853d81b0a3','c18228168e264ed08a01f2d4d9f3263e','141');----
INSERT INTO word VALUES ('34ef75215d0a4db898cfedfeea46d6de','speed up','[spi:d ʌp]','http://res.iciba.com/resource/amp3/0/0/e1/59/e15919e9f3dda8070015df3a70e233ea.mp3','加快速度','','');----
INSERT INTO classwords VALUES ('7eb1549988424b6ebb17461f611446c9','34ef75215d0a4db898cfedfeea46d6de','141');----
INSERT INTO word VALUES ('9bcfedbb732a481288e93e77c46c332c','get away','[ɡet əˈwei]','http://res.iciba.com/resource/amp3/0/0/a0/9f/a09fd686300157ba8e45e2fb4c6429d3.mp3','逃; 离','','');----
INSERT INTO classwords VALUES ('eba8d09ad8d14295a394f5757f378c74','9bcfedbb732a481288e93e77c46c332c','141');----
INSERT INTO word VALUES ('875e9eac585a460687a6e59a28c628f8','go on with','[ɡəu ɔn wið]','http://res-tts.iciba.com/8/0/2/802c1bd0bdeb94b2e25c7885785a394d.mp3','继续','','');----
INSERT INTO classwords VALUES ('b3a9a82747e449a5b654b783a2365083','875e9eac585a460687a6e59a28c628f8','141');----
INSERT INTO word VALUES ('ccb859243296442a953af9c84b0b5d41','go away','[ɡəu əˈwei]','http://res.iciba.com/resource/amp3/0/0/15/8e/158ee90f12f717dcbf3ad71e0f41cdb3.mp3','走开，离去','','');----
INSERT INTO classwords VALUES ('1bd6b5ffc6cc4d0abafe9c749a84db50','ccb859243296442a953af9c84b0b5d41','141');----
INSERT INTO word VALUES ('2dc07edf60884965bb2811d76d9b553b','all over','[ɔ:l ˈəuvə]','http://res.iciba.com/resource/amp3/0/0/28/42/2842c2a9ef530c2fe7633572c62043d9.mp3','到处，遍及，结束','','');----
INSERT INTO classwords VALUES ('97d6a753ce2943f089c130542ff99fce','2dc07edf60884965bb2811d76d9b553b','141');----
INSERT INTO word VALUES ('a397323240784635900e069359d4f102','as well as','[æz wel æz]','http://res.iciba.com/resource/amp3/0/0/75/6f/756fc496c55892dc274ded063136d1c3.mp3','除……之外（也）','','');----
INSERT INTO classwords VALUES ('37f3b48d565749a3b3e352c0077c8cc0','a397323240784635900e069359d4f102','141');----
INSERT INTO word VALUES ('4962c9d8b74f4180bcd24f152030d590','right away','[rait əˈwei]','http://res.iciba.com/resource/amp3/0/0/51/13/511375d0e0766e9e8743def6a16df949.mp3','立即，马上','','');----
INSERT INTO classwords VALUES ('f63363fa16384a53b4bf446cc47b803e','4962c9d8b74f4180bcd24f152030d590','141');----
INSERT INTO word VALUES ('1768ce022b1d4886b87622488d7aa1aa','take one''s ti...','[teik wʌnz taim]','http://res.iciba.com/resource/amp3/0/0/c6/73/c67339faf2eb58430158d29c3c0b2305.mp3','从容，慢慢行动','','');----
INSERT INTO classwords VALUES ('991c85fb43ff45b79d70549263de1846','1768ce022b1d4886b87622488d7aa1aa','141');----
INSERT INTO word VALUES ('16e47b185aa7422dbd76811e103b678d','apart from','[əˈpɑ:t frɔm]','http://res.iciba.com/resource/amp3/0/0/e6/c4/e6c46c7575220104419485f01e0e7ce0.mp3','除去，除了','','');----
INSERT INTO classwords VALUES ('465e134c057341a3a55b2739f9ecdf93','16e47b185aa7422dbd76811e103b678d','141');----
INSERT INTO word VALUES ('31d3de701f4a436f8aa53f6a8e2eca25','join in','[dʒɔin in]','http://res.iciba.com/resource/amp3/0/0/4d/1d/4d1d8ce3255d178b543d1edc8c8c3bcd.mp3','参加，加入','','');----
INSERT INTO classwords VALUES ('4cd3d98baa054232914a98d78fa94b39','31d3de701f4a436f8aa53f6a8e2eca25','141');----
INSERT INTO word VALUES ('00a0cf209bb2486cba1b9a058269b22a','come to','[kʌm tu:]','http://res.iciba.com/resource/amp3/0/0/1f/6b/1f6ba5325095ab494dfad9c1897cf8cd.mp3','共计，达到','','');----
INSERT INTO classwords VALUES ('12ea460c0f884a09aba624439a0fa033','00a0cf209bb2486cba1b9a058269b22a','141');----
INSERT INTO word VALUES ('9e9d4bee27bf4b119130363fe63551fe','once upon a t...','[wʌns əˈpɔn ə taim]','http://res.iciba.com/resource/amp3/0/0/ea/36/ea36fcd25d96821e1455adec6e5d9a3a.mp3','从前，很久以前','','');----
INSERT INTO classwords VALUES ('de9f4d96111c4b5bbeb6dcf498aac314','9e9d4bee27bf4b119130363fe63551fe','141');----
INSERT INTO word VALUES ('d3f2f33fde314205b9bf406919dfbaf0','above all','[əˈbʌv ɔ:l]','http://res.iciba.com/resource/amp3/0/0/17/f9/17f96e133412f7b2ce96939665006e8f.mp3','首先，首要','','');----
INSERT INTO classwords VALUES ('719239c01d73435ebebed55311ac8b85','d3f2f33fde314205b9bf406919dfbaf0','141');----
INSERT INTO word VALUES ('afb977679a194f29847030f52f08d9f7','instead of','[inˈsted ɔv]','http://res.iciba.com/resource/amp3/0/0/7b/b6/7bb63c7de5a5ee79356083a12f21e1e8.mp3','代替，而不是','','');----
INSERT INTO classwords VALUES ('35663bc5581a4e95b1b2f7954621a7ca','afb977679a194f29847030f52f08d9f7','141');----
INSERT INTO word VALUES ('cb12698a24db47a696fc9f0506343832','carry out','[ˈkæri aut]','http://res.iciba.com/resource/amp3/0/0/a8/f3/a8f3fbc8209b6608d2cb431ab23f5c34.mp3','开展，执行','','');----
INSERT INTO classwords VALUES ('35fa7e40d2134e538a139c7fbc090c38','cb12698a24db47a696fc9f0506343832','141');----
INSERT INTO word VALUES ('4b09f84cad5a49469ceeff2201bda3c7','look into','[luk ˈɪntuː]','http://res.iciba.com/resource/amp3/0/0/ca/5e/ca5e430b5c386a10fa1555654bca4711.mp3','向…里面看去; 调查','','');----
INSERT INTO classwords VALUES ('7752205c473a42b29c262d6242701af3','4b09f84cad5a49469ceeff2201bda3c7','141');----
INSERT INTO word VALUES ('43e859d88c6646f9a2ac79a1d8d13dbc','get on with s...','[luk ˈɪntuː]','','与……相处','','');----
INSERT INTO classwords VALUES ('99a4edeb3748486dbc4de01e3ed8c06a','43e859d88c6646f9a2ac79a1d8d13dbc','141');----
INSERT INTO word VALUES ('007d44e0b9c64ff59702fbc6850ffe10','not at all','[nɔt æt ɔ:l]','http://res.iciba.com/resource/amp3/0/0/06/95/06951a076c8f062e7009da6709f26c39.mp3','一点也不，绝非','','');----
INSERT INTO classwords VALUES ('78fe32c86a33454cb764c0348abbf512','007d44e0b9c64ff59702fbc6850ffe10','141');----
INSERT INTO word VALUES ('a9b022b85dd5488e9f46738c09dee5f1','go by','[ɡəu bai]','http://res.iciba.com/resource/amp3/0/0/09/8f/098f3f04eecb8bf1c481c00528d838f3.mp3','走过; 经过; 过去','','');----
INSERT INTO classwords VALUES ('116119812b184f2fa605147b6370acb3','a9b022b85dd5488e9f46738c09dee5f1','141');----
INSERT INTO word VALUES ('ae9fc09f219e47f2a3ab5dbaf8edf8ea','show off','[ʃəu ɔf]','http://res.iciba.com/resource/amp3/0/0/5c/a7/5ca7be6015d17b7ca5b876e01e91c892.mp3','炫耀','','');----
INSERT INTO classwords VALUES ('f9805cfd9d514ca9a0b995975f31a3a6','ae9fc09f219e47f2a3ab5dbaf8edf8ea','141');----
INSERT INTO word VALUES ('10face7493ec4ac99442c977311506b6','hang up','[hæŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/cc/61/cc6145b2f3c30b5214a7a2e86d739f68.mp3','挂断电话','','');----
INSERT INTO classwords VALUES ('6103129992d24d32a8b6f1b213fe6f6e','10face7493ec4ac99442c977311506b6','141');----
INSERT INTO word VALUES ('fef31890a590435faffbaebbfcb422af','in order that...','[in ˈɔ:də ðæt]','http://res-tts.iciba.com/8/1/6/816f4441379eace0087407690e59a317.mp3','为了','','');----
INSERT INTO classwords VALUES ('421e9f0ef3db4bb8bdd076230b9ab07d','fef31890a590435faffbaebbfcb422af','141');----
INSERT INTO word VALUES ('d24ab8cc7cbc44e6826cc719106bdc85','clear up','[kliə ʌp]','http://res.iciba.com/resource/amp3/0/0/80/ed/80edc311f2d4742023e99a3db0e02917.mp3','整理，收拾, (天气)放晴','','');----
INSERT INTO classwords VALUES ('c4b3129d3cd24c1fae17dcd64c9515a1','d24ab8cc7cbc44e6826cc719106bdc85','141');----
INSERT INTO word VALUES ('2ecacfef14114f3783d0c43cc6f52502','keep on','[ki:p ɔn]','http://res.iciba.com/resource/amp3/0/0/dc/4e/dc4e3dde75057e242c16a57f6352ad30.mp3','继续（进行）','','');----
INSERT INTO classwords VALUES ('1c3b4d998162496ea448187e785c3f8b','2ecacfef14114f3783d0c43cc6f52502','141');----
INSERT INTO word VALUES ('72b8cf9477bb4eb2b49ad35f3866fc89','think of','[θiŋk ɔv]','http://res-tts.iciba.com/e/f/f/eff6cf09810856479d918b0874cf3b14.mp3','想起,考虑,认为,看法','','');----
INSERT INTO classwords VALUES ('18c7acb3b9a34abb81dbbb4a0b759683','72b8cf9477bb4eb2b49ad35f3866fc89','141');----
INSERT INTO word VALUES ('883e43e00b9e45ab86302741936d7e9d','for good','[fɔ: ɡud]','http://res.iciba.com/resource/amp3/0/0/4a/00/4a00dd7fb7008456bce24800beef5417.mp3','永远','','');----
INSERT INTO classwords VALUES ('528b0c490753426cb2730c6b620df74a','883e43e00b9e45ab86302741936d7e9d','141');----
INSERT INTO word VALUES ('693f5c93968c461f99ffa8f884e3d0e1','break up','[breik ʌp]','http://res.iciba.com/resource/amp3/0/0/bf/f2/bff2be32210454ea1b271f09f9dceb37.mp3','分解；分裂','','');----
INSERT INTO classwords VALUES ('90ed68c451a5402d96971ad4f680bb76','693f5c93968c461f99ffa8f884e3d0e1','141');----
INSERT INTO word VALUES ('f39c7fa23f9040b1a919f1e2f17007bd','compare to','[kəmˈpɛə tu:]','http://res.iciba.com/resource/amp3/0/0/21/2d/212d0f442da20ddc6412cb33a6c93950.mp3','与……相比','','');----
INSERT INTO classwords VALUES ('f441ce9ef34940af951db52a2e9b14e4','f39c7fa23f9040b1a919f1e2f17007bd','141');----
INSERT INTO word VALUES ('0d3a4e2058f64133912a21917e1c9cd6','keep one''s wo...','[ki:p wʌnz wə:d]','http://res.iciba.com/resource/amp3/0/0/ab/5a/ab5a8daed81231d8e8897ede5f3194de.mp3','守信','','');----
INSERT INTO classwords VALUES ('d763fc54a77f4c3c83ac5663dca27fc7','0d3a4e2058f64133912a21917e1c9cd6','141');----
INSERT INTO class VALUES ('141','高考常用短语',362,0,0,0,0);
