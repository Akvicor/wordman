INSERT INTO word VALUES ('ca3e218fd7bd4e0fbfcb6ef419140022','let out','[let aut]','http://res.iciba.com/resource/amp3/0/0/af/4b/af4bf7de5a0e47c710664d07e9d0ba22.mp3','放掉, 泄露','','');----
INSERT INTO classwords VALUES ('e2841c6d82774e93aade2165ff2c4099','ca3e218fd7bd4e0fbfcb6ef419140022','141');----
INSERT INTO word VALUES ('be831a70487546c79c1bafaba425d1c4','put away','[put əˈwei]','http://res.iciba.com/resource/amp3/0/0/f6/ae/f6aebbee4163169a82fd337d49ba149e.mp3','储存','','');----
INSERT INTO classwords VALUES ('e6e727a892144ce2aa0c54ec55ccdc12','be831a70487546c79c1bafaba425d1c4','141');----
INSERT INTO word VALUES ('1053331d62fd452daed031de067cf6de','go on doing.....','[put əˈwei]','','继续干某事，不停地干某事','','');----
INSERT INTO classwords VALUES ('cc56ae04b8db4cf7827b88bcef00ee84','1053331d62fd452daed031de067cf6de','141');----
INSERT INTO word VALUES ('6f52b08c04034f1c97db186f3c4ceac8','by and by','[bai ænd bai]','http://res.iciba.com/resource/amp3/0/0/b2/39/b239eb281c171927761398cfdea950dc.mp3','不久以后，逐渐地','','');----
INSERT INTO classwords VALUES ('175ac7e11c4945b3944614af8a66c74c','6f52b08c04034f1c97db186f3c4ceac8','141');----
INSERT INTO word VALUES ('5aab9ab2a412406880951e1741af9f1b','set down','[set daun]','http://res.iciba.com/resource/amp3/0/0/fd/1b/fd1bfbbfb8b86174eb0efb7630b362fc.mp3','放下','','');----
INSERT INTO classwords VALUES ('369a94cad19c4768a2463d883055de22','5aab9ab2a412406880951e1741af9f1b','141');----
INSERT INTO word VALUES ('369f4ea960014096b6ec7e1638d23f5a','write down','[rait daun]','http://res.iciba.com/resource/amp3/1/0/6d/7b/6d7bde8ccf1a2876a85e6d0db303a1ea.mp3','写下，记下','','');----
INSERT INTO classwords VALUES ('4ee0d74c9cd4449eb83e07356486f530','369f4ea960014096b6ec7e1638d23f5a','141');----
INSERT INTO word VALUES ('618b318d0a0f42fb9b10530e1c45694e','earn one's li...','[ə:n wʌnz ˈliviŋ]','http://res.iciba.com/resource/amp3/0/0/f6/6d/f66d7ddb97986031aedf69cb5f372435.mp3','谋生','','');----
INSERT INTO classwords VALUES ('8cd55ece6eb94fa1b9f00a0d2121a55c','618b318d0a0f42fb9b10530e1c45694e','141');----
INSERT INTO word VALUES ('bd2035be9441438d8f2c3c3bdd2f85c1','go in for','[ɡəu in fɔ:]','http://res.iciba.com/resource/amp3/0/0/dd/bc/ddbc2b6f300ea55fedefe363850687e8.mp3','参加，喜欢','','');----
INSERT INTO classwords VALUES ('520eb12eec704228af6bf3cdf3eccc7e','bd2035be9441438d8f2c3c3bdd2f85c1','141');----
INSERT INTO word VALUES ('770166b54a9c4a62bfb77fb1689f4f77','depend on (up...','[ɡəu in fɔ:]','','依靠，相信，信赖','','');----
INSERT INTO classwords VALUES ('f205cf07e8c94b32be87e7cdec03d3df','770166b54a9c4a62bfb77fb1689f4f77','141');----
INSERT INTO word VALUES ('c4f0393b80f14b4594ebff2d49c9e411','send out','[send aut]','http://res.iciba.com/resource/amp3/0/0/e9/d0/e9d07bd968483d687722ad328570d08e.mp3','发出，派遣','','');----
INSERT INTO classwords VALUES ('7c4136aecc3d47e2966854c48a9834c1','c4f0393b80f14b4594ebff2d49c9e411','141');----
INSERT INTO word VALUES ('7e86ac5106124abdad7307c8bc5e68ed','in a hurry','[in ə ˈhʌri]','http://res.iciba.com/resource/amp3/0/0/44/75/44751e53cf7ae2150b00b65fe3eb0e53.mp3','匆忙，很快地','','');----
INSERT INTO classwords VALUES ('c6f277f5391846ac8930baf46b178a42','7e86ac5106124abdad7307c8bc5e68ed','141');----
INSERT INTO word VALUES ('6376a9ad8be7441d86805e4b34256e39','in a word','[in ə wə:d]','http://res.iciba.com/resource/amp3/0/0/1a/5a/1a5ae76a4eedd87f85669c2950ebbfb9.mp3','简言之，总之','','');----
INSERT INTO classwords VALUES ('a13e090d9f154fa390c257e0e0a3ed90','6376a9ad8be7441d86805e4b34256e39','141');----
INSERT INTO word VALUES ('e1541942df154455b6644d9c822b82a4','get along wit...','[ɡet əˈlɔŋ wið]','http://res.iciba.com/resource/amp3/0/0/d3/28/d328cf7a311e10c31fdbe1dd52e8b5d6.mp3','与……相处','','');----
INSERT INTO classwords VALUES ('1972481b40454f8a87a8b9ac7e84fa53','e1541942df154455b6644d9c822b82a4','141');----
INSERT INTO word VALUES ('faf1c76235834284974a4f2dd81225ed','lead to','[li:d tu:]','http://res.iciba.com/resource/amp3/0/0/c1/9a/c19a08e132073ccc42091dc309da8631.mp3','导致，导向','','');----
INSERT INTO classwords VALUES ('656143939d2545e3a743ba27a5e42a4f','faf1c76235834284974a4f2dd81225ed','141');----
INSERT INTO word VALUES ('5754629c6fcf4cad92a7145e013fed97','so far as','[səʊ fɑ: æz]','http://res.iciba.com/resource/amp3/0/0/8c/a4/8ca41b11fe464a0c930f12416a9af961.mp3','（表示程度，范围）就……，尽……','','');----
INSERT INTO classwords VALUES ('6d8f6651554143acaa55b5fede2fa527','5754629c6fcf4cad92a7145e013fed97','141');----
INSERT INTO word VALUES ('80a8b6ca8277446eb70eb6e97adf6d70','in need of','[in ni:d ɔv]','http://res.iciba.com/resource/amp3/0/0/e8/18/e818baf4ba9e825fea07d3a666cb5ea9.mp3','需要，缺少','','');----
INSERT INTO classwords VALUES ('73633ed6da6642419fda7b8c651e27d1','80a8b6ca8277446eb70eb6e97adf6d70','141');----
INSERT INTO word VALUES ('bb1829692f1a47b588b06faa41efe0ef','on foot','[ɔn fut]','http://res.iciba.com/resource/amp3/0/0/f1/8b/f18b10e99f79e4336552ef0789bf6803.mp3','走路，步行','','');----
INSERT INTO classwords VALUES ('d823396963c84ad59dd38d30ab374254','bb1829692f1a47b588b06faa41efe0ef','141');----
INSERT INTO word VALUES ('94f7785af8cf45898d2b9e1e2dda4e62','come about','[kʌm əˈbaut]','http://res.iciba.com/resource/amp3/0/0/ec/9b/ec9b2350dc9e6184af175d996f68aa23.mp3','发生，产生','','');----
INSERT INTO classwords VALUES ('b1f7aebc7f284b3ebfcc913ed17779de','94f7785af8cf45898d2b9e1e2dda4e62','141');----
INSERT INTO word VALUES ('5becb5b7bd0f41d6bbac8a75a1d28e40','get together','[ɡet təˈɡeðə]','http://res.iciba.com/resource/amp3/0/0/b9/e1/b9e14d45cf990c9d2c27e14ae7961810.mp3','聚会，联欢','','');----
INSERT INTO classwords VALUES ('238d35cc71994d558840b54c18ec5d72','5becb5b7bd0f41d6bbac8a75a1d28e40','141');----
INSERT INTO word VALUES ('5b9235591c054a01b5e58189654496c5','check out','[tʃek aut]','http://res.iciba.com/resource/amp3/0/0/8b/81/8b81d9aa118c0c3f760799dcbc9b81c1.mp3','查明; 结账','','');----
INSERT INTO classwords VALUES ('ea10d645f23c45bc9c18a48478a2e0d2','5b9235591c054a01b5e58189654496c5','141');----
INSERT INTO word VALUES ('fb27470ee92d42eabb444410d5ce050f','send for','[send fɔ:]','http://res.iciba.com/resource/amp3/0/0/89/ca/89cab114aff61e28530067c8c876103a.mp3','派人去叫（请）','','');----
INSERT INTO classwords VALUES ('8c36d894c9fb4dc2878b06c39bec2c58','fb27470ee92d42eabb444410d5ce050f','141');----
INSERT INTO word VALUES ('3b8f9c212fd7467ab584dd1bc1f3baea','spend...on','','http://res-tts.iciba.com/8/1/4/814ff9557adbebd02186ecab27e08b51.mp3','在……花钱','','');----
INSERT INTO classwords VALUES ('b8170c03b2fd4abe804e152a0dba5a1e','3b8f9c212fd7467ab584dd1bc1f3baea','141');----
INSERT INTO word VALUES ('6d78e4df51dd4887b975681e586a5468','get off','[ɡet ɔf]','http://res.iciba.com/resource/amp3/0/0/25/c3/25c3ada1387b1c6b2c855a0facf5ef3a.mp3','脱下（衣服等）；下车','','');----
INSERT INTO classwords VALUES ('dd91f642ed4f4eae8d93a92204e9e9f6','6d78e4df51dd4887b975681e586a5468','141');----
INSERT INTO word VALUES ('ecbfe06c75a94c6f86fa013637098a98','make up of','[meik ʌp ɔv]','http://res.iciba.com/resource/amp3/0/0/9b/bd/9bbda06a23ed1b22a9b597d1b95edf40.mp3','由……组成，构成','','');----
INSERT INTO classwords VALUES ('6b4328ce993b483eb6fc0fa420b25c63','ecbfe06c75a94c6f86fa013637098a98','141');----
INSERT INTO word VALUES ('28a007b85b974e20a30636d1e73c617b','hold on','[həuld ɔn]','http://res.iciba.com/resource/amp3/0/0/45/c1/45c194a91bfef734109bb8ecaffa5561.mp3','等一等（别挂电话）','','');----
INSERT INTO classwords VALUES ('6c72a5473fff47119382abfea326cc50','28a007b85b974e20a30636d1e73c617b','141');----
INSERT INTO word VALUES ('12e64ebc399d4095997906a11dc327d7','in the end','[in ðə end]','http://res.iciba.com/resource/amp3/0/0/a6/a3/a6a3b11134c4bc7538bb79454ce5ea31.mp3','最后，终于','','');----
INSERT INTO classwords VALUES ('fb3819dfb94640a29f25cbd6c04bdeb6','12e64ebc399d4095997906a11dc327d7','141');----
INSERT INTO word VALUES ('95f3b5e38da242b4a689065bb17375a5','stand for','[stænd fɔ:]','http://res.iciba.com/resource/amp3/0/0/c2/91/c291452d4077260e22b5996663975ae4.mp3','代表，象征','','');----
INSERT INTO classwords VALUES ('cbed17a1bf804019bc610b82b451bfff','95f3b5e38da242b4a689065bb17375a5','141');----
INSERT INTO word VALUES ('e0048c3a80d24f0e8240edb6e8abe0f1','dozens of','','http://res-tts.iciba.com/1/d/5/1d5c6dd343acbf5b5989a74bc68d1346.mp3','几十','','');----
INSERT INTO classwords VALUES ('a835dd9a1d2e4eeb9854c4e6c1024451','e0048c3a80d24f0e8240edb6e8abe0f1','141');----
INSERT INTO word VALUES ('f0001e0ada9a4e9fa8b78f6877401dd3','or else','[ɔ: els]','http://res.iciba.com/resource/amp3/0/0/f2/80/f28035166a9889f3c27b266611c0358c.mp3','否则，要不然','','');----
INSERT INTO classwords VALUES ('8a41f8e6915842d6ac4fa47586c0d1b3','f0001e0ada9a4e9fa8b78f6877401dd3','141');----
INSERT INTO word VALUES ('6a6f31ac64954c238a7e9c17aaed0125','come across','[kʌm əˈkrɔs]','http://res.iciba.com/resource/amp3/0/0/6d/af/6daf350034e01ceff031200e2fc32f2c.mp3','(偶然)遇见(或发现）','','');----
INSERT INTO classwords VALUES ('4a7ca5f8fb8840b886c2e2a45242e1a3','6a6f31ac64954c238a7e9c17aaed0125','141');----
INSERT INTO word VALUES ('d39a064d7ff3486a9bd9d11a3f114eff','feel like doi...','[fi:l laik ˈdu:ɪŋ]','http://res-tts.iciba.com/9/8/3/9832edcd0d97315c02e18c05e1ab598b.mp3','想要…, 感觉要…','','');----
INSERT INTO classwords VALUES ('67dca027f52c42b1bd6aa43843d71a42','d39a064d7ff3486a9bd9d11a3f114eff','141');----
INSERT INTO word VALUES ('db084324736642a888bb45e1b493f28e','be strict wit...','[bi: strikt wið]','http://res-tts.iciba.com/3/a/d/3ade0973b5d44523a62ff0cb6526e132.mp3','对……严格要求','','');----
INSERT INTO classwords VALUES ('fdb35fc0ff2e48f19d947f514f691795','db084324736642a888bb45e1b493f28e','141');----
INSERT INTO word VALUES ('20f38ec2a7b044139433c898c553a6dd','cut off','[kʌt ɔf]','http://res.iciba.com/resource/amp3/1/0/cc/64/cc64e77e65d232d2741f5e62efa3faee.mp3','切断','','');----
INSERT INTO classwords VALUES ('13941f70718e43a19c414c179c457364','20f38ec2a7b044139433c898c553a6dd','141');----
INSERT INTO word VALUES ('471c49c608e34396afe4c9d7b9432284','in peace','[in pi:s]','http://res.iciba.com/resource/amp3/0/0/18/cf/18cf642f9eea7ec484e9a6853e3e1938.mp3','安静，宁静','','');----
INSERT INTO classwords VALUES ('b7f9b244c9604049beff7804246ec256','471c49c608e34396afe4c9d7b9432284','141');----
INSERT INTO word VALUES ('e98604f2c3db4c9b8d98c35a79705fb8','make a face','[meik ə feis]','http://res.iciba.com/resource/amp3/0/0/f9/08/f908e0e91862b1b4fcd68129ee94b5fd.mp3','做鬼脸，做苦脸','','');----
INSERT INTO classwords VALUES ('4814299ea3914b3787e015249a03f48b','e98604f2c3db4c9b8d98c35a79705fb8','141');----
INSERT INTO word VALUES ('405ee78a34574f48bcc612f9c1934bd2','think about','[θiŋk əˈbaut]','http://res-tts.iciba.com/3/e/e/3eecef3ee37002c553a48e7e9974b75d.mp3','考虑（是否去做）','','');----
INSERT INTO classwords VALUES ('abe948b226af43f3ad9b78244bd4a517','405ee78a34574f48bcc612f9c1934bd2','141');----
INSERT INTO word VALUES ('d16e2ea2ad5e4b23bd8d33046e9a9e18','arrive at (in...','[θiŋk əˈbaut]','','到达某地','','');----
INSERT INTO classwords VALUES ('bc1899e4ac5845e9b47b5a39193f4eef','d16e2ea2ad5e4b23bd8d33046e9a9e18','141');----
INSERT INTO word VALUES ('d9e7599a361341379af8ee0a6de491a5','go on','[ɡəu ɔn]','http://res.iciba.com/resource/amp3/0/0/4f/e6/4fe62855e964d07c63617d5ac8c5b88a.mp3','继续','','');----
INSERT INTO classwords VALUES ('c115c360426143fdb856f4ae8a8a361d','d9e7599a361341379af8ee0a6de491a5','141');----
INSERT INTO word VALUES ('eb88b883eb5c459080add7e49ed867f8','on (the, an) ...','[ɡəu ɔn]','','平均，按平均数计算','','');----
INSERT INTO classwords VALUES ('ef54f3aa11b74bdb97d1bfae0da85579','eb88b883eb5c459080add7e49ed867f8','141');----
INSERT INTO word VALUES ('3588970a841d4ae7a532bb9717f036b4','give back','[ɡiv bæk]','http://res.iciba.com/resource/amp3/0/0/d5/38/d538fbd83e4531b493c4a268cafdc97e.mp3','归还；送回','','');----
INSERT INTO classwords VALUES ('ea79e643dafd4abab682d95bf2ff18d3','3588970a841d4ae7a532bb9717f036b4','141');----
INSERT INTO word VALUES ('ab4dfbdf368b40ceb8474bb52e275dec','laugh at','[lɑ:f æt]','http://res.iciba.com/resource/amp3/0/0/1a/ec/1aecc42e226fb222c0f74ab686311d04.mp3','嘲笑','','');----
INSERT INTO classwords VALUES ('0f3a8790c93445b7bb4093c258d6c3fa','ab4dfbdf368b40ceb8474bb52e275dec','141');----
INSERT INTO word VALUES ('f91e21d005ac4bafbaf1fd615143287d','all kinds of','','http://res.iciba.com/resource/amp3/0/0/71/8c/718c0bf22971db0f7bbce83c4de05fbd.mp3','各种各样的','','');----
INSERT INTO classwords VALUES ('b59926046e35450c820734af0ad9bf9e','f91e21d005ac4bafbaf1fd615143287d','141');----
INSERT INTO word VALUES ('29908c8a73d94bb4a5cb3ae99dee9171','look for','[luk fɔ:]','http://res.iciba.com/resource/amp3/0/0/80/95/8095d87fe84e9c5288bccd590976964e.mp3','寻找','','');----
INSERT INTO classwords VALUES ('7d49be7aa3534a4ea4f8e01d053a132a','29908c8a73d94bb4a5cb3ae99dee9171','141');----
INSERT INTO word VALUES ('afd822f22b7640afb42f3369ef0c94f0','go out','[ɡəu aut]','http://res.iciba.com/resource/amp3/0/0/f0/eb/f0ebc176acb87aaf3b7165173a057106.mp3','出去, 熄灭','','');----
INSERT INTO classwords VALUES ('94741279036b41c1ba5f75b8ebd93793','afd822f22b7640afb42f3369ef0c94f0','141');----
INSERT INTO word VALUES ('61a9e7902076473fb1fe7cf7ebe74e76','pay for','[pei fɔ:]','http://res.iciba.com/resource/amp3/0/0/d5/22/d52299dfff4ae51adc2f883011389cc0.mp3','付款','','');----
INSERT INTO classwords VALUES ('9df1a71e113146c9ab104f0d45ac762c','61a9e7902076473fb1fe7cf7ebe74e76','141');----
INSERT INTO word VALUES ('cedc3121835245a4a14ccdb52ec67baf','so far','[səʊ fɑ:]','http://res.iciba.com/resource/amp3/0/0/49/6b/496b1a892afca979499eeb40a2f24c44.mp3','到目前为止','','');----
INSERT INTO classwords VALUES ('8606ca7df2d545449d784e4a9ed58c08','cedc3121835245a4a14ccdb52ec67baf','141');----
INSERT INTO word VALUES ('14126331acdd4454897975a962b262b5','help oneself ...','[help wʌnˈself tu:]','http://res.iciba.com/resource/amp3/0/0/31/50/3150c7faf8441558e5951429f2aa8522.mp3','请随便吃点','','');----
INSERT INTO classwords VALUES ('0e65cca8d2314128beede493ebeec370','14126331acdd4454897975a962b262b5','141');----
INSERT INTO word VALUES ('53028a5e5cdb46c49c55d8b178b0e954','get up','[ɡet ʌp]','http://res.iciba.com/resource/amp3/0/0/c6/ec/c6ec1bb206e0f89e1798208abe061ae6.mp3','起床','','');----
INSERT INTO classwords VALUES ('4bf166c1510a473a8c32a51bc0e44019','53028a5e5cdb46c49c55d8b178b0e954','141');----
INSERT INTO word VALUES ('9e4dd3e006f140dfa7d89d621345d8bb','a great deal','[ə ɡreit di:l]','http://res-tts.iciba.com/7/b/5/7b5c6cf6aff9277d15c01c64d0d8a6ba.mp3','大量，许多','','');----
INSERT INTO classwords VALUES ('f528ed0ced37458d92b0ca1772c8e342','9e4dd3e006f140dfa7d89d621345d8bb','141');----
INSERT INTO word VALUES ('db7d7c4efed848469fcb73b3d8be3e02','no longer','','http://res.iciba.com/resource/amp3/0/0/29/2d/292dede7b52cc12cd7a666823620001a.mp3','不再','','');----
INSERT INTO classwords VALUES ('cd06f7474d7e4beaa9cda409ce7d2621','db7d7c4efed848469fcb73b3d8be3e02','141');----
INSERT INTO word VALUES ('aa62dc0576cd4f93a24840e255f65655','keep doing st...','','','继续做某事','','');----
INSERT INTO classwords VALUES ('8ab73c5a1c634ff78bab7a935c2c7e1a','aa62dc0576cd4f93a24840e255f65655','141');----
INSERT INTO word VALUES ('711cd238729b481fa7d14a323d6990dc','put up with','[put ʌp wið]','http://res.iciba.com/resource/amp3/0/0/04/17/0417fdbdca7b77e693428fe35265711f.mp3','忍受','','');----
INSERT INTO classwords VALUES ('8432b90f971c446298d595ad6caeb6e2','711cd238729b481fa7d14a323d6990dc','141');----
INSERT INTO word VALUES ('94ecdbc410d145a9803d5fbf9ded64d9','on show','[ɔn ʃəu]','http://res.iciba.com/resource/amp3/0/0/33/be/33be8345a32226b7ffde4460c5d82c9b.mp3','展出，在上演（放映）','','');----
INSERT INTO classwords VALUES ('db4f7ca5dbf54507ba77793301885834','94ecdbc410d145a9803d5fbf9ded64d9','141');----
INSERT INTO word VALUES ('3e120f7dceda4105a8ae6535301af2ce','turn on','[tə:n ɔn]','http://res.iciba.com/resource/amp3/1/0/b1/97/b197375d9ebab835d23fd69d05cf3eb6.mp3','打开（水、电视、收音机、灯、煤气等）','','');----
INSERT INTO classwords VALUES ('9fac69a5ef414020adc141c166bc86c7','3e120f7dceda4105a8ae6535301af2ce','141');----
INSERT INTO word VALUES ('dbcd2f61760f4d96af437749e6268f96','on duty','[ɔn ˈdju:ti]','http://res.iciba.com/resource/amp3/0/0/bc/66/bc66bd161e10618607e147174d03e72f.mp3','值日，值班','','');----
INSERT INTO classwords VALUES ('adf79fb628b147ffb3ec3ccd6aa87258','dbcd2f61760f4d96af437749e6268f96','141');----
INSERT INTO word VALUES ('e4b1d7cf935e4a1186d003d86f5136c2','hundreds of','','http://res-tts.iciba.com/4/b/d/4bde493da4b8ed0d05b9499392f62e4e.mp3','几百，成百上千','','');----
INSERT INTO classwords VALUES ('a312fb9e4c744d1aac7a3e347f45c2bd','e4b1d7cf935e4a1186d003d86f5136c2','141');----
INSERT INTO word VALUES ('33bfc66f7f4a4d6d874dac4e2ff5b38a','right now','[rait nau]','http://res.iciba.com/resource/amp3/0/0/4b/c3/4bc3954b03f53c00f11a5d99e7263bd6.mp3','立即，马上','','');----
INSERT INTO classwords VALUES ('180926f0008f4245ab9ba529c2f639e4','33bfc66f7f4a4d6d874dac4e2ff5b38a','141');----
INSERT INTO word VALUES ('ef66093b58394024bedbd5a520ef86a7','work out','[wə:k aut]','http://res.iciba.com/resource/amp3/1/0/64/45/6445838221dd01d60743ccb8da88407e.mp3','算出，解决','','');----
INSERT INTO classwords VALUES ('8b98b567581e4bab9893f9cbcdc8f884','ef66093b58394024bedbd5a520ef86a7','141');----
INSERT INTO word VALUES ('7444ef790e5045fc84ab181265857831','in danger','[in ˈdeindʒə]','http://res.iciba.com/resource/amp3/0/0/00/21/002125b1a358b3ce4972376722d4e800.mp3','处在危险状态','','');----
INSERT INTO classwords VALUES ('df04f43c55ca4e0a92c2607c3ce3ac24','7444ef790e5045fc84ab181265857831','141');----
INSERT INTO word VALUES ('f9c69446626b443f8dbfd283e901dd78','go for a walk...','[ɡəu fɔ: ə wɔ:k]','http://res.iciba.com/resource/amp3/0/0/f8/f4/f8f47e27973f90f1f3068903a4e58b58.mp3','散步','','');----
INSERT INTO classwords VALUES ('0ab5e3ff80e64ab9973a1ab92bc8bb27','f9c69446626b443f8dbfd283e901dd78','141');----
INSERT INTO word VALUES ('51eb0e9a93e34b98878bb1155c9ceaf7','sentence...to...','[ɡəu fɔ: ə wɔ:k]','','判处死刑','','');----
INSERT INTO classwords VALUES ('6036edb7cf15424f87bdd1873346c086','51eb0e9a93e34b98878bb1155c9ceaf7','141');----
INSERT INTO word VALUES ('fc2c49ba84664b9d8564122d471f9a53','save one's li...','[ɡəu fɔ: ə wɔ:k]','','挽救某人生命','','');----
INSERT INTO classwords VALUES ('e40da11a0f8d47c59a56d3c30bf49eae','fc2c49ba84664b9d8564122d471f9a53','141');----
INSERT INTO word VALUES ('ca30d088c4324df29d8aba0b5146fac1','run away','[rʌn əˈwei]','http://res.iciba.com/resource/amp3/0/0/c9/7d/c97da3c65a68a1c8068f311b3752b3d1.mp3','逃跑, 失控','','');----
INSERT INTO classwords VALUES ('6776af53a3c340ce86a8d33ab27a1296','ca30d088c4324df29d8aba0b5146fac1','141');----
INSERT INTO word VALUES ('39efe20147d94e53baf67b708ca00e8c','figure out','[ˈfiɡə aut]','http://res.iciba.com/resource/amp3/0/0/2d/76/2d7672dee811764e19ae620bd33e3d07.mp3','理解，想明白','','');----
INSERT INTO classwords VALUES ('0e6b12983cb6491b85295ecfeec6b988','39efe20147d94e53baf67b708ca00e8c','141');----
INSERT INTO word VALUES ('16df2315323a4e69b035436d7bbb32c4','a little','[ə ˈlitl]','http://res-tts.iciba.com/2/2/5/225ca0b4604f639c163e0aa77dfd8b58.mp3','一点，少许','','');----
INSERT INTO classwords VALUES ('724ecf137db644de892706770be00ae7','16df2315323a4e69b035436d7bbb32c4','141');----
INSERT INTO word VALUES ('b36dbc3d306b480a8446092cca2547b7','stop doing st...','','http://res-tts.iciba.com/a/f/d/afd12a2e57b73e35a4e2bfc3d44bc61d.mp3','停止做某事','','');----
INSERT INTO classwords VALUES ('c8c17555fb79404094c2f64002126c20','b36dbc3d306b480a8446092cca2547b7','141');----
INSERT INTO word VALUES ('8e87da0f057f48ed9d3a23ae8b350bfd','go through','[ɡəu θru:]','http://res.iciba.com/resource/amp3/0/0/45/60/456032ca6aaecf560ef92adf5acc6ee2.mp3','浏览; 翻阅，通过','','');----
INSERT INTO classwords VALUES ('e05a52dd049841ec8be3cb15de48f3b7','8e87da0f057f48ed9d3a23ae8b350bfd','141');----
INSERT INTO word VALUES ('27a252bad14a42a2a6ab16f3f2362067','refer to','[riˈfə: tu:]','http://res.iciba.com/resource/amp3/0/0/d6/87/d6876c7aadc3629552b3db734c615db5.mp3','提到，涉及，有关','','');----
INSERT INTO classwords VALUES ('647ecf9a18764f47a86cbf48379e5dd5','27a252bad14a42a2a6ab16f3f2362067','141');----
INSERT INTO word VALUES ('f9ac019699d6469f934678903cc1fdd2','make friends ...','','http://res.iciba.com/resource/amp3/0/0/93/f4/93f49508669d93663eccada08bd27e54.mp3','与……交朋友','','');----
INSERT INTO classwords VALUES ('98eec44a1ff242bab8f0575a144779f9','f9ac019699d6469f934678903cc1fdd2','141');----
INSERT INTO word VALUES ('807878df30fd484d91b31fc19ba2e096','connect to','[kəˈnekt tu:]','http://res-tts.iciba.com/0/7/4/074481cdbfb1b31384a05eff275e00bf.mp3','连接，相连','','');----
INSERT INTO classwords VALUES ('f77c07036e3a4b3780563894b8813b1c','807878df30fd484d91b31fc19ba2e096','141');----
INSERT INTO word VALUES ('3cb3143f0f1f4e7ea18ef58b3dbbecd4','in time','[in taim]','http://res.iciba.com/resource/amp3/0/0/6d/6d/6d6d79c57c8e833a6b82a9bff8f7f736.mp3','及时，来得及','','');----
INSERT INTO classwords VALUES ('918055db79d24483aa20d0389ab97487','3cb3143f0f1f4e7ea18ef58b3dbbecd4','141');----
INSERT INTO word VALUES ('58a1b052ab0e473586b71d067972a2b7','not only ... ...','','http://res.iciba.com/resource/amp3/0/0/b9/a8/b9a82c1c7c7e6b72a7e5c035406b5447.mp3','不仅…而且…','','');----
INSERT INTO classwords VALUES ('e24a7345b2ea4f5ab4028da8e24d432a','58a1b052ab0e473586b71d067972a2b7','141');----
INSERT INTO word VALUES ('9611205adeee429989d899602337dc70','bring in','[briŋ in]','http://res.iciba.com/resource/amp3/0/0/1c/f4/1cf447e6230970ae01f9fa844f4f69d9.mp3','引来，引进，吸收','','');----
INSERT INTO classwords VALUES ('475ab37d85f64deda63a56a7227d7e6b','9611205adeee429989d899602337dc70','141');----
INSERT INTO word VALUES ('c0fa07bada42442995f10ac9d6ec592a','set out','[set aut]','http://res.iciba.com/resource/amp3/0/0/47/97/479742c1eb280b2bce596b8dc7eb9b13.mp3','出发; 开始','','');----
INSERT INTO classwords VALUES ('840896200feb4c6d856e3c4c103ba0a0','c0fa07bada42442995f10ac9d6ec592a','141');----
INSERT INTO word VALUES ('24902b7bbd9a471ca30e12a588a68c5a','take up','[teik ʌp]','http://res.iciba.com/resource/amp3/0/0/90/70/90709b4878b07a9b6e669e3b53bbb1b2.mp3','占去，占据（时间、地位等）','','');----
INSERT INTO classwords VALUES ('258da83a26f546ee85153790ae56cbcd','24902b7bbd9a471ca30e12a588a68c5a','141');----
INSERT INTO word VALUES ('f1b72a6e45cf412680387ca437856d4d','ring up','[riŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/34/55/3455986d98f74c6e54d1b0c32db456cb.mp3','打电话给','','');----
INSERT INTO classwords VALUES ('04931f9b5a7e462d98326fcf9cea42db','f1b72a6e45cf412680387ca437856d4d','141');----
INSERT INTO word VALUES ('921c355d991c47c8aa24636a34c019b6','after class','[ˈɑ:ftə klɑ:s]','http://res-tts.iciba.com/5/3/1/531cad3e444c6974610074d112e5bce9.mp3','课后','','');----
INSERT INTO classwords VALUES ('6d2e5fae6ff04a6ab437f44dba7a8f77','921c355d991c47c8aa24636a34c019b6','141');----
INSERT INTO word VALUES ('ac515635ef3147e69ee84b4192076318','take off','[teik ɔf]','http://res.iciba.com/resource/amp3/0/0/e5/4f/e54f0f6c95f9f9bd43ea0e266b0ef4ca.mp3','脱下，起飞','','');----
INSERT INTO classwords VALUES ('0536581f7bad431998dc6ebd01d27b5f','ac515635ef3147e69ee84b4192076318','141');----
INSERT INTO word VALUES ('67a8f619d74e473dae38ed60b52a6902','day and night...','[dei ænd nait]','http://res-tts.iciba.com/f/1/b/f1bd884ad5b81c4c3238e0025054aa30.mp3','日日夜夜','','');----
INSERT INTO classwords VALUES ('44e2c396b98c4a298600fcb9761c5a79','67a8f619d74e473dae38ed60b52a6902','141');----
INSERT INTO word VALUES ('10a4eaaac52a486d8a22230970c2d137','fall asleep','[fɔ:l əˈsli:p]','http://res.iciba.com/resource/amp3/0/0/b3/8a/b38a2bc60138c2c7c9b6f4a240863d74.mp3','入睡','','');----
INSERT INTO classwords VALUES ('a7d05f465dc24d61824867daff42a8a1','10a4eaaac52a486d8a22230970c2d137','141');----
INSERT INTO word VALUES ('c0306694ee9449d68ef9e3a739a5c906','after all','[ˈɑ:ftə ɔ:l]','http://res.iciba.com/resource/amp3/0/0/d9/bf/d9bf78346b9f609a594e5b7510e2dd0d.mp3','毕竟，终究','','');----
INSERT INTO classwords VALUES ('ca01898cc924450db4a4d62538f8137f','c0306694ee9449d68ef9e3a739a5c906','141');----
INSERT INTO word VALUES ('776571f5cada44d28e3f6138042549c5','hand in','[hænd in]','http://res.iciba.com/resource/amp3/0/0/04/bc/04bc3505649bdc0ce315aa8ac68ef86e.mp3','上交; 交纳','','');----
INSERT INTO classwords VALUES ('392b3fdb57d14ce4ae2334505ffb5aef','776571f5cada44d28e3f6138042549c5','141');----
INSERT INTO word VALUES ('b6d5325d17bd495a9901f5940a1782f8','hold one's br...','','http://res.iciba.com/resource/amp3/0/0/0f/3d/0f3d1d3597485f323812a82fec67eabb.mp3','不出气,屏住呼吸','','');----
INSERT INTO classwords VALUES ('57a4107853a04fa2b177d0f2f1a5ed95','b6d5325d17bd495a9901f5940a1782f8','141');----
INSERT INTO word VALUES ('6089ecd359e64809946eb97abe5b7cb1','get in','[ɡet in]','http://res.iciba.com/resource/amp3/0/0/ad/b2/adb2733c99aee6038538aba3b9672f6a.mp3','进入, 收获，达到','','');----
INSERT INTO classwords VALUES ('652c49f3d484496893204e92d7558b74','6089ecd359e64809946eb97abe5b7cb1','141');----
INSERT INTO word VALUES ('6362319283f44c19bda0087162bb2d62','fill in','[fil in]','http://res.iciba.com/resource/amp3/0/0/da/27/da2770eb7910e1dfae779adb454a45b2.mp3','填充','','');----
INSERT INTO classwords VALUES ('4de58692bc92454ca1b345633abb153f','6362319283f44c19bda0087162bb2d62','141');----
INSERT INTO word VALUES ('a2ddc0cbaf4549228fa819d7b46757d3','deal with','[di:l wið]','http://res.iciba.com/resource/amp3/1/0/1c/b4/1cb49697bf438bc903ff9704e950a633.mp3','处理，对付','','');----
INSERT INTO classwords VALUES ('daa36f96b98f4bb9945d234b928c3eb1','a2ddc0cbaf4549228fa819d7b46757d3','141');----
INSERT INTO word VALUES ('2cf482d0167d428b8d818286e643f50d','get on','[ɡet ɔn]','http://res.iciba.com/resource/amp3/0/0/fc/94/fc94b89254559d145986b854c7b2e2cb.mp3','上车；过活','','');----
INSERT INTO classwords VALUES ('d57bdcbff7a94b859a8d7b73e3d3973c','2cf482d0167d428b8d818286e643f50d','141');----
INSERT INTO word VALUES ('88c5158d278242abb9a014b34e620fc5','divide up','[diˈvaid ʌp]','http://res.iciba.com/resource/amp3/1/0/b2/7d/b27daf51715232c40113c69bfeee2247.mp3','分配','','');----
INSERT INTO classwords VALUES ('89f60c82204c46669d69436d5f742605','88c5158d278242abb9a014b34e620fc5','141');----
INSERT INTO word VALUES ('c85491d7df4e4f94b66b74f4d694e573','get down to','[ɡet daun tu:]','http://res.iciba.com/resource/amp3/0/0/d7/c3/d7c333a895962fe5b174e3e6038bf9b7.mp3','开始认真（做某事）','','');----
INSERT INTO classwords VALUES ('7d51088692ad48c28ab390a178d138a2','c85491d7df4e4f94b66b74f4d694e573','141');----
INSERT INTO word VALUES ('b5833c7015944bf89f64575dba2a1974','carry off','[ˈkæri ɔf]','http://res.iciba.com/resource/amp3/0/0/ac/2c/ac2c398aabfd21a7b3754aefe665b8c4.mp3','携走，夺走','','');----
INSERT INTO classwords VALUES ('56b31878e77942db8051be6a981cf7c5','b5833c7015944bf89f64575dba2a1974','141');----
INSERT INTO word VALUES ('2974e4d877674dcd91b1fb5f4559bd3a','pass by','[pɑ:s bai]','http://res.iciba.com/resource/amp3/0/0/02/21/02212fae7818e725863de3f14eaa94b6.mp3','经过','','');----
INSERT INTO classwords VALUES ('f10d023f8d5f4e78ae1f7c43fa5a9ac9','2974e4d877674dcd91b1fb5f4559bd3a','141');----
INSERT INTO word VALUES ('9a017b7650104758a2ac4ab06d298075','have fun with...','','http://res-tts.iciba.com/a/7/f/a7fae4ff97dc602dc037af360c9fffcd.mp3','玩得高兴','','');----
INSERT INTO classwords VALUES ('28732dadb9e34bc2bee9ba681b1b69d4','9a017b7650104758a2ac4ab06d298075','141');----
INSERT INTO word VALUES ('5039da3e65184a7792c407b6eea0d6d4','agree with sb...','','http://res-tts.iciba.com/5/4/c/54c2ca250447a763d8411b918bbfd949.mp3','同意某人的看法，与某人看法一致','','');----
INSERT INTO classwords VALUES ('a3f89648af9f4affa64adb796f15ba9f','5039da3e65184a7792c407b6eea0d6d4','141');----
INSERT INTO word VALUES ('12a3e034566c4f849ddf3776ad113390','build up','[bild ʌp]','http://res.iciba.com/resource/amp3/0/0/50/e0/50e05d5cf0e374c7b7369326b957d16b.mp3','逐步建立','','');----
INSERT INTO classwords VALUES ('965c6ab515224a7ea998bded97cfbee8','12a3e034566c4f849ddf3776ad113390','141');----
INSERT INTO word VALUES ('af241bc105f54c2ab60fb284447185ea','break off','[breik ɔf]','http://res.iciba.com/resource/amp3/0/0/4e/21/4e21fe61899be58cb5cf1957b99a6bae.mp3','打断; 折断','','');----
INSERT INTO classwords VALUES ('7069f9f9d4154c0f982f5a2b2de5c341','af241bc105f54c2ab60fb284447185ea','141');----
INSERT INTO word VALUES ('ac042bcb9201478d9b4cdba17ed638f4','bring up','[briŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/58/77/5877f75c7f78669372e2159ddd6e85b5.mp3','教育，培养','','');----
INSERT INTO classwords VALUES ('8e2d2085bb5f42bf9607ab6cb5a5fdc5','ac042bcb9201478d9b4cdba17ed638f4','141');----
INSERT INTO word VALUES ('ff14687fcf9747d3a9244354778a28a5','in order','[in ˈɔ:də]','http://res.iciba.com/resource/amp3/0/0/c6/55/c65530c55229fab2e3af0bc9fb1ed124.mp3','按顺序','','');----
INSERT INTO classwords VALUES ('7997631a86844b23b9a41afde8b833b5','ff14687fcf9747d3a9244354778a28a5','141');----
INSERT INTO word VALUES ('7a920ef2a64244829c40d2800fd0d5af','in other word...','','http://res.iciba.com/resource/amp3/0/0/78/0f/780f7b0f52d613efc5678a6a616eb4c7.mp3','换句话说','','');----
INSERT INTO classwords VALUES ('8ccc8aa2e58646229075340df4937998','7a920ef2a64244829c40d2800fd0d5af','141');----
INSERT INTO word VALUES ('c225d944019b4eae9ee8cb973ddf9a5c','turn down','[tə:n daun]','http://res.iciba.com/resource/amp3/1/0/87/89/8789270b7a02a169d0a065e3ca03fdf8.mp3','关小，调低','','');----
INSERT INTO classwords VALUES ('6a5e8998f3934a95bd9f3bf4451134cc','c225d944019b4eae9ee8cb973ddf9a5c','141');----
INSERT INTO word VALUES ('24db4bb69016497b98d432ad538c634c','look down upo...','[luk daun əˈpɔn]','http://res.iciba.com/resource/amp3/0/0/97/5f/975f4d5381cf08d20f0eff8e9fcfb5b2.mp3','看不起，轻视','','');----
INSERT INTO classwords VALUES ('8b061e24b460435f9a9b84ff5707a502','24db4bb69016497b98d432ad538c634c','141');----
INSERT INTO word VALUES ('5912728c485d4deba81d60f9925e494a','ought to','[ˈɔ:t tə]','http://res.iciba.com/resource/amp3/oxford/0/97/bb/97bb0d22013a0cd9bee66e42cf2de9dd.mp3','应该','','');----
INSERT INTO classwords VALUES ('d4fbbda8d32e46c0a372418fe9a05df4','5912728c485d4deba81d60f9925e494a','141');----
INSERT INTO word VALUES ('f72abf78782b46ec9ce23b6c061c3594','stop to do st...','[ˈɔ:t tə]','','停下来做某事','','');----
INSERT INTO classwords VALUES ('ad698eed74894ccd8663ed1544252fec','f72abf78782b46ec9ce23b6c061c3594','141');----
INSERT INTO word VALUES ('a589231e4f7e4176a2ddb5de5c7ff194','be proud of','[bi: praud ɔv]','http://res.iciba.com/resource/amp3/0/0/1e/90/1e90c729ad3c5fbf9b86fd69266ddde3.mp3','骄傲，自豪','','');----
INSERT INTO classwords VALUES ('59119fe28a7a4fcf9be8767600a51e0e','a589231e4f7e4176a2ddb5de5c7ff194','141');----
INSERT INTO word VALUES ('db22b26c72154695a7216daa9d6318ab','come back','[kʌm bæk]','http://res.iciba.com/resource/amp3/0/0/1f/ce/1fce5629baaeaade48f614c18f10626b.mp3','回来，想起来','','');----
INSERT INTO classwords VALUES ('a8927cb9248f4c669c5ec84ccab97375','db22b26c72154695a7216daa9d6318ab','141');----
INSERT INTO word VALUES ('c7cf4b3eb8614064a782b2aba08d2e64','have a good t...','[hæv ə ɡud taim]','http://res.iciba.com/resource/amp3/0/0/60/bc/60bc0718d1c81013812de7ea467ad975.mp3','玩得高兴，过得愉快','','');----
INSERT INTO classwords VALUES ('42ddcfdc8b3447e980a99cfed09a5cf8','c7cf4b3eb8614064a782b2aba08d2e64','141');----
INSERT INTO word VALUES ('e2bc7f50128b406da1d03e0863866c31','as if','[æz if]','http://res.iciba.com/resource/amp3/0/0/ad/32/ad3203e31be3977b9108254cdb7a07aa.mp3','好像，仿佛','','');----
INSERT INTO classwords VALUES ('0dcd89c43c97430d8eaaf487cebc0100','e2bc7f50128b406da1d03e0863866c31','141');----
INSERT INTO word VALUES ('a67a335c53ed43da9b60dca00460c2e9','all in all','[ɔ:l in ɔ:l]','http://res.iciba.com/resource/amp3/0/0/55/53/5553f74713ecef912082b1189fbade16.mp3','总的来说，总计','','');----
INSERT INTO classwords VALUES ('92c01adf6714479fb8984d3a56d2134c','a67a335c53ed43da9b60dca00460c2e9','141');----
INSERT INTO word VALUES ('fc56218827c54dc1a53f773462480d8b','come on','[kʌm ɔn]','http://res.iciba.com/resource/amp3/0/0/b1/9b/b19b704a47b51ae9d8c3ef7101eb9a7e.mp3','来吧，赶快','','');----
INSERT INTO classwords VALUES ('8abe5aead2d840acb33519a1f4be43ad','fc56218827c54dc1a53f773462480d8b','141');----
INSERT INTO word VALUES ('822f97c6005d4552a87a6a3906c0f383','hurry up','[ˈhʌri ʌp]','http://res.iciba.com/resource/amp3/0/0/0f/45/0f45cf405da2bb03814883f28cfd4c8c.mp3','赶快，快点','','');----
INSERT INTO classwords VALUES ('7b0966628cf24119a225cd4ebff40701','822f97c6005d4552a87a6a3906c0f383','141');----
INSERT INTO word VALUES ('9633a6794b1b485abf4afe30bd6010cf','go fishing','[ɡəu ˈfɪʃɪŋ]','http://res.iciba.com/resource/amp3/0/0/3b/43/3b4342f88a82a18e04c9ebbb27b7b6c7.mp3','（去）钓鱼','','');----
INSERT INTO classwords VALUES ('85eae0a0affc44c19bf0e4fa20c9e102','9633a6794b1b485abf4afe30bd6010cf','141');----
INSERT INTO word VALUES ('f03d416a4eb24fcfb2ae8da9d96db84e','again and aga...','[əˈɡen ænd əˈɡen]','http://res.iciba.com/resource/amp3/0/0/51/52/5152ac16a2540d8a72fdb1e65107fbaa.mp3','反复地，再三地','','');----
INSERT INTO classwords VALUES ('eb64a4936b6d45c892bd0d10fb3139cd','f03d416a4eb24fcfb2ae8da9d96db84e','141');----
INSERT INTO word VALUES ('b851d3b6d5cd4cb6961a7cb438d7a9ff','try out','[trai aut]','http://res.iciba.com/resource/amp3/1/0/f6/07/f607f2a5c3a82ce4f8dab4ae574486af.mp3','试验','','');----
INSERT INTO classwords VALUES ('50d64edb26ec4bcc9f51de0f225037a5','b851d3b6d5cd4cb6961a7cb438d7a9ff','141');----
INSERT INTO word VALUES ('1c7c8b8534084ae1a88da07d0837520a','talk about','[tɔ:k əˈbaut]','http://res.iciba.com/resource/amp3/0/0/b0/f9/b0f91942e580a96767c0ccca31c6de46.mp3','谈论，议论','','');----
INSERT INTO classwords VALUES ('77681d163d1e47438dcf5b393ff30744','1c7c8b8534084ae1a88da07d0837520a','141');----
INSERT INTO word VALUES ('07f1b58db0864f62988d99b73ed029ea','write to','[rait tu:]','http://res-tts.iciba.com/e/9/e/e9eb435a0792f6fed24b43cdd5662acf.mp3','写信给…','','');----
INSERT INTO classwords VALUES ('2f501ea3df554ced8dce34bdab17dfc6','07f1b58db0864f62988d99b73ed029ea','141');----
INSERT INTO word VALUES ('31d2abd48e044cd381970f099e655aa2','come from','[kʌm frɔm]','http://res.iciba.com/resource/amp3/0/0/4c/89/4c89cd90affd70a24513f11161dc4167.mp3','出生（于），来自','','');----
INSERT INTO classwords VALUES ('26dffde4261e4845856aaf36040ccfda','31d2abd48e044cd381970f099e655aa2','141');----
INSERT INTO word VALUES ('a67327a8246b4560a79813fed6df2fa4','come in','[kʌm in]','http://res.iciba.com/resource/amp3/0/0/e1/99/e199114d6fbbcb354e308561f3723f8e.mp3','进入，进来','','');----
INSERT INTO classwords VALUES ('4c0ff1a444ec49548a03dd2a530bac8d','a67327a8246b4560a79813fed6df2fa4','141');----
INSERT INTO word VALUES ('932490f0b4b54d25a207708bc3544803','in all','[in ɔ:l]','http://res.iciba.com/resource/amp3/0/0/66/90/6690b31d1f2a51d6e7f6c63dff94261f.mp3','总之','','');----
INSERT INTO classwords VALUES ('ac9b379b60fe4d2997cc42896f4c7db2','932490f0b4b54d25a207708bc3544803','141');----
INSERT INTO word VALUES ('710ceedc8cb7466dbacd6365f9d0ded6','once more','[wʌns mɔ:]','http://res.iciba.com/resource/amp3/0/0/97/f8/97f880f250c33c3af41aa38d48f5a4ae.mp3','再一次','','');----
INSERT INTO classwords VALUES ('d2f4c2997b3a4e4faf694f5c3e13151b','710ceedc8cb7466dbacd6365f9d0ded6','141');----
INSERT INTO word VALUES ('1ac373f1339b4dbd935dfaf801de9338','each other','[i:tʃ ˈʌðə(r]','http://res-tts.iciba.com/3/e/e/3eef9039b69cd989f551655ea2103dad.mp3','相互','','');----
INSERT INTO classwords VALUES ('6bd71e967c8b40cd9ee61c880435f4a8','1ac373f1339b4dbd935dfaf801de9338','141');----
INSERT INTO word VALUES ('d60f13f14d92400a94e136da73c366b2','send up','[send ʌp]','http://res.iciba.com/resource/amp3/0/0/2d/cf/2dcfaf5e68c86024cfbad070a58bf657.mp3','发出, 射出','','');----
INSERT INTO classwords VALUES ('7d22cbd6695740d8a470bebff2d1d36f','d60f13f14d92400a94e136da73c366b2','141');----
INSERT INTO word VALUES ('5ce94cf3915a44e2aed64a392e443566','see...off','[send ʌp]','','为某人送行','','');----
INSERT INTO classwords VALUES ('6b51502c92df4c94bbc05c20129a9189','5ce94cf3915a44e2aed64a392e443566','141');----
INSERT INTO word VALUES ('b329e59745764fefab3efac24eab4e9a','die out','[dai aut]','http://res.iciba.com/resource/amp3/1/0/db/b7/dbb7f99f26a1c5fc87097cb058531055.mp3','消失，灭亡','','');----
INSERT INTO classwords VALUES ('259104d9b3b34013a8fe1c55238787a8','b329e59745764fefab3efac24eab4e9a','141');----
INSERT INTO word VALUES ('8a42a3a5cfea455fbe6b872df373d68b','give up','[ɡiv ʌp]','http://res.iciba.com/resource/amp3/0/0/07/8d/078da1f9958e5856d6cdf0741d98c421.mp3','放?','','');----
INSERT INTO classwords VALUES ('ec4ceb16ab2e480292db1db876f2f03b','8a42a3a5cfea455fbe6b872df373d68b','141');----
INSERT INTO word VALUES ('fced73334b234a88873b2f25594f8ca1','in fact','[in fækt]','http://res.iciba.com/resource/amp3/0/0/a6/de/a6deccdb95cbd779293edd17d3fe47ae.mp3','事实上，实际上','','');----
INSERT INTO classwords VALUES ('5f40ce3b0f6c491e8982c2f1ca00d452','fced73334b234a88873b2f25594f8ca1','141');----
INSERT INTO word VALUES ('3e938668cbc04296835714d9fb77dd7d','even if','[ˈi:vən if]','http://res-tts.iciba.com/d/f/9/df99d2ca8ccbc29caa6628f08dea0ce8.mp3','即使，尽管','','');----
INSERT INTO classwords VALUES ('204ac61e4621489db7107c3f22071a4f','3e938668cbc04296835714d9fb77dd7d','141');----
INSERT INTO word VALUES ('257471b625e240208e40cb25becacaa5','take it easy','[teik it ˈi:zi]','http://res.iciba.com/resource/amp3/0/0/10/7e/107e07983e9f50df860abced64637438.mp3','别着急，别紧张','','');----
INSERT INTO classwords VALUES ('306e9b77860f4bdb996084308c8729d6','257471b625e240208e40cb25becacaa5','141');----
INSERT INTO word VALUES ('ed76ef1597c14338b5db906cfedb3756','in debt','[in det]','http://res.iciba.com/resource/amp3/0/0/aa/5f/aa5f7c7715ffd6aeed32dd70634af2cb.mp3','欠债','','');----
INSERT INTO classwords VALUES ('f1487587f1fc46b48e0147181dcc7f61','ed76ef1597c14338b5db906cfedb3756','141');----
INSERT INTO word VALUES ('42fed59fcd504e5590af0fa6c15b85bc','put on a perf...','[in det]','','演出','','');----
INSERT INTO classwords VALUES ('d71fbf84c2274cfd9ec1eaf1917a172b','42fed59fcd504e5590af0fa6c15b85bc','141');----
INSERT INTO word VALUES ('6e45a16ce6784786a4680e61c3ea1e7b','come up','[kʌm ʌp]','http://res.iciba.com/resource/amp3/0/0/a8/6a/a86a0d634f7bf63a521e986d3bab64f7.mp3','上来，上升，抬头','','');----
INSERT INTO classwords VALUES ('7aa57a326fdd480da82a8c5abd591c58','6e45a16ce6784786a4680e61c3ea1e7b','141');----
INSERT INTO word VALUES ('3b76023b38154a5180b3c511c9ba15ef','grow up','[ɡrəu ʌp]','http://res.iciba.com/resource/amp3/0/0/7a/c3/7ac361505e596dfc8932b526466ff882.mp3','长大成人，成长','','');----
INSERT INTO classwords VALUES ('7b2767f0e66f4a4f8aa560c1083a90ce','3b76023b38154a5180b3c511c9ba15ef','141');----
INSERT INTO word VALUES ('3adf33e586a9479db956d2efe3c19121','get down','[ɡet daun]','http://res.iciba.com/resource/amp3/0/0/9d/9a/9d9a627954fbd2915b2c132c775af471.mp3','降下','','');----
INSERT INTO classwords VALUES ('1d3f521c6b714021aebd70831454ae88','3adf33e586a9479db956d2efe3c19121','141');----
INSERT INTO word VALUES ('11803f16aa494f3a8eab46c009d58731','now and then','[nau ænd ðen]','http://res.iciba.com/resource/amp3/0/0/af/b3/afb348c8eae5841560b39a27bc1dafbe.mp3','不时，偶尔','','');----
INSERT INTO classwords VALUES ('c79002fc10d6413186819b3e57dd51cb','11803f16aa494f3a8eab46c009d58731','141');----
INSERT INTO word VALUES ('c1a84b183acc429b8edce0c3f9335d54','one after ano...','[wʌn ˈɑ:ftə əˈnʌðər]','http://res.iciba.com/resource/amp3/0/0/de/b6/deb6c001798c6b3f8a570a6fac6c8fcf.mp3','一个接一个','','');----
INSERT INTO classwords VALUES ('0e496e3442804daabbe0e98899b19755','c1a84b183acc429b8edce0c3f9335d54','141');----
INSERT INTO word VALUES ('d16a0f969870472bb57fae1acce27e60','hand out','[hænd aut]','http://res.iciba.com/resource/amp3/0/0/e8/fb/e8fb10760d6610fa2024e8d38e32a789.mp3','分发','','');----
INSERT INTO classwords VALUES ('eb9bf161b5894db7a546ce671890467c','d16a0f969870472bb57fae1acce27e60','141');----
INSERT INTO word VALUES ('729e88993fee4237b959b39d67a4bec1','persuade sb. ...','[hænd aut]','','说服','','');----
INSERT INTO classwords VALUES ('15c759487e6e4f93b026ff7e571708a1','729e88993fee4237b959b39d67a4bec1','141');----
INSERT INTO word VALUES ('c1740222d2b442d194bfefec6bfaa4f6','turn over','[tə:n ˈəuvə]','http://res.iciba.com/resource/amp3/1/0/08/63/0863e371d7ef2a18ebff815835f1d57a.mp3','翻动，犁翻（土地）','','');----
INSERT INTO classwords VALUES ('c0301cb9f6d741c79ab0ad3497cce6ac','c1740222d2b442d194bfefec6bfaa4f6','141');----
INSERT INTO word VALUES ('4c40b89e587b4cf7b966499a7e35d641','from... to','[tə:n ˈəuvə]','','从……到……','','');----
INSERT INTO classwords VALUES ('fe076164703442bb8095178675d8f048','4c40b89e587b4cf7b966499a7e35d641','141');----
INSERT INTO word VALUES ('e0b8a2b35de34a879fd2696dd69c2cce','try on','[trai ɔn]','http://res.iciba.com/resource/amp3/1/0/3c/6a/3c6ae4c14bdf6ec8fcaf8e9ccf83741d.mp3','试穿，试试看','','');----
INSERT INTO classwords VALUES ('afbf407260e9426f9c95ab08f2f3961f','e0b8a2b35de34a879fd2696dd69c2cce','141');----
INSERT INTO word VALUES ('b187e6eb67d342d99ad39faca4ad7fa7','keep back','[ki:p bæk]','http://res.iciba.com/resource/amp3/0/0/04/5f/045f55136e98eeb2347633494319e834.mp3','留下','','');----
INSERT INTO classwords VALUES ('5d6dd6770d0446f3ba987b180d36f816','b187e6eb67d342d99ad39faca4ad7fa7','141');----
INSERT INTO word VALUES ('5d7dc95900944f64aafce6cb1cc0a864','rather than','','http://res.iciba.com/resource/amp3/0/0/13/3d/133d5a7c747b955dcb621ab1de6dadab.mp3','而不，非','','');----
INSERT INTO classwords VALUES ('585e57b9b7c14f5996f1ac4ae6861cea','5d7dc95900944f64aafce6cb1cc0a864','141');----
INSERT INTO word VALUES ('e1eec855ca2c453c9266835593edaa66','both...and','','http://res-tts.iciba.com/6/5/7/6575a8f2a8455b328a36fba21d798ea7.mp3','两个都，既…又…','','');----
INSERT INTO classwords VALUES ('be422d49767944009d6db62a956af191','e1eec855ca2c453c9266835593edaa66','141');----
INSERT INTO word VALUES ('9b8c4d7515c04a91b1cfff82e0cf1920','call in','[kɔ:l in]','http://res.iciba.com/resource/amp3/0/0/bf/d5/bfd58bacc1791ffdb1e8ce2fe7278a9b.mp3','召来，召集','','');----
INSERT INTO classwords VALUES ('a5dacc8aa37b4210b3030783ec62d77a','9b8c4d7515c04a91b1cfff82e0cf1920','141');----
INSERT INTO word VALUES ('e07d4f4c7be045d7bb469962a1533d97','in front of','[in frʌnt ɔv]','http://res.iciba.com/resource/amp3/0/0/29/17/2917f8743e8dd4d36ae50a74526d28de.mp3','在……前面','','');----
INSERT INTO classwords VALUES ('5f65c0e9189745d1b57a6881f8ac6974','e07d4f4c7be045d7bb469962a1533d97','141');----
INSERT INTO word VALUES ('459aace34d38422cbb9b467acf0a0c96','take away','[teik əˈwei]','http://res.iciba.com/resource/amp3/0/0/6f/63/6f6367d451aa380d8842523467d11a41.mp3','拿走','','');----
INSERT INTO classwords VALUES ('dfcfcddd11924493b9563b560886b3c3','459aace34d38422cbb9b467acf0a0c96','141');----
INSERT INTO word VALUES ('e4f9f3b0790c4923b6173f3f443dc7ef','as usual','[æz ˈju:ʒuəl]','http://res.iciba.com/resource/amp3/0/0/65/3e/653ee6d5b0670423d7e06481e52ac751.mp3','通常，平常地','','');----
INSERT INTO classwords VALUES ('726dbfbeae4146368e188fa433c2d284','e4f9f3b0790c4923b6173f3f443dc7ef','141');----
INSERT INTO word VALUES ('df33c8ce1fec44a980cf7a35e047c676','open up','[ˈəupən ʌp]','http://res.iciba.com/resource/amp3/0/0/0b/59/0b5932c3721f47c6feefcf767b06b64e.mp3','开启；开创; 开辟','','');----
INSERT INTO classwords VALUES ('7ecc0d4995a2445292eee56f0fbf7880','df33c8ce1fec44a980cf7a35e047c676','141');----
INSERT INTO word VALUES ('99e6d4c9b36b460f93b73c56fda2aaa6','out of order','[aut ɔv ˈɔ:də]','http://res.iciba.com/resource/amp3/0/0/17/35/17356f966aa42919007009984bb87132.mp3','运转不正常，出毛病','','');----
INSERT INTO classwords VALUES ('dc9dd2590d8644d98db241286d59ac8e','99e6d4c9b36b460f93b73c56fda2aaa6','141');----
INSERT INTO word VALUES ('75cd371eea26454ea125018e8381338b','a number of','[ə ˈnʌmbə ɔv]','http://res-tts.iciba.com/5/f/9/5f95a07c8848241cfe5076ac69477212.mp3','一些，许多','','');----
INSERT INTO classwords VALUES ('a1c017f772744a7489452de39c6ade3f','75cd371eea26454ea125018e8381338b','141');----
INSERT INTO word VALUES ('eaee79140b884a9d8e578c0764a6892e','the day after...','','http://res.iciba.com/resource/amp3/0/0/70/8c/708cceace22e3cde6e69a9304a6b79c4.mp3','后天','','');----
INSERT INTO classwords VALUES ('c0946712aa8f4d39b9940fe31271a1b6','eaee79140b884a9d8e578c0764a6892e','141');----
INSERT INTO word VALUES ('6e83efa154324d6785bcad32c0d3a5c9','make up one's...','','http://res.iciba.com/resource/amp3/0/0/ce/46/ce46d880a6977b195d5adb40dc2dfbc5.mp3','下决心','','');----
INSERT INTO classwords VALUES ('7a767f7ca03a47a9ac22d7d20c1f9d2f','6e83efa154324d6785bcad32c0d3a5c9','141');----
INSERT INTO word VALUES ('2a446b3177a9463f8ca8b005b29c55f0','the more...th...','','http://res-tts.iciba.com/6/f/3/6f36811f428e54535b679f4377cc313a.mp3','越…就越…','','');----
INSERT INTO classwords VALUES ('68dc28075c3c42a79adb8f305acaea6e','2a446b3177a9463f8ca8b005b29c55f0','141');----
INSERT INTO word VALUES ('394fd8c7ba844e4192e4c53ee3d4fe59','from time to ...','[frɔm taim tu: taim]','http://res.iciba.com/resource/amp3/0/0/c2/ad/c2ad5f6f255616748a0310496d576e8b.mp3','不时，偶尔','','');----
INSERT INTO classwords VALUES ('168dbcd2b7f242efa1d4209a66a16343','394fd8c7ba844e4192e4c53ee3d4fe59','141');----
INSERT INTO word VALUES ('35936be497ca49468128fc5f84af01e9','just now','[dʒʌst nau]','http://res.iciba.com/resource/amp3/0/0/26/54/2654992d78afbd40bad349302a6f2b6a.mp3','现在，刚才','','');----
INSERT INTO classwords VALUES ('f622b8a5dbd1442da5e1cf6183487814','35936be497ca49468128fc5f84af01e9','141');----
INSERT INTO word VALUES ('b9a4e53ad1504a03abde8a03a1d557d9','millions of','','http://res-tts.iciba.com/6/d/f/6dfe0e2013068722b91822a1a474efb1.mp3','成百万上千万，数以百万计','','');----
INSERT INTO classwords VALUES ('88291324f7a64502b83c93b67768d59b','b9a4e53ad1504a03abde8a03a1d557d9','141');----
INSERT INTO word VALUES ('36e8a369b48849abb24951f82dd96d26','for example','[fɔ: iɡˈzɑ:mpl]','http://res.iciba.com/resource/amp3/0/0/02/3d/023dbce5e060641d09218027704ca4b3.mp3','例如','','');----
INSERT INTO classwords VALUES ('d90805d6bf5f49cba07d1550ba9f8b7b','36e8a369b48849abb24951f82dd96d26','141');----
INSERT INTO word VALUES ('0c54557bbda64110b36105853ba60e2a','wait for','[weit fɔ:]','http://res-tts.iciba.com/e/3/5/e35031efc5cf102eb14d71f301faa475.mp3','等候，等待','','');----
INSERT INTO classwords VALUES ('480518ae321742f29f677ed30a741475','0c54557bbda64110b36105853ba60e2a','141');----
INSERT INTO word VALUES ('c1f519c7fd7d4d05859518511e288f35','thousands of','','http://res-tts.iciba.com/1/f/7/1f741dd5c3c6458071193f208c895e6d.mp3','成千上万，几千','','');----
INSERT INTO classwords VALUES ('d6e29e88adda4d36b7f5f193a5f59dac','c1f519c7fd7d4d05859518511e288f35','141');----
INSERT INTO word VALUES ('8c09396e56fa4b93ac2e78c771fffa51','worry about','[ˈwʌri əˈbaut]','http://res-tts.iciba.com/5/f/e/5fe5dd576111fd6e5e18c3d10bcef64c.mp3','担心，烦恼','','');----
INSERT INTO classwords VALUES ('46f9b8a55a114f589e8e0a847258257b','8c09396e56fa4b93ac2e78c771fffa51','141');----
INSERT INTO word VALUES ('4584a0b90f234968b523f8faafcbb88d','a great many','[ə ɡreit ˈmeni]','http://res-tts.iciba.com/1/5/c/15cfccb6d4ed6c872ce70d6329de4cd5.mp3','大量，许多','','');----
INSERT INTO classwords VALUES ('67caeda875734f54bacb3c16ac6d387f','4584a0b90f234968b523f8faafcbb88d','141');----
INSERT INTO word VALUES ('8ba3a94a13274d1caac9799fd701f776','wrap up','[ræp ʌp]','http://res.iciba.com/resource/amp3/1/0/e5/94/e594ba35385531b78c8252893dd915d9.mp3','包好, 伪装','','');----
INSERT INTO classwords VALUES ('2079aaf986d044d2ae8c61b6e904dc35','8ba3a94a13274d1caac9799fd701f776','141');----
INSERT INTO word VALUES ('34c6b19b3f324ee49237e400768ca18b','take out','[teik aut]','http://res.iciba.com/resource/amp3/0/0/6d/60/6d60b5b90711ac3669744f550314d52d.mp3','取出','','');----
INSERT INTO classwords VALUES ('ba97aab963194e0e863835ce2ff80603','34c6b19b3f324ee49237e400768ca18b','141');----
INSERT INTO word VALUES ('06f74425c71e4e6d96fc78b25fbc0fe7','according to','','http://res-tts.iciba.com/4/4/0/440a3bbc91716125aef7de35fc6e49ae.mp3','根据，按照','','');----
INSERT INTO classwords VALUES ('d6bac551da9342b9a635bbe7ea4af830','06f74425c71e4e6d96fc78b25fbc0fe7','141');----
INSERT INTO word VALUES ('332d9f3ea54d48c295a228bc94b29d38','by day','[bai dei]','http://res.iciba.com/resource/amp3/0/0/d7/10/d7106bda7e75a8ab4dfd96fcb56fb2b6.mp3','日间，在白天','','');----
INSERT INTO classwords VALUES ('b721fc68da4446d18967d823141cff12','332d9f3ea54d48c295a228bc94b29d38','141');----
INSERT INTO word VALUES ('e80b4eaa42894abf837759570a46d53b','let in','[let in]','http://res.iciba.com/resource/amp3/0/0/00/a6/00a6ff3dfbd23c1d8c3bafc3aa38e11a.mp3','让……进来，放进','','');----
INSERT INTO classwords VALUES ('c927da6d0c9c498a868bfd9a046e5a6c','e80b4eaa42894abf837759570a46d53b','141');----
INSERT INTO word VALUES ('5fa08c93152b4b1e9c18a8796c38d2e8','the other day...','[ðə ˈʌðə(r dei]','http://res.iciba.com/resource/amp3/0/0/64/e9/64e9f2bda171874aee42b8e8fe57659d.mp3','前几天，某日','','');----
INSERT INTO classwords VALUES ('366726c1d5ec4b03afc79a89556883ea','5fa08c93152b4b1e9c18a8796c38d2e8','141');----
INSERT INTO word VALUES ('a3a6fa95255e4d95ac4fd0f46bd143ca','join up','[dʒɔin ʌp]','http://res.iciba.com/resource/amp3/0/0/14/2b/142bd51fd91e810c5bc5b2e242a084be.mp3','联合起来，联结起来','','');----
INSERT INTO classwords VALUES ('ac9a5c92716b4f98977d6ea5f79407bc','a3a6fa95255e4d95ac4fd0f46bd143ca','141');----
INSERT INTO word VALUES ('f3a2d1b0c5ce486dbe8c1a2e6a9cf6e6','compare with','[kəmˈpɛə wið]','http://res.iciba.com/resource/amp3/0/0/0e/06/0e062bf7d1366cf048b96b419614a399.mp3','与……相比','','');----
INSERT INTO classwords VALUES ('ad9014621c8243c99ed6934a7665aa06','f3a2d1b0c5ce486dbe8c1a2e6a9cf6e6','141');----
INSERT INTO word VALUES ('6222ca8bab494ffda93fba027445f388','go ahead','[ɡəu əˈhed]','http://res.iciba.com/resource/amp3/0/0/86/7b/867b716ecfc8971b436fbf52f1961a2e.mp3','走在前面，领先；干吧，干下去','','');----
INSERT INTO classwords VALUES ('d0984ab969db47b49b6bebac1ac600e1','6222ca8bab494ffda93fba027445f388','141');----
INSERT INTO word VALUES ('8a814e34854f4d7ba991b1886abd13f8','in surprise','[in səˈpraiz]','http://res.iciba.com/resource/amp3/0/0/7d/5c/7d5c332b18f2d6baca2fa1d090874d97.mp3','吃惊，惊讶','','');----
INSERT INTO classwords VALUES ('0431151308ad4c3685ad6aa9cd53e708','8a814e34854f4d7ba991b1886abd13f8','141');----
INSERT INTO word VALUES ('ce4d550b93b44a149510dc6ca7128462','too...to','','http://res-tts.iciba.com/6/4/a/64a2e60ba8cfabb347b75b38644c7540.mp3','太……以至于不……','','');----
INSERT INTO classwords VALUES ('2f1a2ec5f48f4bb5bb29573c0605ad63','ce4d550b93b44a149510dc6ca7128462','141');----
INSERT INTO word VALUES ('f138757743c7424592f9c55819bdb9f0','care for','[kɛə fɔ:]','http://res.iciba.com/resource/amp3/0/0/11/96/11961689f25c32f0dfffb0aa75e3247a.mp3','喜欢；照顾（病人）','','');----
INSERT INTO classwords VALUES ('8b9daaaa69164aa3a9d18f76b39e186a','f138757743c7424592f9c55819bdb9f0','141');----
INSERT INTO word VALUES ('127642b3977e45fdad438c782b4585d2','put up','[put ʌp]','http://res.iciba.com/resource/amp3/0/0/23/cd/23cd8397e107fc963fb05fefd703a92b.mp3','挂起，举起, 贴（广告等）','','');----
INSERT INTO classwords VALUES ('90dec50d3aed4c519f9ae59c716398f5','127642b3977e45fdad438c782b4585d2','141');----
INSERT INTO word VALUES ('a531941e728049c58124d8d9e7250eca','hold out','[həuld aut]','http://res.iciba.com/resource/amp3/0/0/93/4f/934ff94692ff719304400953146259bb.mp3','伸出；坚持，维持','','');----
INSERT INTO classwords VALUES ('4e35917d40c5498caba94109d33ba1bb','a531941e728049c58124d8d9e7250eca','141');----
INSERT INTO word VALUES ('4d1a3747051543dda1ad82686ac8adcf','do one's best...','','http://res.iciba.com/resource/amp3/0/0/86/d8/86d814dba6bed684dc03b57f07fe6a10.mp3','尽最大的努力','','');----
INSERT INTO classwords VALUES ('2af7646b00324cc5862a5e885a2bd9a2','4d1a3747051543dda1ad82686ac8adcf','141');----
INSERT INTO word VALUES ('eabf503594604432a42aa147a6db0fa6','check in','[tʃek in]','http://res.iciba.com/resource/amp3/0/0/cf/94/cf94356230791d87b214dfe333d6a1ef.mp3','报到，登记','','');----
INSERT INTO classwords VALUES ('39f23f28a508465f938a20d2e551b8a9','eabf503594604432a42aa147a6db0fa6','141');----
INSERT INTO word VALUES ('69bcdbe9f0294b0082da9a220a32a058','as long as','[æz lɔŋ æz]','http://res.iciba.com/resource/amp3/0/0/a7/e1/a7e1918270b582b7707d5003f2fceee6.mp3','只要','','');----
INSERT INTO classwords VALUES ('fb14e0eee85c40bbb2a2a9ea5a51a431','69bcdbe9f0294b0082da9a220a32a058','141');----
INSERT INTO word VALUES ('ed50c069129e4f65a02d59c97868adf0','as soon as','[æz su:n æz]','http://res.iciba.com/resource/amp3/0/0/24/f1/24f13ed38651c85860749d97dfe308e8.mp3','一……就……','','');----
INSERT INTO classwords VALUES ('2690df8e3e5a4cd78ef4a0c45c327a9a','ed50c069129e4f65a02d59c97868adf0','141');----
INSERT INTO word VALUES ('202b9862f089411aa614af1c8bf8ad70','from now on','[frɔm nau ɔn]','http://res.iciba.com/resource/amp3/0/0/fa/ad/faad5ad56b8c73bce5eaebf02142edf5.mp3','从今以后，今后','','');----
INSERT INTO classwords VALUES ('81d614391a104e18a85b2fd0294a7e72','202b9862f089411aa614af1c8bf8ad70','141');----
INSERT INTO word VALUES ('3a1559f11da7495d8fc2e1794600701f','sooner or lat...','[ˈsu:nə ɔ: ˈleitə]','http://res-tts.iciba.com/a/0/c/a0c95377df42ebdde1d92e75882c9f45.mp3','迟早，早晚','','');----
INSERT INTO classwords VALUES ('93568e2fba924f868c7bf0b852202f04','3a1559f11da7495d8fc2e1794600701f','141');----
INSERT INTO word VALUES ('c2c90955768743d98bc78b68b9675c7e','so long as','[səʊ lɔŋ æz]','http://res.iciba.com/resource/amp3/0/0/f4/67/f467d6a633756249c727674c59bfee3c.mp3','只要','','');----
INSERT INTO classwords VALUES ('c5f52f29401e4744939d6269bce2f0f1','c2c90955768743d98bc78b68b9675c7e','141');----
INSERT INTO word VALUES ('a319322f9d4247bd9378ed0daf670903','as a result','[æz ə riˈzʌlt]','http://res.iciba.com/resource/amp3/0/0/a8/af/a8af6a2a396546732e6a8f2f80ee9662.mp3','（作为）结果','','');----
INSERT INTO classwords VALUES ('df5e9239fb854997b89e02430645efeb','a319322f9d4247bd9378ed0daf670903','141');----
INSERT INTO word VALUES ('1d860dc3b642416aa34143b124b198d2','carry on','[ˈkæri ɔn]','http://res.iciba.com/resource/amp3/0/0/4a/0e/4a0e02c055688cce77335f7f2c41e58b.mp3','继续下去; 继续开展','','');----
INSERT INTO classwords VALUES ('cde6b46a74d64f179e67c420ba684e38','1d860dc3b642416aa34143b124b198d2','141');----
INSERT INTO word VALUES ('db9ca97254244588ade61585d6fe1b99','next to','[nekst tu:]','http://res.iciba.com/resource/amp3/0/0/c9/e2/c9e244f799835714073e72b1921a8704.mp3','紧接着，相邻，次于','','');----
INSERT INTO classwords VALUES ('f66e56df24c04c278d043a99fb2eae8c','db9ca97254244588ade61585d6fe1b99','141');----
INSERT INTO word VALUES ('966b46b93849487e8aeb010d9eb69c5e','break away fr...','[breik əˈwei frɔm]','http://res-tts.iciba.com/f/d/6/fd66575b05175e2ad2102658ebda931e.mp3','脱离……','','');----
INSERT INTO classwords VALUES ('7a7e4c2d9fc34e32bbd43c5fc5db6f0a','966b46b93849487e8aeb010d9eb69c5e','141');----
INSERT INTO word VALUES ('4125e5239d96439da32b901ada1ad017','break in','[breik in]','http://res.iciba.com/resource/amp3/0/0/0e/24/0e24b1d22f59c9440ea7133eed842750.mp3','闯入，强行进入，插嘴，打断','','');----
INSERT INTO classwords VALUES ('0141883307194a26b896653ef8dd72a4','4125e5239d96439da32b901ada1ad017','141');----
INSERT INTO word VALUES ('668da0ca4f844bf1be612fa008417735','fill ... with...','[breik in]','','用……填充','','');----
INSERT INTO classwords VALUES ('387b84faa036429691320d03a5039c2d','668da0ca4f844bf1be612fa008417735','141');----
INSERT INTO word VALUES ('7cfdae7d0e7a486188c87b6bd9636325','from then on','[frɔm ðen ɔn]','http://res.iciba.com/resource/amp3/0/0/eb/9f/eb9fd3016d12557bdca4e2e199a61499.mp3','从那时起','','');----
INSERT INTO classwords VALUES ('77f989a33e484cc38e9f1e2142a2724a','7cfdae7d0e7a486188c87b6bd9636325','141');----
INSERT INTO word VALUES ('e31237ab2c5049a6a768a491bfe4f784','regard... as','[frɔm ðen ɔn]','','把……看作','','');----
INSERT INTO classwords VALUES ('1ee4cbeb739c4c87a2b670733f8f76dd','e31237ab2c5049a6a768a491bfe4f784','141');----
INSERT INTO word VALUES ('45c96b843764400a8293411242212f8e','face to face','[feis tu: feis]','http://res.iciba.com/resource/amp3/0/0/d3/88/d388edf5afa5fd99c68be208c8595cfa.mp3','面对面','','');----
INSERT INTO classwords VALUES ('fd13f112d1df417f929a9b1e08272cdc','45c96b843764400a8293411242212f8e','141');----
INSERT INTO word VALUES ('fde1533fa0434eb1a26869679357abfb','not so...as','[feis tu: feis]','','不像，不如','','');----
INSERT INTO classwords VALUES ('1ff8b9048b58492f8b0bc24da0ac6fde','fde1533fa0434eb1a26869679357abfb','141');----
INSERT INTO word VALUES ('b62ea79f53054ef7bac5efc592934b70','come up with','[kʌm ʌp wið]','http://res.iciba.com/resource/amp3/0/0/b0/59/b059a9afa191519f6bf63bd3c4669fa8.mp3','追上，赶上；想出（主意）；找出（答案） ...','','');----
INSERT INTO classwords VALUES ('df20a6ec371a4c9fac6568a82ebf6848','b62ea79f53054ef7bac5efc592934b70','141');----
INSERT INTO word VALUES ('52d2700fed5449488d1515a7d162b076','put off','[put ɔf]','http://res.iciba.com/resource/amp3/0/0/44/ad/44adabc905dfefc327bc915f31262499.mp3','推迟','','');----
INSERT INTO classwords VALUES ('7ebd8538444b4da08b906a7a88de017c','52d2700fed5449488d1515a7d162b076','141');----
INSERT INTO word VALUES ('d1d42b05ff914508b62846dd1a5f33b0','help...out','[put ɔf]','','帮助某人解决困难','','');----
INSERT INTO classwords VALUES ('3ffcb6bac4ed4c3c8a858cd8f4a3584d','d1d42b05ff914508b62846dd1a5f33b0','141');----
INSERT INTO word VALUES ('bc881981bd324cddbb9050473e3c6e70','hear from','[hiə frɔm]','http://res.iciba.com/resource/amp3/0/0/60/cb/60cb29239d2a7de5159605c75ae38c25.mp3','收到……的来信','','');----
INSERT INTO classwords VALUES ('893d5f5929754a9b86842508c30cec68','bc881981bd324cddbb9050473e3c6e70','141');----
INSERT INTO word VALUES ('5935cb6b827040d1ba6c406ec40fb5b8','even though','[ˈi:vən ðəu]','http://res-tts.iciba.com/e/5/8/e5866395d694695aa637d925e97ffb5a.mp3','即使，尽管','','');----
INSERT INTO classwords VALUES ('7da6937db86941fea961da1a3c6e385b','5935cb6b827040d1ba6c406ec40fb5b8','141');----
INSERT INTO word VALUES ('675d428516ac4300ac846868ba4bc140','by air','[bai eə(r)]','http://res.iciba.com/resource/amp3/0/0/49/a9/49a98b981d2e5dab9b9b7d4158256c01.mp3','乘飞机','','');----
INSERT INTO classwords VALUES ('499869ec227642b9879031cb7fa3945e','675d428516ac4300ac846868ba4bc140','141');----
INSERT INTO word VALUES ('d4462ec162ee49fead1438414e86b834','get back','[ɡet bæk]','http://res.iciba.com/resource/amp3/0/0/84/57/84578ce6cf9960f8e409f4911fe947da.mp3','返回; 回来; 回家','','');----
INSERT INTO classwords VALUES ('15d70e2d49694df8b3245b64e17228bd','d4462ec162ee49fead1438414e86b834','141');----
INSERT INTO word VALUES ('73788e45bbe844d2b994055205451c43','change into','[tʃeindʒ ˈɪntuː]','http://res.iciba.com/resource/amp3/0/0/27/05/2705ca40b2ea0e391db7131182b8cfed.mp3','转换成，把…变成','','');----
INSERT INTO classwords VALUES ('8f2f7cbaed73400a9aeeb514b14da274','73788e45bbe844d2b994055205451c43','141');----
INSERT INTO word VALUES ('4f05e382f81045ac89de12763a2ab1b8','due to','[dju: tu:]','http://res-tts.iciba.com/5/2/2/52240cd4b527c97395eacc1291cb9c26.mp3','由于，因为','','');----
INSERT INTO classwords VALUES ('8b2ca2d2fa4849a4ac442505af611d05','4f05e382f81045ac89de12763a2ab1b8','141');----
INSERT INTO word VALUES ('8884f6b89e94401195f04599c68cf988','take the plac...','[teik ðə pleis ɔv]','http://res.iciba.com/resource/amp3/0/0/26/e6/26e6f1953748ad7993bec2742e995964.mp3','取代，代替','','');----
INSERT INTO classwords VALUES ('b2745fc7e7aa468ea4aa64d8280f56d8','8884f6b89e94401195f04599c68cf988','141');----
INSERT INTO word VALUES ('5099dc728a8e490892f2a71bf4b0f800','put down','[put daun]','http://res.iciba.com/resource/amp3/0/0/e4/c5/e4c5be348abc4b35771019e2bffbccbc.mp3','记下','','');----
INSERT INTO classwords VALUES ('bbea1384cd5c41d9be5c4c20ae7004ea','5099dc728a8e490892f2a71bf4b0f800','141');----
INSERT INTO word VALUES ('de249465243b4207b584248859e2a264','turn up','[tə:n ʌp]','http://res.iciba.com/resource/amp3/1/0/05/52/05527875cf4aae455370251f7c802001.mp3','到达，来到；开大（声音）','','');----
INSERT INTO classwords VALUES ('fa31b795d93a402d92538d34a17cb46f','de249465243b4207b584248859e2a264','141');----
INSERT INTO word VALUES ('2308ec78c2df447fbc76cc6611fb884b','go for','[ɡəu fɔ:]','http://res.iciba.com/resource/amp3/0/0/93/87/9387151f8677a651ad0d6fb40111837f.mp3','主张','','');----
INSERT INTO classwords VALUES ('eae11a6767c34501bd257101dd3f0ee6','2308ec78c2df447fbc76cc6611fb884b','141');----
INSERT INTO word VALUES ('bb61332dcdbc4fb1addc1e18591ac7bf','in public','[in ˈpʌblik]','http://res.iciba.com/resource/amp3/0/0/09/26/0926b816624b02dc24677af90e917e90.mp3','当众；公开','','');----
INSERT INTO classwords VALUES ('c861187f840445eb8bfc4f97705d3574','bb61332dcdbc4fb1addc1e18591ac7bf','141');----
INSERT INTO word VALUES ('c8c8d0c693d442bdb727be145a0199ce','come down','[kʌm daun]','http://res.iciba.com/resource/amp3/0/0/85/6e/856eb24f8deb24806b0e0347313eba1b.mp3','落，下来','','');----
INSERT INTO classwords VALUES ('d966f2ef28f04ded8229df460bd4cf0f','c8c8d0c693d442bdb727be145a0199ce','141');----
INSERT INTO word VALUES ('fdfa0a3a5a3b40c588d4554d2fd556ce','pay back','[pei bæk]','http://res.iciba.com/resource/amp3/0/0/a1/56/a1563907f99b050a167186f34885fe6e.mp3','偿还（借款等）','','');----
INSERT INTO classwords VALUES ('412682e948e2471c81c73bbc3d820d02','fdfa0a3a5a3b40c588d4554d2fd556ce','141');----
INSERT INTO word VALUES ('58096bb51fc74a0f96e7bffdd2448bdf','more or less','[mɔ: ɔ: les]','http://res.iciba.com/resource/amp3/0/0/41/dd/41dd4bb13058a0040c57baae65050137.mp3','或多或少','','');----
INSERT INTO classwords VALUES ('930f452203a74d6eba0c5947b4ae42df','58096bb51fc74a0f96e7bffdd2448bdf','141');----
INSERT INTO word VALUES ('ca5e31442f3145048b8ee1be4f837f27','a kind of','[ə kaind ɔv]','http://res-tts.iciba.com/5/e/e/5ee16c6f899d372bb3a5d800f2a8e0c9.mp3','一种，一类','','');----
INSERT INTO classwords VALUES ('ec1a0fffef0c427e9de66f921ce7edf0','ca5e31442f3145048b8ee1be4f837f27','141');----
INSERT INTO word VALUES ('7c5ff9db9f8b4f7f9d1a049d453df8c2','pay attention...','[pei əˈtenʃən tu:]','http://res.iciba.com/resource/amp3/0/0/31/5b/315b8d3e829b92b88756600b865fabcf.mp3','注意','','');----
INSERT INTO classwords VALUES ('67c011a2c1a74c73b2d648a9371f0ab1','7c5ff9db9f8b4f7f9d1a049d453df8c2','141');----
INSERT INTO word VALUES ('17532342a5ff4b07aa7c5428214e2e62','different fro...','[ˈdifərənt frɔm]','http://res-tts.iciba.com/6/5/4/65439ed619063e1287aa60b756c9eaf3.mp3','与……不同','','');----
INSERT INTO classwords VALUES ('c229507393eb4e0d88934ee6e331a18f','17532342a5ff4b07aa7c5428214e2e62','141');----
INSERT INTO word VALUES ('165a9c828dac4a0a88aa819add1ba520','knock at','[nɔk æt]','http://res-tts.iciba.com/c/3/b/c3bf14aa5630ab67a282cd597862c8ef.mp3','敲','','');----
INSERT INTO classwords VALUES ('41ef23a57ee74d8497111c84dad5ce0e','165a9c828dac4a0a88aa819add1ba520','141');----
INSERT INTO word VALUES ('1ddbf3e977b5439383498901391ca886','in order to','[in ˈɔ:də tu:]','http://res.iciba.com/resource/amp3/0/0/a3/13/a3138ab4fdbfb1e7a02598d3b004dcc3.mp3','为了','','');----
INSERT INTO classwords VALUES ('b9d335064acd49508234f9a5062fbeee','1ddbf3e977b5439383498901391ca886','141');----
INSERT INTO word VALUES ('3b40c1103ca44f4c978cbdd62490da3d','all right','[ɔ:l rait]','http://res.iciba.com/resource/amp3/0/0/67/78/67787c5a3a7b3a7cea96d77aa1f6d338.mp3','行,好吧，（病）好了','','');----
INSERT INTO classwords VALUES ('ab0238c9d31944d1b86cf81328c7282a','3b40c1103ca44f4c978cbdd62490da3d','141');----
INSERT INTO word VALUES ('6fc16b27a39242978134f429bd688adb','pick up','[pik ʌp]','http://res.iciba.com/resource/amp3/0/0/e3/cf/e3cf48bb1f3593ae49166794aded6d73.mp3','拾起，捡起, 接收；开车去接……','','');----
INSERT INTO classwords VALUES ('baac2553cb3a477098d0717cb8f7e5db','6fc16b27a39242978134f429bd688adb','141');----
INSERT INTO word VALUES ('c787481f0fd7411cbbffbfd3ed547388','set up settle...','','','建立创立 定居，平静下来','','');----
INSERT INTO classwords VALUES ('2dcb01e215fc439cbb6e62dc22c2afaa','c787481f0fd7411cbbffbfd3ed547388','141');----
INSERT INTO word VALUES ('1ff889c1c8e344e3b00e273068b5f951','come out','[kʌm aut]','http://res.iciba.com/resource/amp3/0/0/3f/1b/3f1bd609c8d6081876afedfe0e952b3a.mp3','出来,(书)出版，发行','','');----
INSERT INTO classwords VALUES ('db62a6f7af5e493a8ec06fb80a24c5c2','1ff889c1c8e344e3b00e273068b5f951','141');----
INSERT INTO word VALUES ('2c2b9df783924902a67bf8f4a3f39829','a piece of','[ə pi:s ɔv]','http://res-tts.iciba.com/7/a/c/7acb053eaebfd283d43b5b1d08613e8d.mp3','一块(张，根，片)','','');----
INSERT INTO classwords VALUES ('cf167ac2d46c41ba9049d49249582a55','2c2b9df783924902a67bf8f4a3f39829','141');----
INSERT INTO word VALUES ('cabcea9a58374765a2e62029cdac469a','talk of','[tɔ:k ɔv]','http://res-tts.iciba.com/0/a/a/0aaeea5185c4918f18c270f42f62fe84.mp3','谈论，议论','','');----
INSERT INTO classwords VALUES ('e18acd033cf64dc288f14dc870a6771c','cabcea9a58374765a2e62029cdac469a','141');----
INSERT INTO word VALUES ('0dc534fcc0ec4421b0cff7b5f5306743','divide...into...','','http://res-tts.iciba.com/f/0/b/f0bc6839bcf9dda4682bd03294b5bac7.mp3','把……分成……','','');----
INSERT INTO classwords VALUES ('8d6c3e48780844dfa11ea2a5422c36b8','0dc534fcc0ec4421b0cff7b5f5306743','141');----
INSERT INTO word VALUES ('f5f026d49ec34d58b1ccba80909d8de5','agree to do s...','','','同意做某事','','');----
INSERT INTO classwords VALUES ('a644906f4597410d86cbd5843dc0a13a','f5f026d49ec34d58b1ccba80909d8de5','141');----
INSERT INTO word VALUES ('cc05ff759eca49a5b14f0ee265108eb9','a pair of','[ə pɛə ɔv]','http://res-tts.iciba.com/1/a/4/1a4e0b4d7f0550f20c8551c339e84694.mp3','一双，一副','','');----
INSERT INTO classwords VALUES ('51881bb3d0404c0ba80f2f9eb82b1331','cc05ff759eca49a5b14f0ee265108eb9','141');----
INSERT INTO word VALUES ('0ed27978a93a45ef95db7d8156a4cd8a','find out','[faind aut]','http://res.iciba.com/resource/amp3/0/0/5a/d2/5ad2c5b490a54c67c04e0f5b9780a35f.mp3','查明，发现，了解','','');----
INSERT INTO classwords VALUES ('dff521035b4945ea850b54895c00ac9e','0ed27978a93a45ef95db7d8156a4cd8a','141');----
INSERT INTO word VALUES ('192401b79fb9404487348dca895abb14','knock into sb...','','','撞上','','');----
INSERT INTO classwords VALUES ('4fae5dc30c1c4355a3c1237d5655694f','192401b79fb9404487348dca895abb14','141');----
INSERT INTO word VALUES ('9c09ed4935e0476383b7d4c4153103b2','give in','[ɡiv in]','http://res.iciba.com/resource/amp3/0/0/50/65/506577a183061a715d54a6ce4307ad36.mp3','屈服，让步','','');----
INSERT INTO classwords VALUES ('b951f3c307e94367a0bc1cd21eb52c94','9c09ed4935e0476383b7d4c4153103b2','141');----
INSERT INTO word VALUES ('320b8413e19d4e9ca7e67bf0ae5a4597','by accident','[bai ˈæksidənt]','http://res.iciba.com/resource/amp3/0/0/e4/f1/e4f13d1238b751c94c365b611bc5af53.mp3','偶然','','');----
INSERT INTO classwords VALUES ('5e15e4b1ca4c4b74addb19e5dbafa0b6','320b8413e19d4e9ca7e67bf0ae5a4597','141');----
INSERT INTO word VALUES ('80a30680f9d447c1a3d7250f0d0826b6','bring on','[briŋ ɔn]','http://res.iciba.com/resource/amp3/0/0/41/52/4152ff948163297b0bfc9c385c8f2c1f.mp3','引起，导致，使前进','','');----
INSERT INTO classwords VALUES ('3b4c08a7311f4973a99c57726a5baa80','80a30680f9d447c1a3d7250f0d0826b6','141');----
INSERT INTO word VALUES ('58f857a287ab4a209a0ecbed492ff060','have to','[ˈhæv tə]','http://res.iciba.com/resource/amp3/oxford/0/5c/7f/5c7f422788b4b656a9b487eb387d8ed0.mp3','不得不；必须','','');----
INSERT INTO classwords VALUES ('bc28402fc9e54433a7eba4e1313a3897','58f857a287ab4a209a0ecbed492ff060','141');----
INSERT INTO word VALUES ('205222db802e4b3fa21b211a8627e606','a few','[ə fju:]','http://res-tts.iciba.com/d/3/2/d32356ae23a439134548ebfa140807d0.mp3','一些，少量','','');----
INSERT INTO classwords VALUES ('2551c5106fb842dfb259a8a322f6b142','205222db802e4b3fa21b211a8627e606','141');----
INSERT INTO word VALUES ('8e15135d5b144c5aab12d2f1559fa86a','on time','[ɔn taim]','http://res.iciba.com/resource/amp3/0/0/f8/62/f862d2178ec3e62f06ca531fcdfb5abf.mp3','准时','','');----
INSERT INTO classwords VALUES ('40263e70aaf94b8fa7ad9797f2ee1e10','8e15135d5b144c5aab12d2f1559fa86a','141');----
INSERT INTO word VALUES ('974d853481c1465c898de069d196d46a','go over','[ɡəu ˈəuvə]','http://res.iciba.com/resource/amp3/0/0/4d/ea/4deabe70a30da612c00f421964c15ca4.mp3','仔细检查，复习','','');----
INSERT INTO classwords VALUES ('041209b680154bcdac2f31d39743df24','974d853481c1465c898de069d196d46a','141');----
INSERT INTO word VALUES ('8760258fa42640ac9ed912bb0dd79816','keep up','[ki:p ʌp]','http://res.iciba.com/resource/amp3/0/0/ea/80/ea8021151b3ead7b373e4d21970e8c4a.mp3','保持; 维持; 继续','','');----
INSERT INTO classwords VALUES ('f3dd7b98e64a46c3b9e3a0f8594819b9','8760258fa42640ac9ed912bb0dd79816','141');----
INSERT INTO word VALUES ('a1e17dd8c86d41fe97549ef3a243deb9','a lot of','[ə lɔt ɔv]','http://res-tts.iciba.com/6/3/a/63af6f4b77006e73ac28fdfac900cb4c.mp3','许多，大量','','');----
INSERT INTO classwords VALUES ('4a7089653fed4cd3b7e7ea6811f8ea46','a1e17dd8c86d41fe97549ef3a243deb9','141');----
INSERT INTO word VALUES ('4679727fbe01457583721f6e34d756e8','prevent ... f...','[ə lɔt ɔv]','','妨碍,,防止,,预防','','');----
INSERT INTO classwords VALUES ('a7aed56763c44cb6bbcddfba385badf5','4679727fbe01457583721f6e34d756e8','141');----
INSERT INTO word VALUES ('6ff44ea9f4bd49c5a6343a77decbb6e9','add up to','[æd ʌp tu:]','http://res.iciba.com/resource/amp3/0/0/d8/72/d8721479e748ca3e2e13ac994909c339.mp3','合计达……','','');----
INSERT INTO classwords VALUES ('d4c1ce5737ab44789d010eeb11e2a17a','6ff44ea9f4bd49c5a6343a77decbb6e9','141');----
INSERT INTO word VALUES ('a4394de6a493495d9ce53f2dcfbd708a','get through','[ɡet θru:]','http://res.iciba.com/resource/amp3/0/0/36/7a/367ac5fe6beadc1db90aac6dc9fa3f84.mp3','通过，拨通（电话）','','');----
INSERT INTO classwords VALUES ('c264bf932ac74f4eb4890301ae83dee9','a4394de6a493495d9ce53f2dcfbd708a','141');----
INSERT INTO word VALUES ('836ba820ac1a49cfbb5c64f7c5066cd0','put on','[put ɔn]','http://res.iciba.com/resource/amp3/0/0/eb/d3/ebd3e097113faefd1925035941e048f0.mp3','穿，戴上，上演','','');----
INSERT INTO classwords VALUES ('1daf4f01a52f407291c9d464b86c4e72','836ba820ac1a49cfbb5c64f7c5066cd0','141');----
INSERT INTO word VALUES ('31dbc4b74ec541d592c26b8942731f98','out of work','[aut ɔv wə:k]','http://res.iciba.com/resource/amp3/0/0/c3/c2/c3c2d8a855e45f490928e17d0e8065c6.mp3','失业','','');----
INSERT INTO classwords VALUES ('be890142a3944397a5a7dc9e6f0b162c','31dbc4b74ec541d592c26b8942731f98','141');----
INSERT INTO word VALUES ('3a9b62e815aa4b81aaedc182d35029a2','such as','[sʌtʃ æz]','http://res.iciba.com/resource/amp3/0/0/0b/be/0bbe6fca13f94373a18a92d9d72eaa1e.mp3','例如','','');----
INSERT INTO classwords VALUES ('1e4808ed598d489cb42812377fbf06d4','3a9b62e815aa4b81aaedc182d35029a2','141');----
INSERT INTO word VALUES ('962b6ca02cf54e0e801c2e8b03f13963','live on','[liv ɔn]','http://res.iciba.com/resource/amp3/0/0/93/24/93242002069b2adf658ee1d716b3a0a1.mp3','以…为主食，靠…为生','','');----
INSERT INTO classwords VALUES ('e9e745f5dba8454cb9838357231dbe45','962b6ca02cf54e0e801c2e8b03f13963','141');----
INSERT INTO word VALUES ('649e99b8107042148c397342c506797b','used to sth.','','','习惯于','','');----
INSERT INTO classwords VALUES ('0ad43452b3f64d32a98b48e02d7b2fba','649e99b8107042148c397342c506797b','141');----
INSERT INTO word VALUES ('a58e5d9faad3458aa7b7777a9ab757cc','take sb. in t...','','','搂抱','','');----
INSERT INTO classwords VALUES ('6b6e995dc0b643cb9b0b0bcbfcf89634','a58e5d9faad3458aa7b7777a9ab757cc','141');----
INSERT INTO word VALUES ('995d30d58b2d432088a928f64bfed6d1','have a gift f...','[hæv ə ɡift fɔ:]','http://res.iciba.com/resource/amp3/0/0/8c/93/8c931faaf34907e63671692a8ef1949c.mp3','对……有天赋','','');----
INSERT INTO classwords VALUES ('565584d9aea34dc3ac06e9b7df9ce2d1','995d30d58b2d432088a928f64bfed6d1','141');----
INSERT INTO word VALUES ('682868f7045c49e18385a86925137323','connect with','[kəˈnekt wið]','http://res.iciba.com/resource/amp3/0/0/cf/49/cf498faab75ee066b07a546cbaf34aa6.mp3','与……相连','','');----
INSERT INTO classwords VALUES ('e33381f2e6684452a7c0f1a5dc68f0dc','682868f7045c49e18385a86925137323','141');----
INSERT INTO word VALUES ('cb744137d358425b8bb8d4e05d9eb701','hold up','[həuld ʌp]','http://res.iciba.com/resource/amp3/0/0/d9/29/d929c03cb73b773897e1be72d46241fa.mp3','阻挡，使停顿','','');----
INSERT INTO classwords VALUES ('8d634b5e28994e5693e030b4d6f1dbc9','cb744137d358425b8bb8d4e05d9eb701','141');----
INSERT INTO word VALUES ('f1e6174f2a3e4817b21f15e6e51e302b','so...that','','http://res-tts.iciba.com/7/3/8/738a74d88fcad66a03e90cc106179e82.mp3','太……以至于……','','');----
INSERT INTO classwords VALUES ('85daec88914d497f957448a2e7be77e7','f1e6174f2a3e4817b21f15e6e51e302b','141');----
INSERT INTO word VALUES ('34dea9997c49432ab5b672018abaa5be','run out of','[rʌn aut ɔv]','http://res.iciba.com/resource/amp3/0/0/22/de/22de1402f5c516aa56a7b4b03d967d56.mp3','用完','','');----
INSERT INTO classwords VALUES ('90e344564c6d443abd3c79c5e11a20d1','34dea9997c49432ab5b672018abaa5be','141');----
INSERT INTO word VALUES ('68544b5b7f8a44c88b58ffcf42ca2ccc','once again','[wʌns əˈɡen]','http://res.iciba.com/resource/amp3/0/0/d8/53/d8531b3941d19ac2fe920c503d3d3d4e.mp3','再一次','','');----
INSERT INTO classwords VALUES ('19e818b33f8a4271b32894b5922e8874','68544b5b7f8a44c88b58ffcf42ca2ccc','141');----
INSERT INTO word VALUES ('bf4cfba51499464f96d7e92625ad5a75','over and over...','','http://res.iciba.com/resource/amp3/0/0/e0/21/e021c7e63887ff4bf77a827929fe7589.mp3','反复，多次重复','','');----
INSERT INTO classwords VALUES ('3d1c14b540cb45d683ca2bc8041e6864','bf4cfba51499464f96d7e92625ad5a75','141');----
INSERT INTO word VALUES ('f94a0f09b8534f0abe6f66b567bf78b8','have classes','','','上课','','');----
INSERT INTO classwords VALUES ('f47242f0e8924837b09be464222e0736','f94a0f09b8534f0abe6f66b567bf78b8','141');----
INSERT INTO word VALUES ('c09d7739c9b94c62981d9098c926c065','point to','[pɔint tu:]','http://res.iciba.com/resource/amp3/0/0/99/a1/99a1815243a7c4d9f534c9ed7f0a1634.mp3','指向','','');----
INSERT INTO classwords VALUES ('175f4d46d63a4afabce297d1a59d2024','c09d7739c9b94c62981d9098c926c065','141');----
INSERT INTO word VALUES ('6cdb66bac9ca4f48ac7e5a4def1948a1','as...as','','http://res-tts.iciba.com/8/5/d/85d1b82309997b057945da1916bfdbad.mp3','像，如同','','');----
INSERT INTO classwords VALUES ('5d94c15513464f3a8b0c763e14afaa4f','6cdb66bac9ca4f48ac7e5a4def1948a1','141');----
INSERT INTO word VALUES ('419dd042758e4708a2432230002da384','do some clean...','','','做扫除（买东西）','','');----
INSERT INTO classwords VALUES ('7a145e6b6a994a5cbbc7f406a52ee1b1','419dd042758e4708a2432230002da384','141');----
INSERT INTO word VALUES ('1bc77a4f75744df2999a4ae9351bd285','come off','[kʌm ɔf]','http://res.iciba.com/resource/amp3/0/0/73/de/73de03fccc931d0c805cc1f80b4da222.mp3','从…离开，脱落','','');----
INSERT INTO classwords VALUES ('9b686de1dfa64cb095070f06f84a0979','1bc77a4f75744df2999a4ae9351bd285','141');----
INSERT INTO word VALUES ('bfa68ca350e9429fa94bb9da3b3b9d60','struggle agai...','[ˈstrʌɡl əˈɡenst]','http://res-tts.iciba.com/7/8/b/78b6da010d48b46c7ad344d7a214f226.mp3','同……作斗争','','');----
INSERT INTO classwords VALUES ('3a7bbe15fd5f47f699ed93ba1e732ebb','bfa68ca350e9429fa94bb9da3b3b9d60','141');----
INSERT INTO word VALUES ('47c1840b24be408583a812ebef03ad0d','look out','[luk aut]','http://res.iciba.com/resource/amp3/0/0/fc/22/fc221f09a3353c9ff905d5cae86f4a0a.mp3','留神，当心','','');----
INSERT INTO classwords VALUES ('b0f5db10823e4b39b4aacf65d85a891f','47c1840b24be408583a812ebef03ad0d','141');----
INSERT INTO word VALUES ('b981a2d4a76e4163b0b39037a09fe285','call for','[kɔ:l fɔ:]','http://res.iciba.com/resource/amp3/0/0/88/bd/88bd4d0ec2ebb751d1f6b2891891aa1f.mp3','提倡，号召, 需要','','');----
INSERT INTO classwords VALUES ('9d2ec0f981e542968a0fd9d379608192','b981a2d4a76e4163b0b39037a09fe285','141');----
INSERT INTO word VALUES ('3e7fba7b5d84463c915ae45ed0aa60e7','out of breath...','[aut ɔv breθ]','http://res.iciba.com/resource/amp3/0/0/39/93/3993f0a15439f30c62fbe29ee8ab336f.mp3','上气不接下气','','');----
INSERT INTO classwords VALUES ('d36ffbd13c7442b5be109a6d510c873b','3e7fba7b5d84463c915ae45ed0aa60e7','141');----
INSERT INTO word VALUES ('7da3b903b37141a690acbc4f80c8483e','ahead of','[əˈhed ɔv]','http://res.iciba.com/resource/amp3/0/0/97/92/9792c3e1358b1040a5152a28f54bc3eb.mp3','在……之前','','');----
INSERT INTO classwords VALUES ('ce35c9ce3e22491db1dcd4e2713af105','7da3b903b37141a690acbc4f80c8483e','141');----
INSERT INTO word VALUES ('d5f09988be7b4c57a97d4262588caa4d','all the best','[ɔ:l ðə best]','http://res.iciba.com/resource/amp3/0/0/39/f8/39f8775a67429e4476fd9339431472dc.mp3','一切顺利，万事如意','','');----
INSERT INTO classwords VALUES ('617d5accc7564fd5be3965cd76c25551','d5f09988be7b4c57a97d4262588caa4d','141');----
INSERT INTO word VALUES ('6c8df44b1f8b433885d78c563bf8415c','sell out','[sel aut]','http://res.iciba.com/resource/amp3/0/0/f7/91/f7913e55dedd60cb934feb79eadda8b6.mp3','卖完, 出卖','','');----
INSERT INTO classwords VALUES ('d4827fbcaebf4e03ae0a03f611a904fe','6c8df44b1f8b433885d78c563bf8415c','141');----
INSERT INTO word VALUES ('f76c764c4598406d8986ebc2ba87b2cf','by the way','[bai ðə wei]','http://res.iciba.com/resource/amp3/0/0/ca/d9/cad97f3383c232b08a510ea0fdf75750.mp3','顺便说','','');----
INSERT INTO classwords VALUES ('8d601333eeb54085828b68972634f1e4','f76c764c4598406d8986ebc2ba87b2cf','141');----
INSERT INTO word VALUES ('3dab61593bee4ea8bbd444ee1f6c2f25','look through','[luk θru:]','http://res.iciba.com/resource/amp3/0/0/54/0f/540f7b46d806304b8c4f9cdf3ba2ac82.mp3','看穿, 浏览','','');----
INSERT INTO classwords VALUES ('4f4acf78e76446d2a18022720e5fff4d','3dab61593bee4ea8bbd444ee1f6c2f25','141');----
INSERT INTO word VALUES ('c21dd40234434ce7870e67b528315baf','far from','[fɑ: frɔm]','http://res.iciba.com/resource/amp3/0/0/b9/ad/b9ad79d9bbb99dc4e851d00328bf783e.mp3','远离','','');----
INSERT INTO classwords VALUES ('2d2e971485b343d3839beeddb798b167','c21dd40234434ce7870e67b528315baf','141');----
INSERT INTO word VALUES ('ecf93f16589b47e8a6e2648b52e702ce','as though','[æz ðəu]','http://res.iciba.com/resource/amp3/0/0/2f/af/2faf0cbe7df7b94dcce70a1ffa24ae58.mp3','好像，仿佛','','');----
INSERT INTO classwords VALUES ('bba85398cb104a3cb4a878671524167d','ecf93f16589b47e8a6e2648b52e702ce','141');----
INSERT INTO word VALUES ('aa738188624f48a8a03661570214cc0e','side by side','[said bai said]','http://res.iciba.com/resource/amp3/0/0/41/15/41159e627c3a65cf4a9aeba8b762e6d0.mp3','肩并肩，一起','','');----
INSERT INTO classwords VALUES ('b8888d4108d64e47ae99423336d553aa','aa738188624f48a8a03661570214cc0e','141');----
INSERT INTO word VALUES ('103852c84d45406bb70f23326d454e59','help sb. with...','','http://res-tts.iciba.com/8/f/3/8f3af8889abadb6891993031a0e760fd.mp3','帮助某人做某事','','');----
INSERT INTO classwords VALUES ('26e0b081697f46b6bae21fd60c934342','103852c84d45406bb70f23326d454e59','141');----
INSERT INTO word VALUES ('245d2fba587b431081efae9ac717b304','far away','[fɑ: əˈwei]','http://res.iciba.com/resource/amp3/0/0/65/f2/65f2aa14acc55b118fd0bc08cc1b7459.mp3','遥远的','','');----
INSERT INTO classwords VALUES ('aec910f185fb4bd68afbf45f6772332d','245d2fba587b431081efae9ac717b304','141');----
INSERT INTO word VALUES ('281bda16fb9145ffaef59ab7a2db9d72','point out','[pɔint aut]','http://res.iciba.com/resource/amp3/0/0/5a/24/5a241a357f672a0a8728d94e25b67d96.mp3','指出','','');----
INSERT INTO classwords VALUES ('015e4803f839403c8c749b53f293e34a','281bda16fb9145ffaef59ab7a2db9d72','141');----
INSERT INTO word VALUES ('70489293c198479b95265af0ba316134','go off','[ɡəu ɔf]','http://res.iciba.com/resource/amp3/0/0/ac/71/ac7111fb2708b55432a8f06f79ee38c2.mp3','走开','','');----
INSERT INTO classwords VALUES ('4dd62b9ebf6c454f83a75168e8a6012a','70489293c198479b95265af0ba316134','141');----
INSERT INTO word VALUES ('da5cc4b992e247058f696d6120c8127d','take place','[teik pleis]','http://res.iciba.com/resource/amp3/0/0/a4/08/a408ac81cfbc1ed758a18b36a3e725e6.mp3','发生','','');----
INSERT INTO classwords VALUES ('e25f3d0a2ca143ad94a3a4b07d80fb10','da5cc4b992e247058f696d6120c8127d','141');----
INSERT INTO word VALUES ('c21cf442f5c04d1bb81acc64d26a3ac4','wake up','[weik ʌp]','http://res.iciba.com/resource/amp3/1/0/4e/60/4e604e908ec2a7de01330cccef6aebf1.mp3','醒来','','');----
INSERT INTO classwords VALUES ('b48cc0a9bb7040f39522b574686c2c45','c21cf442f5c04d1bb81acc64d26a3ac4','141');----
INSERT INTO word VALUES ('c171c572cf754f418a38860cc38120e8','set off','[set ɔf]','http://res.iciba.com/resource/amp3/0/0/fa/3d/fa3d30cea53d70ad4a1445c2b2dfc4dd.mp3','动身，起程；使爆发','','');----
INSERT INTO classwords VALUES ('7e0a387ac2a14a649fdfb2e35f86b846','c171c572cf754f418a38860cc38120e8','141');----
INSERT INTO word VALUES ('ebb073aabef0417498d6c961a200722e','cut down','[kʌt daun]','http://res.iciba.com/resource/amp3/1/0/18/22/1822414142adf64fe1cec4969b8bf7d2.mp3','砍倒','','');----
INSERT INTO classwords VALUES ('ebd6e10932564d719d06de1807d74789','ebb073aabef0417498d6c961a200722e','141');----
INSERT INTO word VALUES ('52551da451114079ac14344157c68cf3','give away','[ɡiv əˈwei]','http://res.iciba.com/resource/amp3/0/0/34/fe/34fe2733c679d1bf71aafe2d028109e3.mp3','分发','','');----
INSERT INTO classwords VALUES ('ea22e7b0063e450e976bb8bfd8bbcc17','52551da451114079ac14344157c68cf3','141');----
INSERT INTO word VALUES ('58a2d2529cf941128793c65fe785f483','lots of','','http://res-tts.iciba.com/f/2/3/f23ab6c89fc92b69431c6e0bd83449b8.mp3','许多，大量','','');----
INSERT INTO classwords VALUES ('5b181140926a44eeaa41d455ea652a97','58a2d2529cf941128793c65fe785f483','141');----
INSERT INTO word VALUES ('e8c8c8e953ce408285ecf1eadba33342','ever since','[ˈevə sins]','http://res-tts.iciba.com/7/6/4/7646a57320ea0fc383cce850644da8fd.mp3','自那时起直到现在','','');----
INSERT INTO classwords VALUES ('5e799bff31c24b20a26e3b40e84073e1','e8c8c8e953ce408285ecf1eadba33342','141');----
INSERT INTO word VALUES ('562249d655254b15a813eba99de01d61','break out','[breik aut]','http://res.iciba.com/resource/amp3/0/0/48/f0/48f03593b0812e6c3d5f20e2d45b9af9.mp3','（战争、火灾等）突然发生，爆发','','');----
INSERT INTO classwords VALUES ('b107d48323b44fffbf8a20fcfe395863','562249d655254b15a813eba99de01d61','141');----
INSERT INTO word VALUES ('eabe1863918e40a894b9b74a0c495c91','a bit (of)','[breik aut]','','有一点，一会儿','','');----
INSERT INTO classwords VALUES ('bd628915d2e743e8a1a8f5b08fa94d7f','eabe1863918e40a894b9b74a0c495c91','141');----
INSERT INTO word VALUES ('7d2681a0056143b08e0f56888a53e58a','no doubt','','http://res.iciba.com/resource/amp3/0/0/7d/c8/7dc82bcd2b458b0a9fca5528c6672d60.mp3','无疑地','','');----
INSERT INTO classwords VALUES ('f7a08bd882d243319a7e37d504cb338c','7d2681a0056143b08e0f56888a53e58a','141');----
INSERT INTO word VALUES ('732bee6cf9f54b5eaf63d296594f9a1f','throw away','[θrəu əˈwei]','http://res.iciba.com/resource/amp3/1/0/47/07/4707cd69d39a4acad59aef79a15775ae.mp3','扔掉','','');----
INSERT INTO classwords VALUES ('edddbebf609a47acb53b80bd57eef874','732bee6cf9f54b5eaf63d296594f9a1f','141');----
INSERT INTO word VALUES ('96746f69395c49779a42e4c08fa32331','have got to','[hæv gɔt tu:]','http://res-tts.iciba.com/1/b/0/1b0b026d163c8a18e889e73fbdeac5ff.mp3','不得不；必须','','');----
INSERT INTO classwords VALUES ('77dd76a87f09449ab518657ed09654b8','96746f69395c49779a42e4c08fa32331','141');----
INSERT INTO word VALUES ('242977d16ea44bc2bce89a7a5237f17c','either...or','','http://res-tts.iciba.com/3/7/8/378fb3e0b8de2103b19be40aaca6c218.mp3','或者……或者……','','');----
INSERT INTO classwords VALUES ('d3d9b3deaa174c52915f72c032919ff6','242977d16ea44bc2bce89a7a5237f17c','141');----
INSERT INTO word VALUES ('dd4e5c3dd82447b6b5d3229fddd00063','give out','[ɡiv aut]','http://res.iciba.com/resource/amp3/0/0/2d/6e/2d6ea4238eebbb080e08da91499301cc.mp3','分发','','');----
INSERT INTO classwords VALUES ('2d1ada14666147a3a8297f6d5ff22e12','dd4e5c3dd82447b6b5d3229fddd00063','141');----
INSERT INTO word VALUES ('583c014452fb47a3ba48bc30a96d5e97','the day befor...','','http://res.iciba.com/resource/amp3/0/0/86/62/8662dbb265603f8b9efaf78b93b1d088.mp3','前天','','');----
INSERT INTO classwords VALUES ('85613dc59098439fb9e27b857ef1432a','583c014452fb47a3ba48bc30a96d5e97','141');----
INSERT INTO word VALUES ('966c69400cf9400aa27567b650c3eacf','not until','[nɔt ənˈtil]','http://res-tts.iciba.com/0/b/6/0b6acf926ae27ff3ab89575078d90700.mp3','直到……才','','');----
INSERT INTO classwords VALUES ('58632f833e1644a596c292f66cf5b8fe','966c69400cf9400aa27567b650c3eacf','141');----
INSERT INTO word VALUES ('477e69cc2c364fa1bb2c5df1c45d0f4f','make up','[meik ʌp]','http://res.iciba.com/resource/amp3/0/0/2e/9d/2e9d335be8c5d384ed7b6df0a31c9696.mp3','和解，化装','','');----
INSERT INTO classwords VALUES ('cf443a04ac464b8682f2a114ea7d1f60','477e69cc2c364fa1bb2c5df1c45d0f4f','141');----
INSERT INTO word VALUES ('282ab40c20db44c7a637d214bffe6d98','belong to','[biˈlɔŋ tu:]','http://res.iciba.com/resource/amp3/0/0/6d/e6/6de67cdcae9555b3e7908d4bd29290bd.mp3','属于','','');----
INSERT INTO classwords VALUES ('c41a9fcf8b1043d4ab397cad3c2af6e6','282ab40c20db44c7a637d214bffe6d98','141');----
INSERT INTO word VALUES ('4cf4c44729e24e739a02d8f1b5da350b','hang on','[hæŋ ɔn]','http://res.iciba.com/resource/amp3/0/0/20/df/20df2fb162ce67d279eb0ecef66ae6a3.mp3','（打电话时）不挂断，等待片刻','','');----
INSERT INTO classwords VALUES ('058fee3d5ed943f893ae7917a66ca36b','4cf4c44729e24e739a02d8f1b5da350b','141');----
INSERT INTO word VALUES ('3bdcf5715f1c4cb29c9cf6341ff9c66a','of course','[ɔv kɔː(r)s]','http://res.iciba.com/resource/amp3/0/0/0c/a9/0ca964bb74251fce6bb741c97e1cb4b8.mp3','当然','','');----
INSERT INTO classwords VALUES ('9e627cacecf14821b603267f652f8371','3bdcf5715f1c4cb29c9cf6341ff9c66a','141');----
INSERT INTO word VALUES ('008755108ef9463cadce10063c608370','catch up with...','[kætʃ ʌp wið]','http://res.iciba.com/resource/amp3/0/0/ae/6d/ae6d4336f407e7c76e9884e62e3b60bf.mp3','赶上（或超过）','','');----
INSERT INTO classwords VALUES ('f7b126ee5dc64c92b4622f3e62875073','008755108ef9463cadce10063c608370','141');----
INSERT INTO word VALUES ('5bc9f03ff53549e49a4298641de05d17','set free','[set fri:]','http://res.iciba.com/resource/amp3/0/0/68/f1/68f16fcf7b18ef04b552377b0abb4f9b.mp3','释放，解放','','');----
INSERT INTO classwords VALUES ('636bc5325a004efbba8c74f362e2fa61','5bc9f03ff53549e49a4298641de05d17','141');----
INSERT INTO word VALUES ('ffffd6d038544338819d058c46e9c0a7','answer for','[ˈɑ:nsə fɔ:]','http://res.iciba.com/resource/amp3/0/0/44/43/444320f7d80371a413041df96e96d0c5.mp3','对……负责','','');----
INSERT INTO classwords VALUES ('5b86e1cf86a34a609bdcc96968554555','ffffd6d038544338819d058c46e9c0a7','141');----
INSERT INTO word VALUES ('546f70be4f6b4763ab739bbc8c84cc78','put on weight...','[put ɔn weit]','http://res.iciba.com/resource/amp3/0/0/36/93/3693047ecfef9960be2bcb7c14abb8c6.mp3','发福，增加体重','','');----
INSERT INTO classwords VALUES ('7385a5fa81ee412ea907387a982002ab','546f70be4f6b4763ab739bbc8c84cc78','141');----
INSERT INTO word VALUES ('3f685aa3152841328ee0fdf06f72832f','look up','[luk ʌp]','http://res.iciba.com/resource/amp3/0/0/b1/d2/b1d2bfafc04edf0032e087d532e03f40.mp3','查找','','');----
INSERT INTO classwords VALUES ('15659ed7f2eb4db5b97b179edc331234','3f685aa3152841328ee0fdf06f72832f','141');----
INSERT INTO word VALUES ('a262707e50764cd8ad335b258ee1eb57','keep off','[ki:p ɔf]','http://res.iciba.com/resource/amp3/0/0/a4/ad/a4ad8f6ddb62584ef754a2a23d29918c.mp3','勿踏; 勿踩','','');----
INSERT INTO classwords VALUES ('17e313640ba6452b9879bee70954c040','a262707e50764cd8ad335b258ee1eb57','141');----
INSERT INTO word VALUES ('ddcc2679c1b345e988e8d8a4f4ac3d0b','fall ill','[fɔ:l il]','http://res.iciba.com/resource/amp3/0/0/8b/b2/8bb22ec4d0ba3acde4c6123236507a76.mp3','患病，病倒','','');----
INSERT INTO classwords VALUES ('bba439b961194a178934f56dfb79d9d0','ddcc2679c1b345e988e8d8a4f4ac3d0b','141');----
INSERT INTO word VALUES ('7468c548365a43b480c2115e2d298b25','as a matter o...','[æz ə ˈmætə ɔv fækt]','http://res.iciba.com/resource/amp3/0/0/e0/8e/e08e1c5605b12e9b0b6b771930742ab6.mp3','事实上，其实','','');----
INSERT INTO classwords VALUES ('37e9a0ff69a74fafac9ff2d36a4cc6a5','7468c548365a43b480c2115e2d298b25','141');----
INSERT INTO word VALUES ('5dfeb54a19f443689bfb6215b207d4e5','call up','[kɔ:l ʌp]','http://res.iciba.com/resource/amp3/0/0/ff/cb/ffcb47b23fb50d501b74f1dd808c0571.mp3','号召，打电话','','');----
INSERT INTO classwords VALUES ('61c8a102c6c0417a9bfd484a6229fac5','5dfeb54a19f443689bfb6215b207d4e5','141');----
INSERT INTO word VALUES ('1668918853ac46029ed3dc29615b7cb7','come true','[kʌm truː]','http://res.iciba.com/resource/amp3/0/0/e2/c0/e2c0016a803ace116df92b858854159f.mp3','变为现实，成为事实','','');----
INSERT INTO classwords VALUES ('8c7acaeccfac475f9ccbe48ebdff8f76','1668918853ac46029ed3dc29615b7cb7','141');----
INSERT INTO word VALUES ('40d62bd7c1bb40c79521b4a4ba910f5f','ring back','[riŋ bæk]','http://res.iciba.com/resource/amp3/0/0/ff/c3/ffc351e2a96c7c7fb17cc6f06c064af5.mp3','回电话','','');----
INSERT INTO classwords VALUES ('473b67f086814ee7b28c86e242d723bd','40d62bd7c1bb40c79521b4a4ba910f5f','141');----
INSERT INTO word VALUES ('4364f5c3e3304f4eb16080b7a93f04b3','pay off','[pei ɔf]','http://res.iciba.com/resource/amp3/0/0/dd/1c/dd1c1db317165e5c585d7dbd318c3536.mp3','偿清(欠款等)','','');----
INSERT INTO classwords VALUES ('207eeeb0380c44b2a240d1fbb3aa8cb8','4364f5c3e3304f4eb16080b7a93f04b3','141');----
INSERT INTO word VALUES ('f6e5106ec0524ef1bbc66335a77af893','turn off','[tə:n ɔf]','http://res.iciba.com/resource/amp3/1/0/54/6f/546fa8c1eeaa45d4f018b8f53d64bb10.mp3','关掉（水、电、电视、收音机等）','','');----
INSERT INTO classwords VALUES ('52341b6030124f33bafe37d8f1755f3a','f6e5106ec0524ef1bbc66335a77af893','141');----
INSERT INTO word VALUES ('91c93ff5f55542449217e6cb3ca70eba','neither...nor...','','http://res-tts.iciba.com/c/4/7/c4714351d0944a6d311802ff78c52582.mp3','既不……也不……','','');----
INSERT INTO classwords VALUES ('e63ea423bf4c494ab7e881c8dd2cdaa7','91c93ff5f55542449217e6cb3ca70eba','141');----
INSERT INTO word VALUES ('875d69ba6ea94a0a83fcd6a0102b4cc1','put out','[put aut]','http://res.iciba.com/resource/amp3/0/0/58/82/5882efa990a1c83ed0037a4fe3d54fd4.mp3','扑灭，关熄','','');----
INSERT INTO classwords VALUES ('76b5fbc9dd254e58aaa717e88b63c9c7','875d69ba6ea94a0a83fcd6a0102b4cc1','141');----
INSERT INTO word VALUES ('102c88028cec46f7a22b5b639cdf3e15','enjoy oneself...','[inˈdʒɔi wʌnˈself]','http://res-tts.iciba.com/d/f/8/df8495bd1a9c3145c280348844de74b2.mp3','过得愉快','','');----
INSERT INTO classwords VALUES ('2ffe118b24324bd5847ca44ee34c2160','102c88028cec46f7a22b5b639cdf3e15','141');----
INSERT INTO word VALUES ('39f1da44532a46afb7ca073fd4ae85dc','over the radi...','[inˈdʒɔi wʌnˈself]','','通过收音机','','');----
INSERT INTO classwords VALUES ('2d00da36ce0f43b88bdbeb0aa647fe6c','39f1da44532a46afb7ca073fd4ae85dc','141');----
INSERT INTO word VALUES ('104bf7efb97241db8d5d9aca54cf9078','so as to','[səʊ æz tu:]','http://res.iciba.com/resource/amp3/0/0/db/2f/db2f8c1913705fe4f9287f4d953742cd.mp3','以便，为的是','','');----
INSERT INTO classwords VALUES ('9ecba7748b4548a8bd1ef1f661180f6d','104bf7efb97241db8d5d9aca54cf9078','141');----
INSERT INTO word VALUES ('e56e55cfb87449a48801fe1be5eab282','pick out','[pik aut]','http://res.iciba.com/resource/amp3/0/0/3f/86/3f863d9c2a8a55a8b695ac80f4a28f80.mp3','选出','','');----
INSERT INTO classwords VALUES ('6d90198ab18d48aa861e35dc86bb9b99','e56e55cfb87449a48801fe1be5eab282','141');----
INSERT INTO word VALUES ('3b1d1cd5acc74e7f905e5829bd1feb6e','first of all','[fə:st ɔv ɔ:l]','http://res.iciba.com/resource/amp3/0/0/e3/e2/e3e26e5b7350bb89a4449424dbcead7f.mp3','首先','','');----
INSERT INTO classwords VALUES ('5d878f40037b4038acb81725b15f80de','3b1d1cd5acc74e7f905e5829bd1feb6e','141');----
INSERT INTO word VALUES ('ef1fba30d08f451f81f008a35b668ebf','up and down','[ʌp ænd daun]','http://res-tts.iciba.com/1/b/7/1b75533ed5a869ff6f3ae0336d0c3320.mp3','上下，来回','','');----
INSERT INTO classwords VALUES ('4a3a6db3f3404547a844785915dcdfbd','ef1fba30d08f451f81f008a35b668ebf','141');----
INSERT INTO word VALUES ('f63147cb1e0f44e6ba82e942e62a0eab','not any more','[nɔt ˈeni mɔ:]','http://res.iciba.com/resource/amp3/0/0/da/5f/da5f5e7f141e89b7d040d01495996af8.mp3','不再','','');----
INSERT INTO classwords VALUES ('d010153612ae426e8959ced689122b56','f63147cb1e0f44e6ba82e942e62a0eab','141');----
INSERT INTO word VALUES ('a75b8ae48309469d8f5169514fc8be3b','used to do st...','[nɔt ˈeni mɔ:]','','过去常常','','');----
INSERT INTO classwords VALUES ('98532a18dce44b4d8ac42a0391877b22','a75b8ae48309469d8f5169514fc8be3b','141');----
INSERT INTO word VALUES ('6b4e55ff39f84dfa9f494d216e5fa1a2','had better (d...','[nɔt ˈeni mɔ:]','','最好（做）','','');----
INSERT INTO classwords VALUES ('ff91a211dbff4411be8d881f746572bb','6b4e55ff39f84dfa9f494d216e5fa1a2','141');----
INSERT INTO word VALUES ('d59aeae77e074923895c7dd63dd46c1e','look after','[luk ˈɑ:ftə]','http://res.iciba.com/resource/amp3/0/0/50/d5/50d5b9b739ca88d298d2badd660d3f45.mp3','照顾','','');----
INSERT INTO classwords VALUES ('c62ca7c4d79e4f9c854f2a1ca68f9260','d59aeae77e074923895c7dd63dd46c1e','141');----
INSERT INTO word VALUES ('a2fdd05900f54c07b7d6517ce7d7ed52','scores of','[skɔ:z ɔv]','http://res-tts.iciba.com/7/9/0/79097afe4c108b3ae8225ed54ed8856c.mp3','许多，大量','','');----
INSERT INTO classwords VALUES ('08620486801a4f0e803aab1714a0b411','a2fdd05900f54c07b7d6517ce7d7ed52','141');----
INSERT INTO word VALUES ('309098102cdc455cb48881ee17dd4a06','cut up','[kʌt ʌp]','http://res.iciba.com/resource/amp3/1/0/b7/0b/b70bc6b2750b9076a03645246696d286.mp3','齐根割掉，切碎','','');----
INSERT INTO classwords VALUES ('5f7688a2048d4471b0ce3ae60d465660','309098102cdc455cb48881ee17dd4a06','141');----
INSERT INTO word VALUES ('a14cc2dceb51457591f5aade8fd20faf','separate...fr...','','http://res-tts.iciba.com/d/b/0/db0f3a90557b5a63bc31a9a5a77f8f64.mp3','分开','','');----
INSERT INTO classwords VALUES ('d6bf2dbe6a0e4d25bc5c2548b9c9b62f','a14cc2dceb51457591f5aade8fd20faf','141');----
INSERT INTO word VALUES ('b6355079dfb74b07ab69408e167068d5','ring off','[riŋ ɔf]','http://res.iciba.com/resource/amp3/0/0/18/9f/189f83252e11d0a4e9787f09bcb31374.mp3','挂断电话，停止讲话','','');----
INSERT INTO classwords VALUES ('e4142e82db7c43b2887d810f91c2db49','b6355079dfb74b07ab69408e167068d5','141');----
INSERT INTO word VALUES ('bc672addedd24542aac4286a6ff24cb9','look forward ...','[luk ˈfɔ:wəd tu:]','http://res.iciba.com/resource/amp3/0/0/7e/64/7e640ae8ee37aa9b36d9f697834edd48.mp3','盼望','','');----
INSERT INTO classwords VALUES ('8301e1d4f4574d4dabdc2a0f1ca397e7','bc672addedd24542aac4286a6ff24cb9','141');----
INSERT INTO word VALUES ('8a71594f33eb4095a21a9a33783de64c','now that','[nau ðæt]','http://res.iciba.com/resource/amp3/0/0/e7/d4/e7d4d861dd506fa668f62035468743dc.mp3','既然','','');----
INSERT INTO classwords VALUES ('bb3719abb1194cffb459a3a91ee5b0a2','8a71594f33eb4095a21a9a33783de64c','141');----
INSERT INTO word VALUES ('51286480bf67409dae98ac4fdcdfbf90','congratulate....','[nau ðæt]','','祝贺……','','');----
INSERT INTO classwords VALUES ('4aefa6c70a984d368b09da430879c7ce','51286480bf67409dae98ac4fdcdfbf90','141');----
INSERT INTO word VALUES ('95b83d7a642f4aa0a6437ff8a9a79dc5','as far as','[æz fɑ: æz]','http://res.iciba.com/resource/amp3/0/0/26/45/2645890eaf982b0dc222673fc86d8ef3.mp3','（表示程度，范围）就……；尽……','','');----
INSERT INTO classwords VALUES ('f67e87b1d8c843c0a877173b3e632f16','95b83d7a642f4aa0a6437ff8a9a79dc5','141');----
INSERT INTO word VALUES ('b700e9953a44414bb8e2ad2487edc0c8','for ever','[fɔ: ˈevə]','http://res.iciba.com/resource/amp3/0/0/ce/e2/cee2bad6bc2cc0fa3ae882677315fcba.mp3','永远','','');----
INSERT INTO classwords VALUES ('d430fd3b6ead4f6fabc3f04547a9c2bc','b700e9953a44414bb8e2ad2487edc0c8','141');----
INSERT INTO word VALUES ('0e10f447ea584253af0d1eb51f14c82f','in common','[in ˈkɔmən]','http://res.iciba.com/resource/amp3/0/0/2d/44/2d44f214137994bdec8e8fa142f78ff2.mp3','共同，共有','','');----
INSERT INTO classwords VALUES ('b1e65504f193417a80fcca4de349feb3','0e10f447ea584253af0d1eb51f14c82f','141');----
INSERT INTO word VALUES ('46ca87afee1b4e0184d2f18cb65044fe','look ahead','[luk əˈhed]','http://res.iciba.com/resource/amp3/0/0/13/22/1322749cc7376eb4fbad645af54c0a1a.mp3','向前看，展望未来','','');----
INSERT INTO classwords VALUES ('a84972b5c8654faa9f6889957d16c1d7','46ca87afee1b4e0184d2f18cb65044fe','141');----
INSERT INTO word VALUES ('67f97dec91d04e6d9df4799fd8a0bcdf','have a cold','[hæv ə kəuld]','http://res.iciba.com/resource/amp3/0/0/f1/bd/f1bdc43e23d9671e610e5f5676c73f1a.mp3','患感冒','','');----
INSERT INTO classwords VALUES ('cddd8baa9dd74a2a94d1d989aeaf3382','67f97dec91d04e6d9df4799fd8a0bcdf','141');----
INSERT INTO word VALUES ('6e1e493029d8444bb85a1f7d875c1df8','as well','[æz wel]','http://res-tts.iciba.com/a/b/2/ab256241aac70f922e45e2936a5a4770.mp3','也，还有','','');----
INSERT INTO classwords VALUES ('70bf50147ae7448ba4b6b7def4fb980d','6e1e493029d8444bb85a1f7d875c1df8','141');----
INSERT INTO word VALUES ('e898bd46cca948438e2b24761d89dfc6','break down','[breik daun]','http://res.iciba.com/resource/amp3/0/0/a1/7a/a17ab636cff45318af41533e570a1396.mp3','损坏; (把化合物等) 分解，（汽车）抛...','','');----
INSERT INTO classwords VALUES ('ee1c200e462e466cb9489c4aec6d44e4','e898bd46cca948438e2b24761d89dfc6','141');----
INSERT INTO word VALUES ('080767f66fbc4baeacfbb99f280864a9','drop in','[drɔp in]','http://res.iciba.com/resource/amp3/1/0/83/d7/83d776cb280d1dafb6a624b0c776190b.mp3','顺便走访（某人）','','');----
INSERT INTO classwords VALUES ('b64553c96e404e58bb9aac7b1cefebc4','080767f66fbc4baeacfbb99f280864a9','141');----
INSERT INTO word VALUES ('72f231d992fb4048bb79a45305da583f','hear of','[hiə ɔv]','http://res.iciba.com/resource/amp3/0/0/5a/18/5a18dca446a07defdc8fcae673400e5c.mp3','听说，知道','','');----
INSERT INTO classwords VALUES ('f542ecbd779d4b75b8b27c026e802e25','72f231d992fb4048bb79a45305da583f','141');----
INSERT INTO word VALUES ('c4cd06af1b2b42acaef37194338a73a6','call on','[kɔ:l ɔn]','http://res.iciba.com/resource/amp3/0/0/f6/a7/f6a7b7e2a8e576a926855b7e45007c70.mp3','拜访，访问','','');----
INSERT INTO classwords VALUES ('7929d140911e402b91460beefdeb11a5','c4cd06af1b2b42acaef37194338a73a6','141');----
INSERT INTO word VALUES ('de1a3c4ce5514180b0b746a675e5dfc6','tick to','[kɔ:l ɔn]','','坚持','','');----
INSERT INTO classwords VALUES ('b37052f0be854fdeadaef83bcb22d0e0','de1a3c4ce5514180b0b746a675e5dfc6','141');----
INSERT INTO word VALUES ('9eb11054612f4384b149e690199d3708','get close (to...','[kɔ:l ɔn]','','接近','','');----
INSERT INTO classwords VALUES ('7e4f6521538e443ca47406c6d3150402','9eb11054612f4384b149e690199d3708','141');----
INSERT INTO word VALUES ('9fd07d773b1f4d81b3efd51a9210864a','speed up','[spi:d ʌp]','http://res.iciba.com/resource/amp3/0/0/e1/59/e15919e9f3dda8070015df3a70e233ea.mp3','加快速度','','');----
INSERT INTO classwords VALUES ('60b30c4047a34f6196f87e184c147b4f','9fd07d773b1f4d81b3efd51a9210864a','141');----
INSERT INTO word VALUES ('cd4dac1fa8d340d989f43345e70ae476','get away','[ɡet əˈwei]','http://res.iciba.com/resource/amp3/0/0/a0/9f/a09fd686300157ba8e45e2fb4c6429d3.mp3','逃; 离','','');----
INSERT INTO classwords VALUES ('84ff624e1c8d4c55836481037d68425f','cd4dac1fa8d340d989f43345e70ae476','141');----
INSERT INTO word VALUES ('ab93b8a9792b4f1b957bf1dfc6c71f12','go on with','[ɡəu ɔn wið]','http://res-tts.iciba.com/8/0/2/802c1bd0bdeb94b2e25c7885785a394d.mp3','继续','','');----
INSERT INTO classwords VALUES ('77032fbe06de43568ced3116ca36739b','ab93b8a9792b4f1b957bf1dfc6c71f12','141');----
INSERT INTO word VALUES ('4d3f74a905e74eed86b9465c50edcbbe','go away','[ɡəu əˈwei]','http://res.iciba.com/resource/amp3/0/0/15/8e/158ee90f12f717dcbf3ad71e0f41cdb3.mp3','走开，离去','','');----
INSERT INTO classwords VALUES ('f2690c50fae849438a5548c42306a951','4d3f74a905e74eed86b9465c50edcbbe','141');----
INSERT INTO word VALUES ('ea560786333a4d2eabfd2f3ebe1798d6','all over','[ɔ:l ˈəuvə]','http://res.iciba.com/resource/amp3/0/0/28/42/2842c2a9ef530c2fe7633572c62043d9.mp3','到处，遍及，结束','','');----
INSERT INTO classwords VALUES ('d3d91e21ff7a466eba961af582ae6d06','ea560786333a4d2eabfd2f3ebe1798d6','141');----
INSERT INTO word VALUES ('2aafc150cec14fa9bd247218a5d9e70e','as well as','[æz wel æz]','http://res.iciba.com/resource/amp3/0/0/75/6f/756fc496c55892dc274ded063136d1c3.mp3','除……之外（也）','','');----
INSERT INTO classwords VALUES ('2ce83af6cad141ae82004355537b5deb','2aafc150cec14fa9bd247218a5d9e70e','141');----
INSERT INTO word VALUES ('4782829377aa43d39140ec4555a7d1c1','right away','[rait əˈwei]','http://res.iciba.com/resource/amp3/0/0/51/13/511375d0e0766e9e8743def6a16df949.mp3','立即，马上','','');----
INSERT INTO classwords VALUES ('4da84596920b4a50a14a0b257977a67c','4782829377aa43d39140ec4555a7d1c1','141');----
INSERT INTO word VALUES ('44336c4a203d471580d3d2c4f060c223','take one's ti...','[teik wʌnz taim]','http://res.iciba.com/resource/amp3/0/0/c6/73/c67339faf2eb58430158d29c3c0b2305.mp3','从容，慢慢行动','','');----
INSERT INTO classwords VALUES ('dd6c02c7a67d4b9e9aa52f3ea99467f1','44336c4a203d471580d3d2c4f060c223','141');----
INSERT INTO word VALUES ('7f807d6c250248528b7e8e4ec685d273','apart from','[əˈpɑ:t frɔm]','http://res.iciba.com/resource/amp3/0/0/e6/c4/e6c46c7575220104419485f01e0e7ce0.mp3','除去，除了','','');----
INSERT INTO classwords VALUES ('131bc435d42c4519923e939336446724','7f807d6c250248528b7e8e4ec685d273','141');----
INSERT INTO word VALUES ('4248eaaa276a45f2a2f404d9ebc2aa6e','join in','[dʒɔin in]','http://res.iciba.com/resource/amp3/0/0/4d/1d/4d1d8ce3255d178b543d1edc8c8c3bcd.mp3','参加，加入','','');----
INSERT INTO classwords VALUES ('d0ee397d7e054ce5bf7b6a68ef1a346e','4248eaaa276a45f2a2f404d9ebc2aa6e','141');----
INSERT INTO word VALUES ('72bf16b7320e409b8a98c8660bb96899','come to','[kʌm tu:]','http://res.iciba.com/resource/amp3/0/0/1f/6b/1f6ba5325095ab494dfad9c1897cf8cd.mp3','共计，达到','','');----
INSERT INTO classwords VALUES ('2e9f633e787a439bb11324f571f47edc','72bf16b7320e409b8a98c8660bb96899','141');----
INSERT INTO word VALUES ('875f4fc5d9cb4bfda281da86a094e63c','once upon a t...','[wʌns əˈpɔn ə taim]','http://res.iciba.com/resource/amp3/0/0/ea/36/ea36fcd25d96821e1455adec6e5d9a3a.mp3','从前，很久以前','','');----
INSERT INTO classwords VALUES ('8ec8fe2dd8104312aab2d60f7205888c','875f4fc5d9cb4bfda281da86a094e63c','141');----
INSERT INTO word VALUES ('13bddafbed3c467db798e4caa98b8733','above all','[əˈbʌv ɔ:l]','http://res.iciba.com/resource/amp3/0/0/17/f9/17f96e133412f7b2ce96939665006e8f.mp3','首先，首要','','');----
INSERT INTO classwords VALUES ('cf253f4ea14541ac831ce11f8583e983','13bddafbed3c467db798e4caa98b8733','141');----
INSERT INTO word VALUES ('e629bc28518c400cb7a0e95e20379336','instead of','[inˈsted ɔv]','http://res.iciba.com/resource/amp3/0/0/7b/b6/7bb63c7de5a5ee79356083a12f21e1e8.mp3','代替，而不是','','');----
INSERT INTO classwords VALUES ('f398f1c694494ce78732f56a5bfe7810','e629bc28518c400cb7a0e95e20379336','141');----
INSERT INTO word VALUES ('bc2a011fefea407cb77f270cbef68e0e','carry out','[ˈkæri aut]','http://res.iciba.com/resource/amp3/0/0/a8/f3/a8f3fbc8209b6608d2cb431ab23f5c34.mp3','开展，执行','','');----
INSERT INTO classwords VALUES ('bfe88f208d6b4719baa3788c77a96385','bc2a011fefea407cb77f270cbef68e0e','141');----
INSERT INTO word VALUES ('e28b5cfbe3354752a508fce9a9c720f0','look into','[luk ˈɪntuː]','http://res.iciba.com/resource/amp3/0/0/ca/5e/ca5e430b5c386a10fa1555654bca4711.mp3','向…里面看去; 调查','','');----
INSERT INTO classwords VALUES ('7cd4c5c873954bceb9eda35429db6970','e28b5cfbe3354752a508fce9a9c720f0','141');----
INSERT INTO word VALUES ('7bfac195c3b041e0bdf5ade96de86598','get on with s...','[luk ˈɪntuː]','','与……相处','','');----
INSERT INTO classwords VALUES ('0e12617b5ba8434fa1e7dd45864313f5','7bfac195c3b041e0bdf5ade96de86598','141');----
INSERT INTO word VALUES ('a34ecc19b7c848f2b86fde07c82bc4c8','not at all','[nɔt æt ɔ:l]','http://res.iciba.com/resource/amp3/0/0/06/95/06951a076c8f062e7009da6709f26c39.mp3','一点也不，绝非','','');----
INSERT INTO classwords VALUES ('4e00363d957a46d2a4feb19280a28690','a34ecc19b7c848f2b86fde07c82bc4c8','141');----
INSERT INTO word VALUES ('3489879cda0a4484b6430c56d9f77160','go by','[ɡəu bai]','http://res.iciba.com/resource/amp3/0/0/09/8f/098f3f04eecb8bf1c481c00528d838f3.mp3','走过; 经过; 过去','','');----
INSERT INTO classwords VALUES ('94cd95b5ab834599a1f9b168d65575ee','3489879cda0a4484b6430c56d9f77160','141');----
INSERT INTO word VALUES ('97e96199576c42adafead4199dfcfbe7','show off','[ʃəu ɔf]','http://res.iciba.com/resource/amp3/0/0/5c/a7/5ca7be6015d17b7ca5b876e01e91c892.mp3','炫耀','','');----
INSERT INTO classwords VALUES ('b77e6946c4714c90bda972e33314852d','97e96199576c42adafead4199dfcfbe7','141');----
INSERT INTO word VALUES ('5a850a682906496e88c6b69fcbfc5f01','hang up','[hæŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/cc/61/cc6145b2f3c30b5214a7a2e86d739f68.mp3','挂断电话','','');----
INSERT INTO classwords VALUES ('6de60befdb184373931c0335ec442aec','5a850a682906496e88c6b69fcbfc5f01','141');----
INSERT INTO word VALUES ('12146a4cb056408eb1a0a5d51fa06f99','in order that...','[in ˈɔ:də ðæt]','http://res-tts.iciba.com/8/1/6/816f4441379eace0087407690e59a317.mp3','为了','','');----
INSERT INTO classwords VALUES ('468c56d84abe4f12afd0386051941c0b','12146a4cb056408eb1a0a5d51fa06f99','141');----
INSERT INTO word VALUES ('9e48389ccdf648bfbcb19db327b06264','clear up','[kliə ʌp]','http://res.iciba.com/resource/amp3/0/0/80/ed/80edc311f2d4742023e99a3db0e02917.mp3','整理，收拾, (天气)放晴','','');----
INSERT INTO classwords VALUES ('2d379c12a8b5418c931c27277a8c4cd0','9e48389ccdf648bfbcb19db327b06264','141');----
INSERT INTO word VALUES ('4501c301d12443299bef16a6446ea6c6','keep on','[ki:p ɔn]','http://res.iciba.com/resource/amp3/0/0/dc/4e/dc4e3dde75057e242c16a57f6352ad30.mp3','继续（进行）','','');----
INSERT INTO classwords VALUES ('b941d5ddcb9a4b2cbba20eeb16c6a2ee','4501c301d12443299bef16a6446ea6c6','141');----
INSERT INTO word VALUES ('5c8ebe329eb14b768171a463666682d2','think of','[θiŋk ɔv]','http://res-tts.iciba.com/e/f/f/eff6cf09810856479d918b0874cf3b14.mp3','想起,考虑,认为,看法','','');----
INSERT INTO classwords VALUES ('62db6d7b8457489c80b627cd6c1a818f','5c8ebe329eb14b768171a463666682d2','141');----
INSERT INTO word VALUES ('d5ca21d59b944efc8d8d0adfc4002d3c','for good','[fɔ: ɡud]','http://res.iciba.com/resource/amp3/0/0/4a/00/4a00dd7fb7008456bce24800beef5417.mp3','永远','','');----
INSERT INTO classwords VALUES ('12d43a909d494dc8918931fe385d6af9','d5ca21d59b944efc8d8d0adfc4002d3c','141');----
INSERT INTO word VALUES ('8b826fae457741dd9d1ba629ae739dea','break up','[breik ʌp]','http://res.iciba.com/resource/amp3/0/0/bf/f2/bff2be32210454ea1b271f09f9dceb37.mp3','分解；分裂','','');----
INSERT INTO classwords VALUES ('331df393b9a54fbe86523c8b3ea33d09','8b826fae457741dd9d1ba629ae739dea','141');----
INSERT INTO word VALUES ('cab8bfd8570e413da1c59b610e426ee3','compare to','[kəmˈpɛə tu:]','http://res.iciba.com/resource/amp3/0/0/21/2d/212d0f442da20ddc6412cb33a6c93950.mp3','与……相比','','');----
INSERT INTO classwords VALUES ('a7ad192ced934641bd2a9ae0d08fb8a8','cab8bfd8570e413da1c59b610e426ee3','141');----
INSERT INTO word VALUES ('b861c5f0eaa548f7a2273537f7da0ed6','keep one's wo...','[ki:p wʌnz wə:d]','http://res.iciba.com/resource/amp3/0/0/ab/5a/ab5a8daed81231d8e8897ede5f3194de.mp3','守信','','');----
INSERT INTO classwords VALUES ('2ff5ef93df1846b2bc800c744142eae0','b861c5f0eaa548f7a2273537f7da0ed6','141');----
INSERT INTO class VALUES ('141','高考常用短语','362');
