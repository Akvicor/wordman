INSERT INTO word VALUES ('a2ac0f832dd44e368e71512a168dc7f3','expire','[iksˈpaiə]','http://res.iciba.com/resource/amp3/oxford/0/4e/da/4edaeac0484b942bf3cf597906fca4f9.mp3','vi. 满期，到期；断气','','');----
INSERT INTO classwords VALUES ('7d2ee0fa109643d1bb85c58ef3cc43e3','a2ac0f832dd44e368e71512a168dc7f3','12');----
INSERT INTO word VALUES ('50436587fd1349d7b9a9dff709c6a836','wield','[wi:ld]','http://res.iciba.com/resource/amp3/oxford/0/ba/13/ba13ece5675455847f921b7489439b40.mp3','vt. 挥（剑）；行使（权利）','','');----
INSERT INTO classwords VALUES ('c027b50a2ade43e4bb8c3171e3aeebe6','50436587fd1349d7b9a9dff709c6a836','12');----
INSERT INTO word VALUES ('22e2c1787a424478ab1b90b7ada6afc8','heater','[ˈhi:tə]','http://res.iciba.com/resource/amp3/oxford/0/40/e4/40e40f3b40c88b485068dbfa4b9b9f88.mp3','n. 加热器；炉子','','');----
INSERT INTO classwords VALUES ('c1291cfd192944868674957929107503','22e2c1787a424478ab1b90b7ada6afc8','12');----
INSERT INTO word VALUES ('f335009c92544e86a1ad9a5c1df7716c','mature','[məˈtjuə]','http://res.iciba.com/resource/amp3/oxford/0/0e/25/0e2504413502338ee5d477c6d09c1ef8.mp3','vi. 成熟','','');----
INSERT INTO classwords VALUES ('12ce08cd08164febb49e590b711a7663','f335009c92544e86a1ad9a5c1df7716c','12');----
INSERT INTO word VALUES ('e78f937cfd8d45a0a2eda7ba2db40f55','ferrous','[ˈferəs]','http://res.iciba.com/resource/amp3/oxford/0/b7/15/b7156bcc784c79c954c71a90f9192cae.mp3','adj. 铁的，含铁的','','');----
INSERT INTO classwords VALUES ('5310deeef6d445f785e6dbeddfdae22b','e78f937cfd8d45a0a2eda7ba2db40f55','12');----
INSERT INTO word VALUES ('d68f380f26784012bf33d7841013d210','breakdown','[ˈbreikdaun]','http://res.iciba.com/resource/amp3/oxford/0/e6/3d/e63d71bd6ac702667bb8edcb4ee0f6fd.mp3','n. 崩溃；故障；细目列表','','');----
INSERT INTO classwords VALUES ('95108a9043394ef8b496c578190d2ecd','d68f380f26784012bf33d7841013d210','12');----
INSERT INTO word VALUES ('df0804e21dff4883ab191af5cee58203','embody','[imˈbɔdi]','http://res.iciba.com/resource/amp3/0/0/08/ce/08ce371c6cc0c3ab8edfc78482fa6647.mp3','vt. 体现；包含，包括','','');----
INSERT INTO classwords VALUES ('6dcd4c569314473c9ee235bc505d2960','df0804e21dff4883ab191af5cee58203','12');----
INSERT INTO word VALUES ('4011b2c977ee40689a45ece8875bad9b','everlasting','[ˌevəˈlɑ:stiŋ]','http://res.iciba.com/resource/amp3/0/0/2c/7b/2c7b08a7c3931545776007493a36742c.mp3','adj. 永久的；永不停止的','','');----
INSERT INTO classwords VALUES ('40e9170d00ef4e8fb229aee7617fd64a','4011b2c977ee40689a45ece8875bad9b','12');----
INSERT INTO word VALUES ('56f30c6ed58e47238bff2dfa725e8ecd','treasurer','[ˈtreʒəə]','http://res.iciba.com/resource/amp3/oxford/0/a1/58/a1589140f46fad6528325e5206202f4f.mp3','n. 司库，财务主管','','');----
INSERT INTO classwords VALUES ('85c8e715fef34cc08dc84152449bd975','56f30c6ed58e47238bff2dfa725e8ecd','12');----
INSERT INTO word VALUES ('f7d718995dce46158109742d4e62d425','attachment','[əˈtætʃmənt]','http://res.iciba.com/resource/amp3/oxford/0/8d/fa/8dfadc13b7870f5f80d220b69986a1a9.mp3','n. 附件；爱慕','','');----
INSERT INTO classwords VALUES ('af27d5bb005b4267ba8330b874653566','f7d718995dce46158109742d4e62d425','12');----
INSERT INTO word VALUES ('f61ad0c201a946848a428aa664570f39','overlap','[ˌəuvəˈlæp]','http://res.iciba.com/resource/amp3/0/0/9c/12/9c126c20047e421bde49e44ed51ae805.mp3','vi.&vt. 重叠 n.重叠部分； ...','','');----
INSERT INTO classwords VALUES ('0975c6dc978747e49e45c644678ba88e','f61ad0c201a946848a428aa664570f39','12');----
INSERT INTO word VALUES ('d6d11db4c4b14505b3e55ee2952c3414','Christian','[ˈkristʃən]','http://res.iciba.com/resource/amp3/oxford/0/f9/cc/f9ccad898e083dfbf5ab081c8ae5487b.mp3','adj. 基督教的；基督徒的','','');----
INSERT INTO classwords VALUES ('6b372799746f4bf1a221edaf8ee97d89','d6d11db4c4b14505b3e55ee2952c3414','12');----
INSERT INTO word VALUES ('595e013f41a749b993e623280c345521','through','[θru:]','http://res.iciba.com/resource/amp3/oxford/0/ac/08/ac0855984f750c05af8d7486d210cfd2.mp3','prep. 穿过，通过；跨越；在…之间','','');----
INSERT INTO classwords VALUES ('473bb5772cfa4c7998bcc7cf562731ce','595e013f41a749b993e623280c345521','12');----
INSERT INTO word VALUES ('810823dd09eb41da8a3c2b3416cfac0d','except','[ikˈsept]','http://res.iciba.com/resource/amp3/oxford/0/c3/e3/c3e38872f3ba8784c8fae6a2d0c7c42a.mp3','vt. 把…除外','','');----
INSERT INTO classwords VALUES ('590ca1f081f4484e8be2d91df0196467','810823dd09eb41da8a3c2b3416cfac0d','12');----
INSERT INTO word VALUES ('8c7172576ab74392944e3f867747ac06','declaration','[ˌdekləˈreiʃən]','http://res.iciba.com/resource/amp3/oxford/0/6f/91/6f91f4b800972fa5f488aa965ed1cca2.mp3','n. 宣布，宣言，公告；宣称；表白；申报','','');----
INSERT INTO classwords VALUES ('a1d1ea60c2094ef6a8941708bea4ea09','8c7172576ab74392944e3f867747ac06','12');----
INSERT INTO word VALUES ('e590ea6f744343fa879d524b4a37a5c9','delegate','[ˈdeliɡit]','http://res.iciba.com/resource/amp3/oxford/0/2e/d4/2ed4d58f15291db0b296d9625b28ceb4.mp3','n. 代表，代表团成员','','');----
INSERT INTO classwords VALUES ('01253270ebb14f79b890b72d4fdee586','e590ea6f744343fa879d524b4a37a5c9','12');----
INSERT INTO word VALUES ('1c920ce2f1a841de884e9285018981ce','periodical','[ˌpiəriˈɔdikəl]','http://res.iciba.com/resource/amp3/oxford/0/6e/75/6e7528f305987afca4a3049191f08ceb.mp3','n. 期刊','','');----
INSERT INTO classwords VALUES ('a5c2f5d08e7a43fab92ba35fcf6a150f','1c920ce2f1a841de884e9285018981ce','12');----
INSERT INTO word VALUES ('253a2ec638174b86a6f04b5467b997de','adoption','[əˈdɒpʃn]','http://res.iciba.com/resource/amp3/0/0/31/94/319495d3f42bbdbb87c4c00529cd3f76.mp3','n. 收养；采纳，采取','','');----
INSERT INTO classwords VALUES ('a262cc593b5249deb790126bab68316d','253a2ec638174b86a6f04b5467b997de','12');----
INSERT INTO word VALUES ('97f957f2372743f89d8a653bd6d9e7b1','napkin','[ˈnæpkin]','http://res.iciba.com/resource/amp3/oxford/0/8c/e2/8ce2547e8f9b62763b44dfb56912dd22.mp3','n. 餐巾，餐巾纸','','');----
INSERT INTO classwords VALUES ('014a37bfd4624a1282d48f835ac19857','97f957f2372743f89d8a653bd6d9e7b1','12');----
INSERT INTO word VALUES ('a88e782fd3ff4e4b8199f49876589fe9','dwarf','[dwɔ:f]','http://res.iciba.com/resource/amp3/0/0/95/89/95899c10da3bb02e53e499283ad15e9a.mp3','n. 矮子，侏儒；[天]矮星','','');----
INSERT INTO classwords VALUES ('34e01e2de13845088d9cca1fc957098e','a88e782fd3ff4e4b8199f49876589fe9','12');----
INSERT INTO word VALUES ('f9c36db15059479184f4b57241e12fc3','selection','[siˈlekʃən]','http://res.iciba.com/resource/amp3/oxford/0/58/2e/582ecf36587cb3d81666c9c2d29accb2.mp3','n. 选择；挑选出来的一批人；可供选择的...','','');----
INSERT INTO classwords VALUES ('9074b20d214e47d1b7a3e1261f93012a','f9c36db15059479184f4b57241e12fc3','12');----
INSERT INTO word VALUES ('1c6f333a8d434de39b87afbfd78a77d4','analytic','[ˌænəˈlɪtɪk]','http://res.iciba.com/resource/amp3/oxford/0/ad/8b/ad8b9414bc7e1b30f7490ddf7640ad39.mp3','adj. 分析的；解析的(=analyt...','','');----
INSERT INTO classwords VALUES ('84717dd6bc2e443684dc2fa5dfc9323c','1c6f333a8d434de39b87afbfd78a77d4','12');----
INSERT INTO word VALUES ('ae4ba38be6884e6f87be326f2416734a','duke','[dju:k]','http://res.iciba.com/resource/amp3/0/0/04/1c/041cf7cf23d3d372644b707505218fb0.mp3','n. 公爵','','');----
INSERT INTO classwords VALUES ('5848ace55fc64e6b9c046eb5f9a569af','ae4ba38be6884e6f87be326f2416734a','12');----
INSERT INTO word VALUES ('8a764be6eaa7473e8ce006690bdc4422','vigorous','[ˈviɡərəs]','http://res.iciba.com/resource/amp3/oxford/0/54/0e/540e7ab8a1f6fa6c8bb03f66a9c8efd2.mp3','adj. 剧烈的；活跃的；精力旺盛的','','');----
INSERT INTO classwords VALUES ('1fd9d0324fa44ed7ab95bda5a6480712','8a764be6eaa7473e8ce006690bdc4422','12');----
INSERT INTO word VALUES ('7bfbc006422042c0be08844671a6d38d','resemblance','[riˈzembləns]','http://res.iciba.com/resource/amp3/oxford/0/1b/81/1b8129c78e515bd260ff8009effce49e.mp3','n. 相似，类似之处','','');----
INSERT INTO classwords VALUES ('089c4e533a7941ffa7db4fe2f122fc84','7bfbc006422042c0be08844671a6d38d','12');----
INSERT INTO word VALUES ('41764f4b29e648e19388b4cecfe39827','prediction','[prɪˈdɪkʃən]','http://res.iciba.com/resource/amp3/oxford/0/71/f6/71f67f10807a64ca0a61c8fdf0a8c8db.mp3','n. 预言；预告；预测','','');----
INSERT INTO classwords VALUES ('81f01cd6e27d43ce9357160b63bf837d','41764f4b29e648e19388b4cecfe39827','12');----
INSERT INTO word VALUES ('f4302388688e49289f4479cc0d9d7501','escort','[ˈeskɔ:t]','http://res.iciba.com/resource/amp3/0/0/70/c7/70c7bde83a322c7341e685d3d3eeeaec.mp3','vt. 陪同；护送','','');----
INSERT INTO classwords VALUES ('3395f19e67ae4ed1bbf999f279658884','f4302388688e49289f4479cc0d9d7501','12');----
INSERT INTO word VALUES ('8c5754d70cee40fe93cb96d96cadaf46','hurrah','[hʊˈrɑ:]','http://res.iciba.com/resource/amp3/oxford/0/b5/bd/b5bd52c650e7d43ccc8464565bb38a99.mp3','int. 好哇；万岁','','');----
INSERT INTO classwords VALUES ('053826b1b3604b88a44187ff996061ff','8c5754d70cee40fe93cb96d96cadaf46','12');----
INSERT INTO word VALUES ('c76b2f5050784193ba8e93d4cd825b46','edit','[ˈedit]','http://res.iciba.com/resource/amp3/oxford/0/dd/a5/dda5611704d34e9d869425b439b4461d.mp3','vt. 编辑，编纂；校订；编选；剪辑；主...','','');----
INSERT INTO classwords VALUES ('2a7e9f667f0140db9aa0a97ebc6b58ec','c76b2f5050784193ba8e93d4cd825b46','12');----
INSERT INTO word VALUES ('b7463d9814b84859932a4ab5d8583bc7','narration','[næˈreɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/53/6e/536e2d1fc8bbd5762e1625b55a841574.mp3','n. 叙述；故事；叙述法','','');----
INSERT INTO classwords VALUES ('4adb60a4eeb04b38920258c263c642fe','b7463d9814b84859932a4ab5d8583bc7','12');----
INSERT INTO word VALUES ('305ee3e28ef44bc48df7b19741a33de0','distinct','[disˈtiŋkt]','http://res.iciba.com/resource/amp3/oxford/0/37/b1/37b1795bd93be3154770d2f6dd060a96.mp3','adj. 有区别的；不同的；清楚的；确切...','','');----
INSERT INTO classwords VALUES ('087df4c4a2d1408c93162c4e88ab71cd','305ee3e28ef44bc48df7b19741a33de0','12');----
INSERT INTO word VALUES ('5b23363802a9407397dafdd719213c66','Moslem','[ˈmɔzləm]','http://res.iciba.com/resource/amp3/oxford/0/a5/26/a52658cfaaa5dd39b767054b9bc78782.mp3','adj. 穆斯林（的）','','');----
INSERT INTO classwords VALUES ('c1f34dea879d42268b08453130e8e688','5b23363802a9407397dafdd719213c66','12');----
INSERT INTO word VALUES ('5d27433278f3472b9ae7fe23d0732774','incredible','[inˈkredəbl]','http://res.iciba.com/resource/amp3/oxford/0/27/31/2731d7d3e40bd9d20b81adc5c92f83ba.mp3','adj. 难以置信的；惊人的；妙极的','','');----
INSERT INTO classwords VALUES ('5abbc375d74141348a9c2e2e4d268c51','5d27433278f3472b9ae7fe23d0732774','12');----
INSERT INTO word VALUES ('f73bfbcb25da4c2cb742439d5180ccb8','subsequent','[ˈsʌbsikwənt]','http://res.iciba.com/resource/amp3/oxford/0/0b/f9/0bf9b89a2232b7b6a671a9cda0c526d8.mp3','adj. 随后的；后来的','','');----
INSERT INTO classwords VALUES ('8acd32485e2d44da8fe4292386fc9b1f','f73bfbcb25da4c2cb742439d5180ccb8','12');----
INSERT INTO word VALUES ('73f94c1d0b1642b9b0b9bab42123ca43','fantastic','[fænˈtæstik]','http://res.iciba.com/resource/amp3/oxford/0/8a/25/8a2580966e0b6ccd20543210b8a51a9b.mp3','adj. 空想的；奇异的；极好的','','');----
INSERT INTO classwords VALUES ('fe3c2d6e7b8b4bbeae6de18730bffcac','73f94c1d0b1642b9b0b9bab42123ca43','12');----
INSERT INTO word VALUES ('6abc11a87af84ee5bf3388354fee7abb','pose','[pəuz]','http://res.iciba.com/resource/amp3/0/0/2d/5f/2d5f8ae9328c6535be72ed28bff47560.mp3','vt. 造成（威胁、危险等）；提出','','');----
INSERT INTO classwords VALUES ('1a6d3f845a4f4f499220eb24fc825942','6abc11a87af84ee5bf3388354fee7abb','12');----
INSERT INTO word VALUES ('7a044d78c37f478cae32535907e1485e','hamper','[ˈhæmpə]','http://res.iciba.com/resource/amp3/oxford/0/08/d0/08d01c57cb8a2c9c5b38854c39d6993a.mp3','vt. 妨碍，阻碍，牵制','','');----
INSERT INTO classwords VALUES ('93e6b5edfcdc47b1bc12b0650a32e1bd','7a044d78c37f478cae32535907e1485e','12');----
INSERT INTO word VALUES ('98fbf1eac50b409c964ca1a9cba00431','charter','[ˈtʃɑ:tə]','http://res.iciba.com/resource/amp3/oxford/0/fb/f8/fbf8b359f5868000a158c887c68de393.mp3','n. 宪章，章程； 包租 vt.发给……...','','');----
INSERT INTO classwords VALUES ('817441d3714e414487b73735651759f2','98fbf1eac50b409c964ca1a9cba00431','12');----
INSERT INTO word VALUES ('487d9daf60d14fb9a1fbcca606e2d120','Christ','[kraist]','http://res.iciba.com/resource/amp3/oxford/0/3e/22/3e22189ea5703485e9aa9bdd6324db6a.mp3','n. 救世主；基督','','');----
INSERT INTO classwords VALUES ('9333140dda164a0d87d920c1921beda1','487d9daf60d14fb9a1fbcca606e2d120','12');----
INSERT INTO word VALUES ('0da9f1618855499c8f8de39af88e0869','studio','[ˈstju:diəu]','http://res.iciba.com/resource/amp3/0/0/c9/44/c944634550c698febdd9c868db908d9d.mp3','n. 画室；工作室；录音室；唱片公司','','');----
INSERT INTO classwords VALUES ('a45c8324e55b4d898beed775eb71809b','0da9f1618855499c8f8de39af88e0869','12');----
INSERT INTO word VALUES ('cb15d4fec0a04a8a9905b90fa4542076','proper','[ˈprɔpə]','http://res.iciba.com/resource/amp3/oxford/0/d2/35/d2359ea5a0a290e8a1fbfe2d0bc1bef1.mp3','adj. 得体的；适宜的，正当的；合适的','','');----
INSERT INTO classwords VALUES ('222704125d2c4016b5a0bab70d4875a2','cb15d4fec0a04a8a9905b90fa4542076','12');----
INSERT INTO word VALUES ('343d7a03784e41afa3b79ab11bf39089','furious','[ˈfjuəriəs]','http://res.iciba.com/resource/amp3/oxford/0/f1/9e/f19e2ccfdb243874ef3d65310d160611.mp3','adj. 狂怒的；强烈的；激烈的','','');----
INSERT INTO classwords VALUES ('ac80c7af0e98406f8c2ba1c3de7508c5','343d7a03784e41afa3b79ab11bf39089','12');----
INSERT INTO word VALUES ('c2ce939158824da2a485330c5a6f62af','jerk','[dʒə:k]','http://res.iciba.com/resource/amp3/0/0/1f/9f/1f9ffc11e36167dc758b59f346a69e0b.mp3','vt.&vi. （使）猝然一动','','');----
INSERT INTO classwords VALUES ('7acc6621d2d1446a8e586f300b61a182','c2ce939158824da2a485330c5a6f62af','12');----
INSERT INTO word VALUES ('9ed8449cc6ad4ebfb32c000477bf5d00','convention','[kənˈvenʃən]','http://res.iciba.com/resource/amp3/oxford/0/d6/a1/d6a1d38764d7e4bf2bbc7a95ca52a977.mp3','n. 习俗；传统做法；公约；大型会议','','');----
INSERT INTO classwords VALUES ('477f8ca4c0fd4287b45ae99c8a117d37','9ed8449cc6ad4ebfb32c000477bf5d00','12');----
INSERT INTO word VALUES ('98c4e2dd5c8f4ce8a464b08ad1bc7811','extraction','[ɪkˈstrækʃən]','http://res.iciba.com/resource/amp3/oxford/0/ea/7a/ea7a6cbc0dbe216cbba4d000a75261c6.mp3','n. 抽出；血统，家世','','');----
INSERT INTO classwords VALUES ('af6c020def714d36aa255879cca6a443','98c4e2dd5c8f4ce8a464b08ad1bc7811','12');----
INSERT INTO word VALUES ('ec293997601c4be2805eeaa2f6b9c782','counsel','[ˈkaunsəl]','http://res.iciba.com/resource/amp3/oxford/0/57/31/5731a19fa6d15dfabfac0a0137fe6b01.mp3','n. 建议；忠告；律师','','');----
INSERT INTO classwords VALUES ('a33da68518f54a51b500681a43c82202','ec293997601c4be2805eeaa2f6b9c782','12');----
INSERT INTO word VALUES ('1b28c2bb72054588957b9f28ba5fda9d','junior','[ˈdʒu:njə]','http://res.iciba.com/resource/amp3/oxford/0/34/45/3445c349d87ae251de3f61e748098472.mp3','n. 年少者；三年级学生','','');----
INSERT INTO classwords VALUES ('c4fe23683d494349b54f08e0ee71ceab','1b28c2bb72054588957b9f28ba5fda9d','12');----
INSERT INTO word VALUES ('db94fcbfca324009ae5c1ca65e0eebb7','propaganda','[ˌprɒpəˈɡændə]','http://res.iciba.com/resource/amp3/oxford/0/6b/02/6b02b53485a236794c53a53b436a827b.mp3','n. 宣传，宣传运动','','');----
INSERT INTO classwords VALUES ('fb1148dc124c45ab8dd2b7e43756dfdd','db94fcbfca324009ae5c1ca65e0eebb7','12');----
INSERT INTO word VALUES ('0ce0e9ef388c4c91916630afaf5b61c1','avail','[əˈveil]','http://res.iciba.com/resource/amp3/oxford/0/1d/b7/1db70ad30233b1990866132dd9f1359c.mp3','n. 益处','','');----
INSERT INTO classwords VALUES ('44a4dd062a6542bdb1829669bb9b4c6a','0ce0e9ef388c4c91916630afaf5b61c1','12');----
INSERT INTO word VALUES ('41d3221238814eed9efe483f27be401d','pneumatic','[nu:ˈmætɪk]','http://res.iciba.com/resource/amp3/oxford/0/86/1c/861cf391276cefe2bc2b72202fb3ccb4.mp3','adj. 充气的；气动的','','');----
INSERT INTO classwords VALUES ('048e13659dab4d82bb5096a921ef92f5','41d3221238814eed9efe483f27be401d','12');----
INSERT INTO word VALUES ('3dc50e6b91844c18b868aa4fb1741f76','hug','[hʌɡ]','http://res.iciba.com/resource/amp3/oxford/0/ab/ee/abee0f02137ac667f4489c4e5cb817c8.mp3','n. 紧紧拥抱','','');----
INSERT INTO classwords VALUES ('fef79312f4fd470cbd93603a274398d3','3dc50e6b91844c18b868aa4fb1741f76','12');----
INSERT INTO word VALUES ('96473890e27041648fcfe11a1639630b','icy','[ˈaɪsi:]','http://res.iciba.com/resource/amp3/oxford/0/f0/0c/f00c9400d093fbe91299470dfcf2a3d4.mp3','adj. 冰冷的；冷冰冰的；结冰的','','');----
INSERT INTO classwords VALUES ('703681580d434cb3bea7e18d84d36397','96473890e27041648fcfe11a1639630b','12');----
INSERT INTO word VALUES ('928347ecf08e49ac8e60deec29eb0f97','datum','[ˈdeɪtəm]','http://res.iciba.com/resource/amp3/oxford/0/77/c7/77c7ee43cf971bedbe44d70d13b876c2.mp3','n. 资料；数据','','');----
INSERT INTO classwords VALUES ('1095049bbebd4db699aa7db8046f8ece','928347ecf08e49ac8e60deec29eb0f97','12');----
INSERT INTO word VALUES ('2dea8980d4e64761976cdba08e0fd089','acquaint','[əˈkweint]','http://res.iciba.com/resource/amp3/oxford/0/b0/04/b004fbf4e90db26b0e831abdcf4021fd.mp3','vt. 使认识，使了解','','');----
INSERT INTO classwords VALUES ('9a7a7734bafd4b0c91ee968801929d82','2dea8980d4e64761976cdba08e0fd089','12');----
INSERT INTO word VALUES ('653abf3ff83444059229220061060965','wisdom','[ˈwizdəm]','http://res.iciba.com/resource/amp3/oxford/0/49/29/4929fcbb3d590c2e2b5a62f5c95af77a.mp3','n. 智慧；知识；明智','','');----
INSERT INTO classwords VALUES ('482366b441354b4da3871cb293ac07d3','653abf3ff83444059229220061060965','12');----
INSERT INTO word VALUES ('ed41b6061a9e4ed1b33251155c84fa54','compensate','[ˈkɔmpenseit]','http://res.iciba.com/resource/amp3/oxford/0/96/87/968736f85c96e2fdd0528134a2e3b0f2.mp3','vt. 补偿，赔偿；抵销','','');----
INSERT INTO classwords VALUES ('a39e292c789f4c18b542eb2c8b3870df','ed41b6061a9e4ed1b33251155c84fa54','12');----
INSERT INTO word VALUES ('f2a47ca6ed6349439ac71855069dbfa6','miniature','[ˈminiətʃə]','http://res.iciba.com/resource/amp3/oxford/0/ce/9e/ce9e3e1c1f7984aacb0558f099c657cc.mp3','adj. 微小的；微型的','','');----
INSERT INTO classwords VALUES ('ff144da9b0a44ef498b32df36fbefd3a','f2a47ca6ed6349439ac71855069dbfa6','12');----
INSERT INTO word VALUES ('52f4b2cc94e243fea52ec52307255284','attorney','[əˈtə:ni]','http://res.iciba.com/resource/amp3/0/0/d9/1d/d91ddf1d5c2616a59491f5247f68e5b0.mp3','n. 辩护律师','','');----
INSERT INTO classwords VALUES ('9ea482d68844453180b41fc01b96c919','52f4b2cc94e243fea52ec52307255284','12');----
INSERT INTO word VALUES ('b12cceda3b2e401390a36630539f46ec','taper','[ˈteɪpə]','http://res.iciba.com/resource/amp3/oxford/0/5a/58/5a5847f2c41b43141098949708b2899c.mp3','v. （使）一端逐渐变细；逐渐减少','','');----
INSERT INTO classwords VALUES ('25376f5d401949689d2e37c8e22b1370','b12cceda3b2e401390a36630539f46ec','12');----
INSERT INTO word VALUES ('ee4776bd04c245d6968f03c26def6a64','northwards','[ˈnɔ:θwədz]','http://res.iciba.com/resource/amp3/0/0/79/62/796297ea7a29d2372b875435194a854a.mp3','adv. 向北方','','');----
INSERT INTO classwords VALUES ('45902d696f1c46a4945300ce6ad8baee','ee4776bd04c245d6968f03c26def6a64','12');----
INSERT INTO word VALUES ('64e30407dd44435f95987561bc9b3632','referee','[ˌrefəˈri:]','http://res.iciba.com/resource/amp3/oxford/0/9c/57/9c57f446bee674099301e09a4ffe3feb.mp3','v. 为…担任裁判；执法（比赛）','','');----
INSERT INTO classwords VALUES ('c882286d1fd74bf7a7048e5478eef292','64e30407dd44435f95987561bc9b3632','12');----
INSERT INTO word VALUES ('990819266242439bbd4cf0bf0a9de8fc','locality','[ləuˈkæliti]','http://res.iciba.com/resource/amp3/oxford/0/c6/e2/c6e2657d0930cf65b2cf10edf74e3571.mp3','n. 位置，地点；地区','','');----
INSERT INTO classwords VALUES ('732a35148bab47e1881f4b2712195901','990819266242439bbd4cf0bf0a9de8fc','12');----
INSERT INTO word VALUES ('9e0028b69a454d84a9e6c0bc2ed8a628','sift','[sift]','http://res.iciba.com/resource/amp3/oxford/0/75/db/75db38b27d3620f5234cd97bbd6cee23.mp3','vi. 筛','','');----
INSERT INTO classwords VALUES ('bb82cf331c614651b5bdeedc31221b95','9e0028b69a454d84a9e6c0bc2ed8a628','12');----
INSERT INTO word VALUES ('fbb82e31d77e4d82aeb24201e5d8a487','brand','[brænd]','http://res.iciba.com/resource/amp3/oxford/0/83/ea/83ea0016004ff4e7928228d685cc2574.mp3','vt. 在…上打烙印；加污名于','','');----
INSERT INTO classwords VALUES ('7b8a6e877b3a4372b7c9705ea5a60711','fbb82e31d77e4d82aeb24201e5d8a487','12');----
INSERT INTO word VALUES ('4c9a026b030945d2a5fa1cd59937df72','skip','[skip]','http://res.iciba.com/resource/amp3/oxford/0/b7/59/b7596b82be8bc1e24b90046847fa6222.mp3','vi. 跳跃；跳绳；略过','','');----
INSERT INTO classwords VALUES ('ac2f8ba7dafb4a79afaa7dce320f30ae','4c9a026b030945d2a5fa1cd59937df72','12');----
INSERT INTO word VALUES ('5feb8dfc99b54c7c8e3e47ff011e45f6','installment','[ɪn''stɔːlmənt]','http://res.iciba.com/resource/amp3/0/0/5e/6e/5e6eb4c9ac2d5e75edee67dc9801d543.mp3','n. 分期付款','','');----
INSERT INTO classwords VALUES ('407c46718c2b41949c40043847bc4a15','5feb8dfc99b54c7c8e3e47ff011e45f6','12');----
INSERT INTO word VALUES ('84a8e200621c4de9bd4c0d7501eaad7a','reservation','[ˌrezəˈveiʃən]','http://res.iciba.com/resource/amp3/oxford/0/20/73/2073066b4f21fb2ae86f3b858205a230.mp3','n. 保留；预订；保留地','','');----
INSERT INTO classwords VALUES ('fb1b5f0d86354227939497e0339163ed','84a8e200621c4de9bd4c0d7501eaad7a','12');----
INSERT INTO word VALUES ('34f77d9d1eb1415195667c78d22a31d8','sandwich','[ˈsænwidʒ]','http://res.iciba.com/resource/amp3/oxford/0/2f/0c/2f0cedf6247dee682e1dd74adbb40558.mp3','vt. 夹裹；把…夹入','','');----
INSERT INTO classwords VALUES ('1c603cbc2b754d0e9ff6641310653e87','34f77d9d1eb1415195667c78d22a31d8','12');----
INSERT INTO word VALUES ('00bf44d2658a46e393c668427e982e8f','Heaven','','http://res-tts.iciba.com/7/1/4/714d82a0a84f9c6e3495fe2aa5618627.mp3','n. 上帝，神','','');----
INSERT INTO classwords VALUES ('1accc85d5f324ce4976b18018bc3ca2f','00bf44d2658a46e393c668427e982e8f','12');----
INSERT INTO word VALUES ('cfabed3f58594e28a2220b6ed75785a0','slap','[slæp]','http://res.iciba.com/resource/amp3/oxford/0/69/50/695097a676d98abb20bcd522a7f0dc00.mp3','n. 掌掴','','');----
INSERT INTO classwords VALUES ('84cd8d3f083048d392007bbc56ca2313','cfabed3f58594e28a2220b6ed75785a0','12');----
INSERT INTO word VALUES ('bb8c0816179b4daf94e8ce6ae559a05c','editorial','[ˌediˈtɔ:riəl]','http://res.iciba.com/resource/amp3/oxford/0/53/02/5302896dce3223370dd99ff639e2c5d9.mp3','adj. 社论的；编辑的，编者的','','');----
INSERT INTO classwords VALUES ('bc36c6594e9044ddbd5e071f1dd4c970','bb8c0816179b4daf94e8ce6ae559a05c','12');----
INSERT INTO word VALUES ('1eeb7c59e0a84d8d867b27dbcb55e460','murmur','[ˈmə:mə]','http://res.iciba.com/resource/amp3/oxford/0/39/32/39325f544b4a6eb52af80ba6c106684f.mp3','n. 低语；咕哝','','');----
INSERT INTO classwords VALUES ('707256e23154451496c590f87b9db76f','1eeb7c59e0a84d8d867b27dbcb55e460','12');----
INSERT INTO word VALUES ('fdf7edc5b8bd416ca7e8847b40ea6387','thereof','[ðeərˈʌv]','http://res.iciba.com/resource/amp3/1/0/62/5b/625bbf2d6cff3d4f710a8e562d21bd15.mp3','adv. 在其中，其；它的','','');----
INSERT INTO classwords VALUES ('1fda948380f64dd3a09a6450b57fe1ff','fdf7edc5b8bd416ca7e8847b40ea6387','12');----
INSERT INTO word VALUES ('750e20093e414d2a931eb24c8abbf221','balcony','[ˈbælkəni]','http://res.iciba.com/resource/amp3/oxford/0/43/d5/43d5ee504a23ce4e694915bfe3f7ef1c.mp3','n. 阳台；（电影院等的）楼厅，楼座','','');----
INSERT INTO classwords VALUES ('6f82f35c438847e692a1d820cc4964fd','750e20093e414d2a931eb24c8abbf221','12');----
INSERT INTO word VALUES ('0776c68c70c542a49886537a46165365','commence','[kəˈmens]','http://res.iciba.com/resource/amp3/oxford/0/bf/e5/bfe5187b17b446a81e88b00fd66b9354.mp3','vt.& vi.开始； 着手； 获得学位','','');----
INSERT INTO classwords VALUES ('5efef17f07834a2c8305124b6e4d2497','0776c68c70c542a49886537a46165365','12');----
INSERT INTO word VALUES ('9ca5f199a5604960a2204d07edbe1ef3','adjacent','[əˈdʒeisənt]','http://res.iciba.com/resource/amp3/oxford/0/dd/80/dd8095547d78fddb16bed61fc0616bad.mp3','adj. 毗连的；邻近的','','');----
INSERT INTO classwords VALUES ('ada555541a82460b96fbbefeb6d49acc','9ca5f199a5604960a2204d07edbe1ef3','12');----
INSERT INTO word VALUES ('295920ecfd984233a4e4b8a5d978911c','mustard','[ˈmʌstəd]','http://res.iciba.com/resource/amp3/oxford/0/03/cf/03cf33c83b9eeafea9d3d42cf31b3a52.mp3','n. 芥末；芥菜；芥末色','','');----
INSERT INTO classwords VALUES ('00b8bf3807f246a781204d6c50c5cfbd','295920ecfd984233a4e4b8a5d978911c','12');----
INSERT INTO word VALUES ('ce11613aed294894b97573690fb5ef6f','subsequently','[ˈsʌbsɪkwəntlɪ]','http://res.iciba.com/resource/amp3/oxford/0/47/9e/479e6299997652858e21548dec7885ae.mp3','adv. 其后，其次，接着','','');----
INSERT INTO classwords VALUES ('e12f561d44fa4c679b4aec4639250b86','ce11613aed294894b97573690fb5ef6f','12');----
INSERT INTO word VALUES ('8dd23ddaca7d4a4780b7ea72cc8b4dd4','descent','[diˈsent]','http://res.iciba.com/resource/amp3/oxford/0/87/fa/87fab3be58b93f5ed283e03bcf514387.mp3','n. 下降；出身；斜坡','','');----
INSERT INTO classwords VALUES ('45508047d4da467ebe786b2abc188d98','8dd23ddaca7d4a4780b7ea72cc8b4dd4','12');----
INSERT INTO word VALUES ('f877d928274e4186bef65af6dd591455','instrumental','[ˌɪnstruˈmentl]','http://res.iciba.com/resource/amp3/0/0/0c/9b/0c9bb4ec2237995230573a658194d14f.mp3','adj. 用乐器演奏的；有帮助的','','');----
INSERT INTO classwords VALUES ('1c1ef5653bcc49c3bd3e0f6ceef9ac9b','f877d928274e4186bef65af6dd591455','12');----
INSERT INTO word VALUES ('1d71b57bfefc45488aae7cf689504d35','goodness','[ˈɡudnis]','http://res.iciba.com/resource/amp3/oxford/0/d1/59/d15925f89797509a96690b050b8ece31.mp3','n. 善良，美德','','');----
INSERT INTO classwords VALUES ('933b91ea507048e7882bcbade8afad51','1d71b57bfefc45488aae7cf689504d35','12');----
INSERT INTO word VALUES ('502a3b07bbc0404f82d8b86b22ad3701','slim','[slim]','http://res.iciba.com/resource/amp3/oxford/0/d3/d0/d3d0880baebf73f5cb44de24bdaefa78.mp3','adj. 纤细的；微小的；薄的','','');----
INSERT INTO classwords VALUES ('1ffeccba69b148c4831794b0406f0a2e','502a3b07bbc0404f82d8b86b22ad3701','12');----
INSERT INTO word VALUES ('a47a9eddf8b24d7a860b2fc7d4c242f7','plump','[plʌmp]','http://res.iciba.com/resource/amp3/oxford/0/d1/a9/d1a9dd6345612fb14b21ca744bca0286.mp3','adj. 丰满的；胖乎乎的','','');----
INSERT INTO classwords VALUES ('18014486965f4a31a15a872d85c335bc','a47a9eddf8b24d7a860b2fc7d4c242f7','12');----
INSERT INTO word VALUES ('4f5694116b944c749db4a11dcfe7167e','contradict','[ˌkɔntrəˈdikt]','http://res.iciba.com/resource/amp3/oxford/0/70/89/70898a7499a64f3c68354e255fad1d80.mp3','vt. 反驳，否认；与…矛盾','','');----
INSERT INTO classwords VALUES ('679610046a7d4118b8b92f3eb6494888','4f5694116b944c749db4a11dcfe7167e','12');----
INSERT INTO word VALUES ('ece0932c1784497aa80677564a83baaf','xerox','[ˈzɪərɔks]','http://res.iciba.com/resource/amp3/0/0/b0/08/b00890530c661f9acc7c4e0419d8d4b4.mp3','vt.&vi. 复印，影印','','');----
INSERT INTO classwords VALUES ('c8b6ba067af84e3a9114e70c57198fa7','ece0932c1784497aa80677564a83baaf','12');----
INSERT INTO word VALUES ('7a4729ed4f3f4648bef1cfe561c74acd','action','[ˈækʃən]','http://res.iciba.com/resource/amp3/oxford/0/6e/c9/6ec960e647db61d54318f1b34642433a.mp3','n. 行为；活动；措施；效用；诉讼','','');----
INSERT INTO classwords VALUES ('000ad64b446c4ece816ee08b582007e0','7a4729ed4f3f4648bef1cfe561c74acd','12');----
INSERT INTO word VALUES ('f1f019046b7647c7a20fdf23f4894037','cross','[krɔs]','http://res.iciba.com/resource/amp3/0/0/22/aa/22aadb26447d87b550b155a4d764fad0.mp3','adj. 生气的，愤怒的；（街道）交叉的','','');----
INSERT INTO classwords VALUES ('c7f8e60f70d04e7588adec19d88083de','f1f019046b7647c7a20fdf23f4894037','12');----
INSERT INTO word VALUES ('8d304d8a259945b49413362194d73e50','herald','[ˈherəld]','http://res.iciba.com/resource/amp3/oxford/0/73/08/73081a0c8365623171bfa7063bb581e6.mp3','v. 预告；宣布','','');----
INSERT INTO classwords VALUES ('dfee9f79803a4c2b83061573184a3b80','8d304d8a259945b49413362194d73e50','12');----
INSERT INTO word VALUES ('1590a9a1c0fe46d3bd7fc2e8e72c03d0','retirement','[rɪˈtaɪəmənt]','http://res.iciba.com/resource/amp3/oxford/0/32/11/321159fc96a6256be4b7a160e124bbfe.mp3','n. 退休；退休生活','','');----
INSERT INTO classwords VALUES ('5d36d983da2b4b37954a942c355bebf8','1590a9a1c0fe46d3bd7fc2e8e72c03d0','12');----
INSERT INTO word VALUES ('eaae44056d5a4cba9f9f6e3b188df872','white','[hwait]','http://res.iciba.com/resource/amp3/oxford/0/ae/51/ae512bcb1304c83999f2ae5c21e95a18.mp3','adj. 白种人的；脸色苍白的','','');----
INSERT INTO classwords VALUES ('91fb4f98230440948bf0bf1894dd90c9','eaae44056d5a4cba9f9f6e3b188df872','12');----
INSERT INTO word VALUES ('4db92615eb95477b9b2908993ecdbd85','detach','[diˈtætʃ]','http://res.iciba.com/resource/amp3/oxford/0/f0/bc/f0bc9bc02e2f13a382bc8d540be7b580.mp3','vt. 分开；拆卸；使脱离','','');----
INSERT INTO classwords VALUES ('72d03ab14f7b48aaa3ba3b44e7abfaff','4db92615eb95477b9b2908993ecdbd85','12');----
INSERT INTO word VALUES ('67c98f8f433b4253bea5544ed7cea566','liable','[ˈlaiəbl]','http://res.iciba.com/resource/amp3/oxford/0/71/4f/714f4a1cbe53209bf80a14101f2b76d5.mp3','adj. 有（法律）责任的；有…倾向的','','');----
INSERT INTO classwords VALUES ('d193a4a9568e40b183f1052690d101de','67c98f8f433b4253bea5544ed7cea566','12');----
INSERT INTO word VALUES ('ce090436ee1f48d79015c4896706936a','bazaar','[bəˈzɑ:]','http://res.iciba.com/resource/amp3/oxford/0/7d/54/7d54ee5cf89b0883dc5febcce23ed604.mp3','n. 集市，市场；义卖','','');----
INSERT INTO classwords VALUES ('4d0b92d3f2524dda8afd3058d022ca13','ce090436ee1f48d79015c4896706936a','12');----
INSERT INTO word VALUES ('20c41a8fceda440bb48a2f2408548e99','pantry','[ˈpæntri:]','http://res.iciba.com/resource/amp3/oxford/0/4e/d5/4ed54017b6eb2a33dd59a5f140c39b83.mp3','n. 食品柜，餐具室','','');----
INSERT INTO classwords VALUES ('46544899c56745cba12b2b9766dc2727','20c41a8fceda440bb48a2f2408548e99','12');----
INSERT INTO word VALUES ('600c81be26c642ddb9a1f7292d24f775','integrity','[inˈteɡriti]','http://res.iciba.com/resource/amp3/oxford/0/ae/3f/ae3fea738b4f3477e5bc4c7e20454826.mp3','n. 诚实，正直；完整','','');----
INSERT INTO classwords VALUES ('7d373d39e7924b3890f6718a0aeabab7','600c81be26c642ddb9a1f7292d24f775','12');----
INSERT INTO word VALUES ('feb3ba99cf024a4d917b3f11b5f9951a','decorative','[ˈdekərətɪv]','http://res.iciba.com/resource/amp3/0/0/8a/81/8a8173677f164dd2e2cf83bea2a42a8b.mp3','adj. 装饰的；可作装饰的','','');----
INSERT INTO classwords VALUES ('b71c2ea5914349dda88eed23fe5c501d','feb3ba99cf024a4d917b3f11b5f9951a','12');----
INSERT INTO word VALUES ('74183ca7ef74430891d35f55db04de56','documentary','[ˌdɔkjuˈmentəri]','http://res.iciba.com/resource/amp3/oxford/0/09/fb/09fbb6bd9a4893f94a565a7271196f11.mp3','adj. 纪录的；文件的；书面的','','');----
INSERT INTO classwords VALUES ('ab983d87b27d4932949960b7d7ee7b0e','74183ca7ef74430891d35f55db04de56','12');----
INSERT INTO word VALUES ('6196ac804add41deb446312c339a9195','survival','[səˈvaivəl]','http://res.iciba.com/resource/amp3/oxford/0/b2/1e/b21ecdaac12f20979d12a4089529ff1e.mp3','n. 幸存，存活；幸存者；遗物','','');----
INSERT INTO classwords VALUES ('d2b77224bd0b4aae94aa3b2656378f7f','6196ac804add41deb446312c339a9195','12');----
INSERT INTO word VALUES ('7fb7ced939234ad39c0bd58cfcd309be','successor','[səkˈsesə]','http://res.iciba.com/resource/amp3/oxford/0/3a/6d/3a6d0b0ce27a7e264911ec200e79db3a.mp3','n. 接任者，继承者','','');----
INSERT INTO classwords VALUES ('6165068cfd1b459997021e2627799055','7fb7ced939234ad39c0bd58cfcd309be','12');----
INSERT INTO word VALUES ('60846be4e9d04589a159e4b09e980fb8','roller','[ˈrəulə]','http://res.iciba.com/resource/amp3/oxford/0/89/16/89168f3676be781c827b8a156df92a1a.mp3','n. 滚轴，滚筒；发卷','','');----
INSERT INTO classwords VALUES ('d4571e0e558d4932abf8f251f5c9767e','60846be4e9d04589a159e4b09e980fb8','12');----
INSERT INTO word VALUES ('7c284d870de549a68139630a53a2323b','tread','[tred]','http://res.iciba.com/resource/amp3/oxford/0/ef/cb/efcbdccb30891a7a115455bde143960c.mp3','vt. 踩，踏，践踏；步行','','');----
INSERT INTO classwords VALUES ('e4580e7d9dba46248a29ff1a03f66054','7c284d870de549a68139630a53a2323b','12');----
INSERT INTO word VALUES ('0f76317f6fb84881b61651fad726b98b','disorder','[disˈɔ:də]','http://res.iciba.com/resource/amp3/oxford/0/6c/fb/6cfba4d9151e2bcebb5963ba6eda7ec1.mp3','n. （身心机能的）失调，不适；杂乱，混...','','');----
INSERT INTO classwords VALUES ('37722555d0024e508608a0680e024bec','0f76317f6fb84881b61651fad726b98b','12');----
INSERT INTO word VALUES ('c106bcb465f14a3c8e258e4cb765332c','wharf','[hwɔ:f]','http://res.iciba.com/resource/amp3/0/0/ef/60/ef60277995a4cf4de903dd68c41cf4da.mp3','n. 码头，停泊所','','');----
INSERT INTO classwords VALUES ('2c7d730e2e67409f803a17558cb703f6','c106bcb465f14a3c8e258e4cb765332c','12');----
INSERT INTO word VALUES ('d84f5fc413b94207bbf979f63adfb2df','confirmation','[ˌkɔnfəˈmeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/dd/61/dd6142101b2b5ea8d10925868f94a3f0.mp3','n. 证实；确认','','');----
INSERT INTO classwords VALUES ('ac5a43066b6544fa97ee4d7bc78991bf','d84f5fc413b94207bbf979f63adfb2df','12');----
INSERT INTO word VALUES ('64ad7e9371ce4d80a082da9603abe18f','streamline','[ˈstri:mlain]','http://res.iciba.com/resource/amp3/oxford/0/cb/21/cb21eb6b5fd56a60b6566e6edc34d8e7.mp3','v. 使效率更高；精简','','');----
INSERT INTO classwords VALUES ('0493664ee1ec4d2eb85a19abe5e89ac9','64ad7e9371ce4d80a082da9603abe18f','12');----
INSERT INTO word VALUES ('0341330e3e8a469c886544d994b78af3','practicable','[ˈpræktikəbl]','http://res.iciba.com/resource/amp3/oxford/0/29/ec/29ec9f23e2ac64495b91e609b29a1f9e.mp3','adj. 切实可行的，行得通的','','');----
INSERT INTO classwords VALUES ('9b93312ab77b47ec99518935d7f639e4','0341330e3e8a469c886544d994b78af3','12');----
INSERT INTO word VALUES ('66ad2867221b4341b9264e90df301ce5','log','[lɔɡ]','http://res.iciba.com/resource/amp3/0/0/dc/1d/dc1d71bbb5c4d2a5e936db79ef10c19f.mp3','n. 航海日志；原木；干材','','');----
INSERT INTO classwords VALUES ('51c500e6c0ce429682ce7574bbe670fa','66ad2867221b4341b9264e90df301ce5','12');----
INSERT INTO word VALUES ('93dc21a4b9224ed7b57087b5fe7f979f','pilgrim','[ˈpilɡrim]','http://res.iciba.com/resource/amp3/oxford/0/b7/e3/b7e38ce6ca823e0b0e3774ed4a034a23.mp3','n. 香客，朝圣者','','');----
INSERT INTO classwords VALUES ('f59eeba07da94853bdc0bee30aba1c31','93dc21a4b9224ed7b57087b5fe7f979f','12');----
INSERT INTO word VALUES ('191b72d3ddd549aab211dd03aa9b1f59','equation','[iˈkweiʃən]','http://res.iciba.com/resource/amp3/oxford/0/55/cb/55cbdfcc16648fc493e33491bdb56655.mp3','n. 平衡，综合体；方程式','','');----
INSERT INTO classwords VALUES ('1d95e56d24db473e806b3e456f7ff07a','191b72d3ddd549aab211dd03aa9b1f59','12');----
INSERT INTO word VALUES ('0f11f9e1d12d42f3962703f2811ecc20','innovation','[ˌɪnəuˈveiʃən]','http://res.iciba.com/resource/amp3/oxford/0/f3/40/f34016ab6b4dbfc83eb2b83fe4d9c3d0.mp3','n. 创新，改革；新方法','','');----
INSERT INTO classwords VALUES ('030bd5e90d984c4f9762747e049d3a37','0f11f9e1d12d42f3962703f2811ecc20','12');----
INSERT INTO word VALUES ('125c29fa4c044ceda332f3822b169b30','jelly','[ˈdʒeli:]','http://res.iciba.com/resource/amp3/0/0/32/83/328356824c8487cf314aa350d11ae145.mp3','n. 果冻；果酱；胶状物','','');----
INSERT INTO classwords VALUES ('a419e54d9b24400195d028e323f89e10','125c29fa4c044ceda332f3822b169b30','12');----
INSERT INTO word VALUES ('53c0ef711c5c469a81bb7d88fecb579c','mute','[mju:t]','http://res.iciba.com/resource/amp3/oxford/0/bd/6c/bd6c38bedce59b8d8c8c3376e54a40d0.mp3','adj. 缄默的；哑的','','');----
INSERT INTO classwords VALUES ('08adb94b0889470b9a04b92213815544','53c0ef711c5c469a81bb7d88fecb579c','12');----
INSERT INTO word VALUES ('5fd95b292eb445e5b5699fc06e373e88','offspring','[ˈɔfspriŋ]','http://res.iciba.com/resource/amp3/oxford/0/5b/f3/5bf304683fdf61eaaeaa1c092bf6261d.mp3','n. 儿女，子孙，后代','','');----
INSERT INTO classwords VALUES ('e3e3eef5815f4dc689a0d17ac41c40ed','5fd95b292eb445e5b5699fc06e373e88','12');----
INSERT INTO word VALUES ('2533e0319a274f5f807bc95ef4fca08a','support','[səˈpɔ:t]','http://res.iciba.com/resource/amp3/0/0/43/49/434990c8a25d2be94863561ae98bd682.mp3','vt. 支持；供养；证实；支撑','','');----
INSERT INTO classwords VALUES ('afd66f54c1f74b4680f6da283a382d55','2533e0319a274f5f807bc95ef4fca08a','12');----
INSERT INTO word VALUES ('90f1f68e9dc349a8b0491a6084f1c9d5','insight','[ˈinsait]','http://res.iciba.com/resource/amp3/oxford/0/d1/7d/d17d8e1921230f8652e8928fce2a267a.mp3','n. 洞察力；洞悉','','');----
INSERT INTO classwords VALUES ('8b5524f1cfdd4aaab3f31437451c7470','90f1f68e9dc349a8b0491a6084f1c9d5','12');----
INSERT INTO word VALUES ('0c6916e40bd543cbb1be08db720c8de4','revenue','[ˈrevənju:]','http://res.iciba.com/resource/amp3/oxford/0/f4/33/f43372fb26b09aaba5f978672e4f3264.mp3','n. 收入，收益；税收','','');----
INSERT INTO classwords VALUES ('dce558d7ecd3443194e90f0039fe5925','0c6916e40bd543cbb1be08db720c8de4','12');----
INSERT INTO word VALUES ('2ab3ccfc58034b6f95f2a8da4ccd1ea4','extra','[ˈekstrə]','http://res.iciba.com/resource/amp3/oxford/0/12/77/12774c230d045ce94ab201e85460311a.mp3','n. 附加物；额外费用；临时演员','','');----
INSERT INTO classwords VALUES ('7698aceaf76b41b3a5ee3bfd4d76933c','2ab3ccfc58034b6f95f2a8da4ccd1ea4','12');----
INSERT INTO word VALUES ('ade5ee047f5847f4929d41ced22da9b8','dominant','[ˈdɔminənt]','http://res.iciba.com/resource/amp3/oxford/0/50/e9/50e949382b05722191551ddd7924928a.mp3','n. 主因；显性 adj. 占优势的；...','','');----
INSERT INTO classwords VALUES ('92ca58314ffc4671a5e2072eff4fd7df','ade5ee047f5847f4929d41ced22da9b8','12');----
INSERT INTO word VALUES ('ddc23c470cb2447ebcb178ed03f79f8c','radical','[ˈrædikəl]','http://res.iciba.com/resource/amp3/oxford/0/91/31/9131fa3aac433f642f209efe430d567a.mp3','adj. 基本的；彻底的；激进的','','');----
INSERT INTO classwords VALUES ('509bf2b28e384e8cbaefee415f944697','ddc23c470cb2447ebcb178ed03f79f8c','12');----
INSERT INTO word VALUES ('8e9a235c612743df8c5d10c40361033d','feel','[fi:l]','http://res.iciba.com/resource/amp3/oxford/0/00/73/007399e897df2728c213af6d810d4ae0.mp3','v. 感觉；摸上去；触摸；觉察到','','');----
INSERT INTO classwords VALUES ('186b1a80f9da46a389e838fef6067689','8e9a235c612743df8c5d10c40361033d','12');----
INSERT INTO word VALUES ('daa9dc56fbb44770a5ec8fdf6b955d7a','global','[ˈɡləubəl]','http://res.iciba.com/resource/amp3/0/0/9c/70/9c70933aff6b2a6d08c687a6cbb6b765.mp3','adj. 全面的；全球的','','');----
INSERT INTO classwords VALUES ('4ee5ebf4dc3542e5bbc935315e9112ea','daa9dc56fbb44770a5ec8fdf6b955d7a','12');----
INSERT INTO word VALUES ('10932774c72d4669895c117d25e18be7','shortage','[ˈʃɔ:tidʒ]','http://res.iciba.com/resource/amp3/oxford/0/43/4b/434bc97003de8dc32a5c42a1e14f974f.mp3','n. 短缺，缺少；不足','','');----
INSERT INTO classwords VALUES ('7bfefb825ad8439d97c936856be5b98d','10932774c72d4669895c117d25e18be7','12');----
INSERT INTO word VALUES ('e87d79bf0d04488a882736c6a7ce0632','superstition','[ˌsju:pəˈstiʃən]','http://res.iciba.com/resource/amp3/oxford/0/3d/f0/3df02e14e32acbc1b7189af0a15f58e8.mp3','n. 迷信，迷信观念','','');----
INSERT INTO classwords VALUES ('5a7a37146a194a52b5a62b9d91bc2a94','e87d79bf0d04488a882736c6a7ce0632','12');----
INSERT INTO word VALUES ('22cfe7eb3cf349eaa14376a10dc05206','infinite','[ˈinfinit]','http://res.iciba.com/resource/amp3/oxford/0/f2/5e/f25eaa796ccdd83f9d3058f6be1b3188.mp3','adj. 无限的，无穷的；极度的','','');----
INSERT INTO classwords VALUES ('9f8705b3e67645779ec06507ddfb0f6c','22cfe7eb3cf349eaa14376a10dc05206','12');----
INSERT INTO word VALUES ('d4deb2a31b814af49cf31bd269c1e5dc','damn','[dæm]','http://res.iciba.com/resource/amp3/oxford/0/16/d9/16d9a024fcb8c4963275afaa476c6aad.mp3','n. 一点点；丝毫 vt.诅咒； 谴责...','','');----
INSERT INTO classwords VALUES ('f2651a1abbba47feb9371770e1e75e68','d4deb2a31b814af49cf31bd269c1e5dc','12');----
INSERT INTO word VALUES ('22a8f26ef2904b239b9808a2cda2acc1','hail','[heil]','http://res.iciba.com/resource/amp3/oxford/0/40/2c/402c16d5b1ad9a60e9fb912a42111f68.mp3','n. 冰雹；一阵','','');----
INSERT INTO classwords VALUES ('dd7453bf67ea4f4c8906ef87d4040b70','22a8f26ef2904b239b9808a2cda2acc1','12');----
INSERT INTO word VALUES ('f780d3c0f15e45bb8de7510d0f0918d8','rapture','[ˈræptʃə]','http://res.iciba.com/resource/amp3/oxford/0/b4/2a/b42a421fed98c31c321e5a45ffcc8e3d.mp3','n. 狂喜；欣喜若狂','','');----
INSERT INTO classwords VALUES ('1b2396a3385d412aa0c1bb53ce8aa016','f780d3c0f15e45bb8de7510d0f0918d8','12');----
INSERT INTO word VALUES ('9553dafeb4e04fa2b495221424ae9e1f','periodic','[ˌpiəriˈɔdik]','http://res.iciba.com/resource/amp3/1/0/e6/ff/e6ffdec5e14fce371eb7ae99edebbbee.mp3','adj. 周期的；定期的','','');----
INSERT INTO classwords VALUES ('316faecaf6f1442ebe68d75d138c611d','9553dafeb4e04fa2b495221424ae9e1f','12');----
INSERT INTO word VALUES ('f007ba9462104165b6a442c63863da98','persist','[pəˈsist]','http://res.iciba.com/resource/amp3/oxford/0/a9/5a/a95aec07982879e952404ff5f6599a9a.mp3','vi. 继续存在；执著','','');----
INSERT INTO classwords VALUES ('25252bd0b8da44729b968ddb14da6852','f007ba9462104165b6a442c63863da98','12');----
INSERT INTO word VALUES ('afad5e0a992746839cfe29d38e6c7334','cloak','[kləuk]','http://res.iciba.com/resource/amp3/0/0/7d/06/7d067ef3bf74d1659b8fa9df3de1a047.mp3','n.披风，斗篷； 外套； 借口，掩饰； ...','','');----
INSERT INTO classwords VALUES ('1e0b83b32a744e9a9f6155a0abb63af2','afad5e0a992746839cfe29d38e6c7334','12');----
INSERT INTO word VALUES ('17223707da6d420f82b92f117eee572f','gap','[ɡæp]','http://res.iciba.com/resource/amp3/oxford/0/c8/ce/c8ce00282b2f98be0bf91d5166cafe66.mp3','n. 缺口；间隔；漏洞；差距；分歧','','');----
INSERT INTO classwords VALUES ('328b1051b4bf4e8396c8f5226fefb138','17223707da6d420f82b92f117eee572f','12');----
INSERT INTO word VALUES ('2488229acf86465da14348e5e055cd5a','senseless','[ˈsenslɪs]','http://res.iciba.com/resource/amp3/oxford/0/00/a3/00a3c319b874cd1165d25653cbd814b2.mp3','adj. 失去知觉的；无意义的','','');----
INSERT INTO classwords VALUES ('1989a0d3986747cb92cbc9dca9e2fa76','2488229acf86465da14348e5e055cd5a','12');----
INSERT INTO word VALUES ('2b2e37f598eb4a1e8499b531c66a02e0','vocabulary','[vəˈkæbjuləri]','http://res.iciba.com/resource/amp3/oxford/0/d6/d1/d6d13aa6ae60d3fdab9b6ae38fad23d1.mp3','n. 词汇；词汇量；专业词汇','','');----
INSERT INTO classwords VALUES ('df8d6a37c788484eb0b56b699d2da34b','2b2e37f598eb4a1e8499b531c66a02e0','12');----
INSERT INTO word VALUES ('2266ea3746b74149a45d36e6e9e6bca5','senator','[ˈsenətə]','http://res.iciba.com/resource/amp3/oxford/0/11/8a/118a6be72e54907241452ed9f0eadaa0.mp3','n. 参议员','','');----
INSERT INTO classwords VALUES ('91dd1eafadc049639a71378714f7466e','2266ea3746b74149a45d36e6e9e6bca5','12');----
INSERT INTO word VALUES ('f16bd9b7d38947eab6f1e09ed4eb2ac9','brightness','[ˈbraɪtnɪs]','http://res.iciba.com/resource/amp3/0/0/aa/71/aa71a2ef3fb13c2642ea72645a698cb8.mp3','n. 明亮，光亮；聪明','','');----
INSERT INTO classwords VALUES ('9763df6e1c4740cdb9d8dab7274f8d5d','f16bd9b7d38947eab6f1e09ed4eb2ac9','12');----
INSERT INTO word VALUES ('30e321ea90f54873b5c5fa00cb0dd44f','offer','[ˈɔfə]','http://res.iciba.com/resource/amp3/oxford/0/18/c6/18c605475a860b46a281267055ba1876.mp3','vi. 提议','','');----
INSERT INTO classwords VALUES ('f1d13018221a40a7a8dfea0058cda789','30e321ea90f54873b5c5fa00cb0dd44f','12');----
INSERT INTO word VALUES ('c4e183ba5fb24839b9524e6f4662911f','resident','[ˈrezidənt]','http://res.iciba.com/resource/amp3/oxford/0/a0/f5/a0f50a314c5b0f5dfe70a9274a5ecf98.mp3','n. 居民，住户；实习医生','','');----
INSERT INTO classwords VALUES ('921a7565ac374fc9ad1de4b10c16f062','c4e183ba5fb24839b9524e6f4662911f','12');----
INSERT INTO word VALUES ('c49ed41a3ce84029b246c3e246cd5f29','magnitude','[ˈmæɡnitju:d]','http://res.iciba.com/resource/amp3/oxford/0/2d/0b/2d0b17a510a1dd0d61cd64f6193f932b.mp3','n. 巨大；重要性；震级','','');----
INSERT INTO classwords VALUES ('7f4489c7a46c4c3398f8809ebe39537b','c49ed41a3ce84029b246c3e246cd5f29','12');----
INSERT INTO word VALUES ('70497850efff4f599a0354d97edf33a3','rectify','[ˈrektifai]','http://res.iciba.com/resource/amp3/oxford/0/e9/4c/e94c8f0ef7521337454d3f8235c81243.mp3','vt. 纠正，修正','','');----
INSERT INTO classwords VALUES ('68c4494e5dca45e19e0ae4d2325b8a72','70497850efff4f599a0354d97edf33a3','12');----
INSERT INTO word VALUES ('6d9310dfc72347718f65f187aa282c60','deprive','[diˈpraiv]','http://res.iciba.com/resource/amp3/oxford/0/e5/69/e569df0e63779a10d7665ccfa2d559b5.mp3','vt. 剥夺；使丧失；使不能享有','','');----
INSERT INTO classwords VALUES ('ac4211c6fdcb4391abc3d9a18a0c3ab2','6d9310dfc72347718f65f187aa282c60','12');----
INSERT INTO word VALUES ('2dce911bd98745448dfed02378820ca3','grunt','[ɡrʌnt]','http://res.iciba.com/resource/amp3/oxford/0/10/b8/10b83759eadbed2bbe9331fa5fe185de.mp3','vi. 作呼噜声；（指人）发出类似的哼声','','');----
INSERT INTO classwords VALUES ('3cb5bc3b100b4bf5b2743ee02cf8d6d6','2dce911bd98745448dfed02378820ca3','12');----
INSERT INTO word VALUES ('4696154a0bb64f23a1a715fc97f0455f','handbook','[ˈhændbuk]','http://res.iciba.com/resource/amp3/oxford/0/19/96/1996a0c4c280ed685a79edabfeaeddb1.mp3','n. 手册，说明书','','');----
INSERT INTO classwords VALUES ('f8554327cc0b4053bf45b5dcc506b3e4','4696154a0bb64f23a1a715fc97f0455f','12');----
INSERT INTO word VALUES ('ba9eb559f1f1454ba55b9ba3d7fcfca6','assassinate','[əˈsæsəˌneɪt]','http://res.iciba.com/resource/amp3/oxford/0/d8/e0/d8e017d0b4db247a8f421ca8514f9df0.mp3','vt. 暗杀，行刺；中伤','','');----
INSERT INTO classwords VALUES ('222daca9e91248868ff53dfb4e3557a2','ba9eb559f1f1454ba55b9ba3d7fcfca6','12');----
INSERT INTO word VALUES ('93bc4d10db194d88baed28a5ba122a46','clatter','[ˈklætə]','http://res.iciba.com/resource/amp3/oxford/0/ec/e8/ece8cc20a8ae43ee8eada6980871c6b2.mp3','vt.&vi. 发出声响；（硬物）发出碰...','','');----
INSERT INTO classwords VALUES ('36cb2614eaa944ef943d1ab0b002b061','93bc4d10db194d88baed28a5ba122a46','12');----
INSERT INTO word VALUES ('2ac552f6013e4cccb6093deae42fe1a9','restrain','[risˈtrein]','http://res.iciba.com/resource/amp3/oxford/0/5d/86/5d863265de7e67b6ab3f2f3916dedf42.mp3','vt. 制止；克制，抑制','','');----
INSERT INTO classwords VALUES ('5f7089e33f204398b134cfcd79ff0e2e','2ac552f6013e4cccb6093deae42fe1a9','12');----
INSERT INTO word VALUES ('8fd3cc24aee340b3ba96165d0e23327b','handicap','[ˈhændikæp]','http://res.iciba.com/resource/amp3/oxford/0/63/7e/637eb0d269dad265c07b6e470bc01051.mp3','vt. 妨碍，使不利','','');----
INSERT INTO classwords VALUES ('ad58e84fb5864dcfaa97d715f4a0e57a','8fd3cc24aee340b3ba96165d0e23327b','12');----
INSERT INTO word VALUES ('275e4b82dfa4471ea258d82c5dce8b7a','disregard','[ˌdisriˈɡɑ:d]','http://res.iciba.com/resource/amp3/oxford/0/fc/5d/fc5dbbe7d86128f233178a041857a51d.mp3','n. 漠视，忽视','','');----
INSERT INTO classwords VALUES ('4d34572991d740deae83a8d763d55ddc','275e4b82dfa4471ea258d82c5dce8b7a','12');----
INSERT INTO word VALUES ('618a100ce14f483abbc6b27ee845c008','shovel','[ˈʃʌvl]','http://res.iciba.com/resource/amp3/oxford/0/65/7c/657cb586764ce7acdbc772a1551471de.mp3','vt. 铲；用铲挖；迅速把…大量送入','','');----
INSERT INTO classwords VALUES ('8ae71497e82a4af78a14b68aaef17ed6','618a100ce14f483abbc6b27ee845c008','12');----
INSERT INTO word VALUES ('f88aa2318726402b911be1582dbd6bb4','hurricane','[ˈhʌrikən]','http://res.iciba.com/resource/amp3/1/0/c5/28/c5285abd05d46a954151ddf9b8128114.mp3','n. 飓风','','');----
INSERT INTO classwords VALUES ('51b9e9cd1ddb4a618315d68d80292584','f88aa2318726402b911be1582dbd6bb4','12');----
INSERT INTO word VALUES ('8bbb1a064b794427af99fde2cbf5a57b','terrify','[ˈterifai]','http://res.iciba.com/resource/amp3/oxford/0/9a/be/9abefb71707421b7ed7313d517d1ff46.mp3','vt. 使恐慌，使惊吓','','');----
INSERT INTO classwords VALUES ('e2e97c021b704e62882e3890eeca44b6','8bbb1a064b794427af99fde2cbf5a57b','12');----
INSERT INTO word VALUES ('7765b7d0b6844fd599641be58450b7ef','respectable','[rɪˈspektəbəl]','http://res.iciba.com/resource/amp3/oxford/0/3e/d4/3ed4f45cc552bcae564c07890fdd01a5.mp3','adj. 可敬的；可观的；体面的','','');----
INSERT INTO classwords VALUES ('3c8913c63a2a4798a90526962d5986c4','7765b7d0b6844fd599641be58450b7ef','12');----
INSERT INTO word VALUES ('ac3fbb73ee424a419d3c018593b50c25','jungle','[ˈdʒʌŋɡl]','http://res.iciba.com/resource/amp3/oxford/0/8b/3d/8b3dd11285e17454a26ad6a6fd71eaa7.mp3','n. 丛林，密林；堆满东西的地方；复杂困...','','');----
INSERT INTO classwords VALUES ('b8d6d6ce8b8f4bd494f0635037806c8d','ac3fbb73ee424a419d3c018593b50c25','12');----
INSERT INTO word VALUES ('1db7abd69eec450aab0613583e106fcc','market','[ˈmɑ:kit]','http://res.iciba.com/resource/amp3/oxford/0/37/3f/373fc5cac0e00ccd045c5e4e81772f8e.mp3','vt. 营销，推销','','');----
INSERT INTO classwords VALUES ('3279c9dbd6cb4559a5bffc6b32824ab3','1db7abd69eec450aab0613583e106fcc','12');----
INSERT INTO word VALUES ('cf7527f87a1342fdaf11a7c1b5576f4c','viscous','[ˈvɪskəs]','http://res.iciba.com/resource/amp3/oxford/0/b6/2a/b62ae2e56925821494fe93b246c41eff.mp3','adj. 黏的；黏性的','','');----
INSERT INTO classwords VALUES ('4f23baa864cc4c85b349d08d288a7071','cf7527f87a1342fdaf11a7c1b5576f4c','12');----
INSERT INTO word VALUES ('e984228abcb949788a8920ad2255a825','blunder','[ˈblʌndə]','http://res.iciba.com/resource/amp3/oxford/0/69/1c/691c296bfe4793475f363bd07e6f1628.mp3','n. 疏忽；失误','','');----
INSERT INTO classwords VALUES ('82da324ae6c34e8896c8e5a4d323f35f','e984228abcb949788a8920ad2255a825','12');----
INSERT INTO word VALUES ('b86933e39ba941bd963f5537afbe36d5','continental','[ˌkɔntəˈnentl]','http://res.iciba.com/resource/amp3/oxford/0/37/56/37560046da05d36a1f42cdb1a9118f67.mp3','adj. 欧洲大陆的；大陆的','','');----
INSERT INTO classwords VALUES ('879cab45109d4a56971405c441a54513','b86933e39ba941bd963f5537afbe36d5','12');----
INSERT INTO word VALUES ('3f56697602c84c8bb88b1b4b54c4f9fe','wink','[wiŋk]','http://res.iciba.com/resource/amp3/oxford/0/e5/ad/e5adef978ba89feaea13c580c647673e.mp3','vi. 眨眼；使眼色；闪烁','','');----
INSERT INTO classwords VALUES ('f84c3631a38247688c70c40a255f1b16','3f56697602c84c8bb88b1b4b54c4f9fe','12');----
INSERT INTO word VALUES ('e69ea831ae6b47fca7f31e9e77ac648c','visa','[ˈviːzə]','http://res.iciba.com/resource/amp3/oxford/0/99/0f/990f098594642209b5956931bdc4d386.mp3','n. 签证','','');----
INSERT INTO classwords VALUES ('09a1c4dff1f9476db99d7ddca0d46183','e69ea831ae6b47fca7f31e9e77ac648c','12');----
INSERT INTO word VALUES ('207c75f6883948d28a26a08ef0fd0188','hesitate','[ˈheziteit]','http://res.iciba.com/resource/amp3/oxford/0/33/07/3307a9de6ff62b1b150f6a8c148b8257.mp3','vi. 犹豫，踌躇；不愿','','');----
INSERT INTO classwords VALUES ('7e9f5325d7f7494f9292f514904617c3','207c75f6883948d28a26a08ef0fd0188','12');----
INSERT INTO word VALUES ('9522b0b51159410288bd3a7090522a0c','coordinate','[kəuˈɔ:dineit]','http://res.iciba.com/resource/amp3/0/0/f5/d7/f5d7aa3ba4929cc12dc51a92c59fabd3.mp3','v. 使协调；使调和','','');----
INSERT INTO classwords VALUES ('8000638b64254acfb4fc31882a4a7a99','9522b0b51159410288bd3a7090522a0c','12');----
INSERT INTO word VALUES ('a49851a53637477681ef35139760ebcd','ruby','[ˈru:bi]','http://res.iciba.com/resource/amp3/oxford/0/81/3b/813b5ca806276063421d57fb94fdbff5.mp3','n. 红宝石；红宝石色','','');----
INSERT INTO classwords VALUES ('37d749677a354cd7b7f76204195d5f2b','a49851a53637477681ef35139760ebcd','12');----
INSERT INTO word VALUES ('e4bb87d146974b97b187eaf2a3258959','contrast','[ˈkɔntræst]','http://res.iciba.com/resource/amp3/0/0/c8/fd/c8fd07f040a8f2dc85f5b2d3804ea3db.mp3','vi. 形成对比','','');----
INSERT INTO classwords VALUES ('0ce4425de57a4d939438916b5940cbe5','e4bb87d146974b97b187eaf2a3258959','12');----
INSERT INTO word VALUES ('ab9ae1196c724931b10f13885f01f420','deform','[dɪˈfɔ:m]','http://res.iciba.com/resource/amp3/oxford/0/5e/a0/5ea02659fc1b8036537f67bc04d5bf6c.mp3','vt. 使变形；损毁…的外形','','');----
INSERT INTO classwords VALUES ('008942a84a894c24aee270898af10efa','ab9ae1196c724931b10f13885f01f420','12');----
INSERT INTO word VALUES ('96ff4f841a4b4aad8783e6c46ec3f0bc','integrate','[ˈintiɡreit]','http://res.iciba.com/resource/amp3/oxford/0/ff/c5/ffc552a5a37c008fe3a85f166b8f41f8.mp3','vt. 使结合；使融入；使融合','','');----
INSERT INTO classwords VALUES ('b923fa8d62e54cb59d04464fe4fed0f4','96ff4f841a4b4aad8783e6c46ec3f0bc','12');----
INSERT INTO word VALUES ('11a873f877644e98a58c45e8a5ba5809','psychology','[saiˈkɔlədʒi]','http://res.iciba.com/resource/amp3/oxford/0/03/19/0319ed5ce3d9204698529e777ddcabfd.mp3','n. 心理学；心理','','');----
INSERT INTO classwords VALUES ('a21f3829a62348fca1df5b1b77ac8802','11a873f877644e98a58c45e8a5ba5809','12');----
INSERT INTO word VALUES ('a00d1dd8c5e04237b6f9beba064da38b','blaze','[bleiz]','http://res.iciba.com/resource/amp3/oxford/0/af/35/af35e441f5eef9de666324bc89ff6bbd.mp3','vi. 燃烧；照耀；发出强光；（眼睛）闪...','','');----
INSERT INTO classwords VALUES ('1617ddf73a784248bc9734b45037051c','a00d1dd8c5e04237b6f9beba064da38b','12');----
INSERT INTO word VALUES ('a022a76c709749f5924351be4e7f46e1','team','[ti:m]','http://res.iciba.com/resource/amp3/oxford/0/9e/7a/9e7a75ea37fea8a983afca5eee568ccc.mp3','vi. 协作，合作','','');----
INSERT INTO classwords VALUES ('22f19a07f2164a00ad35dd840b1b86cb','a022a76c709749f5924351be4e7f46e1','12');----
INSERT INTO word VALUES ('03e9aed0818648d9b88eea33d4ae892a','inevitably','[ɪnˈevɪtəblɪ]','http://res.iciba.com/resource/amp3/oxford/0/8f/df/8fdfa3d754cc31415ebcbf274394f3c2.mp3','adv. 不可避免地','','');----
INSERT INTO classwords VALUES ('49cfa08fa2a04d06bdfac8dbdc713cc2','03e9aed0818648d9b88eea33d4ae892a','12');----
INSERT INTO word VALUES ('bf6f8f6f39ca43dab2d0b602af675713','haughty','[ˈhɔ:ti:]','http://res.iciba.com/resource/amp3/oxford/0/c6/ee/c6eea8753c24e5ce522395df77b291aa.mp3','adj. 傲慢的；目中无人的','','');----
INSERT INTO classwords VALUES ('1726238c30564d5fa0149c5015a65023','bf6f8f6f39ca43dab2d0b602af675713','12');----
INSERT INTO word VALUES ('5d550188545d44c280747f6a8a15fbe4','stainless','[ˈsteɪnlɪs]','http://res.iciba.com/resource/amp3/0/0/83/62/8362d309caed32b97ec4cfae7e2621cc.mp3','adj. 纯洁的；不锈的','','');----
INSERT INTO classwords VALUES ('a559713feede4af18be881e4bc6e5fac','5d550188545d44c280747f6a8a15fbe4','12');----
INSERT INTO word VALUES ('08aff4c9e75d428ab1e68899c9b27209','incorporate','[inˈkɔ:pəreit]','http://res.iciba.com/resource/amp3/oxford/0/df/b5/dfb531e7b1442008b988f3d4745cdffe.mp3','vt. 使并入，合并；包含','','');----
INSERT INTO classwords VALUES ('ec0e9c34ab164b53a8ce27ecddb02e20','08aff4c9e75d428ab1e68899c9b27209','12');----
INSERT INTO word VALUES ('b0503b975935456c9ba5d628bb23fa2b','fill','[fil]','http://res.iciba.com/resource/amp3/oxford/0/97/52/9752f7ce6b2a3ba575473a564787dfaf.mp3','vt. 使装满；挤满，占满；填塞；布满，...','','');----
INSERT INTO classwords VALUES ('5a57f03c70ac4883bf90f20fdadbcbcd','b0503b975935456c9ba5d628bb23fa2b','12');----
INSERT INTO word VALUES ('113c30998e6c4b00a9a97f76ee684463','pal','[pæl]','http://res.iciba.com/resource/amp3/oxford/0/d4/a7/d4a7f52a5ab9eda4002a903ca666240b.mp3','n. 朋友','','');----
INSERT INTO classwords VALUES ('32a285a5d9e84adf9dbb5b217072ae0a','113c30998e6c4b00a9a97f76ee684463','12');----
INSERT INTO word VALUES ('832025e0963c4fd6ae87ff1bdff45ba5','toad','[təud]','http://res.iciba.com/resource/amp3/0/0/ca/03/ca03e4b0d6a8a08f400264b5e45fb441.mp3','n. 蟾蜍，癞蛤蟆','','');----
INSERT INTO classwords VALUES ('58061deb849747e884e0f93eb60ea8b1','832025e0963c4fd6ae87ff1bdff45ba5','12');----
INSERT INTO word VALUES ('026e8657b1f04f76b682e9e7df13ab89','tempt','[tempt]','http://res.iciba.com/resource/amp3/oxford/0/3b/8b/3b8b5354752ffc1fabd792aea17d898b.mp3','vt. 引诱，诱惑；怂恿','','');----
INSERT INTO classwords VALUES ('fe0ef3f611744dd2b8b444fc100d6557','026e8657b1f04f76b682e9e7df13ab89','12');----
INSERT INTO word VALUES ('75279b2cf5bc4a3b9839d092a1690e55','specimen','[ˈspesimən]','http://res.iciba.com/resource/amp3/oxford/0/09/c3/09c3b6981d2bda44749d4d273a905e92.mp3','n. 抽样；样品；标本','','');----
INSERT INTO classwords VALUES ('37cd81ad0e5b409b91a320a0028e6d0c','75279b2cf5bc4a3b9839d092a1690e55','12');----
INSERT INTO word VALUES ('f56da6b9d898433d8f02d5be84168aa3','microwave','[ˈmaɪkrəˌweɪv]','http://res.iciba.com/resource/amp3/oxford/0/31/8f/318f88af14057dfa3197d7becb0e9f98.mp3','n. 微波','','');----
INSERT INTO classwords VALUES ('0957d9c8b12d4db287e5ed4b704203ad','f56da6b9d898433d8f02d5be84168aa3','12');----
INSERT INTO word VALUES ('124261ad3a7f418d9bad85b5323d66bc','inadequate','[ɪnˈædɪkwɪt]','http://res.iciba.com/resource/amp3/oxford/0/6b/53/6b533ade4f9551de455308eb122cfde8.mp3','adj. 不充足的；不够格的，不能胜任的','','');----
INSERT INTO classwords VALUES ('aee66b7f74bb4674916550f4a4ae7583','124261ad3a7f418d9bad85b5323d66bc','12');----
INSERT INTO word VALUES ('aa81f64a323446d6ba6c64620f721737','inaccurate','[ɪnˈækjərɪt]','http://res.iciba.com/resource/amp3/oxford/0/8e/55/8e551445979003c462a8954d60b736aa.mp3','adj. 不精确的；不准确的','','');----
INSERT INTO classwords VALUES ('1d9b5fdd8a6e46859ae97fbbf6dd5e0f','aa81f64a323446d6ba6c64620f721737','12');----
INSERT INTO word VALUES ('a7eba6caaf52414eb914864e2405306f','shameful','[ˈʃeɪmfəl]','http://res.iciba.com/resource/amp3/oxford/0/2a/7f/2a7f159b22432f1f05573672a0cdb8b1.mp3','adj. 可耻的；丢脸的','','');----
INSERT INTO classwords VALUES ('4cdc77d6a3aa4565bdb6b5152008a15f','a7eba6caaf52414eb914864e2405306f','12');----
INSERT INTO word VALUES ('171f44a220c44c29a6cb3328dedd75f5','clap','[klæp]','http://res.iciba.com/resource/amp3/oxford/0/10/9e/109ebdecb99089b660c5724f4802cbea.mp3','v. 鼓掌；快速放置；轻拍','','');----
INSERT INTO classwords VALUES ('5093c75247b640e69a16179af1382e3e','171f44a220c44c29a6cb3328dedd75f5','12');----
INSERT INTO word VALUES ('bf67675912454473a1cb185c6e429435','strife','[straif]','http://res.iciba.com/resource/amp3/oxford/0/f2/b7/f2b77d5ab94d1650d671b2ea7f8d60a8.mp3','n. 冲突，争斗','','');----
INSERT INTO classwords VALUES ('e9337168469540c0bae4a9fd230f435b','bf67675912454473a1cb185c6e429435','12');----
INSERT INTO word VALUES ('25a4a85fb3d749c5a939b1470056f7af','consistent','[kənˈsistənt]','http://res.iciba.com/resource/amp3/oxford/0/c0/58/c05870dbb35d2f58f159b9a52acc8e6f.mp3','adj. 一致的，连贯的','','');----
INSERT INTO classwords VALUES ('10e0014b899744c6a9bd7e586bd95aa3','25a4a85fb3d749c5a939b1470056f7af','12');----
INSERT INTO word VALUES ('f327c02c1da84babbaaefe44309f5ec8','friction','[ˈfrikʃən]','http://res.iciba.com/resource/amp3/oxford/0/87/54/87543cc5dd9ff5659670e93832af9b8c.mp3','n. 矛盾，不和；摩擦力；摩擦','','');----
INSERT INTO classwords VALUES ('6a3395ae005a4ff28272a03e79e6caa1','f327c02c1da84babbaaefe44309f5ec8','12');----
INSERT INTO word VALUES ('3598c6fd01d74cda9d1c93ddf47e604b','slide','[slaid]','http://res.iciba.com/resource/amp3/oxford/0/fe/d6/fed6dc5221f7882a4e3e2bf55035b22e.mp3','vi. 滑动；悄悄地溜到；贬值','','');----
INSERT INTO classwords VALUES ('9258837a80504beb9c44001d66678c1f','3598c6fd01d74cda9d1c93ddf47e604b','12');----
INSERT INTO word VALUES ('81bca6d862c34f4fa3cb8559ee865914','gangster','[ˈɡæŋstə]','http://res.iciba.com/resource/amp3/oxford/0/28/0e/280e693b0c549e28dbaf60b3ad832224.mp3','n. 匪徒，歹徒','','');----
INSERT INTO classwords VALUES ('7f789d41da0e47989f3dd7ee523e46a5','81bca6d862c34f4fa3cb8559ee865914','12');----
INSERT INTO word VALUES ('7412c268297045f882b5dc90cde399aa','inaugurate','[iˈnɔ:ɡjureit]','http://res.iciba.com/resource/amp3/oxford/0/d2/2d/d22db6115990474bc7af98022eca4c92.mp3','vt. 开创；为…举行落成仪式；为…举行...','','');----
INSERT INTO classwords VALUES ('20ab09b14ba140aeaa0054e80fe43906','7412c268297045f882b5dc90cde399aa','12');----
INSERT INTO word VALUES ('23528ba4a8f147879eb37453887c3891','couch','[kautʃ]','http://res.iciba.com/resource/amp3/oxford/0/89/76/897678484b0617e73dcb1952673508ef.mp3','n. 睡椅，长沙发椅；（病人接受检查或治...','','');----
INSERT INTO classwords VALUES ('e5c314caa59b416091774e682aa54287','23528ba4a8f147879eb37453887c3891','12');----
INSERT INTO word VALUES ('ae2eba8845c94f8f8055ab47117acb53','tradesman','[ˈtreɪdzmən]','http://res.iciba.com/resource/amp3/oxford/0/00/e2/00e263ecfa554fdd4f1082d2aa8a0362.mp3','n. 商人；手艺人','','');----
INSERT INTO classwords VALUES ('701123f404154167a6b715700d816a2e','ae2eba8845c94f8f8055ab47117acb53','12');----
INSERT INTO word VALUES ('6aab1fa8a9c442faa7a9c0932d90461e','rectangle','[ˈrektæŋɡl]','http://res.iciba.com/resource/amp3/oxford/0/d6/fc/d6fcfc0d05109dc5c2fc89adf4531042.mp3','n. 矩形，长方形','','');----
INSERT INTO classwords VALUES ('73087113567e4f6b8b831ccc25a8de32','6aab1fa8a9c442faa7a9c0932d90461e','12');----
INSERT INTO word VALUES ('d122b22657bd4089abcc765924a99401','ought','[ɔ:t]','http://res.iciba.com/resource/amp3/0/0/1c/16/1c160466e2f9661f9498dbbbfdfad0e2.mp3','v. 应该，应当；本该','','');----
INSERT INTO classwords VALUES ('23d496e7d0434c7b96670087bf0024f4','d122b22657bd4089abcc765924a99401','12');----
INSERT INTO word VALUES ('907c98ec83fa470c85a527ed3783f8a2','kinetic','[kɪˈnetɪk]','http://res.iciba.com/resource/amp3/oxford/0/7e/c0/7ec00c290e8f2424b6f196ae36c0cd62.mp3','adj. 运动的','','');----
INSERT INTO classwords VALUES ('f32490a92f814e66813db7b98735b7b2','907c98ec83fa470c85a527ed3783f8a2','12');----
INSERT INTO word VALUES ('0a32ccd889b94d3ab5fe58e110ff3737','range','[reindʒ]','http://res.iciba.com/resource/amp3/oxford/0/1b/f6/1bf679700477274e111f07a8c3d6176e.mp3','vi. 变化；涉及；使排成行或列；漫游','','');----
INSERT INTO classwords VALUES ('35aacb6809784f9c94bb02489558708f','0a32ccd889b94d3ab5fe58e110ff3737','12');----
INSERT INTO word VALUES ('ece49eae3bd841f29b7a6b228a4963c7','economically','[ˌi:kəˈnɔmɪkəlɪ]','http://res.iciba.com/resource/amp3/oxford/0/1a/64/1a64480906fb426650ca8df2d54a1554.mp3','adv. 节约地；在经济上','','');----
INSERT INTO classwords VALUES ('d3db08081d054ba48ad5450cc0ddc355','ece49eae3bd841f29b7a6b228a4963c7','12');----
INSERT INTO word VALUES ('c7a796056ce144c585e07b8f18c5c761','Venus','[ˈvi:nəs]','http://res.iciba.com/resource/amp3/0/0/a5/71/a5717a649d346ed0c51be68888c130cd.mp3','n. 维纳斯（爱与美的女神）；金星','','');----
INSERT INTO classwords VALUES ('c7e55aaaf84b4a60b1d5593da1708d81','c7a796056ce144c585e07b8f18c5c761','12');----
INSERT INTO word VALUES ('3ceb8a601e8e4964bcf8f40a070d39f3','patriot','[ˈpeitriət]','http://res.iciba.com/resource/amp3/oxford/0/da/f5/daf5e57063f48af5f0a1e8abb0505976.mp3','n. 爱国者，爱国主义者','','');----
INSERT INTO classwords VALUES ('b4ce3e622c974fd28ec19f1a566ad7b0','3ceb8a601e8e4964bcf8f40a070d39f3','12');----
INSERT INTO word VALUES ('fadb1bc5b4594b5ab7ec5025460cefeb','rooster','[ˈru:stə]','http://res.iciba.com/resource/amp3/oxford/0/19/dd/19dd143f04ba519879e26ee880203ae0.mp3','n. 公鸡','','');----
INSERT INTO classwords VALUES ('de88b5e900ae43c7beb90b23c2c5b8c5','fadb1bc5b4594b5ab7ec5025460cefeb','12');----
INSERT INTO word VALUES ('c2a2fe59416049de99f730526922de04','absorption','[əbˈsɔ:pʃən]','http://res.iciba.com/resource/amp3/oxford/0/a4/25/a4253e96b489417268369176d6ea9896.mp3','n. 吸收；专注；合并','','');----
INSERT INTO classwords VALUES ('985c6be179b645bfbb2434e8311aea6d','c2a2fe59416049de99f730526922de04','12');----
INSERT INTO word VALUES ('49271652319f48798dff9f5a6d4aa808','radius','[ˈreidjəs]','http://res.iciba.com/resource/amp3/oxford/0/6d/41/6d41c123bb9e61664ecf1c2bd346acbc.mp3','n. 半径距离；半径','','');----
INSERT INTO classwords VALUES ('a8dda2e367824849809eaa2590c10f0b','49271652319f48798dff9f5a6d4aa808','12');----
INSERT INTO word VALUES ('7a25a57e2dc9497fb65a2a90c720ac6d','grateful','[ˈɡreitful]','http://res.iciba.com/resource/amp3/oxford/0/ac/15/ac1506f0f3c79d649a972a467279ee4f.mp3','adj. 感激的；表示感谢的','','');----
INSERT INTO classwords VALUES ('2c2b92b154ca4267a6dcd6ce5940ab6c','7a25a57e2dc9497fb65a2a90c720ac6d','12');----
INSERT INTO word VALUES ('3305cef39a0f4d15b0c1d0f8580b048b','grin','[ɡrin]','http://res.iciba.com/resource/amp3/oxford/0/fc/ff/fcff79cce446f9727c9cbd3eb05fd546.mp3','vi. 咧着嘴笑；露齿而笑','','');----
INSERT INTO classwords VALUES ('17814bf9f352466084de7533465d08b6','3305cef39a0f4d15b0c1d0f8580b048b','12');----
INSERT INTO word VALUES ('e9ea5de7f52242a2bbddff379cb85210','announce','[əˈnauns]','http://res.iciba.com/resource/amp3/oxford/0/cb/bf/cbbf48ab4fe5544878e14995ba9d27b2.mp3','vt. 宣布；宣告；播报','','');----
INSERT INTO classwords VALUES ('4ba2c938675e41ec8acece94d2bc01cf','e9ea5de7f52242a2bbddff379cb85210','12');----
INSERT INTO word VALUES ('a18a384a82d844c1b066d20c6952c5cc','baffle','[ˈbæfl]','http://res.iciba.com/resource/amp3/oxford/0/df/b0/dfb0214fb48d37bcd77776dd3586b3a1.mp3','n. 挡板，隔音板；困惑','','');----
INSERT INTO classwords VALUES ('6a0912db085c4e118ac225b56266f1ea','a18a384a82d844c1b066d20c6952c5cc','12');----
INSERT INTO word VALUES ('828fb4c5a60d48e7a0e40c44cbd339d1','summit','[ˈsʌmit]','http://res.iciba.com/resource/amp3/oxford/0/1d/67/1d67a7e5b537452a8b703ded422ae198.mp3','n. 顶点；峰会；顶峰','','');----
INSERT INTO classwords VALUES ('3d68fc79c209474a99ef4f9bb44d7bd2','828fb4c5a60d48e7a0e40c44cbd339d1','12');----
INSERT INTO word VALUES ('165437cf2a404184b6bd7befede9f143','inspiration','[ˌɪnspəˈreiʃən]','http://res.iciba.com/resource/amp3/oxford/0/74/67/74673f73715a6e66ac4d7016e154c738.mp3','n. 灵感；灵感来源；鼓舞；妙计','','');----
INSERT INTO classwords VALUES ('b5af74a735704bbda4796a343596dc62','165437cf2a404184b6bd7befede9f143','12');----
INSERT INTO word VALUES ('50ec550479a14f5ea6147554855ce8a9','dictator','[ˈdɪkˌteɪtə]','http://res.iciba.com/resource/amp3/0/0/f0/fa/f0fa7f364cabe3eae9346cfd1090c97a.mp3','n. 独裁者，专政者','','');----
INSERT INTO classwords VALUES ('4d284059318c4941b4b4ab685ffe345d','50ec550479a14f5ea6147554855ce8a9','12');----
INSERT INTO word VALUES ('734a4258e3754b37b3dc54205785f972','tact','[tækt]','http://res.iciba.com/resource/amp3/oxford/0/82/06/8206f092f11c38416fcfd727a97a38f5.mp3','n. 机敏；圆滑，得体','','');----
INSERT INTO classwords VALUES ('c6d5217a35234aeda766b7773da7fa7b','734a4258e3754b37b3dc54205785f972','12');----
INSERT INTO word VALUES ('4de1772d7cf249fca4e0c05b5594aa9c','prevention','[prɪˈvenʃən]','http://res.iciba.com/resource/amp3/oxford/0/26/c6/26c60d8ed155182c41840d0d42d3887a.mp3','n. 预防；阻止，妨碍','','');----
INSERT INTO classwords VALUES ('0740993cadc44e57873accb3419e3461','4de1772d7cf249fca4e0c05b5594aa9c','12');----
INSERT INTO word VALUES ('5d0ff7aa8cc944d28ec82c8a037d14ea','nourishment','[ˈnʌriʃmənt]','http://res.iciba.com/resource/amp3/oxford/0/9b/4b/9b4b7ce8ff15b2988a0c1d58a37df9e9.mp3','n. 食物；滋养品；营养','','');----
INSERT INTO classwords VALUES ('ba81fa21e0e842dfb1fa1e9a91b82d0a','5d0ff7aa8cc944d28ec82c8a037d14ea','12');----
INSERT INTO word VALUES ('46dd0eae60f345089377dc720b098669','cuckoo','[ˈku:ku:]','http://res.iciba.com/resource/amp3/oxford/0/96/a6/96a60a52601fc129001f7821622d5299.mp3','n. 杜鹃，布谷鸟','','');----
INSERT INTO classwords VALUES ('8586b12d1aba4133b73500c6a7444be7','46dd0eae60f345089377dc720b098669','12');----
INSERT INTO word VALUES ('65f079e44eaa4657865e1941b29cd1e6','antique','[ænˈti:k]','http://res.iciba.com/resource/amp3/oxford/0/a0/c0/a0c0214c34e9d29518fc464ef5632b0b.mp3','n. 古物，古董','','');----
INSERT INTO classwords VALUES ('661a6db39a3d47b79e6ddeda998842e1','65f079e44eaa4657865e1941b29cd1e6','12');----
INSERT INTO word VALUES ('2a766004a9734f8f9a38e2d5c5d68b9d','outbreak','[ˈautbreik]','http://res.iciba.com/resource/amp3/oxford/0/68/4d/684dc4ef355abd9358f16012c90bb148.mp3','n. （战争、愤怒等）爆发，突然发生','','');----
INSERT INTO classwords VALUES ('a9427a0ca11e414899857385f8614140','2a766004a9734f8f9a38e2d5c5d68b9d','12');----
INSERT INTO word VALUES ('212ade4cba4747c6a699237ac24c3c3f','strip','[strip]','http://res.iciba.com/resource/amp3/oxford/0/24/81/2481500d7ea7211a86d5b32a39e0ada1.mp3','n. （食物等的）条，带；狭长区域','','');----
INSERT INTO classwords VALUES ('9b24977ef0c0453da76e08dfe55ec481','212ade4cba4747c6a699237ac24c3c3f','12');----
INSERT INTO word VALUES ('ac958749d76d43eebc932ef3c2942e88','chip','[tʃip]','http://res.iciba.com/resource/amp3/oxford/0/5b/c2/5bc25d5395e731e719e5ab3d31f94f20.mp3','n. 碎片，碎屑；炸薯条；芯片','','');----
INSERT INTO classwords VALUES ('42c81929c68b473ab2e0751b36ad914c','ac958749d76d43eebc932ef3c2942e88','12');----
INSERT INTO word VALUES ('8c51f14599db4d2bb79eb6936c02b77b','inflation','[inˈfleiʃən]','http://res.iciba.com/resource/amp3/oxford/0/95/5e/955e4ad0af19261d7e42ad5d12c7104d.mp3','n. 通货膨胀','','');----
INSERT INTO classwords VALUES ('9918aba2bcd24a9abb846767bc822f7c','8c51f14599db4d2bb79eb6936c02b77b','12');----
INSERT INTO word VALUES ('ba040c0b531144e0a3a287bbb5ca9dfb','automate','[ˈɔ:təˌmeɪt]','http://res.iciba.com/resource/amp3/oxford/0/65/ec/65ec96865ed647ed19b6e596a545d488.mp3','vt. 使自动化','','');----
INSERT INTO classwords VALUES ('c501e24de9fd4379a0d4876ccb5b8ce5','ba040c0b531144e0a3a287bbb5ca9dfb','12');----
INSERT INTO word VALUES ('01e2ff76a3454ce48d36db4b6dbdb393','intake','[ˈinteik]','http://res.iciba.com/resource/amp3/oxford/0/60/d0/60d031c742b96b620207fa41fe438cc6.mp3','n. 吸入量，摄取量；新招收者','','');----
INSERT INTO classwords VALUES ('163cf549009b44c383c797f57154d0ca','01e2ff76a3454ce48d36db4b6dbdb393','12');----
INSERT INTO word VALUES ('c2f852e499c74d55aed182a86c4b09b6','magician','[məˈdʒɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/6e/36/6e36e1fa55a01d0d1dde692660b58b3b.mp3','n. 魔术师；巫师；奇才','','');----
INSERT INTO classwords VALUES ('1c5cbfede404436aa1b84c1d004db7b0','c2f852e499c74d55aed182a86c4b09b6','12');----
INSERT INTO word VALUES ('8167bb6d11e044c08018fba392e907fc','ion','[ˈaɪən]','http://res.iciba.com/resource/amp3/oxford/0/b8/9c/b89ca3f36ef036a54173ce7ad1d5c621.mp3','n. 离子','','');----
INSERT INTO classwords VALUES ('9d02887604e54ea2be13ebd6b8a944fc','8167bb6d11e044c08018fba392e907fc','12');----
INSERT INTO word VALUES ('a4338974873841c9907cb6caca40e4e4','interior','[inˈtiəriə]','http://res.iciba.com/resource/amp3/oxford/0/af/fc/affc2b934a2d3e21128ad7940b4dd54c.mp3','adj. 内部的；国内的；内心的','','');----
INSERT INTO classwords VALUES ('53b73208ee3f4dafae7881913db0f95d','a4338974873841c9907cb6caca40e4e4','12');----
INSERT INTO word VALUES ('61b3dc66fe39400785d5dbafe85d3019','parade','[pəˈreid]','http://res.iciba.com/resource/amp3/oxford/0/8a/b4/8ab45ac2e6916f28edb772bd1bcf3db9.mp3','vt. 炫耀；游行','','');----
INSERT INTO classwords VALUES ('136164155a5f493dbcceb17776404c15','61b3dc66fe39400785d5dbafe85d3019','12');----
INSERT INTO word VALUES ('3db16b1bdebe47ac9b29f2718bc8d81c','inertia','[iˈnə:ʃjə]','http://res.iciba.com/resource/amp3/oxford/0/35/f9/35f9b781e74bfde137b4ffbe363202a2.mp3','n. 惯性；惰性；迟钝','','');----
INSERT INTO classwords VALUES ('63ec52e7963a476aaf16d93a086bac83','3db16b1bdebe47ac9b29f2718bc8d81c','12');----
INSERT INTO word VALUES ('3c3b08e8564746948505d79ff90b4ebb','scar','[skɑ:]','http://res.iciba.com/resource/amp3/oxford/0/e4/14/e41419afdb58e126e8e646d97f4a0c32.mp3','n. 伤疤，伤痕','','');----
INSERT INTO classwords VALUES ('ffdf8ad3f0c64ed2bcbe474eadeff981','3c3b08e8564746948505d79ff90b4ebb','12');----
INSERT INTO word VALUES ('95b37ac8abc946a3a22bbbbf802e0140','incline','[inˈklain]','http://res.iciba.com/resource/amp3/oxford/0/e7/18/e718b3ca293f4024a031789529e9da30.mp3','n. 斜坡；斜面','','');----
INSERT INTO classwords VALUES ('0be7ad28c97f468d805cf14639de3a82','95b37ac8abc946a3a22bbbbf802e0140','12');----
INSERT INTO word VALUES ('319ab6052f9249da84a60f4ef95ecd8a','ambient','[ˈæmbi:ənt]','http://res.iciba.com/resource/amp3/oxford/0/d4/5b/d45b4dc163577dd177ab2aebcaa5bcf3.mp3','adj. 周围的；四周的','','');----
INSERT INTO classwords VALUES ('569f871516464a56b9af7686fbfb919b','319ab6052f9249da84a60f4ef95ecd8a','12');----
INSERT INTO word VALUES ('ec2e8d1ef7ac448682e4f62a2c358d60','dignity','[ˈdiɡniti]','http://res.iciba.com/resource/amp3/oxford/0/6b/63/6b636f195e80224de6ba311d5bf01dbf.mp3','n. 尊贵；庄严；尊严','','');----
INSERT INTO classwords VALUES ('05fce475bb7e49d9806b395773d88e9d','ec2e8d1ef7ac448682e4f62a2c358d60','12');----
INSERT INTO word VALUES ('8f84900bd7954ff18e8b6f1d2ff1b128','tyrant','[ˈtaɪərənt]','http://res.iciba.com/resource/amp3/oxford/0/06/0a/060a138205cee0c2c89f073d91ba9b4e.mp3','n. 暴君导，专制君主；专横的人','','');----
INSERT INTO classwords VALUES ('174667def93345e5b1d2234856cb4f80','8f84900bd7954ff18e8b6f1d2ff1b128','12');----
INSERT INTO word VALUES ('c94093e80c404c558fbb2eebeb45d8b7','antenna','[ænˈtenə]','http://res.iciba.com/resource/amp3/oxford/0/dc/dc/dcdc049d73acedcfa2c1abacba58c707.mp3','n. 触角；天线','','');----
INSERT INTO classwords VALUES ('4d58dd37bc944d338ef2a72674eb817b','c94093e80c404c558fbb2eebeb45d8b7','12');----
INSERT INTO word VALUES ('08ea610511724669b2232973e85bf75c','modification','[ˌmɔdəfɪˈkeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/e6/49/e6492585f52614762bc568f59a1417d2.mp3','n. 缓和；修改；修饰','','');----
INSERT INTO classwords VALUES ('2b68c580c31b47638dc9abf7b2caf7f7','08ea610511724669b2232973e85bf75c','12');----
INSERT INTO word VALUES ('0273b371c3244eebafb0ae90c2817b9c','competitive','[kəmˈpetitiv]','http://res.iciba.com/resource/amp3/oxford/0/b7/6c/b76ccd799c36213cfe1545d86e4f22db.mp3','adj. 竞争的，比赛的；好竞争的；具有...','','');----
INSERT INTO classwords VALUES ('9839119633f7495db3a0e74554415dd9','0273b371c3244eebafb0ae90c2817b9c','12');----
INSERT INTO word VALUES ('d04c956d95a14274801fbdd0fe0145d4','clown','[klaun]','http://res.iciba.com/resource/amp3/oxford/0/c7/f5/c7f562a066c776fcf43cd1380fca6dff.mp3','n. （马戏团的）小丑，丑角','','');----
INSERT INTO classwords VALUES ('2b15e5c4d7ef44bc8617c546f2cdde22','d04c956d95a14274801fbdd0fe0145d4','12');----
INSERT INTO word VALUES ('9326a024ce0a408c9a5627d7086807df','graze','[ɡreiz]','http://res.iciba.com/resource/amp3/oxford/0/9a/d7/9ad78ceab0b600ec90333060809c3292.mp3','v. 擦伤；放牧；轻擦','','');----
INSERT INTO classwords VALUES ('b9a267801c644070b77e7430a8dd69b3','9326a024ce0a408c9a5627d7086807df','12');----
INSERT INTO word VALUES ('7fcef61df72040c58c3416de9cda11d7','ascend','[əˈsend]','http://res.iciba.com/resource/amp3/oxford/0/2c/70/2c700dd46ea1bc458c6c1c3d75a45001.mp3','vi. 攀登；上升','','');----
INSERT INTO classwords VALUES ('5ce957e47173493c8a2cf4edd29469dd','7fcef61df72040c58c3416de9cda11d7','12');----
INSERT INTO word VALUES ('ebaa043ad57d4323985504aad7734ca8','agitation','[ˌædʒɪˈteɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/7a/20/7a200693c98b7dbe09e35d58cd5e7f06.mp3','n. 鼓动，搅动；焦虑，烦恼','','');----
INSERT INTO classwords VALUES ('9c331794fa574749937c77d595ae55f4','ebaa043ad57d4323985504aad7734ca8','12');----
INSERT INTO word VALUES ('6c0ba7e9a6234a41a384f65314895d5f','basement','[ˈbeismənt]','http://res.iciba.com/resource/amp3/oxford/0/a3/8a/a38a40c7d382e1f543942b66bf65a837.mp3','n. 地下室；根基','','');----
INSERT INTO classwords VALUES ('60d7d4d9dcfb4e358726376df05d6d42','6c0ba7e9a6234a41a384f65314895d5f','12');----
INSERT INTO word VALUES ('d129b16c908d47f08c455b72af89c813','haul','[hɔ:l]','http://res.iciba.com/resource/amp3/oxford/0/6d/e8/6de8f31ceccbb6fc0ee0558d961326ca.mp3','vt. 拖，拉；传讯','','');----
INSERT INTO classwords VALUES ('2e97355f55284726989c8fac86a209bd','d129b16c908d47f08c455b72af89c813','12');----
INSERT INTO word VALUES ('42e4a6844f14426bb6980d06c2801ebf','twilight','[ˈtwailait]','http://res.iciba.com/resource/amp3/oxford/0/ff/7a/ff7a45e1f504eb988479a97bdde3ac87.mp3','n. 黄昏；暮光；衰落时期','','');----
INSERT INTO classwords VALUES ('d9563f5c353244bbabbb1afe64d13c8f','42e4a6844f14426bb6980d06c2801ebf','12');----
INSERT INTO word VALUES ('71bb45d1988e44158dd42e02309f9df1','beetle','[ˈbi:tl]','http://res.iciba.com/resource/amp3/oxford/0/8f/2a/8f2a77cef9ebb10c345ac04ab24771e3.mp3','n. 甲虫；木槌；[纺]捶布机','','');----
INSERT INTO classwords VALUES ('926e1aa69b92404db41e5eea785d99ae','71bb45d1988e44158dd42e02309f9df1','12');----
INSERT INTO word VALUES ('ec359ae43ee5434eb31825411ecbcaaa','meditate','[ˈmedɪˌteɪt]','http://res.iciba.com/resource/amp3/oxford/0/dd/27/dd27a8e37f04ab2ea5625615b035394b.mp3','vt. 沉思；仔细考虑；冥想','','');----
INSERT INTO classwords VALUES ('f210796d14cc44c29066d8cdf3c92be4','ec359ae43ee5434eb31825411ecbcaaa','12');----
INSERT INTO word VALUES ('1fd7817ca5584dd9a0b4d5533145a18e','literal','[ˈlitərəl]','http://res.iciba.com/resource/amp3/oxford/0/91/bb/91bb5057cc6d7e0301ec37b5f35f3f5c.mp3','adj. 逐字的；字面的；确确实实的','','');----
INSERT INTO classwords VALUES ('1f4a962e8dc945e6a41243c2357fa208','1fd7817ca5584dd9a0b4d5533145a18e','12');----
INSERT INTO word VALUES ('38670de6dde24c5fbdf3bf266c9eb353','drainage','[ˈdreinidʒ]','http://res.iciba.com/resource/amp3/oxford/0/21/32/213282c7384db3417589d7e00321b064.mp3','n. 排水；排水系统','','');----
INSERT INTO classwords VALUES ('c7628c9ce75d4d7abfb25e2a9928da6d','38670de6dde24c5fbdf3bf266c9eb353','12');----
INSERT INTO word VALUES ('b764c1df51d541d1bd4a110e410416ea','luxurious','[lʌɡˈzjuəriəs]','http://res.iciba.com/resource/amp3/oxford/0/06/23/06232fc947c00cbd3c925f7a72333971.mp3','adj. 奢侈的；豪华的；惬意的','','');----
INSERT INTO classwords VALUES ('97f11added464367942a7ce180aaec72','b764c1df51d541d1bd4a110e410416ea','12');----
INSERT INTO word VALUES ('b01e7b92bc8744fd9452bb19716cec20','reason','[ˈri:zən]','http://res.iciba.com/resource/amp3/oxford/0/f1/7b/f17b3359692586c3f679a84fab3e2f7c.mp3','vt. 推理；争辩','','');----
INSERT INTO classwords VALUES ('14da202e2f2445d288de40376704d6ea','b01e7b92bc8744fd9452bb19716cec20','12');----
INSERT INTO word VALUES ('01fa7d6c335442b7a430269d9ef4eb06','implore','[ɪmˈplɔ:]','http://res.iciba.com/resource/amp3/oxford/0/86/b7/86b79542ec3f0cff8b67e69b6e9248a4.mp3','vt. 乞求，恳求，哀求','','');----
INSERT INTO classwords VALUES ('cca44eb0b2a847b789f62ad5b04269fd','01fa7d6c335442b7a430269d9ef4eb06','12');----
INSERT INTO word VALUES ('cf3f706b515f440fb2f9f7cc70d9695b','conviction','[kənˈvikʃən]','http://res.iciba.com/resource/amp3/oxford/0/20/4e/204e119bef0defe040a580fdb02a332d.mp3','n. 确信；信念；定罪，判罪','','');----
INSERT INTO classwords VALUES ('214821c36883428d8ae156ebc8038058','cf3f706b515f440fb2f9f7cc70d9695b','12');----
INSERT INTO word VALUES ('645b811aee4c4e4e94043e5c9add079b','hinge','[hindʒ]','http://res.iciba.com/resource/amp3/oxford/0/5a/86/5a8692fbed3911da072bb12545f824ef.mp3','n. 合页，铰链','','');----
INSERT INTO classwords VALUES ('03a57e42a7a4448390c5d440365002c4','645b811aee4c4e4e94043e5c9add079b','12');----
INSERT INTO word VALUES ('aff0b1fc24764d4f9f6a62a54a7c5e79','dome','[dəum]','http://res.iciba.com/resource/amp3/0/0/1b/71/1b71c8e9e749753da4e8f55b029ced5f.mp3','n. 圆屋顶；半球形物','','');----
INSERT INTO classwords VALUES ('f63793ba53e5421098da7bc132ae9497','aff0b1fc24764d4f9f6a62a54a7c5e79','12');----
INSERT INTO word VALUES ('f7438dc9a0444884bee875e033f81c35','sensitivity','[ˌsensɪˈtɪvɪti:]','http://res.iciba.com/resource/amp3/oxford/0/a5/54/a554aec61d75f52e4e51de7e22a9bb91.mp3','n. 敏感（性）；灵敏性','','');----
INSERT INTO classwords VALUES ('1a7923d3c7824248a386923d8781dc32','f7438dc9a0444884bee875e033f81c35','12');----
INSERT INTO word VALUES ('cd96cd701b1d452fa4b16ad1fb187704','geology','[dʒiˈɔlədʒi]','http://res.iciba.com/resource/amp3/oxford/0/d1/1a/d11a4a9126f2d48b21bb16e92da6d1b2.mp3','n. 地质学；地质状况','','');----
INSERT INTO classwords VALUES ('65e6077b0a61415fbc291fdcd4fdd29a','cd96cd701b1d452fa4b16ad1fb187704','12');----
INSERT INTO word VALUES ('cb502ec80f0c4c728d357306082c17e5','liner','[ˈlainə]','http://res.iciba.com/resource/amp3/oxford/0/0d/77/0d77d753c2ba1b901450a647d28d1e85.mp3','n. 邮轮，客轮；衬里，衬垫','','');----
INSERT INTO classwords VALUES ('65faae0f414449d2af92d458971a1868','cb502ec80f0c4c728d357306082c17e5','12');----
INSERT INTO word VALUES ('127ee2db0a5449808666f0cf4d07e90d','veto','[ˈvi:təu]','http://res.iciba.com/resource/amp3/oxford/0/39/f9/39f98ca5934f708a97e6bede2741f990.mp3','v. 否决，否定','','');----
INSERT INTO classwords VALUES ('d2e5c4b65b8e4c1ea9f312951c7a1e7b','127ee2db0a5449808666f0cf4d07e90d','12');----
INSERT INTO word VALUES ('462e136e3abd4ea5b277aa8ff1811731','Thanksgiving','[θæŋksˈgɪvɪŋ]','http://res.iciba.com/resource/amp3/0/0/65/bd/65bd10756687e64c347423ba3836f065.mp3','n. 感恩节','','');----
INSERT INTO classwords VALUES ('51646df91b8f45728426349fd3a40a1a','462e136e3abd4ea5b277aa8ff1811731','12');----
INSERT INTO word VALUES ('8fd37148de6e48959736690bd4b37236','bull','[bul]','http://res.iciba.com/resource/amp3/oxford/0/b8/5c/b85cc6e6d10298c0a1ebcdcf00255c8a.mp3','n. 买空的证券投机商；公牛；雄兽','','');----
INSERT INTO classwords VALUES ('d1959a35d72b4900a39dfd8a100f0524','8fd37148de6e48959736690bd4b37236','12');----
INSERT INTO word VALUES ('a62f42ef272649098c405ccf3fc0346c','foreign','[ˈfɔrin]','http://res.iciba.com/resource/amp3/0/0/68/4a/684a72e08f24f55b1138edd5a7c2b53e.mp3','adj. 外国的；外交的；外来的；陌生的...','','');----
INSERT INTO classwords VALUES ('99a48ce616134b16a783a1bd0e9abfb6','a62f42ef272649098c405ccf3fc0346c','12');----
INSERT INTO word VALUES ('fe1c354d7aeb4fae9ac1f037b20c7f59','bribe','[braib]','http://res.iciba.com/resource/amp3/oxford/0/24/a2/24a2340f42e2a47552722ded74b8681d.mp3','vt. 向…行贿','','');----
INSERT INTO classwords VALUES ('cd04327c6c564ecbb98da20f87dd62dc','fe1c354d7aeb4fae9ac1f037b20c7f59','12');----
INSERT INTO word VALUES ('83e9cc4df9e84208b785399adf1dfbdc','response','[riˈspɔns]','http://res.iciba.com/resource/amp3/0/0/d1/fc/d1fc8eaf36937be0c3ba8cfe0a2c1bfe.mp3','n. 回复，回答，回应','','');----
INSERT INTO classwords VALUES ('6d690acd6cc3494587b937663469d494','83e9cc4df9e84208b785399adf1dfbdc','12');----
INSERT INTO word VALUES ('a9778410f3f94ffbbb86cc89e40bdda5','commission','[kəˈmiʃən]','http://res.iciba.com/resource/amp3/oxford/0/9d/97/9d97e5639a888fa1558512777c1ef587.mp3','n. 授权，委托；委员会；佣金','','');----
INSERT INTO classwords VALUES ('27d7354be30249efa87d3fb950211137','a9778410f3f94ffbbb86cc89e40bdda5','12');----
INSERT INTO word VALUES ('026f3f21d7324c43a291a6ba9e820041','smart','[smɑ:t]','http://res.iciba.com/resource/amp3/0/0/8c/31/8c319f28d81d1527a9428e9a5c2195f5.mp3','vi. 刺痛，剧痛；感到难受','','');----
INSERT INTO classwords VALUES ('ccbe73e1815e4759ba4bc94945a1d96f','026f3f21d7324c43a291a6ba9e820041','12');----
INSERT INTO word VALUES ('eae1eab202094790ab62cab7ceb7c6fd','negligible','[ˈneɡlidʒəbl]','http://res.iciba.com/resource/amp3/oxford/0/db/32/db3265157bb265e5bfc8228dbd8289f6.mp3','adj. 微不足道的；可忽略不计的','','');----
INSERT INTO classwords VALUES ('fed1318c12e2471cbec5ec705e1d01c1','eae1eab202094790ab62cab7ceb7c6fd','12');----
INSERT INTO word VALUES ('2405e0985b7047f1809fd533bb1afb02','positive','[ˈpɔzitiv]','http://res.iciba.com/resource/amp3/oxford/0/53/f5/53f552fba108ca787f77442bf91d9e34.mp3','adj. 积极的；有信心的；明确的；有把...','','');----
INSERT INTO classwords VALUES ('4c1bcf4a8b184f9ab97a09ef48e6ac39','2405e0985b7047f1809fd533bb1afb02','12');----
INSERT INTO word VALUES ('7bbde85418584082aaf78c9e0c8fe9e6','axle','[ˈæksəl]','http://res.iciba.com/resource/amp3/oxford/0/ab/77/ab779f1ea9e3202c855b07d5f71f2a1a.mp3','n. 轮轴，车轴','','');----
INSERT INTO classwords VALUES ('476da899a5944bf1a5605ad9be75b936','7bbde85418584082aaf78c9e0c8fe9e6','12');----
INSERT INTO word VALUES ('cac81e53106a49d182d76d7993034420','whilst','[wailst]','http://res.iciba.com/resource/amp3/0/0/1a/71/1a71a5f199dc82a9cbd8aa163cd6a52f.mp3','conj. 同时；时时','','');----
INSERT INTO classwords VALUES ('802adba56def4b1cb3d0c77d5c4e8340','cac81e53106a49d182d76d7993034420','12');----
INSERT INTO word VALUES ('628c7f6853234d78aa15255bdb2cb992','fro','[frəʊ]','http://res.iciba.com/resource/amp3/0/0/75/93/759359ae2dfb9bb829f4277eebad5aaf.mp3','adv. 向后，向那边','','');----
INSERT INTO classwords VALUES ('89041919c2fd450ab4febf4d3a2c9b95','628c7f6853234d78aa15255bdb2cb992','12');----
INSERT INTO word VALUES ('b03977117fda4ed592f8772c19e06e1e','zinc','[ziŋk]','http://res.iciba.com/resource/amp3/oxford/0/1a/d8/1ad8a97f8c275c599c931024ae0ea0a7.mp3','vt. 在…上镀锌','','');----
INSERT INTO classwords VALUES ('1d27fd39404b4878a2f1da915e390f5f','b03977117fda4ed592f8772c19e06e1e','12');----
INSERT INTO word VALUES ('6ba4d769dd9840d4bb53249f4c82ab79','coincide','[ˌkəuinˈsaid]','http://res.iciba.com/resource/amp3/oxford/0/f3/a4/f3a4e1d3d1c116cfefcaaed462838346.mp3','vi. 相符，一致；巧合，同时发生','','');----
INSERT INTO classwords VALUES ('974cf56dd4a1467fb33f9f11dde2dfd7','6ba4d769dd9840d4bb53249f4c82ab79','12');----
INSERT INTO word VALUES ('0568718a3e1140ea97d9f848c38fd487','theorem','[ˈθi:ərəm]','http://res.iciba.com/resource/amp3/oxford/0/48/6d/486d737607eda7ddb0d0f42eb3952399.mp3','n. 定理','','');----
INSERT INTO classwords VALUES ('5dc4f90601f7428eb2ecb33c3f2a209b','0568718a3e1140ea97d9f848c38fd487','12');----
INSERT INTO word VALUES ('73fad8d37e824ba981268cd56e6c5bd9','persecute','[ˈpə:sikju:t]','http://res.iciba.com/resource/amp3/oxford/0/b3/83/b383bcf119e848e67093b1687b84e00e.mp3','vt. 迫害，残害；骚扰','','');----
INSERT INTO classwords VALUES ('9046b6c6c1054abd8a42710ba21d5bf6','73fad8d37e824ba981268cd56e6c5bd9','12');----
INSERT INTO word VALUES ('e29377859d6d44b78e57016c4b4b353e','metallic','[miˈtælik]','http://res.iciba.com/resource/amp3/oxford/0/7c/c3/7cc3d3dbe7cd48dee3ff3973cb7770b0.mp3','adj. 金属的；尖厉刺耳的；金属般闪亮...','','');----
INSERT INTO classwords VALUES ('3f7dcc4ca75448618253bce083267744','e29377859d6d44b78e57016c4b4b353e','12');----
INSERT INTO word VALUES ('3b552be1df014887a5da7c5138899208','stability','[stəˈbiliti]','http://res.iciba.com/resource/amp3/oxford/0/17/31/1731a9dee7c990ae8a6a68fde7cde515.mp3','n. 坚定；稳定','','');----
INSERT INTO classwords VALUES ('c4dc4396e7b04543b662350844f41af5','3b552be1df014887a5da7c5138899208','12');----
INSERT INTO word VALUES ('8bb1412c64bb4918953632c198402584','pamphlet','[ˈpæmflit]','http://res.iciba.com/resource/amp3/oxford/0/3c/3d/3c3ddba18886691d36762e4210c14178.mp3','n. 小册子','','');----
INSERT INTO classwords VALUES ('a13cf3a7173e4f31a7caaaf75d1c1537','8bb1412c64bb4918953632c198402584','12');----
INSERT INTO word VALUES ('ae342d2f0d98483bb6bdf2a775299a6a','overthrow','[ˌəuvəˈθrəu]','http://res.iciba.com/resource/amp3/0/0/ab/f7/abf712462fa6f1bc237fab3ff46d952f.mp3','n. 推翻，瓦解','','');----
INSERT INTO classwords VALUES ('d2dfb9fe0ac14ee08407d6336057e76a','ae342d2f0d98483bb6bdf2a775299a6a','12');----
INSERT INTO word VALUES ('14b8a0e9f9db47128c951746455a73a2','multiplicatio...','[ˌmʌltəplɪˈkeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/70/88/7088e6c338ad0c9aa8a9991c49f4c64e.mp3','n. 增加；乘法','','');----
INSERT INTO classwords VALUES ('8a695164784c460aad77688076df207e','14b8a0e9f9db47128c951746455a73a2','12');----
INSERT INTO word VALUES ('a30b32f770d64aceba3ab726b0038ce6','unanimous','[ju:ˈnæniməs]','http://res.iciba.com/resource/amp3/oxford/0/d0/b9/d0b98b9f0b66a8a255b7e84145e087aa.mp3','adj. 一致同意的，无异议的','','');----
INSERT INTO classwords VALUES ('73b3bf9356cd4a2cbd81e5da72ac2813','a30b32f770d64aceba3ab726b0038ce6','12');----
INSERT INTO word VALUES ('83286e39f09f41c7b8514efc78fa5629','decisive','[diˈsaisiv]','http://res.iciba.com/resource/amp3/oxford/0/00/07/00071621f3351f883b4ad56c6ad91a5f.mp3','adj. 决定性的；果断的，决断的','','');----
INSERT INTO classwords VALUES ('56bd75e796ec421aa2034047b6ad448b','83286e39f09f41c7b8514efc78fa5629','12');----
INSERT INTO word VALUES ('b4c85110270b4b1ebe66ef3cf8f389fb','sneeze','[sni:z]','http://res.iciba.com/resource/amp3/oxford/0/91/06/9106589d5be98877c45c5147e95a5df6.mp3','vi. 打喷嚏','','');----
INSERT INTO classwords VALUES ('064f5e470b00468c986c7243e05ab2de','b4c85110270b4b1ebe66ef3cf8f389fb','12');----
INSERT INTO word VALUES ('851aeddae11c456a97a4111df0daf88c','awkward','[ˈɔ:kwəd]','http://res.iciba.com/resource/amp3/oxford/0/3a/43/3a43e4f8b889cab6ef17402a850c1238.mp3','adj. 使人尴尬的；笨拙的；难携带的','','');----
INSERT INTO classwords VALUES ('3985249599344e1aa838ed42053b9d44','851aeddae11c456a97a4111df0daf88c','12');----
INSERT INTO word VALUES ('4a1d00fa9aa54c7493734e97e6d43218','quantitative','[ˈkwɔntitətiv]','http://res.iciba.com/resource/amp3/oxford/0/24/e1/24e1a78ab13fdec73130825a47ff33fe.mp3','adj. 大小的；数量的','','');----
INSERT INTO classwords VALUES ('cc89749956ea4e7ca552a4265261f1c5','4a1d00fa9aa54c7493734e97e6d43218','12');----
INSERT INTO word VALUES ('98bc306debef4ea1b0c1f52bc6a3e31b','applause','[əˈplɔ:z]','http://res.iciba.com/resource/amp3/1/0/65/48/6548859e76d1158e4a3b0bd046f1a14d.mp3','n. 喝彩；掌声','','');----
INSERT INTO classwords VALUES ('6a05bc367a3542ceb29f27cbab225563','98bc306debef4ea1b0c1f52bc6a3e31b','12');----
INSERT INTO word VALUES ('6fecb0f758e14749a1ac66f38ff91a94','flavour','[ˈfleivə]','http://res.iciba.com/resource/amp3/oxford/0/ae/c7/aec7d90d46ba49233679eddab6199e9a.mp3','vt. 给…调味','','');----
INSERT INTO classwords VALUES ('f0415ad2b2ef4e1c858bf8da2085027e','6fecb0f758e14749a1ac66f38ff91a94','12');----
INSERT INTO word VALUES ('59a80916bcab42f2afba1573e45b5339','modulate','[ˈmɔdʒəˌleɪt]','http://res.iciba.com/resource/amp3/0/0/15/e9/15e95cb1264e3dfced379f625e5773d3.mp3','vt. 调整；调节（声音）','','');----
INSERT INTO classwords VALUES ('ae4115144e0e490aa0d7e6b7df58390d','59a80916bcab42f2afba1573e45b5339','12');----
INSERT INTO word VALUES ('7a69ecb98d44444a926312de1c418007','deliberate','[diˈlibərit]','http://res.iciba.com/resource/amp3/oxford/0/77/b1/77b11a8994eecc82aec53340c8d85cc3.mp3','adj. 故意的；蓄意的；审慎的','','');----
INSERT INTO classwords VALUES ('b085e2c265c840e1bf0c9b67331e249f','7a69ecb98d44444a926312de1c418007','12');----
INSERT INTO word VALUES ('084dd6bd813f4eeba376ab8a18a8e8bb','generalizatio...','[ˌdʒenərəlɪˈzeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/fd/a7/fda72db2104dec5facc3ac5bd8ff52bd.mp3','n. 一般化；概括，归纳','','');----
INSERT INTO classwords VALUES ('a676cfce25134f75acfe3d6ad20db4ee','084dd6bd813f4eeba376ab8a18a8e8bb','12');----
INSERT INTO word VALUES ('789dd1bfcfb34327b44347daac7d4d55','complaint','[kəmˈpleint]','http://res.iciba.com/resource/amp3/oxford/0/6b/29/6b29c23d21b61d79eb0c9b659276365f.mp3','n. 疾病；投诉；抱怨','','');----
INSERT INTO classwords VALUES ('2a2024a7025e4f398f27b59163b3d19a','789dd1bfcfb34327b44347daac7d4d55','12');----
INSERT INTO word VALUES ('5592a439f94a4d7d93cee1d310331fac','prestige','[presˈti:ʒ]','http://res.iciba.com/resource/amp3/oxford/0/d6/c8/d6c8467141e958d2050f3fd2de4a0b55.mp3','n. 威望，威信，声望','','');----
INSERT INTO classwords VALUES ('1b8197b08a83434ea272b5562661f6d3','5592a439f94a4d7d93cee1d310331fac','12');----
INSERT INTO word VALUES ('e9345d2584994a418484f784ef57262f','Islam','[ɪsˈlɑ:m]','http://res.iciba.com/resource/amp3/oxford/0/c5/1f/c51fdfc91375ab4c68c0e5d0ad20e378.mp3','n. 伊斯兰教；伊斯兰教国家','','');----
INSERT INTO classwords VALUES ('b18b4ba8e2ae4abf8261843c74d32c9b','e9345d2584994a418484f784ef57262f','12');----
INSERT INTO word VALUES ('77f5ba2336394baba72bc4e3ce05cd4e','reside','[riˈzaid]','http://res.iciba.com/resource/amp3/oxford/0/a9/e6/a9e61cb698bf51afa5459efba4f18fd1.mp3','vi. 居住，定居；属于','','');----
INSERT INTO classwords VALUES ('b99e52322f434b0ba225eaaec2d60a6a','77f5ba2336394baba72bc4e3ce05cd4e','12');----
INSERT INTO word VALUES ('7630cfc8fd744ff5b602fa6a855c0bfc','shabby','[ˈʃæbi]','http://res.iciba.com/resource/amp3/oxford/0/6a/84/6a846682ec074ccb058b563748d92238.mp3','adj. 衣衫褴褛的；破旧的；卑鄙的','','');----
INSERT INTO classwords VALUES ('e01a99354a2a43208c376fb531483059','7630cfc8fd744ff5b602fa6a855c0bfc','12');----
INSERT INTO word VALUES ('ca9d39ada9e548d4a6fc237e557aa511','woodpecker','[ˈwʊdˌpekə]','http://res.iciba.com/resource/amp3/oxford/0/2a/e0/2ae03690a5b030c6a60cfa12c3a9db52.mp3','n. 啄木鸟','','');----
INSERT INTO classwords VALUES ('6304e79a12b24992b3f7226fb816c77b','ca9d39ada9e548d4a6fc237e557aa511','12');----
INSERT INTO word VALUES ('f09344d122be4b89a4dd60d211267c18','whitewash','[ˈhwaɪtˌwɔʃ]','http://res.iciba.com/resource/amp3/oxford/0/9a/9c/9a9c47c10ef5da25bba9421a6f67304b.mp3','vt. 粉饰；用石灰水粉刷','','');----
INSERT INTO classwords VALUES ('ec745051ab7b4d7784c6ff3b19d83a2f','f09344d122be4b89a4dd60d211267c18','12');----
INSERT INTO word VALUES ('8522df43c8fe412b895200e5384193d7','unique','[ju:ˈni:k]','http://res.iciba.com/resource/amp3/oxford/0/44/01/4401440c76eb2a205f98dd5733a47a9e.mp3','adj. 独一无二的；独特的；独有的','','');----
INSERT INTO classwords VALUES ('f0dc8f93d0a04d0cbdbd3297fdd88837','8522df43c8fe412b895200e5384193d7','12');----
INSERT INTO word VALUES ('ad96d536ebcd4fe5a05f75ff70f0dfbe','resultant','[riˈzʌltənt]','http://res.iciba.com/resource/amp3/oxford/0/07/36/07362064357a48e1c613a2fdf21af3fd.mp3','adj. 作为结果的，因而发生的，由此引...','','');----
INSERT INTO classwords VALUES ('0a4f815855674890888c5fa5e7f4c4c1','ad96d536ebcd4fe5a05f75ff70f0dfbe','12');----
INSERT INTO word VALUES ('ff602afc6189403db69917ca12a66f44','velocity','[viˈlɔsiti]','http://res.iciba.com/resource/amp3/oxford/0/35/be/35bed464d239f332fb04084ac7b669eb.mp3','n. 速度，速率','','');----
INSERT INTO classwords VALUES ('623869044316444cb02a52ff8a8daa7d','ff602afc6189403db69917ca12a66f44','12');----
INSERT INTO word VALUES ('64eb0259704b44249a4f9ef39f20e937','disperse','[disˈpə:s]','http://res.iciba.com/resource/amp3/0/0/87/fa/87fa76293dd66c1f2a5cbdec249397e2.mp3','vt. （使）分散；使散开；驱散','','');----
INSERT INTO classwords VALUES ('5555a5f13d97440b977689bbde01008c','64eb0259704b44249a4f9ef39f20e937','12');----
INSERT INTO word VALUES ('d564b70cf4dd416a9f5b71ca80027dca','inspector','[ɪnˈspektə]','http://res.iciba.com/resource/amp3/oxford/0/0a/7b/0a7bb8df205c40930f32d5dcbbad3c6d.mp3','n. 检查员；巡官；督察长','','');----
INSERT INTO classwords VALUES ('1ad57cd0454a430fb8d38799e12dfcd9','d564b70cf4dd416a9f5b71ca80027dca','12');----
INSERT INTO word VALUES ('85d49751a4f34278b9d86af8e35b47fc','likelihood','[ˈlaiklihud]','http://res.iciba.com/resource/amp3/oxford/0/8b/ff/8bff5c0ea5d278fd384a55ecb7590339.mp3','n. 可能性；可能的事','','');----
INSERT INTO classwords VALUES ('4a67e557b3d6431fbe2806599f7924e0','85d49751a4f34278b9d86af8e35b47fc','12');----
INSERT INTO word VALUES ('34ee8d40f95f4a85bc0c157bfddbaf47','bronze','[brɔnz]','http://res.iciba.com/resource/amp3/0/0/ca/b7/cab7e764b30007514145eaf2f6a7ed0f.mp3','n. 青铜色；青铜；青铜像','','');----
INSERT INTO classwords VALUES ('8ac99379309244818b293253870f06df','34ee8d40f95f4a85bc0c157bfddbaf47','12');----
INSERT INTO word VALUES ('2400fc3f75a04e5b9c8c8b22435f56c5','originate','[əˈridʒineit]','http://res.iciba.com/resource/amp3/oxford/0/49/7a/497ae83f2bc2909d0f227d2694180c13.mp3','vt. 创始','','');----
INSERT INTO classwords VALUES ('6919431a22564ff290be9746d475e663','2400fc3f75a04e5b9c8c8b22435f56c5','12');----
INSERT INTO word VALUES ('5e3168c96a08456c8032e68482a08b22','composite','[ˈkɔmpəzit]','http://res.iciba.com/resource/amp3/1/0/ec/e0/ece0fa92c82afc69092153da33069c87.mp3','n. 合成物','','');----
INSERT INTO classwords VALUES ('c5e5dfabf0554a55b4019825e19f6c1e','5e3168c96a08456c8032e68482a08b22','12');----
INSERT INTO word VALUES ('5332bf2bee2c4bdea7cacc093a7ab2ce','realistic','[ˌriəˈlistik]','http://res.iciba.com/resource/amp3/oxford/0/4e/f4/4ef454dd02fdcd6a75c4eaaa368e372b.mp3','adj. 现实的；现实主义的','','');----
INSERT INTO classwords VALUES ('f6c34af79d5f41279ca2550aa6c1bb3d','5332bf2bee2c4bdea7cacc093a7ab2ce','12');----
INSERT INTO word VALUES ('5d03506dc46648fa812ebe93875cc878','resent','[riˈzent]','http://res.iciba.com/resource/amp3/oxford/0/fb/f9/fbf926734afbe57f988a42097a8cdbbf.mp3','vt. 怨恨；愤恨','','');----
INSERT INTO classwords VALUES ('8f72b0f6e8ea427d9c9eecf6478af9b8','5d03506dc46648fa812ebe93875cc878','12');----
INSERT INTO word VALUES ('9d4716ed5108426ca30405eda01e1cb6','empirical','[emˈpirikəl]','http://res.iciba.com/resource/amp3/oxford/0/81/79/817999f11725da633e72cbf6d757318d.mp3','adj. 经验主义的','','');----
INSERT INTO classwords VALUES ('bdfc04bee7e347f784b04d1fd8598883','9d4716ed5108426ca30405eda01e1cb6','12');----
INSERT INTO word VALUES ('7b234d505ff94119bd96f62464ed8605','pertinent','[ˈpə:tinənt]','http://res.iciba.com/resource/amp3/0/0/c9/d2/c9d25ae4997499586e133099b1fe8b97.mp3','adj. 恰当的；有关的；中肯的','','');----
INSERT INTO classwords VALUES ('fa443f08a82e465193717ac38f05ab79','7b234d505ff94119bd96f62464ed8605','12');----
INSERT INTO word VALUES ('3a4b27c1911747e5b5a04e159df50fff','engage','[ɪnˈɡeɪdʒ]','http://res.iciba.com/resource/amp3/oxford/0/4b/0a/4b0a6659d8828ebce57219453eaf2529.mp3','vt. 从事；引起（注意、兴趣）；使参与','','');----
INSERT INTO classwords VALUES ('b4003c08fd664aa7b62ed898d851fbd0','3a4b27c1911747e5b5a04e159df50fff','12');----
INSERT INTO word VALUES ('98be9c1f97ac4e299ab4f090fe0db5a7','induce','[inˈdju:s]','http://res.iciba.com/resource/amp3/oxford/0/4c/3d/4c3dd16840cafcf8e35422b9d7630a93.mp3','vt. 劝诱，劝说；引起','','');----
INSERT INTO classwords VALUES ('ec9166275acb4789ab24fa84fd665d23','98be9c1f97ac4e299ab4f090fe0db5a7','12');----
INSERT INTO word VALUES ('cd5ff1cfc46444c090efb5b2885f91e2','flaw','[flɔ:]','http://res.iciba.com/resource/amp3/oxford/0/15/61/15611efb1278f347d2df2be66ae1e3a5.mp3','n. 缺点；瑕疵；错误，谬误','','');----
INSERT INTO classwords VALUES ('27b39933f15c49e594187221b5be656f','cd5ff1cfc46444c090efb5b2885f91e2','12');----
INSERT INTO word VALUES ('19662177e9da459bad00200153e95b5b','tightly','[ˈtaɪtlɪ]','http://res.iciba.com/resource/amp3/oxford/0/cf/dd/cfdd0d32e5d8d7d0f0a62aac8c88568f.mp3','adv. 紧紧地，牢固地','','');----
INSERT INTO classwords VALUES ('0c110899a59f471ebd1a2d3dfbc86b06','19662177e9da459bad00200153e95b5b','12');----
INSERT INTO word VALUES ('39afb9b6ffd341b7be3ae6bb70266812','snap','[snæp]','http://res.iciba.com/resource/amp3/oxford/0/d1/80/d1808b18990665455ff2714c940302bc.mp3','vt. 猛咬；突然折断','','');----
INSERT INTO classwords VALUES ('b19430f9b75d4ccd88d75586701ed8dc','39afb9b6ffd341b7be3ae6bb70266812','12');----
INSERT INTO word VALUES ('23c0aa736c4d4410bee7fc9f13cb0abc','govern','[ˈɡʌvən]','http://res.iciba.com/resource/amp3/0/0/56/4a/564afb427cb3571f2af0285572efecf8.mp3','v. 支配；控制；统治','','');----
INSERT INTO classwords VALUES ('fbf07a121d8d4dd7bdbf1ce9ba023bab','23c0aa736c4d4410bee7fc9f13cb0abc','12');----
INSERT INTO word VALUES ('5377b0a3b2ed40c38bdaa665a10352dd','inorganic','[ˌɪnɔ:ˈgænɪk]','http://res.iciba.com/resource/amp3/oxford/0/2e/a8/2ea8a699bac7bd91880bc3ffd010dbc0.mp3','adj. 无生物的；无机的','','');----
INSERT INTO classwords VALUES ('5d7641dedc7942fd9fdd701bba759ce0','5377b0a3b2ed40c38bdaa665a10352dd','12');----
INSERT INTO word VALUES ('6563812f37354f44969b67850373a76a','unlock','[ʌnˈlɔk]','http://res.iciba.com/resource/amp3/0/0/47/4f/474f3c5e4e32cc95d291d859ae64ef7b.mp3','vt. 释放（潜能）；开启（门锁）','','');----
INSERT INTO classwords VALUES ('ee8f25fccd784bbba13efc03a3d3a666','6563812f37354f44969b67850373a76a','12');----
INSERT INTO word VALUES ('36e5e3f5bf204cd69f78b412fe265b29','specification','[ˌspesifiˈkeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/82/b1/82b185e221c79eaeac50ccf62f6e8e7f.mp3','n. 详述；规格；说明书','','');----
INSERT INTO classwords VALUES ('21ebc11f5c2e4eeb90a5fe60830a73e9','36e5e3f5bf204cd69f78b412fe265b29','12');----
INSERT INTO word VALUES ('d419c3c6c56e4b9d8758b74301caa1f1','mechanics','[mɪˈkænɪks]','http://res.iciba.com/resource/amp3/0/0/05/f8/05f8e33b48d5f8430980e3d1f38e5116.mp3','n. 力学，机械学；机件','','');----
INSERT INTO classwords VALUES ('795ce33b50694829b2d8ebe5745697e6','d419c3c6c56e4b9d8758b74301caa1f1','12');----
INSERT INTO word VALUES ('36d923a71f0743f197b1dbbfac2d7b1d','collide','[kəˈlaid]','http://res.iciba.com/resource/amp3/oxford/0/ef/a7/efa7ea6714420286c01ca74ec8d3094c.mp3','vi. 碰撞；相撞；冲突，抵触','','');----
INSERT INTO classwords VALUES ('db4a9ef32e3a4308856dee305564c9b4','36d923a71f0743f197b1dbbfac2d7b1d','12');----
INSERT INTO word VALUES ('f5494c4d70b14c49bf5cd4126f2aac16','concentrate','[ˈkɔnsəntreit]','http://res.iciba.com/resource/amp3/oxford/0/6e/83/6e83d363199da6dba3621672ed3c8a78.mp3','vt.&vi. 全神贯注；使集中','','');----
INSERT INTO classwords VALUES ('b82b49659d65459fb35df662eb3fcc48','f5494c4d70b14c49bf5cd4126f2aac16','12');----
INSERT INTO word VALUES ('3c7007630d874201bd43e40f508b7c14','filament','[ˈfɪləmənt]','http://res.iciba.com/resource/amp3/oxford/0/b6/ab/b6ab6f1e0cdc63cc8b181dd1011e0893.mp3','n. 细丝，细线，细状物','','');----
INSERT INTO classwords VALUES ('71a106900ebf475fada965b4e671be73','3c7007630d874201bd43e40f508b7c14','12');----
INSERT INTO word VALUES ('46f5659a519348e88072332cecaa05ec','colonist','[ˈkɔlənɪst]','http://res.iciba.com/resource/amp3/oxford/0/88/fd/88fdf46e8fcbf2f0b91026389ad3922d.mp3','n. 移民；殖民地居民；殖民地开拓者','','');----
INSERT INTO classwords VALUES ('79c80d84305e415ebb89ab431773b596','46f5659a519348e88072332cecaa05ec','12');----
INSERT INTO word VALUES ('504ccfe466f0405da699d9bc015459cc','gear','[ɡiə]','http://res.iciba.com/resource/amp3/0/0/fa/e0/fae005cf393a8ec646f3fe040339fd9d.mp3','n. 齿轮；传动装置','','');----
INSERT INTO classwords VALUES ('d5e3612a8ed241928d455a5d15e7aad3','504ccfe466f0405da699d9bc015459cc','12');----
INSERT INTO word VALUES ('ccd9e51e7a0642ad82ae3517e893d560','cock','[kɔk]','http://res.iciba.com/resource/amp3/0/0/92/68/9268d0b2d17670598c70045b0c7abf38.mp3','n. 公鸡；雄禽','','');----
INSERT INTO classwords VALUES ('96dc9f495fe44c52b44741dc9023109c','ccd9e51e7a0642ad82ae3517e893d560','12');----
INSERT INTO word VALUES ('0404b8b4f562466aafdefb8407503b6a','board','[bɔ:d]','http://res.iciba.com/resource/amp3/0/0/11/45/1145f263256c923716d2b8eade2f6689.mp3','vt. （收费）供…膳食；登上（火车等）','','');----
INSERT INTO classwords VALUES ('7ddd1811f3b24061821395e6429eca2c','0404b8b4f562466aafdefb8407503b6a','12');----
INSERT INTO word VALUES ('a7810530e9eb4f289390b562753e219e','flame','[fleim]','http://res.iciba.com/resource/amp3/oxford/0/b2/71/b271c3522e4bfff1f19f99dd62412ac2.mp3','n. 火焰；怒火 vi. 燃烧； 面红；...','','');----
INSERT INTO classwords VALUES ('7fa94edead7f409098fb6e8c2e40f0f0','a7810530e9eb4f289390b562753e219e','12');----
INSERT INTO word VALUES ('eadeb99efc964a77bab88c4410e8026d','proverb','[ˈprɔvəb]','http://res.iciba.com/resource/amp3/0/0/1c/6c/1c6c7ff775735a08459941f9da7ea433.mp3','n. 谚语，格言','','');----
INSERT INTO classwords VALUES ('6cdeae79affa41b79115cdc3cb799f16','eadeb99efc964a77bab88c4410e8026d','12');----
INSERT INTO word VALUES ('5141de0ca13343b79108d54ae13739f0','estate','[isˈteit]','http://res.iciba.com/resource/amp3/oxford/0/20/13/2013da4be62863df16b18abeef46f9e1.mp3','n. 地产；遗产；住宅区','','');----
INSERT INTO classwords VALUES ('ba30eb8a398c4f00a8e2a4a585ac5c6d','5141de0ca13343b79108d54ae13739f0','12');----
INSERT INTO word VALUES ('e114cfeb37024cdfa03d0f6a6a86c764','incidentally','[ˌɪnsiˈdentəli]','http://res.iciba.com/resource/amp3/oxford/0/ea/05/ea056cfe72d86216db1ec7b53a9173fa.mp3','adv. 附带地；顺便提及','','');----
INSERT INTO classwords VALUES ('62f299c5956d4442a90ca10415d78dcc','e114cfeb37024cdfa03d0f6a6a86c764','12');----
INSERT INTO word VALUES ('108a3eb9a0bf481b8a59a2155fe226a6','personality','[ˌpə:səˈnæliti]','http://res.iciba.com/resource/amp3/oxford/0/88/2c/882c201d278533f5293978b0918e2779.mp3','n. 性格，个性；名人；个性鲜明的人','','');----
INSERT INTO classwords VALUES ('3cb77f79b9064a91a97c3a573c447cd0','108a3eb9a0bf481b8a59a2155fe226a6','12');----
INSERT INTO word VALUES ('57a26e3aafbf4a4c9347258dddcab369','sting','[stiŋ]','http://res.iciba.com/resource/amp3/oxford/0/87/47/87478f23df93063f069503f63f08e844.mp3','vt. 刺，叮；（使）感到刺痛','','');----
INSERT INTO classwords VALUES ('f364f93d80974d298fe1e6419c42222f','57a26e3aafbf4a4c9347258dddcab369','12');----
INSERT INTO word VALUES ('03fdccb20df149c6b98e416f9d029618','soy','[sɔɪ]','http://res.iciba.com/resource/amp3/0/0/91/a5/91a5c1de1fb151b6924cbefa6e68fb9b.mp3','n. 酱油；大豆','','');----
INSERT INTO classwords VALUES ('f6a103d31c10463e8faeb0f1f6f0724a','03fdccb20df149c6b98e416f9d029618','12');----
INSERT INTO word VALUES ('9883baaef0e6402da792ab21998291a6','pineapple','[ˈpainˌæpl]','http://res.iciba.com/resource/amp3/oxford/0/62/14/621436a831319765aa64908d023af6e0.mp3','n. 凤梨；波萝','','');----
INSERT INTO classwords VALUES ('9815b811c0c64eb99efb364d6edfd7a6','9883baaef0e6402da792ab21998291a6','12');----
INSERT INTO word VALUES ('d2ee9f62b4924dec990832718fc27646','flannel','[ˈflænəl]','http://res.iciba.com/resource/amp3/oxford/0/83/61/8361510bec62d429992211078123562f.mp3','n. 法兰绒；毛巾；废话','','');----
INSERT INTO classwords VALUES ('54b199d9a90047629f76b5540f44ef32','d2ee9f62b4924dec990832718fc27646','12');----
INSERT INTO word VALUES ('76bcffe020a54f259555837519b09b1a','inclination','[ˌɪnkləˈneɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/b5/27/b5270b90cc8b9209ccfaafd922858f84.mp3','n. 倾向；爱好','','');----
INSERT INTO classwords VALUES ('19efb45024af4c0e8fd4f8ac14d90929','76bcffe020a54f259555837519b09b1a','12');----
INSERT INTO word VALUES ('5f45605e630c4a47b50216fdb2d52d1a','cereal','[ˈsiəriəl]','http://res.iciba.com/resource/amp3/oxford/0/fe/8f/fe8f223060c690516343f58884ed4d00.mp3','n. 谷类；谷物；麦片','','');----
INSERT INTO classwords VALUES ('31d5e64dace34ce5bb2e348cddb65d39','5f45605e630c4a47b50216fdb2d52d1a','12');----
INSERT INTO word VALUES ('8607d4a5035b469885203c0f41b40cfe','fossil','[ˈfɔsl]','http://res.iciba.com/resource/amp3/0/0/bd/2a/bd2ad056056683306b5730e3f2e8ff13.mp3','adj. 化石的','','');----
INSERT INTO classwords VALUES ('eb6cabc8e7974c73b9f5e229a83c2075','8607d4a5035b469885203c0f41b40cfe','12');----
INSERT INTO word VALUES ('d4baae4541d541b08239e4aaac194017','massive','[ˈmæsiv]','http://res.iciba.com/resource/amp3/oxford/0/d7/3a/d73a74a26b7d9223ef3d76f04d698749.mp3','adj. 巨大的，庞大的；非常严重的','','');----
INSERT INTO classwords VALUES ('b07f00b193a145d2918b51d826489933','d4baae4541d541b08239e4aaac194017','12');----
INSERT INTO word VALUES ('728c859c6c7c46f4a422cbc9ca110078','towards','[tə''wɔ:dz]','http://res.iciba.com/resource/amp3/0/0/9c/e9/9ce90fddf23fb66e39c8adb03e690768.mp3','prep. 向，朝；倾向于；关于；接近','','');----
INSERT INTO classwords VALUES ('9c9d79dde29e435cb92a03be323de7b3','728c859c6c7c46f4a422cbc9ca110078','12');----
INSERT INTO word VALUES ('9a776146cbf844ccb55c1319bf45f2f5','convey','[kənˈvei]','http://res.iciba.com/resource/amp3/oxford/0/c0/18/c0189ea427659f29b4bb501c6c908f45.mp3','vt. 传达，传递；运输，运送','','');----
INSERT INTO classwords VALUES ('d3e9ee14893a4512807766ded2154a2a','9a776146cbf844ccb55c1319bf45f2f5','12');----
INSERT INTO word VALUES ('bbe03294bda0468fab9932a2f78a2ec6','superficial','[ˌsju:pəˈfiʃəl]','http://res.iciba.com/resource/amp3/oxford/0/9e/80/9e80f790d305de5821891f99bff910d1.mp3','adj. 表面的；肤浅的','','');----
INSERT INTO classwords VALUES ('b876efe49be644c5b8ae3e0916beeafe','bbe03294bda0468fab9932a2f78a2ec6','12');----
INSERT INTO word VALUES ('28546ddb6c5d4ddc8947cdffc85dab3a','gorilla','[ɡəˈrilə]','http://res.iciba.com/resource/amp3/oxford/0/3c/82/3c827b410f9c9fb43c2acc7797c7cd8e.mp3','n. 大猩猩','','');----
INSERT INTO classwords VALUES ('bf908e803d5b48f3ba7700c694ac9b86','28546ddb6c5d4ddc8947cdffc85dab3a','12');----
INSERT INTO word VALUES ('fc2caab9c48f480ebe7b8c9a2fd0c08e','sequence','[ˈsi:kwəns]','http://res.iciba.com/resource/amp3/oxford/0/48/eb/48eba9b1e4cfd5eedd1c7975330c59ed.mp3','n. 序列；一系列','','');----
INSERT INTO classwords VALUES ('847caae27db04908a2d252695181c241','fc2caab9c48f480ebe7b8c9a2fd0c08e','12');----
INSERT INTO word VALUES ('065fa437bb274481837ae4e241e85acf','portable','[ˈpɔ:təbl]','http://res.iciba.com/resource/amp3/oxford/0/30/f6/30f6ea13683b9f572ccc3ed3e7c3245e.mp3','adj. 轻便的；手提式的；便于携带的','','');----
INSERT INTO classwords VALUES ('fb67a828fe0047939687f0984956b248','065fa437bb274481837ae4e241e85acf','12');----
INSERT INTO word VALUES ('24beed57e6654b3ab8c7018278f26c41','theory','[ˈθiəri]','http://res.iciba.com/resource/amp3/0/0/af/54/af5443b3a2c16990166ab234f3bfb569.mp3','n. 理论，学说；见解，观点','','');----
INSERT INTO classwords VALUES ('e574367858ad49a7900055b68120e790','24beed57e6654b3ab8c7018278f26c41','12');----
INSERT INTO word VALUES ('be58ace4282a4f03a227e61b8b26ecb2','decompose','[ˌdi:kəmˈpəʊz]','http://res.iciba.com/resource/amp3/oxford/0/d7/12/d712de27b2d50f0555e06d61afa33f2c.mp3','vt.&vi. 使腐烂；使分解','','');----
INSERT INTO classwords VALUES ('d2dfa016b87444fca5d764c801f9dca2','be58ace4282a4f03a227e61b8b26ecb2','12');----
INSERT INTO word VALUES ('249d176db8144b6b9ee70046bfde1639','tuberculosis','[tʊˌbɜ:kjəˈləʊsɪs]','http://res.iciba.com/resource/amp3/0/0/27/55/27550c7f434ff7f9a22dd92159c07d3a.mp3','n. 结核病，肺结核','','');----
INSERT INTO classwords VALUES ('de72dc495d914ecb9133ab4cac9125e6','249d176db8144b6b9ee70046bfde1639','12');----
INSERT INTO word VALUES ('2e94e9a66b1349e9aa84d6fce05761b8','foresee','[fɔ:ˈsi:]','http://res.iciba.com/resource/amp3/0/0/3d/af/3daf8260f5eda7317e514862f5ad11de.mp3','vt. 预见，预知，预料','','');----
INSERT INTO classwords VALUES ('212446282aff4b40821e630d3da5bb6e','2e94e9a66b1349e9aa84d6fce05761b8','12');----
INSERT INTO word VALUES ('124e528c553242e8b2cc4f2fbff84a8b','tile','[tail]','http://res.iciba.com/resource/amp3/oxford/0/7d/ca/7dcad0ca5e9d572bc7e8e6f8870ef5e4.mp3','n. 瓦片；瓷砖，墙砖','','');----
INSERT INTO classwords VALUES ('27c69ee6ec1f429c882f3cce5b28c5f2','124e528c553242e8b2cc4f2fbff84a8b','12');----
INSERT INTO word VALUES ('fe8344899e734ca2ad2aedacb2631574','mistress','[ˈmistris]','http://res.iciba.com/resource/amp3/oxford/0/5c/a3/5ca3d50f09e1b9d968fc8919dfa1e021.mp3','n. 情妇；女主人；女教师','','');----
INSERT INTO classwords VALUES ('ebb423d7e79744f2b455660db4336479','fe8344899e734ca2ad2aedacb2631574','12');----
INSERT INTO word VALUES ('73a97f0c6131462aa2b4c557c066142d','villa','[ˈvɪlə]','http://res.iciba.com/resource/amp3/oxford/0/1e/7b/1e7bd9d725154b041c1cf5ddb3792dbc.mp3','n. 别墅','','');----
INSERT INTO classwords VALUES ('6ed6fc02dbcf453f8dcf79fdd973dc3b','73a97f0c6131462aa2b4c557c066142d','12');----
INSERT INTO word VALUES ('9c6a8fa2dcbf4363961d9eb22fc38682','historian','[hisˈtɔ:riən]','http://res.iciba.com/resource/amp3/oxford/0/00/c4/00c410f36e5315bfe4ad7eed5b9a2cdb.mp3','n. 历史学家','','');----
INSERT INTO classwords VALUES ('65094d9ce5f64dfd85beaeb0c636eacc','9c6a8fa2dcbf4363961d9eb22fc38682','12');----
INSERT INTO word VALUES ('2f998204460049b997b56c94aaadeee6','popularity','[ˌpɔpjəˈlærɪti:]','http://res.iciba.com/resource/amp3/oxford/0/db/2b/db2b7a7c6873b2d8779af20aef1910ad.mp3','n. 声望；普遍，流行','','');----
INSERT INTO classwords VALUES ('b82b4f9a660b4593852f54af00408f5d','2f998204460049b997b56c94aaadeee6','12');----
INSERT INTO word VALUES ('2e66832e06d84845acea6077c0d40707','maple','[ˈmeipl]','http://res.iciba.com/resource/amp3/oxford/0/ac/12/ac1277c5704905f6491e12793775f237.mp3','n. 槭树，枫树','','');----
INSERT INTO classwords VALUES ('819dd31bce824007a2940db6dd52d970','2e66832e06d84845acea6077c0d40707','12');----
INSERT INTO word VALUES ('776083c778ff46b88143772cf0d6e34f','cleanliness','[ˈklenlɪnɪs]','http://res.iciba.com/resource/amp3/oxford/0/08/a7/08a7a8d3df91c0ce7ed952b1e105ff01.mp3','n. 清洁，干净','','');----
INSERT INTO classwords VALUES ('d57eab36d7314f17ae6d64bcd23a6579','776083c778ff46b88143772cf0d6e34f','12');----
INSERT INTO word VALUES ('45505189ef2e4a8aa4a85eb0b6d939d7','span','[spæn]','http://res.iciba.com/resource/amp3/oxford/0/7e/0b/7e0b527e42f9c66f337b288cd89edad8.mp3','n. 墩距；间隔；持续时间；宽幅','','');----
INSERT INTO classwords VALUES ('36674cb605074dfe88e9c793e227f0c8','45505189ef2e4a8aa4a85eb0b6d939d7','12');----
INSERT INTO word VALUES ('80d66f14e45c4991bb775e7cbcfb9c57','optical','[ˈɔptikəl]','http://res.iciba.com/resource/amp3/oxford/0/ee/d9/eed9462ddb123a4a8c7956810f95e068.mp3','adj. 光的；光学的；视力的','','');----
INSERT INTO classwords VALUES ('f8b71dac563c4eafb191aafd607896da','80d66f14e45c4991bb775e7cbcfb9c57','12');----
INSERT INTO word VALUES ('e635afdfd1084bd99b6df9224ae6529b','merchandise','[ˈmə:tʃəndaiz]','http://res.iciba.com/resource/amp3/oxford/0/98/0c/980c6dacecbbc0d9a576193a84017dca.mp3','vt. 买卖，销售','','');----
INSERT INTO classwords VALUES ('2eb65208f6b942ccafe15c764962ac29','e635afdfd1084bd99b6df9224ae6529b','12');----
INSERT INTO word VALUES ('839d2afb0d7d4872b9d88d6ac7b59b65','chop','[tʃɔp]','http://res.iciba.com/resource/amp3/0/0/c5/c2/c5c2df792f008f6fa3fa335c921ba65e.mp3','vt. 砍，剁，劈，切','','');----
INSERT INTO classwords VALUES ('fc9af616fe484d22b4fa2e57096d8f5e','839d2afb0d7d4872b9d88d6ac7b59b65','12');----
INSERT INTO word VALUES ('ad7068bb63f141afa83dea1fb432cdaa','burglar','[ˈbə:ɡlə]','http://res.iciba.com/resource/amp3/oxford/0/d8/8c/d88cfc78dd6c0b7e045f96611bdc4690.mp3','n. 夜盗，窃贼','','');----
INSERT INTO classwords VALUES ('b0f36d07ebce4f1a83954e53a9d7b0e6','ad7068bb63f141afa83dea1fb432cdaa','12');----
INSERT INTO word VALUES ('0ba91c3ac4a54ccfb8f8f04cd699d150','preset','[pri:ˈset]','http://res.iciba.com/resource/amp3/oxford/0/67/47/6747bd8f90341d96fbf05e9f1698b2b2.mp3','vt. 预先设置','','');----
INSERT INTO classwords VALUES ('6711173ed8744cec8fdb112092b6bc4c','0ba91c3ac4a54ccfb8f8f04cd699d150','12');----
INSERT INTO word VALUES ('c9c32013197747189baa8f0e23add34b','propulsion','[prəˈpʌlʃən]','http://res.iciba.com/resource/amp3/oxford/0/51/2d/512d030e86007054daa04da6cef38fcd.mp3','n. 推进，推进力','','');----
INSERT INTO classwords VALUES ('64f9b1dc909b498dbbd7ccb7f09c90ac','c9c32013197747189baa8f0e23add34b','12');----
INSERT INTO word VALUES ('b041b7a572444006818e56ae65d093b5','bridegroom','[ˈbraɪdˌgru:m]','http://res.iciba.com/resource/amp3/oxford/0/18/ef/18ef4f0fbd8dba7977d3438d4c8265b9.mp3','n. 新郎','','');----
INSERT INTO classwords VALUES ('7de0146caef1460e8b5c36a68c8f4a53','b041b7a572444006818e56ae65d093b5','12');----
INSERT INTO word VALUES ('79afd5030d0c4abcacc33692df56795f','siege','[si:dʒ]','http://res.iciba.com/resource/amp3/oxford/0/15/72/15722d14a7fe2ea8c6ee8d63f40d38ad.mp3','n. 包围，围攻，围困','','');----
INSERT INTO classwords VALUES ('e2c607cfba634707b15b5cb6184a1e53','79afd5030d0c4abcacc33692df56795f','12');----
INSERT INTO word VALUES ('95e1cc5e550a4dcb96a5d476212db328','scope','[skəup]','http://res.iciba.com/resource/amp3/0/0/31/a1/31a1fd140be4bef2d11e121ec9a18a58.mp3','n. 眼界；范围；施展余地，机会','','');----
INSERT INTO classwords VALUES ('a03b669a6e3842a09651ae4b78f53da2','95e1cc5e550a4dcb96a5d476212db328','12');----
INSERT INTO word VALUES ('e41a6e15139b4c0aa193cfbe5b2ecb8c','blond','[blɔnd]','http://res.iciba.com/resource/amp3/0/0/13/d1/13d106ceb605d1a3f48df3aeeabbcbe2.mp3','n. 白肤金发碧眼的人','','');----
INSERT INTO classwords VALUES ('c809e5e3aebc4c5980b9c6f5e3cb5f48','e41a6e15139b4c0aa193cfbe5b2ecb8c','12');----
INSERT INTO word VALUES ('73a658b0870f4cec80c5d8a214702cdb','passport','[ˈpɑ:spɔ:t]','http://res.iciba.com/resource/amp3/0/0/d0/56/d056025fbea3c4700729c5b96b0ff97b.mp3','n. 护照；手段','','');----
INSERT INTO classwords VALUES ('a7c1d63e89ef448088c71c874b432f82','73a658b0870f4cec80c5d8a214702cdb','12');----
INSERT INTO word VALUES ('491895d0f72e42679a358ecd94b9c46b','undertake','[ˌʌndəˈteik]','http://res.iciba.com/resource/amp3/oxford/0/ef/dd/efddc4c36a88d431fe6e1429ee1b68b6.mp3','vt. 承诺；从事；承担','','');----
INSERT INTO classwords VALUES ('acdfbedf7c904dadba2c3f6e5a13166c','491895d0f72e42679a358ecd94b9c46b','12');----
INSERT INTO word VALUES ('4b7bedca103e46e184fae17a6669af3a','ridicule','[ˈrɪdɪˌkju:l]','http://res.iciba.com/resource/amp3/oxford/0/0c/ba/0cbaace3f0a98639f03eddacb91eef86.mp3','vi. 嘲弄，嘲笑；奚落','','');----
INSERT INTO classwords VALUES ('a0116ebdae91473982c4bfea61f107b0','4b7bedca103e46e184fae17a6669af3a','12');----
INSERT INTO word VALUES ('7908cf6fc8e2497492656fe005fb3ef5','theatre','[ˈθiətə]','http://res.iciba.com/resource/amp3/1/0/a0/ff/a0ff692db630abb30c9eb40adc3d205a.mp3','n. 剧场；戏剧工作；演戏','','');----
INSERT INTO classwords VALUES ('4e78bedae59c4f938f1fe0e5081abc1b','7908cf6fc8e2497492656fe005fb3ef5','12');----
INSERT INTO word VALUES ('bfd03abb1af14e41b760083ad68de78f','terminal','[ˈtə:minəl]','http://res.iciba.com/resource/amp3/oxford/0/b0/b6/b0b6f56db5f706799979b9e0fe35f054.mp3','n. 终端；终点站，集散地；线接头','','');----
INSERT INTO classwords VALUES ('50b15a43410a46eaa5c9d08a1541e099','bfd03abb1af14e41b760083ad68de78f','12');----
INSERT INTO word VALUES ('afa7dd5be4f54314b1a94663d2434456','mystery','[ˈmistəri]','http://res.iciba.com/resource/amp3/oxford/0/43/6d/436d4b5085b57bef680bde100b753080.mp3','n. 谜；神秘的事物；神秘；推理小说','','');----
INSERT INTO classwords VALUES ('13d48d84ed9647b9a302d47556dbfb1a','afa7dd5be4f54314b1a94663d2434456','12');----
INSERT INTO word VALUES ('e35f57f6be5647eb91f4c26bb112c336','fright','[fraɪt]','http://res.iciba.com/resource/amp3/oxford/0/ef/f4/eff45aa5125b9b12b864f12ec0248d2a.mp3','n. 惊吓；恐怖','','');----
INSERT INTO classwords VALUES ('2823abb4c20041899ad81d4e5159b88a','e35f57f6be5647eb91f4c26bb112c336','12');----
INSERT INTO word VALUES ('3681caf805be456d8bfa942bb123cb73','cosmic','[ˈkɔzmik]','http://res.iciba.com/resource/amp3/oxford/0/de/1f/de1f52042693d5af4ab7a66e4c2ec269.mp3','adj. 宇宙的；外太空的','','');----
INSERT INTO classwords VALUES ('6018f736e82f461db12d48d79fca5b54','3681caf805be456d8bfa942bb123cb73','12');----
INSERT INTO word VALUES ('3ffdda74c5a846718a7460fe710f7068','gnaw','[nɔ:]','http://res.iciba.com/resource/amp3/oxford/0/5d/8c/5d8c1f9aa73b23b2ade4aa0c0512a1ed.mp3','vi. 折磨','','');----
INSERT INTO classwords VALUES ('44fa460a54c64832a555a09c36a95322','3ffdda74c5a846718a7460fe710f7068','12');----
INSERT INTO word VALUES ('20ab714f3dea4d809eece7fc2c39992c','video','[ˈvidiəu]','http://res.iciba.com/resource/amp3/oxford/0/c6/9c/c69ccc770da06fde813bf02ccfdd4631.mp3','n. 录象节目；录像，录影；录像机','','');----
INSERT INTO classwords VALUES ('ebd3cbf9e94f41ca949296fe02d11d9a','20ab714f3dea4d809eece7fc2c39992c','12');----
INSERT INTO word VALUES ('e735c82a65d440e199359a7330659462','bald','[bɔ:ld]','http://res.iciba.com/resource/amp3/oxford/0/62/8c/628cd7e744d490f18e7f8a906181a330.mp3','adj. 秃头的；不加修饰的；直截了当的','','');----
INSERT INTO classwords VALUES ('0d0c120774dc4fcc942e2647ea5e5c7f','e735c82a65d440e199359a7330659462','12');----
INSERT INTO word VALUES ('ca2fd63598ef478b86d46da024a6fa82','bypass','[ˈbaipɑ:s]','http://res.iciba.com/resource/amp3/oxford/0/61/5c/615c3e24a97777783232bcfbfacb9f08.mp3','vt. 绕过；为…作搭桥术','','');----
INSERT INTO classwords VALUES ('789458af982e4f61a3e53505440b4909','ca2fd63598ef478b86d46da024a6fa82','12');----
INSERT INTO word VALUES ('476512dd33c34984a03a53dcec432b3a','difficult','[ˈdifikəlt]','http://res.iciba.com/resource/amp3/oxford/0/e3/6c/e36cfa04aec54236ba1521f42cf56798.mp3','adj. 困难的；难相处的','','');----
INSERT INTO classwords VALUES ('ca4c2dbecc164559b556b6be56f13680','476512dd33c34984a03a53dcec432b3a','12');----
INSERT INTO word VALUES ('0a80becc944a41659bab408d57957f3b','torque','[tɔ:k]','http://res.iciba.com/resource/amp3/0/0/e9/ee/e9ee2651c12f09e358eb1da8545952a7.mp3','n. 转矩，扭矩','','');----
INSERT INTO classwords VALUES ('32ecf38ce8d24f7fb08a75dbcfe22e1a','0a80becc944a41659bab408d57957f3b','12');----
INSERT INTO word VALUES ('320a74e7f0364209b6c0dc4d00c0fa50','greed','[ɡri:d]','http://res.iciba.com/resource/amp3/oxford/0/e0/9f/e09fa61bf8412ea3788e0a870869511f.mp3','n. 贪心，贪婪','','');----
INSERT INTO classwords VALUES ('0532436001d84486a699f7902c76fc17','320a74e7f0364209b6c0dc4d00c0fa50','12');----
INSERT INTO word VALUES ('88dbf2a0a51f40edb726a11c719bddff','blush','[blʌʃ]','http://res.iciba.com/resource/amp3/oxford/0/e6/e2/e6e2f811f8c43aa63f7dd128d6bcf00e.mp3','n. 脸红','','');----
INSERT INTO classwords VALUES ('353e1f4876b946969a5fb9067e927b17','88dbf2a0a51f40edb726a11c719bddff','12');----
INSERT INTO word VALUES ('8803a6caefc24ae7b7a5ed732e5de9cc','unfold','[ʌnˈfəuld]','http://res.iciba.com/resource/amp3/0/0/87/27/8727920077943a3af1ff377e46437c42.mp3','vi. 呈现','','');----
INSERT INTO classwords VALUES ('a6b78696257f4a9aac0396e4b3b361c3','8803a6caefc24ae7b7a5ed732e5de9cc','12');----
INSERT INTO word VALUES ('572f373533254bdc9ca955d5db951f9a','switch','[switʃ]','http://res.iciba.com/resource/amp3/oxford/0/e9/9a/e99a269938ba8a0d75c06968960e847b.mp3','v. 转换；改变；转移','','');----
INSERT INTO classwords VALUES ('509e6dab951d44a8bba058aef6809a10','572f373533254bdc9ca955d5db951f9a','12');----
INSERT INTO word VALUES ('e9aa5f61bda9466cb5f0e226096264d8','jug','[dʒʌɡ]','http://res.iciba.com/resource/amp3/oxford/0/37/ab/37ab2102c1cb7ef401fe0bebdc8b38e6.mp3','n. （带柄的）罐，壶','','');----
INSERT INTO classwords VALUES ('f987e57464b3486fad3b13ea059fb786','e9aa5f61bda9466cb5f0e226096264d8','12');----
INSERT INTO word VALUES ('d0944f3ded4f48ee8f2398cdccfee832','mixer','[ˈmɪksə]','http://res.iciba.com/resource/amp3/oxford/0/51/ce/51cea59a91d1866775cc35371e1c1d3f.mp3','n. 混合器，搅拌器','','');----
INSERT INTO classwords VALUES ('f030d57d37494f8ab98fb554007c1019','d0944f3ded4f48ee8f2398cdccfee832','12');----
INSERT INTO word VALUES ('f4a99824745a485899ce171af58e6eb2','applaud','[əˈplɔ:d]','http://res.iciba.com/resource/amp3/oxford/0/05/77/0577f3a70b8b20e2311a23dc5ad2f99f.mp3','vi. 拍手喝采','','');----
INSERT INTO classwords VALUES ('83b57396280445a58a979ab8f1175d18','f4a99824745a485899ce171af58e6eb2','12');----
INSERT INTO word VALUES ('e184be5cc1de408db00c8f2c6ac1c02c','equator','[iˈkweitə]','http://res.iciba.com/resource/amp3/oxford/0/e9/de/e9dec1999cd0b83eacd7bf765925455f.mp3','n. 赤道','','');----
INSERT INTO classwords VALUES ('bc0d60a3fcd6476990d57fd5a2a24015','e184be5cc1de408db00c8f2c6ac1c02c','12');----
INSERT INTO word VALUES ('88ce73b3818d40adb5eeb5105a5ca60f','radiator','[ˈreɪdi:ˌeɪtə]','http://res.iciba.com/resource/amp3/oxford/0/8a/f7/8af7bade4bfde4c02b4155f1b562bf51.mp3','n. 暖气片；散热器；冷却器','','');----
INSERT INTO classwords VALUES ('c72ba63a057d41e4b83d6b6961c016bd','88ce73b3818d40adb5eeb5105a5ca60f','12');----
INSERT INTO word VALUES ('19f769eaf3394ddcba9cd2bb0069e98a','perpendicular','[ˌpɜ:pənˈdɪkjələ]','http://res.iciba.com/resource/amp3/oxford/0/2d/ab/2dab5e03a6d459a34ccc7a7dd6b21af9.mp3','n. 垂直（线）','','');----
INSERT INTO classwords VALUES ('bae47e407d8548c99197d26a90189dd0','19f769eaf3394ddcba9cd2bb0069e98a','12');----
INSERT INTO word VALUES ('e3d10f6a50a4472f862a19e8ef5110c6','deficient','[dɪˈfɪʃənt]','http://res.iciba.com/resource/amp3/oxford/0/35/35/3535d71b7f177754ae61ed05fe78402c.mp3','adj. 缺乏的，不足的；有缺陷的','','');----
INSERT INTO classwords VALUES ('82fbeaddc6ca49e086d6e6951fbbef64','e3d10f6a50a4472f862a19e8ef5110c6','12');----
INSERT INTO word VALUES ('a7a573b40cb745a0a98cb1dfd0096408','heading','[ˈhediŋ]','http://res.iciba.com/resource/amp3/oxford/0/8e/8f/8e8f96f8bb14de99b1318ff239db9589.mp3','n. 标题，题名','','');----
INSERT INTO classwords VALUES ('ceb943ec631e4e3283636f537ef75e8c','a7a573b40cb745a0a98cb1dfd0096408','12');----
INSERT INTO word VALUES ('786f539f594544d8a612edc1d04fc37c','uneasy','[ˌʌnˈi:zi]','http://res.iciba.com/resource/amp3/oxford/0/ef/ea/efeab14db2696bd22945aeef7182988b.mp3','adj. 不安的；无把握的；不稳定的','','');----
INSERT INTO classwords VALUES ('2f19da8b6a1447189b136b807f7b03d1','786f539f594544d8a612edc1d04fc37c','12');----
INSERT INTO word VALUES ('78ddacf245fd490ea0d0eefeb626f1bd','wasteful','[ˈweɪstfəl]','http://res.iciba.com/resource/amp3/oxford/0/46/3d/463d23e76ecc2d6a67bb20ebdfa60468.mp3','adj. 浪费的；耗费的','','');----
INSERT INTO classwords VALUES ('6a37cf418f33472486b382c9ce892d3a','78ddacf245fd490ea0d0eefeb626f1bd','12');----
INSERT INTO word VALUES ('1f3ee74acc4746c094202047b39b2a22','scrap','[skræp]','http://res.iciba.com/resource/amp3/oxford/0/4b/03/4b03fc6402eaac6d83018e3396a1b9f9.mp3','vt. 废弃；取消','','');----
INSERT INTO classwords VALUES ('86ebf65e8cd64e23b58e5e5627c0cd8f','1f3ee74acc4746c094202047b39b2a22','12');----
INSERT INTO word VALUES ('fad242bb98004c6493f1cfe2072eaffb','consul','[ˈkɔnsəl]','http://res.iciba.com/resource/amp3/0/0/3d/2e/3d2e6bded046ca2e3f906f04235b279b.mp3','n. 领事','','');----
INSERT INTO classwords VALUES ('c3befcd6f51743a3a408da9b452e134b','fad242bb98004c6493f1cfe2072eaffb','12');----
INSERT INTO word VALUES ('9bc89c422bae403888b0b3d9efb1e7d3','rear','[riə]','http://res.iciba.com/resource/amp3/0/0/f0/c0/f0c076a3fdf01571c550974f72dcf4db.mp3','vt. 饲养；抚养','','');----
INSERT INTO classwords VALUES ('7c9eb8288a5942b5b96682adc75bbd2d','9bc89c422bae403888b0b3d9efb1e7d3','12');----
INSERT INTO word VALUES ('d98df62dde7f4d4b9e386deabb4674f8','overhear','[ˌəuvəˈhiə]','http://res.iciba.com/resource/amp3/0/0/12/f6/12f625382c5d8662351b7b85bddfa1e5.mp3','vt. 偶然听到；偷听','','');----
INSERT INTO classwords VALUES ('8cfc5a213e7f436c8a264171e72b39cb','d98df62dde7f4d4b9e386deabb4674f8','12');----
INSERT INTO word VALUES ('28359c8c69cd4e95a25e9d28fe13f1e7','eloquence','[ˈeləkwəns]','http://res.iciba.com/resource/amp3/0/0/5d/c8/5dc8c0f418a3cb163a181674a36fd816.mp3','n. 雄辩；口才','','');----
INSERT INTO classwords VALUES ('c7838713161f4ebd9c555ce89bf777f5','28359c8c69cd4e95a25e9d28fe13f1e7','12');----
INSERT INTO word VALUES ('dd1284af6c624c5f9ada758a9ddb7449','plateau','[ˈplætəu]','http://res.iciba.com/resource/amp3/1/0/e6/6a/e66a148f11ce660effbf6ca8bc148aeb.mp3','n. 高原；平稳时期','','');----
INSERT INTO classwords VALUES ('6d850e0117524ccc9503bc54b8c2f19b','dd1284af6c624c5f9ada758a9ddb7449','12');----
INSERT INTO word VALUES ('90813a80c7c94f19b11b9be3602f8571','operation','[ˌɔpəˈreiʃən]','http://res.iciba.com/resource/amp3/oxford/0/03/ca/03ca0fe686b44f46f29cff96dea11d59.mp3','n. 企业，公司；手术；使用；运行','','');----
INSERT INTO classwords VALUES ('16bc07c705b747f08b3009fe30ad98f8','90813a80c7c94f19b11b9be3602f8571','12');----
INSERT INTO word VALUES ('bdd003fa1b744a35806eb1d905361aa7','stride','[straid]','http://res.iciba.com/resource/amp3/oxford/0/ea/0b/ea0b0cbe85e5ab4eeff97daf0474ba86.mp3','n. 大步；步态；进展','','');----
INSERT INTO classwords VALUES ('4a29a600b17844ba9c8d03e956d6229d','bdd003fa1b744a35806eb1d905361aa7','12');----
INSERT INTO word VALUES ('877a8031c9424477a9a8f1be854e26e9','finance','[faiˈnæns]','http://res.iciba.com/resource/amp3/oxford/0/a8/33/a8332abaada98fba295d0a24d229b68b.mp3','vt. 给…提供资金','','');----
INSERT INTO classwords VALUES ('490838cc35184c528f91bd516f693447','877a8031c9424477a9a8f1be854e26e9','12');----
INSERT INTO word VALUES ('fd15543927484072b773e294a03248f3','makeup','[ˈmeɪkˌʌp]','http://res.iciba.com/resource/amp3/0/0/83/74/8374006844199522da79f883955335dc.mp3','n. 补充；体格；化妆','','');----
INSERT INTO classwords VALUES ('e5301bf92d614b82a01b60e8677582bd','fd15543927484072b773e294a03248f3','12');----
INSERT INTO word VALUES ('9aeec7bb16564ce08b3871ddeb172799','unreasonable','[ʌnˈri:zənəbəl]','http://res.iciba.com/resource/amp3/oxford/0/40/fd/40fd0a2662d9cba053023fb9a26d5c09.mp3','adj. 不讲道理的；不公平的；不合理的','','');----
INSERT INTO classwords VALUES ('282422c898d1478b91765fb29597fdbb','9aeec7bb16564ce08b3871ddeb172799','12');----
INSERT INTO word VALUES ('abc40047a5884da4a15e66903d88c019','eclipse','[iˈklips]','http://res.iciba.com/resource/amp3/oxford/0/d9/ca/d9caaee45aae678a9d97ed73c5d3e691.mp3','n. （日，月）食；黯然失色','','');----
INSERT INTO classwords VALUES ('11706332515c43a698784630f4001dae','abc40047a5884da4a15e66903d88c019','12');----
INSERT INTO word VALUES ('82b38c3afbdb4f3691ae6e9d2c3e9a0b','symphony','[ˈsimfəni]','http://res.iciba.com/resource/amp3/oxford/0/56/2b/562b13f0648861c1713be9da19ab9b05.mp3','n. 交响乐，交响曲','','');----
INSERT INTO classwords VALUES ('ce855f0684084142bc85a1ebc02a4204','82b38c3afbdb4f3691ae6e9d2c3e9a0b','12');----
INSERT INTO word VALUES ('b777fe17002f4dbb97ebfe01ec6e5581','alteration','[ˌɔ:ltəˈreɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/b8/09/b809dbce613cfc431666846e9221a027.mp3','n. 变更；改变；更改','','');----
INSERT INTO classwords VALUES ('45745f2124f1433d91ceec1d23388231','b777fe17002f4dbb97ebfe01ec6e5581','12');----
INSERT INTO word VALUES ('63cba45ee1714db58a1d745039a90d91','location','[ləuˈkeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/b9/8b/b98bfbbf469c9df218aca40f835145d4.mp3','n. 位置，场所；外景拍摄地','','');----
INSERT INTO classwords VALUES ('e7c02117acc14d70a066f38ed2092a41','63cba45ee1714db58a1d745039a90d91','12');----
INSERT INTO word VALUES ('66f874c554fb4f5884d62c5d8e3aff8e','earnings','[ˈɜ:nɪŋz]','http://res.iciba.com/resource/amp3/oxford/0/61/a4/61a43c05e493eac5d7f178ddafb205d2.mp3','n. 工资；收入','','');----
INSERT INTO classwords VALUES ('70fd78a4102e48bcbce6e6e01dc16b20','66f874c554fb4f5884d62c5d8e3aff8e','12');----
INSERT INTO word VALUES ('b2fab1f030db4d6483e89be41c48a249','vaccinate','[ˈvæksəˌneɪt]','http://res.iciba.com/resource/amp3/oxford/0/a6/4a/a64ac7a58ca9092b4e4c7abfa480d955.mp3','vt. 给…接种疫苗','','');----
INSERT INTO classwords VALUES ('1386efc5a118453e9b4655a0dbb90bb0','b2fab1f030db4d6483e89be41c48a249','12');----
INSERT INTO word VALUES ('35c9292f6222443bb42bbe535d296368','wardrobe','[ˈwɔ:drəub]','http://res.iciba.com/resource/amp3/0/0/e1/c8/e1c8ac3399a2883e0155182f72205fcd.mp3','n. 衣柜，衣橱；行头','','');----
INSERT INTO classwords VALUES ('5c2eb4162513446cbdff49226fe6e3dc','35c9292f6222443bb42bbe535d296368','12');----
INSERT INTO word VALUES ('3164003153b247f6a36549c3727133d6','feminine','[ˈfeminin]','http://res.iciba.com/resource/amp3/oxford/0/a2/64/a264d9687ace5df3035540d9bdbc38af.mp3','adj. 女性的；女子气的；阴性的','','');----
INSERT INTO classwords VALUES ('d75941e672fe40cb85e026007d6408af','3164003153b247f6a36549c3727133d6','12');----
INSERT INTO word VALUES ('488c35eddd014cca87696e32db2c067e','supplement','[ˈsʌpliment]','http://res.iciba.com/resource/amp3/oxford/0/2f/8b/2f8b7b4e97d29afdfdd6dd57abeed77a.mp3','n. 营养片剂；增刊；补编','','');----
INSERT INTO classwords VALUES ('3dfa22cf05294aaca78fd7bec94abc91','488c35eddd014cca87696e32db2c067e','12');----
INSERT INTO word VALUES ('4962d23cf2184a2b8e79a92ddf6d1615','offset','[ˈɔfset]','http://res.iciba.com/resource/amp3/oxford/0/08/94/08940088158bb7921909fb25e5115efc.mp3','vt. 抵消；补偿','','');----
INSERT INTO classwords VALUES ('cbe568ef54df4daea4370a3c2d5e6358','4962d23cf2184a2b8e79a92ddf6d1615','12');----
INSERT INTO word VALUES ('4f5d6feff31347e89cc41c410ee2df73','substantial','[səbˈstænʃəl]','http://res.iciba.com/resource/amp3/oxford/0/76/c8/76c89abbdca3ffd13dcb65e108bdcc48.mp3','adj. 物质的；坚固的；大量的','','');----
INSERT INTO classwords VALUES ('1033e8273eb244c5b78b9227792a4bfb','4f5d6feff31347e89cc41c410ee2df73','12');----
INSERT INTO word VALUES ('6ce6d88ac0c64627aa41238a1b098abd','mend','[mend]','http://res.iciba.com/resource/amp3/oxford/0/10/41/10410c82723757adcfa0abd48e9bc0c3.mp3','vt. 修理；改正；使康复','','');----
INSERT INTO classwords VALUES ('de6fd4691fba44fb80fecbc77bd8147e','6ce6d88ac0c64627aa41238a1b098abd','12');----
INSERT INTO word VALUES ('7d898da23462432eb92412091c0c6335','elevate','[ˈeliveit]','http://res.iciba.com/resource/amp3/oxford/0/2c/e1/2ce1f9773f87af37f119bce911f7ca4f.mp3','vt. 提高；提升（地位）；举起','','');----
INSERT INTO classwords VALUES ('d028daac88cd455fa35afe7eb19651da','7d898da23462432eb92412091c0c6335','12');----
INSERT INTO word VALUES ('130d99040b904908bd69941443b29219','second','[ˈsekənd]','http://res.iciba.com/resource/amp3/1/0/a9/f0/a9f0e61a137d86aa9db53465e0801612.mp3','vt. 临时调任，临时调派；支持','','');----
INSERT INTO classwords VALUES ('b93982c2b64e4612b78c2c7541840dd6','130d99040b904908bd69941443b29219','12');----
INSERT INTO word VALUES ('2b3dc81ff2124949b1984964ed4b0f72','outside','[ˌautˈsaid]','http://res.iciba.com/resource/amp3/oxford/0/f1/28/f128aa7bfaeb93660d9208df66269bd0.mp3','prep. 在…外，向…外','','');----
INSERT INTO classwords VALUES ('c3ce0defa3e1445ab1ab0e4db0dcc38b','2b3dc81ff2124949b1984964ed4b0f72','12');----
INSERT INTO word VALUES ('19b56b7ee3fe4256913882b82519588a','productivity','[ˌprɔdʌkˈtiviti]','http://res.iciba.com/resource/amp3/oxford/0/56/33/5633af0c2a0ceece5c39c5a78faf2e83.mp3','n. 生产率，生产力','','');----
INSERT INTO classwords VALUES ('8b7b59e90d9049f8a71552d28bd21ea5','19b56b7ee3fe4256913882b82519588a','12');----
INSERT INTO word VALUES ('6bcfc538a794420e9ad1c54a50e69d9f','shady','[ˈʃeɪdi:]','http://res.iciba.com/resource/amp3/oxford/0/ec/e1/ece19fbab89a90ca2a39719e347f0291.mp3','adj. 可疑的；背阴的；不正当的','','');----
INSERT INTO classwords VALUES ('42cd52cc5b5b49dbabd92157ef0c1666','6bcfc538a794420e9ad1c54a50e69d9f','12');----
INSERT INTO word VALUES ('bf381d9341da4617bf645204094f4ff1','notion','[ˈnəuʃən]','http://res.iciba.com/resource/amp3/0/0/5e/a7/5ea790e4a248dab6ac4b6ae1854463c7.mp3','n. 观念，看法','','');----
INSERT INTO classwords VALUES ('e729adaa11344c838a4f68cb1d69de6e','bf381d9341da4617bf645204094f4ff1','12');----
INSERT INTO word VALUES ('29b6363ac5b94b569641095b39210fbd','endeavor','[enˈdevə]','http://res.iciba.com/resource/amp3/0/0/c5/f5/c5f5aaefa43684051f6fa380eef4b59e.mp3','vt.&vi. 尝试，试图','','');----
INSERT INTO classwords VALUES ('f7d46ed4c751423ead849403e0cefdb5','29b6363ac5b94b569641095b39210fbd','12');----
INSERT INTO word VALUES ('36fb35b8ddf741819dffe36c221c7b9d','Roman','[ˈrəʊmən]','http://res.iciba.com/resource/amp3/1/0/b5/df/b5df36ac79aa6391ffb432b9e5ad7880.mp3','n. 罗马人；罗马字体','','');----
INSERT INTO classwords VALUES ('e2fdb15acc4a4e0eaf80f10445f09995','36fb35b8ddf741819dffe36c221c7b9d','12');----
INSERT INTO word VALUES ('a48fcb42b95f4479bbc4d38f767c30ee','compatible','[kəmˈpætəbl]','http://res.iciba.com/resource/amp3/oxford/0/35/f8/35f86a3944e980a790167e8cca2e0abe.mp3','adj. 兼容的；能和谐相处的','','');----
INSERT INTO classwords VALUES ('e589a27b22564ef78eae31c272f9f075','a48fcb42b95f4479bbc4d38f767c30ee','12');----
INSERT INTO word VALUES ('db606d4db68343f7b71bc775033de826','siren','[ˈsaiərin]','http://res.iciba.com/resource/amp3/oxford/0/34/0e/340ec57b2d5ada09abe3f4eeb297a507.mp3','n. 汽笛，警报器；妖妇','','');----
INSERT INTO classwords VALUES ('f1d9bc57ef444a35b46cb0f4296d255f','db606d4db68343f7b71bc775033de826','12');----
INSERT INTO word VALUES ('a59bf37d1be54b29a5efc0a31914c532','requisite','[ˈrekwɪzɪt]','http://res.iciba.com/resource/amp3/oxford/0/f8/1b/f81b348b7c1086d43fa098792330e47b.mp3','n. 必需品；必备品','','');----
INSERT INTO classwords VALUES ('54bc8bf5bd754f26a315fb00a39f1b16','a59bf37d1be54b29a5efc0a31914c532','12');----
INSERT INTO word VALUES ('1e7f30d13d6d49b1bcc103ec6836c466','presume','[priˈzju:m]','http://res.iciba.com/resource/amp3/oxford/0/5c/93/5c9385c87ad162b57550d59a274c9bfd.mp3','vt. 假定，假设；推测；认为','','');----
INSERT INTO classwords VALUES ('ecc71502eea347dfa9955e8f1bef9553','1e7f30d13d6d49b1bcc103ec6836c466','12');----
INSERT INTO word VALUES ('a17dbd846514486a8ff5e68a23586f88','leopard','[ˈlepəd]','http://res.iciba.com/resource/amp3/oxford/0/67/d3/67d35e39a5cc4961105da05ccf2421bf.mp3','n. 豹','','');----
INSERT INTO classwords VALUES ('a0bd5f1c4da3460da1f4748097e78f27','a17dbd846514486a8ff5e68a23586f88','12');----
INSERT INTO word VALUES ('08539648699b4ee18e85e63266a8427d','vitamin','[ˈvitəmin]','http://res.iciba.com/resource/amp3/oxford/0/27/f1/27f10c2c9e235aa873217eff1d850a75.mp3','n. 维生素，维他命','','');----
INSERT INTO classwords VALUES ('fdbe9b3a80df47999ad8b240bfa53c6e','08539648699b4ee18e85e63266a8427d','12');----
INSERT INTO word VALUES ('0ef4cab668d64fa4adec39442f2bd34f','formal','[ ˈfɔ:məl]','http://res.iciba.com/resource/amp3/0/0/c9/dc/c9dcb1b8cccc8c6dc2a5d40cd5b1d010.mp3','adj. 礼仪上的；正式的，规范的','','');----
INSERT INTO classwords VALUES ('505b7802ec85446aaff10196b34ca6fa','0ef4cab668d64fa4adec39442f2bd34f','12');----
INSERT INTO word VALUES ('a862c04bfe474beca15f70d00ab4f68b','masculine','[ˈmɑ:skjulin]','http://res.iciba.com/resource/amp3/oxford/0/60/56/6056c98dc67e02906d04b48f81a2a3dc.mp3','adj. 男性的；阳刚的','','');----
INSERT INTO classwords VALUES ('91dc4834adaa42b7a202fd098d555f80','a862c04bfe474beca15f70d00ab4f68b','12');----
INSERT INTO word VALUES ('523c49a345ee4fc69f2bd0148030452d','consolidate','[kənˈsɔlideit]','http://res.iciba.com/resource/amp3/oxford/0/c5/d1/c5d1a44d452042d684ca85b05bdba703.mp3','vi. 合并，使联合','','');----
INSERT INTO classwords VALUES ('b8db65b2d5594da1b7eafc2aba1685fd','523c49a345ee4fc69f2bd0148030452d','12');----
INSERT INTO word VALUES ('1540025e920e4972bc1dfd6b6ac2a36a','adjustable','[əˈdʒʌstəbl]','http://res.iciba.com/resource/amp3/oxford/0/94/f7/94f7cd5abd642ae143fdfaa410271a7d.mp3','adj. 可调整的','','');----
INSERT INTO classwords VALUES ('a2a9e2cb2e414f0690e016895ef5295b','1540025e920e4972bc1dfd6b6ac2a36a','12');----
INSERT INTO word VALUES ('7b2289f22d7f497d8755ed34704e5426','aviation','[ˌeivi:ˈeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/52/4c/524cf41373be03f2a90d920154da39a3.mp3','n. 航空；飞机制造业','','');----
INSERT INTO classwords VALUES ('cbbb2d206c6f47338edb27b29a9238e5','7b2289f22d7f497d8755ed34704e5426','12');----
INSERT INTO word VALUES ('cd639fe8708b46469c014efa460d6459','horn','[hɔ:n]','http://res.iciba.com/resource/amp3/0/0/50/d4/50d48c9002eb08e248225c1d91732bbc.mp3','n. 角状物；喇叭；角质','','');----
INSERT INTO classwords VALUES ('b99d4f0b81e64a80b3e86f8f9b96be44','cd639fe8708b46469c014efa460d6459','12');----
INSERT INTO word VALUES ('74cdaf9c491849fabeb424e95d707ff8','coward','[ˈkaʊəd]','http://res.iciba.com/resource/amp3/oxford/0/fc/ec/fcec2ce9b9007adf7d563c2149537207.mp3','n. 胆小鬼，懦夫','','');----
INSERT INTO classwords VALUES ('fbc794f1aa83494e8e66e9e01ed6b90a','74cdaf9c491849fabeb424e95d707ff8','12');----
INSERT INTO word VALUES ('5e08c30c66c54f3fb2745d6b5a43f711','oval','[ˈəuvəl]','http://res.iciba.com/resource/amp3/0/0/dc/66/dc66b8bf72021c7c6bd7106da212d92a.mp3','n. 卵形，椭圆形','','');----
INSERT INTO classwords VALUES ('ef87feefa2204726bfba3377f495cc2e','5e08c30c66c54f3fb2745d6b5a43f711','12');----
INSERT INTO word VALUES ('2e58fbad39b9498db9438e3c942b96ca','destiny','[ˈdestini]','http://res.iciba.com/resource/amp3/oxford/0/8e/7c/8e7c23db5b64fe63081955c162777380.mp3','n. 命运；天命','','');----
INSERT INTO classwords VALUES ('d1b054d4e9ff4b31a2575ae2e135c878','2e58fbad39b9498db9438e3c942b96ca','12');----
INSERT INTO word VALUES ('1054f006044b46118bf2bf200dfae1c3','pedlar','[ˈpedlə]','http://res.iciba.com/resource/amp3/oxford/0/a1/81/a1816a1b3ff52a85ffa6cfce7de75713.mp3','n. 流动小贩','','');----
INSERT INTO classwords VALUES ('6cb641c9639f4d8fb6ae0c0e5aa9e4dc','1054f006044b46118bf2bf200dfae1c3','12');----
INSERT INTO word VALUES ('55f2ad49e262444b88b59d3abd96e0e1','supersonic','[ˌsju:pəˈsɔnik]','http://res.iciba.com/resource/amp3/0/0/f0/79/f07956290b0d925230274c74a646ce6f.mp3','adj. 超音速的，超声速的','','');----
INSERT INTO classwords VALUES ('360ed9c924734f769a4583a9c7bd3e94','55f2ad49e262444b88b59d3abd96e0e1','12');----
INSERT INTO word VALUES ('3bb5008c943a4f06b723ad3b403f32cb','allied','[əˈlaɪd]','http://res.iciba.com/resource/amp3/oxford/0/0b/25/0b2531e037ede5c9c034e83f8fc2a789.mp3','adj. 联合的；同盟的','','');----
INSERT INTO classwords VALUES ('7121b21a982b43f8b80e2c651f6a08c3','3bb5008c943a4f06b723ad3b403f32cb','12');----
INSERT INTO word VALUES ('a8982c0e204a4a23a3f0e4412601dbac','insignificant','[ˌɪnsɪgˈnɪfɪkənt]','http://res.iciba.com/resource/amp3/oxford/0/a9/0e/a90ef0a2383edba8ebc4e6f820593fb9.mp3','adj. 无意义的；不重要的','','');----
INSERT INTO classwords VALUES ('260c6bb406bc40d1b51c7467cd9b0ab1','a8982c0e204a4a23a3f0e4412601dbac','12');----
INSERT INTO word VALUES ('f76767bde5534b7d94e476acecbb89a8','ponder','[ˈpɔndə]','http://res.iciba.com/resource/amp3/oxford/0/e6/a9/e6a98b177e9604aca993e650bc7680a6.mp3','vi. 沉思','','');----
INSERT INTO classwords VALUES ('cd1f3b1e65ee49128525d0ed15e0d222','f76767bde5534b7d94e476acecbb89a8','12');----
INSERT INTO word VALUES ('2045cdbca9684a7da4570cc57856b858','certainty','[ˈsə:tnti]','http://res.iciba.com/resource/amp3/0/0/29/fb/29fb887939cb2776fd2eee2061c6fa57.mp3','n. 确定；必然性；必然的事','','');----
INSERT INTO classwords VALUES ('806eb19060c9448bb84294bfbe5450e8','2045cdbca9684a7da4570cc57856b858','12');----
INSERT INTO word VALUES ('be854bb000c1418f8f352c1e76c36fc8','panther','[ˈpænθə]','http://res.iciba.com/resource/amp3/oxford/0/0e/4b/0e4bd948e2d762d0acca83c58e3e44b0.mp3','n. 豹，黑豹；美洲豹','','');----
INSERT INTO classwords VALUES ('c3b2993d423944e8a0552d9a7327a9b6','be854bb000c1418f8f352c1e76c36fc8','12');----
INSERT INTO word VALUES ('8dc2ca2e499a4652850debb61b74592c','ward','[wɔ:d]','http://res.iciba.com/resource/amp3/0/0/49/dd/49ddafa93b4052e15e041a43d4343fda.mp3','n. 病房，病室；选区；被监护人','','');----
INSERT INTO classwords VALUES ('cc14bb6429d84cdf8c35b9cdb48ef4a2','8dc2ca2e499a4652850debb61b74592c','12');----
INSERT INTO word VALUES ('3231ea89d17f43aca8d755cbcd402d86','productive','[prəˈdʌktiv]','http://res.iciba.com/resource/amp3/oxford/0/66/c1/66c10e8f439b2c6adf2eeb67b3c0a8ea.mp3','adj. 多产的；富有成效的；生产…的','','');----
INSERT INTO classwords VALUES ('49021394cc3f4d35a3e89cef38bf0bd0','3231ea89d17f43aca8d755cbcd402d86','12');----
INSERT INTO word VALUES ('a6895bdde61b42e7a9568cd0fbd5958c','vicious','[ˈviʃəs]','http://res.iciba.com/resource/amp3/oxford/0/30/bc/30bc75db3adfbc3acb0823125c158b2d.mp3','adj. 残暴的，凶残的；恶意的','','');----
INSERT INTO classwords VALUES ('f06b616318b442f5a78a2486a2bc2e73','a6895bdde61b42e7a9568cd0fbd5958c','12');----
INSERT INTO word VALUES ('905fa1fbf6614a89a3727d961dd42a6e','reactor','[ri:ˈæktə]','http://res.iciba.com/resource/amp3/oxford/0/2f/f7/2ff75ab4413b1d08ce9021940392ca7f.mp3','n. 反应器；反应堆','','');----
INSERT INTO classwords VALUES ('61448a4dc4ae4b9bbacaf04b8c4403bf','905fa1fbf6614a89a3727d961dd42a6e','12');----
INSERT INTO word VALUES ('1d1ad069080c4c81abcd81e2023b13d4','immigrate','[ˈɪmɪˌgreɪt]','http://res.iciba.com/resource/amp3/oxford/0/4e/da/4edac5346fbc4ac5030b3edfbaf2c708.mp3','vt. （从外国）移居','','');----
INSERT INTO classwords VALUES ('69f386f28ec145fa88c3e097edebfc2c','1d1ad069080c4c81abcd81e2023b13d4','12');----
INSERT INTO word VALUES ('fb752355e8b148f8bf9bd21a17f28489','ignorance','[ˈiɡnərəns]','http://res.iciba.com/resource/amp3/oxford/0/f9/c5/f9c5453fed34cf9e7390416f49508d27.mp3','n. 无知，愚昧','','');----
INSERT INTO classwords VALUES ('e2b402d206674b229706e09bde82aadc','fb752355e8b148f8bf9bd21a17f28489','12');----
INSERT INTO word VALUES ('543f7b196d0c4a1e9a18c1b23d6e0723','metropolitan','[ˌmetrəˈpɔlitən]','http://res.iciba.com/resource/amp3/oxford/0/9b/d7/9bd76fc74f278f7c4f5649de26df034f.mp3','n. 大主教','','');----
INSERT INTO classwords VALUES ('dd792fa08f1f4de4ad04a10890bc0575','543f7b196d0c4a1e9a18c1b23d6e0723','12');----
INSERT INTO word VALUES ('e599e715b2784859938c106b909453e1','inferior','[inˈfiəriə]','http://res.iciba.com/resource/amp3/oxford/0/db/dc/dbdcab4bbd010bae9d1fba459322d569.mp3','adj. （质量等）差的；（地位、能力等...','','');----
INSERT INTO classwords VALUES ('dc3c1b19aff847c890566faf3d41ce75','e599e715b2784859938c106b909453e1','12');----
INSERT INTO word VALUES ('470f45bca7cc42969b6b1a2a29be1e4f','Mars','[mɑ:z]','http://res.iciba.com/resource/amp3/1/0/67/1f/671f028142280b556a85ffdd90e0a43d.mp3','n. 火星；战神','','');----
INSERT INTO classwords VALUES ('32cf0c77d96c41a9bf0342fb195b0980','470f45bca7cc42969b6b1a2a29be1e4f','12');----
INSERT INTO word VALUES ('55796ca295fd41f3befc7dcbbbc98a9e','sofa','[ˈsəufə]','http://res.iciba.com/resource/amp3/0/0/7a/2c/7a2cc8b443e7cf567a8635724b08185a.mp3','n. 沙发','','');----
INSERT INTO classwords VALUES ('ab8af9fa2396498d9cb39c3d00f73672','55796ca295fd41f3befc7dcbbbc98a9e','12');----
INSERT INTO word VALUES ('c6992e09cb814d4babac139573cf43e7','frustrate','[ˈfrʌstreit]','http://res.iciba.com/resource/amp3/0/0/93/05/93054e368446de49a00c7715610d7b31.mp3','vt. 挫败；使沮丧','','');----
INSERT INTO classwords VALUES ('2efd19d5a37041648b0a1bbb778af604','c6992e09cb814d4babac139573cf43e7','12');----
INSERT INTO word VALUES ('2a93521a96714932af71bb1391ca43a1','beam','[bi:m]','http://res.iciba.com/resource/amp3/oxford/0/08/79/0879d46a3320e549939b5c5b61969fa8.mp3','vi. 眉开眼笑；照耀；照射','','');----
INSERT INTO classwords VALUES ('bc7d333916f444e6afd2a20f14b1a388','2a93521a96714932af71bb1391ca43a1','12');----
INSERT INTO word VALUES ('588cd9b818f345ad9b501c847847b8a9','fabrication','[ˌfæbrɪˈkeɪʃən]','http://res.iciba.com/resource/amp3/0/0/3d/4e/3d4e3103ddc7b9de516d68b37ad39f1d.mp3','n. 制造；构造物；捏造','','');----
INSERT INTO classwords VALUES ('a3e2fdbea9e947f5b8bc61d77ce5e319','588cd9b818f345ad9b501c847847b8a9','12');----
INSERT INTO word VALUES ('0eeb0f78933b4350b87f4eca861105c0','lodging','[ˈlɔdʒɪŋ]','http://res.iciba.com/resource/amp3/oxford/0/79/54/79546e48a81132a4d837f47e8d531ec6.mp3','n. 寄宿，住宿；租住的房间','','');----
INSERT INTO classwords VALUES ('b2b42d3305044d76aff572d66a087293','0eeb0f78933b4350b87f4eca861105c0','12');----
INSERT INTO word VALUES ('57ec7cf5be4946009fd70e23fdd218ea','tyranny','[ˈtirəni]','http://res.iciba.com/resource/amp3/oxford/0/6b/a1/6ba17abab5b4b23505a0aa5d3d534d97.mp3','n. 暴政；专横','','');----
INSERT INTO classwords VALUES ('4d1d786b559344618b1c225e4617f174','57ec7cf5be4946009fd70e23fdd218ea','12');----
INSERT INTO word VALUES ('17b25966747c4138b2a6b4353e1a7f46','saturation','[ˌsætʃəˈreɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/e0/8d/e08d7b12cf85993a23467b2ae8f92c73.mp3','n. 饱和（状态）；浸透','','');----
INSERT INTO classwords VALUES ('7897c3c003af45afbbbed30c705cafc6','17b25966747c4138b2a6b4353e1a7f46','12');----
INSERT INTO word VALUES ('86c388020a0f4825a5135f944050be49','tease','[ti:z]','http://res.iciba.com/resource/amp3/oxford/0/b0/52/b052c4e9c4f8b5bbdb226ae5535b74b5.mp3','vt. 嘲笑，取笑；逗弄','','');----
INSERT INTO classwords VALUES ('e93396f492774d2180f0e16a7f459cce','86c388020a0f4825a5135f944050be49','12');----
INSERT INTO word VALUES ('836581a18da24563b2bcecb3b3a6259f','Catholic','[ˈkæθəlɪk]','http://res.iciba.com/resource/amp3/oxford/0/01/1c/011c99db3b51de8b7e315d13e72e5fd2.mp3','n. 天主教徒','','');----
INSERT INTO classwords VALUES ('f53517d19fd14a71966b09fb017e6241','836581a18da24563b2bcecb3b3a6259f','12');----
INSERT INTO word VALUES ('857f102925384322acff11f407be6ec5','mechanism','[ˈmekənizəm]','http://res.iciba.com/resource/amp3/oxford/0/76/b9/76b97243d805576f7df1a1a4ac7477b8.mp3','n. 机械装置；方法，途径；行为方式','','');----
INSERT INTO classwords VALUES ('739ec551ec1b4e0d91fd52e00f381a08','857f102925384322acff11f407be6ec5','12');----
INSERT INTO word VALUES ('485fd15fbba14b7bb2076734c65943c1','concern','[kənˈsə:n]','http://res.iciba.com/resource/amp3/oxford/0/0d/fc/0dfc18b92ff80584d32de7bdb4da9628.mp3','n. 关心；忧虑；关心的事','','');----
INSERT INTO classwords VALUES ('9959d29185ae4a0faed44a7bec34bb7a','485fd15fbba14b7bb2076734c65943c1','12');----
INSERT INTO word VALUES ('32684646f5714910b100b227872a95d1','bourgeois','','http://res.iciba.com/resource/amp3/oxford/0/80/72/8072d7a060f7f49066a46e70d9ac5493.mp3','adj. 资产阶级的；追求名利的','','');----
INSERT INTO classwords VALUES ('4af4bde53e9c4e189118b3d0d8317f29','32684646f5714910b100b227872a95d1','12');----
INSERT INTO word VALUES ('4ebf1c3f7cf04413a2a459431f2ce25e','overestimate','[ˌəʊvəˈestəˌmeɪt]','http://res.iciba.com/resource/amp3/oxford/0/51/3a/513a5d3d6cac76e8c631f40fddbe288b.mp3','vt. 过高估计；过高评价','','');----
INSERT INTO classwords VALUES ('9d25886fc13b4c0da24c4b7ddc4e516d','4ebf1c3f7cf04413a2a459431f2ce25e','12');----
INSERT INTO word VALUES ('42c1470eac4246b1bb61fb758fd5ed02','radial','[ˈreɪdi:əl]','http://res.iciba.com/resource/amp3/oxford/0/e9/01/e9015cf4e6a7db0c90bafb92fb1208ca.mp3','adj. 幅射状的；放射状的','','');----
INSERT INTO classwords VALUES ('178ed58c17724560ad813bec346eb1dd','42c1470eac4246b1bb61fb758fd5ed02','12');----
INSERT INTO word VALUES ('7e7f7cf3f7854b1386044bf0e534e244','radiant','[ˈreidiənt]','http://res.iciba.com/resource/amp3/oxford/0/f6/f0/f6f08ce2ed3f8306b55941ff8399b60a.mp3','adj. 光芒四射的；容光焕发的；辐射的','','');----
INSERT INTO classwords VALUES ('755adb6f23ac4d9bb8a6a61582819cec','7e7f7cf3f7854b1386044bf0e534e244','12');----
INSERT INTO word VALUES ('1c1eeb4e76ff4ff49e0f6af0be3fc44a','establish','[isˈtæbliʃ]','http://res.iciba.com/resource/amp3/oxford/0/09/9f/099f909c8d6510f5d2fe3023b1ba9ff0.mp3','vt. 使…被认可；建立；证实，查实','','');----
INSERT INTO classwords VALUES ('244d6e0b26f9454f82ee47a3f050aa1c','1c1eeb4e76ff4ff49e0f6af0be3fc44a','12');----
INSERT INTO word VALUES ('e31aff0ca2814f7c9babbe2a9eb867e3','expedition','[ˌekspiˈdiʃən]','http://res.iciba.com/resource/amp3/oxford/0/9e/47/9e4716329c63a4369161611fc2795d34.mp3','n. 探险；探险队；远足','','');----
INSERT INTO classwords VALUES ('812dec8ed55c4094b61d91239303d9ef','e31aff0ca2814f7c9babbe2a9eb867e3','12');----
INSERT INTO word VALUES ('d25cf023a04845faba7272e2549ea444','patriotic','[ˌpætriˈɔtik]','http://res.iciba.com/resource/amp3/1/0/d1/29/d129421eb4986b2cc9b4d3a8f04c71a5.mp3','adj. 爱国的','','');----
INSERT INTO classwords VALUES ('ec0622d7a9f04bfc9e8562f3a47e169d','d25cf023a04845faba7272e2549ea444','12');----
INSERT INTO word VALUES ('4053fe7cb2bb4f4fa0d0da608221e9cd','manifest','[ˈmænifest]','http://res.iciba.com/resource/amp3/oxford/0/19/4d/194da820d2ca1c9d0095a22878629bdc.mp3','adj. 明显的，显而易见的','','');----
INSERT INTO classwords VALUES ('097857a3a0b24b01be61c1dc0de3cc63','4053fe7cb2bb4f4fa0d0da608221e9cd','12');----
INSERT INTO word VALUES ('fcc5cb8eb4fc44d49224a265192b3b74','obedient','[əˈbi:djənt]','http://res.iciba.com/resource/amp3/oxford/0/cb/26/cb260dfa39052a8161e0a793b318f9d3.mp3','adj. 服从的，顺从的；温驯的','','');----
INSERT INTO classwords VALUES ('413f71d35ce848edb90fcab0729b2654','fcc5cb8eb4fc44d49224a265192b3b74','12');----
INSERT INTO word VALUES ('c9d5396a92e64dee8260ce1014e22996','patron','[ˈpeitrən]','http://res.iciba.com/resource/amp3/oxford/0/9e/75/9e75c0816f0001cbfc6cf70efbb87209.mp3','n. 代言人；赞助人；主顾','','');----
INSERT INTO classwords VALUES ('63693651c17f4a998e7661ba1cef9a69','c9d5396a92e64dee8260ce1014e22996','12');----
INSERT INTO word VALUES ('5d405009165c4e9f84e2776cba774d3c','intonation','[ˌɪntəˈneɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/d7/44/d7449dd863ccd3bbe9c526e0865cfaae.mp3','n. 语调，声调','','');----
INSERT INTO classwords VALUES ('9b7d252c94e34b3b927b1e97ca5d53f9','5d405009165c4e9f84e2776cba774d3c','12');----
INSERT INTO word VALUES ('e3aa394228d44ec08b4e490681c76112','characterize','[ˈkæriktəraiz]','http://res.iciba.com/resource/amp3/oxford/0/9b/74/9b745a3c3fdd899b77a11c8232c5f060.mp3','vt. 使具有特点；描述','','');----
INSERT INTO classwords VALUES ('e7bcb203d6d3454ebc358de70e89a3d5','e3aa394228d44ec08b4e490681c76112','12');----
INSERT INTO word VALUES ('2bf29b1a95214ecb96d6b6736630ac65','perfection','[pəˈfekʃən]','http://res.iciba.com/resource/amp3/oxford/0/fe/f4/fef46a8695afd885d1f51b75f34a32f2.mp3','n. 完美；完善','','');----
INSERT INTO classwords VALUES ('d7e57908a5824ffbab62b8a577c6772a','2bf29b1a95214ecb96d6b6736630ac65','12');----
INSERT INTO word VALUES ('1b35724dad774e51bebf37ee521b9fa8','leakage','[ˈli:kɪdʒ]','http://res.iciba.com/resource/amp3/oxford/0/54/2a/542ac110a045259a6b968a1b6561f51a.mp3','n. 漏，漏出；漏出物','','');----
INSERT INTO classwords VALUES ('e8a8bae88e2f49f5b644d7099e7d902d','1b35724dad774e51bebf37ee521b9fa8','12');----
INSERT INTO word VALUES ('f2de245739664e6e82755f0ebce7b756','opaque','[əuˈpeik]','http://res.iciba.com/resource/amp3/oxford/0/9f/70/9f702717752b59031ab8a6495f42999c.mp3','adj. 不透明的；费解的','','');----
INSERT INTO classwords VALUES ('dfaa563b73d846bc966cb043d8e1c982','f2de245739664e6e82755f0ebce7b756','12');----
INSERT INTO word VALUES ('c703bdd2bbd040288fdff6242e84a999','tolerant','[ˈtɔlərənt]','http://res.iciba.com/resource/amp3/oxford/0/58/0c/580cf74e0bb47cbc32a8a9821d6ac19c.mp3','adj. 容忍的；有耐受性的','','');----
INSERT INTO classwords VALUES ('8ae05cc870fa4f1ca28d3bf1e9b50472','c703bdd2bbd040288fdff6242e84a999','12');----
INSERT INTO word VALUES ('5ec7699b22b54d3f9ee5dd85e610dd35','hymn','[him]','http://res.iciba.com/resource/amp3/oxford/0/76/7b/767b093814fa9e84fa20a0c4ec980efa.mp3','n. 赞美诗，圣歌；歌颂','','');----
INSERT INTO classwords VALUES ('e823e81b7fdb4ec3899c898361432d2b','5ec7699b22b54d3f9ee5dd85e610dd35','12');----
INSERT INTO word VALUES ('fb481e0ffb6647d7bbdd23e17caa35ed','moor','[mʊə]','http://res.iciba.com/resource/amp3/0/0/99/55/99557f46ccef290d9d93c546f64fb7d6.mp3','vt. 使停泊；系泊','','');----
INSERT INTO classwords VALUES ('f04c0d1f51ca415ca11396e8feda4a8e','fb481e0ffb6647d7bbdd23e17caa35ed','12');----
INSERT INTO word VALUES ('fd494da4500b4436a0b834dc6d1b17b7','consumption','[kənˈsʌmpʃən]','http://res.iciba.com/resource/amp3/oxford/0/e6/2c/e62c9da0e61af20017b1f0eaa9828382.mp3','n. 消费（量）；吃，喝，饮用；消费','','');----
INSERT INTO classwords VALUES ('f70ca0b9981d49deb18244f8aa0b23c3','fd494da4500b4436a0b834dc6d1b17b7','12');----
INSERT INTO word VALUES ('6109c49d422a43e5b0a40ba35680c4b4','ultrasonic','[ˌʌltrəˈsɔnɪk]','http://res.iciba.com/resource/amp3/oxford/0/c7/1b/c71b03f305b2338d36a8082130a1a8cf.mp3','n. 超声波','','');----
INSERT INTO classwords VALUES ('7affd77259d44a1f897a2a860af0285b','6109c49d422a43e5b0a40ba35680c4b4','12');----
INSERT INTO word VALUES ('e1351c02b5f247b3a5f83e8c929ae0d3','fluctuation','[ˌflʌktjʊˈeɪʃɵn]','http://res.iciba.com/resource/amp3/0/0/9b/96/9b9673f2a72165148e1f1d9ba2e3e4db.mp3','n. 波动，涨落，起伏','','');----
INSERT INTO classwords VALUES ('5a8cb7e1db98421b811fa7a22d16ad36','e1351c02b5f247b3a5f83e8c929ae0d3','12');----
INSERT INTO word VALUES ('1fea3c86009040a884601b40cefa7d4f','symmetrical','[sɪˈmetrɪkəl]','http://res.iciba.com/resource/amp3/oxford/0/00/92/00924390e9c9eb396900658daeaca1a1.mp3','adj. 对称的，匀称的','','');----
INSERT INTO classwords VALUES ('a491114fc2ad43d6b3654e8972d2c2ec','1fea3c86009040a884601b40cefa7d4f','12');----
INSERT INTO word VALUES ('de1dbc49e4a34a6188710fc6f9db5ba3','mock','[mɔk]','http://res.iciba.com/resource/amp3/0/0/17/40/17404a596cbd0d1e6c7d23fcd845ab82.mp3','vt. 嘲弄，嘲笑','','');----
INSERT INTO classwords VALUES ('3447e1187d3e4da6897a9e429e88f932','de1dbc49e4a34a6188710fc6f9db5ba3','12');----
INSERT INTO word VALUES ('504cf3dbda094051952a70b020ed0416','flap','[flæp]','http://res.iciba.com/resource/amp3/oxford/0/69/1b/691b416de73042c4aaf1099fc5583ab6.mp3','v. （翅膀）拍打；摆动；挥动（手臂）','','');----
INSERT INTO classwords VALUES ('4ed68fa40eef48f5ac9324b29fedb074','504cf3dbda094051952a70b020ed0416','12');----
INSERT INTO word VALUES ('8a65626062014dcdad37a14f1011bcb5','probe','[prəub]','http://res.iciba.com/resource/amp3/0/0/8d/a8/8da843ff65205a61374b09b81ed0fa35.mp3','vt. 调查；打探；探查；搜寻','','');----
INSERT INTO classwords VALUES ('3a9d5e8629d94cb599cde50e266fc690','8a65626062014dcdad37a14f1011bcb5','12');----
INSERT INTO word VALUES ('bf752dc166af442794beba64351356cc','massacre','[ˈmæsəkə]','http://res.iciba.com/resource/amp3/oxford/0/82/66/82665731ee243c7eebc6b68890109b4c.mp3','n. 大屠杀，大残杀','','');----
INSERT INTO classwords VALUES ('60582a5c458c44dc871ecfa4cc3f48e5','bf752dc166af442794beba64351356cc','12');----
INSERT INTO word VALUES ('7c4966e3c71f4e2f9aa130127d3e9a61','signify','[ˈsiɡnifai]','http://res.iciba.com/resource/amp3/oxford/0/0b/be/0bbec9cb74054953e7f72b6626010bad.mp3','vt. 表示，意味着；表明','','');----
INSERT INTO classwords VALUES ('ab07185d82de4dd587a38af9fe3b87f4','7c4966e3c71f4e2f9aa130127d3e9a61','12');----
INSERT INTO word VALUES ('dad17a872e5d4e169d545b01a4058f17','handout','[ˈhændˌaʊt]','http://res.iciba.com/resource/amp3/oxford/0/d6/25/d62552d6eec191d3a5bec4f01c23bf59.mp3','n. 施舍物，救济品；传单；讲义','','');----
INSERT INTO classwords VALUES ('ddea7bf51d27475ba5a79944e65c72d2','dad17a872e5d4e169d545b01a4058f17','12');----
INSERT INTO word VALUES ('f1f261021c8f425b853354db8497e40a','misfortune','[misˈfɔ:tʃən]','http://res.iciba.com/resource/amp3/oxford/0/3f/09/3f097f20c4eb596839c97fb6581f7214.mp3','n. 不幸，灾祸，灾难','','');----
INSERT INTO classwords VALUES ('a6f4439ec83545c2adf56df59c8f5a63','f1f261021c8f425b853354db8497e40a','12');----
INSERT INTO word VALUES ('c54b1ae191884a79901b38c8b39dc2be','glue','[ɡlu:]','http://res.iciba.com/resource/amp3/oxford/0/42/1f/421f575b84b9604c873d333058ac481f.mp3','vt. 用胶水粘','','');----
INSERT INTO classwords VALUES ('318b4322052a41b6b54697a421fc8867','c54b1ae191884a79901b38c8b39dc2be','12');----
INSERT INTO word VALUES ('f1355639dd9d4dc4a4e1cb0d808595cc','terminology','[ˌtɜ:məˈnɔlədʒi:]','http://res.iciba.com/resource/amp3/oxford/0/d9/05/d90545e02111e3ca356a9c338263eeb8.mp3','n. 术语；专门用语','','');----
INSERT INTO classwords VALUES ('0b507b60ccc44b2ba282b4bc622228bc','f1355639dd9d4dc4a4e1cb0d808595cc','12');----
INSERT INTO word VALUES ('efc47c1c52b34dd189c113768e2b118d','boiler','[ˈbɔɪlə]','http://res.iciba.com/resource/amp3/oxford/0/bd/40/bd40dff639f350940f15ff596c598cba.mp3','n. 锅炉；热水器','','');----
INSERT INTO classwords VALUES ('a7f6668f12914853ae7309f83756edcb','efc47c1c52b34dd189c113768e2b118d','12');----
INSERT INTO word VALUES ('54901b39cd5647129d3f99cabb216159','occurrence','[əˈkʌrəns]','http://res.iciba.com/resource/amp3/oxford/0/14/50/1450cb5c261f0a1f6dcea19d0e5455d3.mp3','n. 事件；发生，出现','','');----
INSERT INTO classwords VALUES ('3104584d0d4a4939bd4e2fa1bc7a042e','54901b39cd5647129d3f99cabb216159','12');----
INSERT INTO word VALUES ('9c816450b42441c39b563060b4777390','theme','[θi:m]','http://res.iciba.com/resource/amp3/oxford/0/1c/19/1c19999976e84e60549465736658025d.mp3','n. 题目；主题；主旋律','','');----
INSERT INTO classwords VALUES ('b3eaa2701b73448391a4100bb3ccea2c','9c816450b42441c39b563060b4777390','12');----
INSERT INTO word VALUES ('8bb118d90ce247459f4a7c4af94b83cf','turtle','[ˈtə:tl]','http://res.iciba.com/resource/amp3/0/0/d4/70/d4705b9f42c96eeb0b9fb53266013516.mp3','n. 海龟','','');----
INSERT INTO classwords VALUES ('df060be09b3a4b68969fbcd30d15e23e','8bb118d90ce247459f4a7c4af94b83cf','12');----
INSERT INTO word VALUES ('96d5f110421343ec9cbee069dab4afe2','cruise','[kru:z]','http://res.iciba.com/resource/amp3/oxford/0/be/3e/be3efa9bc9a4225d0f120bfa8e3ca850.mp3','vt. 乘船游览，航游','','');----
INSERT INTO classwords VALUES ('3a15728515734aa484575e6e8f6b34a6','96d5f110421343ec9cbee069dab4afe2','12');----
INSERT INTO word VALUES ('7fd02a21ca8e41e69cf112cdf0a4a078','transplant','[trænsˈplɑ:nt]','http://res.iciba.com/resource/amp3/oxford/0/54/9e/549ed37af8964bb9500852cb88e4ad74.mp3','vt. 移植（器官）；使迁移','','');----
INSERT INTO classwords VALUES ('c20dfa66c6e7412abde7116bd1c91075','7fd02a21ca8e41e69cf112cdf0a4a078','12');----
INSERT INTO word VALUES ('5e824337d1c747a4b289b3c1b1cade98','untie','[ʌnˈtaɪ]','http://res.iciba.com/resource/amp3/oxford/0/68/90/6890cb3f515f785006861a2998e113fd.mp3','vt. 解开，松开','','');----
INSERT INTO classwords VALUES ('bd0553f6da67424d97e5636b557e2426','5e824337d1c747a4b289b3c1b1cade98','12');----
INSERT INTO word VALUES ('e373d2c84ac74cfa963c75df15fda141','compliment','[ˈkɔmplimənt]','http://res.iciba.com/resource/amp3/oxford/0/3d/a3/3da3db397724ba38c7da5626972d35f1.mp3','vt. 赞美，恭维','','');----
INSERT INTO classwords VALUES ('046e55b2590941878b939ca681fedfd4','e373d2c84ac74cfa963c75df15fda141','12');----
INSERT INTO word VALUES ('c1a79f44179f49b5a74019b424747901','compact','[kəmˈpækt]','http://res.iciba.com/resource/amp3/0/0/7c/f7/7cf74ca49c304df8150205fc915cd465.mp3','vt. 把…压实（或压紧）','','');----
INSERT INTO classwords VALUES ('1625197647f44cf5af7a457da64ce56b','c1a79f44179f49b5a74019b424747901','12');----
INSERT INTO word VALUES ('97c7430086094bcabe3bdf2dd6593560','decree','[diˈkri:]','http://res.iciba.com/resource/amp3/oxford/0/3b/79/3b79604178c0ff6ec385a26fc956ffe5.mp3','n. 法令，政令；判决','','');----
INSERT INTO classwords VALUES ('f945d6f68cb742e38e3d9569c4b60d7a','97c7430086094bcabe3bdf2dd6593560','12');----
INSERT INTO word VALUES ('623c865535e64b629ca311b8200b7766','hover','[ˈhɔvə]','http://res.iciba.com/resource/amp3/0/0/e0/54/e0542f579df8e8138ade69f8f5310bf2.mp3','vi. 徘徊；犹豫不决；悬浮','','');----
INSERT INTO classwords VALUES ('f05f635492b04f18b712fb9f27d918af','623c865535e64b629ca311b8200b7766','12');----
INSERT INTO word VALUES ('cc5d40fd4f2e48fd9f4bb594c09b2a7a','flux','[flʌks]','http://res.iciba.com/resource/amp3/oxford/0/17/0c/170ca6a5cfeb4d6487eafdb99f6147a2.mp3','n. 流体；变动，波动','','');----
INSERT INTO classwords VALUES ('83324b6400f545f0982e58df8e566db0','cc5d40fd4f2e48fd9f4bb594c09b2a7a','12');----
INSERT INTO word VALUES ('e76dd0ed46ea4eb686e43d089e873ce4','bewilder','[biˈwildə]','http://res.iciba.com/resource/amp3/oxford/0/a6/38/a638f5951c9eae3c46cf423dab146898.mp3','vt. 使困惑；使糊涂；使不知所措','','');----
INSERT INTO classwords VALUES ('f24068daa87946758a853c3f93b06eb7','e76dd0ed46ea4eb686e43d089e873ce4','12');----
INSERT INTO word VALUES ('ed5b3d241d5042568d6b03b7d8b2ac07','vine','[vaɪn]','http://res.iciba.com/resource/amp3/oxford/0/d6/4d/d64de6f50b1650f7c562a1bb7f9bce41.mp3','n. 蔓，藤；藤本植物；（尤指）葡萄藤','','');----
INSERT INTO classwords VALUES ('92149b894a394cb1bb1a823e0cb383e6','ed5b3d241d5042568d6b03b7d8b2ac07','12');----
INSERT INTO word VALUES ('7e80d88a1c61444bac891a95ac59e4cc','prevalent','[ˈprevələnt]','http://res.iciba.com/resource/amp3/oxford/0/5d/cf/5dcf8bc78b462c2e48af9c5f2607b109.mp3','adj. 流行的；盛行的；普遍的','','');----
INSERT INTO classwords VALUES ('193cb64999ee4769baa61ba9b1ba1c41','7e80d88a1c61444bac891a95ac59e4cc','12');----
INSERT INTO word VALUES ('8d256ed8aa2842ddbb5400d1a36211b4','politics','[ˈpɔlitiks]','http://res.iciba.com/resource/amp3/oxford/0/26/52/2652beaa11bb1ee636bb6b1dbb080cb1.mp3','n. 政治；策略；政治见解；政治学','','');----
INSERT INTO classwords VALUES ('178868eec6ef45ecadd97c30f82b52e8','8d256ed8aa2842ddbb5400d1a36211b4','12');----
INSERT INTO word VALUES ('59b03daf36df492895049b629f726a7e','seaport','[ˈsi:ˌpɔ:t]','http://res.iciba.com/resource/amp3/oxford/0/9e/15/9e15de1e463a838660c36f517dafab99.mp3','n. 海港；港口城市','','');----
INSERT INTO classwords VALUES ('43091cfd2f324c36b7de969e6bcf3277','59b03daf36df492895049b629f726a7e','12');----
INSERT INTO word VALUES ('3aaa008443b24a89a78bdab74247beb6','perplex','[pəˈpleks]','http://res.iciba.com/resource/amp3/oxford/0/c0/c4/c0c426c3682d450288b28689a8e5b3e2.mp3','vt. 迷惑，使困惑','','');----
INSERT INTO classwords VALUES ('1f45fe65da9a456eb2c61cf155f8ea93','3aaa008443b24a89a78bdab74247beb6','12');----
INSERT INTO word VALUES ('06c596987be04b1f8f1c33a2be7114bf','comprehend','[ˌkɔmpriˈhend]','http://res.iciba.com/resource/amp3/oxford/0/01/fa/01fa4016f64fb7769772e1e1cb916b38.mp3','vt. 理解，领悟','','');----
INSERT INTO classwords VALUES ('d640021e6231423d8b61b0947d9b2482','06c596987be04b1f8f1c33a2be7114bf','12');----
INSERT INTO word VALUES ('8fc851e7f30b4efab59abd1c363f0f56','ranch','[rɑ:ntʃ]','http://res.iciba.com/resource/amp3/0/0/67/2d/672da968bd283438cb0ffd1bba513780.mp3','n. 大牧场，大农场','','');----
INSERT INTO classwords VALUES ('117176154e2c427888436147c51e223c','8fc851e7f30b4efab59abd1c363f0f56','12');----
INSERT INTO word VALUES ('4fb81f53368d4489b4fbf2d5f9d61634','rational','[ˈræʃənl]','http://res.iciba.com/resource/amp3/oxford/0/2a/80/2a80e2c3dcb1adb503f3877482f98eec.mp3','adj. 理性的；合理的；理智的','','');----
INSERT INTO classwords VALUES ('07eb3d32cf1041bc8b47ad88b55e7eaf','4fb81f53368d4489b4fbf2d5f9d61634','12');----
INSERT INTO word VALUES ('4520edb6fb1c483ebb749bdf3c0f9248','recommendatio...','[ˌrekəmenˈdeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/05/b9/05b97e287077e896c3b3cee7a2da0855.mp3','n. 推荐，介绍；建议','','');----
INSERT INTO classwords VALUES ('14340aaf74494b65a5c6c6cb1b8e64c7','4520edb6fb1c483ebb749bdf3c0f9248','12');----
INSERT INTO word VALUES ('d1d3f7270205473397cc87142b91e336','peripheral','[pəˈrɪfərəl]','http://res.iciba.com/resource/amp3/oxford/0/07/98/0798a66562f0b5902aab398222a61728.mp3','adj. 周围的；次要的','','');----
INSERT INTO classwords VALUES ('0353eced4a18422594a6fcd202a8274d','d1d3f7270205473397cc87142b91e336','12');----
INSERT INTO word VALUES ('e5fc919bad874101bea89b282dfce598','predominant','[priˈdɔminənt]','http://res.iciba.com/resource/amp3/oxford/0/40/9c/409ca2ca939eeaaf8ab53a040a9a0982.mp3','adj. 占优势的；占主导地位的','','');----
INSERT INTO classwords VALUES ('7abcff3f30414b818083642fc55df144','e5fc919bad874101bea89b282dfce598','12');----
INSERT INTO word VALUES ('2ff3104bcb9548e3a31465992bcdf8e5','executive','[iɡˈzekjutiv]','http://res.iciba.com/resource/amp3/oxford/0/d3/7f/d37fea0756d884358c2a690c13761baf.mp3','n. 总经理，主管；执行委员会；行政部门','','');----
INSERT INTO classwords VALUES ('d6f48a33766a4f739e1f04b4b9a2f62c','2ff3104bcb9548e3a31465992bcdf8e5','12');----
INSERT INTO word VALUES ('4160b6e330564f579c886f1edd5c7321','deposition','[ˌdepəˈzɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/d0/26/d026f49a874230dd5ef945923ba49098.mp3','n. 罢免；废黜；沉淀；书面证词','','');----
INSERT INTO classwords VALUES ('698738f18e9245ca90cb3fc3d147b80b','4160b6e330564f579c886f1edd5c7321','12');----
INSERT INTO word VALUES ('909d0c9c13864add8232d440f2ea0f1a','diagnose','[ˈdaiəɡnəuz]','http://res.iciba.com/resource/amp3/0/0/1f/e8/1fe85e86c49022a9e72c2b95498364f5.mp3','vt. 诊断；判断','','');----
INSERT INTO classwords VALUES ('5e53974a6dbc43d1966d5a25ef34ebe2','909d0c9c13864add8232d440f2ea0f1a','12');----
INSERT INTO word VALUES ('1a3c8593594442619f5711cdc6226724','photography','[fəˈtɔgrəfi:]','http://res.iciba.com/resource/amp3/oxford/0/20/a8/20a8227bd77848c7bfb7a1be57f7aafd.mp3','n. 摄影','','');----
INSERT INTO classwords VALUES ('97b3097f1bb448e7b2968dad669abf7a','1a3c8593594442619f5711cdc6226724','12');----
INSERT INTO word VALUES ('4f70d1c916b64772afc6ca6dc85033b1','errand','[ˈerənd]','http://res.iciba.com/resource/amp3/oxford/0/e1/45/e145101798ace35448fa10af80b01239.mp3','n. 差使；差事','','');----
INSERT INTO classwords VALUES ('78b821aaab2b4c84baada8cbfd713d24','4f70d1c916b64772afc6ca6dc85033b1','12');----
INSERT INTO word VALUES ('09fc0a03678f4b2aa5985e037317f7cc','tensile','[ˈtensəl]','http://res.iciba.com/resource/amp3/0/0/86/d0/86d07522a8091f7ac361afa076c72292.mp3','adj. 张力的；能伸长的','','');----
INSERT INTO classwords VALUES ('78fd7e685bc548738d50d0c7ee78c09b','09fc0a03678f4b2aa5985e037317f7cc','12');----
INSERT INTO word VALUES ('df71d847531d49d6b1c857f2002e288a','battle','[ˈbætl]','http://res.iciba.com/resource/amp3/oxford/0/c5/08/c508a83613635b0e92f60c157dd8d65e.mp3','vt.&vi. 与…作战；奋战','','');----
INSERT INTO classwords VALUES ('d9b561895cbe4d90913fcbc3dd1c7234','df71d847531d49d6b1c857f2002e288a','12');----
INSERT INTO word VALUES ('676bf699c79547dba106bd6adf535f83','priority','[praiˈɔriti]','http://res.iciba.com/resource/amp3/oxford/0/b1/62/b1625efcce4f0705620fbc08cca53a0e.mp3','n. 优先事项；最重要的事；当务之急','','');----
INSERT INTO classwords VALUES ('b5a4c19bdbe342e6a7c7a12a87779d65','676bf699c79547dba106bd6adf535f83','12');----
INSERT INTO word VALUES ('87e692446d8e4be0ac804a536e0b8b2c','enlighten','[inˈlaitən]','http://res.iciba.com/resource/amp3/oxford/0/19/6a/196aceb25d655fbf0d8c80aa379c6e61.mp3','vt. 启发；开导；教化','','');----
INSERT INTO classwords VALUES ('d5c6c9d753304ffebe609b42c7e8a400','87e692446d8e4be0ac804a536e0b8b2c','12');----
INSERT INTO word VALUES ('258cbcc0ffb647ada3cef0041b36ec6b','liability','[ˌlaiəˈbiliti]','http://res.iciba.com/resource/amp3/oxford/0/20/4a/204ae00f384709d3e9db5d47db4111c6.mp3','n. 责任；累赘；债务','','');----
INSERT INTO classwords VALUES ('0af086cb50e543108c0015bddcb1ca67','258cbcc0ffb647ada3cef0041b36ec6b','12');----
INSERT INTO word VALUES ('8044340ee53d4cf28d45745c29a6f83c','petition','[piˈtiʃən]','http://res.iciba.com/resource/amp3/oxford/0/7b/e4/7be40622a6c3ec09d64fb2246a20b55e.mp3','vt. 向…请愿','','');----
INSERT INTO classwords VALUES ('fa15aded2027475e96950e6b15032831','8044340ee53d4cf28d45745c29a6f83c','12');----
INSERT INTO word VALUES ('1ea9abc2a6c543659ee6dcb17b80659b','currency','[ˈkʌrənsi]','http://res.iciba.com/resource/amp3/oxford/0/b0/61/b061ef005c0fd95e823dfcc67adbcd46.mp3','n. 货币；通用','','');----
INSERT INTO classwords VALUES ('8b835b166e4c48a39a498cf46cb44183','1ea9abc2a6c543659ee6dcb17b80659b','12');----
INSERT INTO word VALUES ('0b7e830777d3446e875c6d912010b47b','overload','[ˌəʊvəˈləʊd]','http://res.iciba.com/resource/amp3/0/0/1c/f9/1cf9f8be06cdce86bfde06213124c08b.mp3','vt. 使超载；使负担过重；超过负荷','','');----
INSERT INTO classwords VALUES ('f114fbf8b01440fb991f05dfdaa237ae','0b7e830777d3446e875c6d912010b47b','12');----
INSERT INTO word VALUES ('01def3fdd7cf4f5a9dc2a1713deb2a2e','tape','[teip]','http://res.iciba.com/resource/amp3/oxford/0/bf/64/bf64e740863d7b877e4e73f56c2964bb.mp3','vt. 录制；粘贴','','');----
INSERT INTO classwords VALUES ('3740813a8c434d659d01aa1c2c9b97be','01def3fdd7cf4f5a9dc2a1713deb2a2e','12');----
INSERT INTO word VALUES ('142f19ee551a496c9e8e1800d044974a','crisis','[ˈkraisis]','http://res.iciba.com/resource/amp3/oxford/0/34/fa/34fac6fd3155fb9c70e9a9f6dc98ecc9.mp3','n. 危机；危急关头','','');----
INSERT INTO classwords VALUES ('d47434c24a2a4245b93e2357a7751a79','142f19ee551a496c9e8e1800d044974a','12');----
INSERT INTO word VALUES ('718cdfa957b74a7299c293cd5dfecf46','torpedo','[tɔ:ˈpi:dəʊ]','http://res.iciba.com/resource/amp3/0/0/22/3e/223e134949f04ee0c9f88519bb29f855.mp3','vt. 用鱼雷袭击；故意破坏','','');----
INSERT INTO classwords VALUES ('b910aa4217fc4bdb91765d5fcf662d59','718cdfa957b74a7299c293cd5dfecf46','12');----
INSERT INTO word VALUES ('e7d13e3721f042bca07198b375f467b4','sensible','[ˈsensəbl]','http://res.iciba.com/resource/amp3/oxford/0/0e/7d/0e7d4576c20553790fc27cd2b52ee053.mp3','adj. 明智的，理智的；（衣服、鞋子）...','','');----
INSERT INTO classwords VALUES ('9f3f8b6df8a445ae8d6cf71f11f4be6d','e7d13e3721f042bca07198b375f467b4','12');----
INSERT INTO word VALUES ('811f9c899f264081956ed06bf7a428c7','utensil','[ju:ˈtensl]','http://res.iciba.com/resource/amp3/oxford/0/5a/18/5a18161b9b2f49093904f18a69776f4a.mp3','n. 器皿，用具','','');----
INSERT INTO classwords VALUES ('7ca29dc4cc214f51b02312917521e3e1','811f9c899f264081956ed06bf7a428c7','12');----
INSERT INTO word VALUES ('a41ced29271f4adc9902e65eb65f4a14','baron','[ˈbærən]','http://res.iciba.com/resource/amp3/oxford/0/01/fe/01fef2103f9f4af5375565a65fc98ea5.mp3','n. 男爵；大亨；巨头','','');----
INSERT INTO classwords VALUES ('198ab6dd26084da3aea89cabc8151bdf','a41ced29271f4adc9902e65eb65f4a14','12');----
INSERT INTO word VALUES ('76a7ce5c1c0e42db976790e87b319f3d','equilibrium','[ˌi:kwəˈlɪbri:əm]','http://res.iciba.com/resource/amp3/oxford/0/48/51/4851a3ab88c9b06759a315548a688dfc.mp3','n. 平衡，均衡；（内心的）平静，安宁','','');----
INSERT INTO classwords VALUES ('417557d1e6cb4543b57008254ba691dd','76a7ce5c1c0e42db976790e87b319f3d','12');----
INSERT INTO word VALUES ('09e4b11f50f74d1a91b986d530ddf5eb','royalty','[ˈrɔiəlti]','http://res.iciba.com/resource/amp3/oxford/0/20/b6/20b6a6893fa29201e591b8721c0e2640.mp3','n. 王室，皇族；版税；使用费','','');----
INSERT INTO classwords VALUES ('3e557c19b50b4b7ca2bb626305f0f2a8','09e4b11f50f74d1a91b986d530ddf5eb','12');----
INSERT INTO word VALUES ('03ca5b256b6e4f4498b5dc858697d6ce','puff','[pʌf]','http://res.iciba.com/resource/amp3/oxford/0/1d/ab/1dabd3ac101729271066580d250ec114.mp3','vt. 吹；喷','','');----
INSERT INTO classwords VALUES ('b552014b523d4640b431244c0e824b1d','03ca5b256b6e4f4498b5dc858697d6ce','12');----
INSERT INTO word VALUES ('36cea60f4abc4eda81bff8aa486cecd8','ware','[wɛə]','http://res.iciba.com/resource/amp3/0/0/f5/28/f52845d1c051920db6594e182ab64f12.mp3','n. 商品，货物；陶器','','');----
INSERT INTO classwords VALUES ('bd6d9c1577d240f685e849115ed2837b','36cea60f4abc4eda81bff8aa486cecd8','12');----
INSERT INTO word VALUES ('1f6a5f757b644d8f877bd850aeba97d3','doubtless','[ˈdautlis]','http://res.iciba.com/resource/amp3/oxford/0/9a/6f/9a6fe6f4b1cff85145214669a5d878c6.mp3','adv. 无疑地；很可能地','','');----
INSERT INTO classwords VALUES ('1da6a991946d40079b909816d93313c1','1f6a5f757b644d8f877bd850aeba97d3','12');----
INSERT INTO word VALUES ('ec55541e2e7f4265b3c20f4cb1bfcfdf','notify','[ˈnəutifai]','http://res.iciba.com/resource/amp3/oxford/0/a0/35/a035c1f13c5b164d0c8ff7b0e0289f1b.mp3','vt. 通知，告知','','');----
INSERT INTO classwords VALUES ('fea7f6f7cb1240cfb3144b04a6f815c0','ec55541e2e7f4265b3c20f4cb1bfcfdf','12');----
INSERT INTO word VALUES ('8f8a59fb2d174dfbb68bbb367ee4820b','version','[ˈvə:ʃən]','http://res.iciba.com/resource/amp3/0/0/2a/f7/2af72f100c356273d46284f6fd1dfc08.mp3','n. 版本；描述','','');----
INSERT INTO classwords VALUES ('e8f91945313a4979bc89933cfeb79c2c','8f8a59fb2d174dfbb68bbb367ee4820b','12');----
INSERT INTO word VALUES ('1e330881436e4316982c4c2ee98738fb','individual','[ˌɪndiˈvidjuəl]','http://res.iciba.com/resource/amp3/oxford/0/7e/42/7e428ddb8ebea180b9dfd1d61d562179.mp3','adj. 个别的；单独的；独特的','','');----
INSERT INTO classwords VALUES ('eb6e75bcc61e4fa2b389b7c0866d4e3b','1e330881436e4316982c4c2ee98738fb','12');----
INSERT INTO word VALUES ('1106724e86a5404d92097357c6f6b621','thereafter','[ðɛərˈɑ:ftə]','http://res.iciba.com/resource/amp3/oxford/0/bd/63/bd63930fbbf84224bf203fa4e418e4a5.mp3','adv. 此后，以后','','');----
INSERT INTO classwords VALUES ('d0d16ce4a30444278f4ec0d3aee84e12','1106724e86a5404d92097357c6f6b621','12');----
INSERT INTO word VALUES ('57ea6b494a9d4efe91204c1f45d0e44b','mortgage','[ˈmɔ:ɡidʒ]','http://res.iciba.com/resource/amp3/oxford/0/cc/a6/cca6091c5f1bc57ade29bb722ac43803.mp3','vt. 抵押','','');----
INSERT INTO classwords VALUES ('bf7636c4d6814280a1b32dc6a6d67d36','57ea6b494a9d4efe91204c1f45d0e44b','12');----
INSERT INTO word VALUES ('e9a03de1df764ae79e69ee05d0522dfb','optimism','[ˈɔptimizəm]','http://res.iciba.com/resource/amp3/oxford/0/93/c0/93c04f3e7488fc42d7f0efb79c9862b7.mp3','n. 乐观，乐观主义','','');----
INSERT INTO classwords VALUES ('4bfed978aaa14383b461c6a3383195dd','e9a03de1df764ae79e69ee05d0522dfb','12');----
INSERT INTO word VALUES ('9c96058caa814906ac7c8a992d224b31','aerial','[ˈɛəriəl]','http://res.iciba.com/resource/amp3/oxford/0/fb/9c/fb9c3f2b9511a836aec12e552f96548c.mp3','adj. 空气中的；航空的','','');----
INSERT INTO classwords VALUES ('920e6b46425c4ce19477dd8beda002de','9c96058caa814906ac7c8a992d224b31','12');----
INSERT INTO word VALUES ('dd28ee55c1d04685b0c54c139ed84ef8','prey','[prei]','http://res.iciba.com/resource/amp3/oxford/0/a7/a5/a7a5d61125301a33fb0acabe78091c88.mp3','n. 猎物；伤害的对象','','');----
INSERT INTO classwords VALUES ('bdc39a321a4b4c18bb1ca20ab6a03073','dd28ee55c1d04685b0c54c139ed84ef8','12');----
INSERT INTO word VALUES ('c6de984c3441403b8ec417d942e0731f','essence','[ˈesns]','http://res.iciba.com/resource/amp3/oxford/0/55/fd/55fdbb48b17df9f86485c95668e4a362.mp3','n. 本质，实质；精华；精油','','');----
INSERT INTO classwords VALUES ('b9ed3abad69c42a186873e5022e97fde','c6de984c3441403b8ec417d942e0731f','12');----
INSERT INTO word VALUES ('181a18cd5d134a728a773081787b27f4','ventilate','[ˈventileit]','http://res.iciba.com/resource/amp3/oxford/0/55/81/55812caca7bdbc280399f92159f9f1d3.mp3','vt. 使通风；发表（看法）','','');----
INSERT INTO classwords VALUES ('b0160693a49b44dab6472af3488f42f2','181a18cd5d134a728a773081787b27f4','12');----
INSERT INTO word VALUES ('278a66e106bf4c25bfeab6624c7fa2ef','squeeze','[skwi:z]','http://res.iciba.com/resource/amp3/oxford/0/03/a6/03a627ba7740b292a5c52a777fc1d16e.mp3','vt. 压榨；挤进；榨取','','');----
INSERT INTO classwords VALUES ('814f1b3e12c04883864425d8eaba5508','278a66e106bf4c25bfeab6624c7fa2ef','12');----
INSERT INTO word VALUES ('c007ed8c30354fc78940499fdf6f4ae0','locomotive','[ˈləukəˌməutiv]','http://res.iciba.com/resource/amp3/1/0/96/80/96803b4f01cd753dde35f11280dca163.mp3','n. 机车；火车头','','');----
INSERT INTO classwords VALUES ('d5aa8fab6cfc4d87bfecac1be23c9380','c007ed8c30354fc78940499fdf6f4ae0','12');----
INSERT INTO word VALUES ('65cd9bade5d7498aa4439675a485ebd4','snack','[snæk]','http://res.iciba.com/resource/amp3/oxford/0/96/8f/968f86dd7f7ba69c460d0faa06d8048d.mp3','n. 快餐；小吃','','');----
INSERT INTO classwords VALUES ('ebc5aedd574b4c6c82185d446e2f82d6','65cd9bade5d7498aa4439675a485ebd4','12');----
INSERT INTO word VALUES ('7eed5f1aa81548139b569e5a711aaec3','vowel','[ˈvaʊəl]','http://res.iciba.com/resource/amp3/oxford/0/15/e6/15e6be1d28e0127e57218e15ce2f0fd7.mp3','n. 元音，元音字母','','');----
INSERT INTO classwords VALUES ('827082815c2d42c8ae108b6c45ed890b','7eed5f1aa81548139b569e5a711aaec3','12');----
INSERT INTO word VALUES ('8050051c1f5b405cbd3704c212f5c3c3','grind','[ɡraind]','http://res.iciba.com/resource/amp3/oxford/0/88/d5/88d5b20491a12cb0d259c87ffb588a23.mp3','vt. 磨碎；用力挤压；把…磨锋利','','');----
INSERT INTO classwords VALUES ('c0372fb164fb48b7ad3358c1dbcc456f','8050051c1f5b405cbd3704c212f5c3c3','12');----
INSERT INTO word VALUES ('5ab9b5fd750d49c9ad14c794544d79a7','stern','[stɜːn]','http://res.iciba.com/resource/amp3/0/0/2d/86/2d86fd41e053dc58ceb95695a314dc49.mp3','adj. 严厉的；苛刻的','','');----
INSERT INTO classwords VALUES ('72028024d13840d594b12b47c7355965','5ab9b5fd750d49c9ad14c794544d79a7','12');----
INSERT INTO word VALUES ('67c96a6bcd4e48cbb8fbe630f0953575','wrath','[ræθ]','http://res.iciba.com/resource/amp3/0/0/28/be/28be4303152333e6c6e9a892f83c16b3.mp3','n. 愤怒，狂怒','','');----
INSERT INTO classwords VALUES ('ac8e37c531704cccadcc48ea2f87b612','67c96a6bcd4e48cbb8fbe630f0953575','12');----
INSERT INTO word VALUES ('5e36bf46448f4c7d89fb6bfba682bc0a','shame','[ʃeim]','http://res.iciba.com/resource/amp3/oxford/0/c0/78/c078552c3176e23317350e3ea6db6eb2.mp3','vt. 使羞愧；使丢脸','','');----
INSERT INTO classwords VALUES ('6a292237479d4fbab683229dfed32359','5e36bf46448f4c7d89fb6bfba682bc0a','12');----
INSERT INTO word VALUES ('8a96306c8dfd44c2a32a6acf8370a5fd','barge','[bɑ:dʒ]','http://res.iciba.com/resource/amp3/0/0/3a/43/3a433e05ba98650b5d832f7aa47494f8.mp3','n. 驳船；游艇','','');----
INSERT INTO classwords VALUES ('9e4a61b4e61b4efdbd1b4bbcb668e8a4','8a96306c8dfd44c2a32a6acf8370a5fd','12');----
INSERT INTO word VALUES ('11a1ddcf3e7345c7a5810ac8119e1009','supervise','[ˈsju:pəvaiz]','http://res.iciba.com/resource/amp3/oxford/0/13/ac/13acbc890f3ae4fe049cae8d2e1bdc4b.mp3','vt.&vi. 监督；指导；管理','','');----
INSERT INTO classwords VALUES ('b5a74f9f71264dc88fb3ec93497854b0','11a1ddcf3e7345c7a5810ac8119e1009','12');----
INSERT INTO word VALUES ('7befeacf601c4116892709c97cb97a9a','indefinite','[inˈdefinit]','http://res.iciba.com/resource/amp3/oxford/0/cc/e5/cce5e50c41a80ec4bf566c33d385971f.mp3','adj. 无限期的；不明确的','','');----
INSERT INTO classwords VALUES ('cb0e8691208a4708b500c7a18846292b','7befeacf601c4116892709c97cb97a9a','12');----
INSERT INTO word VALUES ('af069078ae2544b0ba4ea6baeaa54fee','Jesus','[ˈdʒi:zəs]','http://res.iciba.com/resource/amp3/oxford/0/97/fb/97fbf6290ee052716656dfb3b626afa9.mp3','n. 耶稣','','');----
INSERT INTO classwords VALUES ('91e433f9243b4f04ab3a6c17296f14d3','af069078ae2544b0ba4ea6baeaa54fee','12');----
INSERT INTO word VALUES ('624ad0395deb4868b1c31672b4ddc311','cradle','[ˈkreidl]','http://res.iciba.com/resource/amp3/oxford/0/32/89/32891b3da12d2c1eaea37b08edcb16f8.mp3','n. 摇篮；发源地；支架；听筒架','','');----
INSERT INTO classwords VALUES ('2fd2ed522a1341ef9756f928cbe1d2e1','624ad0395deb4868b1c31672b4ddc311','12');----
INSERT INTO word VALUES ('0711436830964e2db9b6462530d6c273','peril','[ˈperil]','http://res.iciba.com/resource/amp3/oxford/0/a1/24/a1242d82e10736a0f4e5100548494c8d.mp3','n. 重大危险；（某活动或行为的）危险，...','','');----
INSERT INTO classwords VALUES ('8027adc146b0440f97ca2077ae2e6f19','0711436830964e2db9b6462530d6c273','12');----
INSERT INTO word VALUES ('d8f82b8510414327968576f6c7a043fa','bid','[bid]','http://res.iciba.com/resource/amp3/oxford/0/83/ab/83ab7f08a8241993e691b2a891717d84.mp3','n. 努力；投标','','');----
INSERT INTO classwords VALUES ('b8df6d08f2bb4df99db067eaeada4281','d8f82b8510414327968576f6c7a043fa','12');----
INSERT INTO word VALUES ('5487fbe7e5994cc48fe0d857ea6ebf1d','sheriff','[ˈʃerɪf]','http://res.iciba.com/resource/amp3/oxford/0/99/66/9966edac18094274584cbc4d7e034a5d.mp3','n. 郡长；县治安官','','');----
INSERT INTO classwords VALUES ('c4c0b92aa55e454db77803ceb89a5123','5487fbe7e5994cc48fe0d857ea6ebf1d','12');----
INSERT INTO word VALUES ('2be52bbb63b944a0b7cc7d53d45a4445','missionary','[ˈmiʃənəri]','http://res.iciba.com/resource/amp3/oxford/0/6b/ae/6baea48ffad949e3c51a57d67c64a667.mp3','n. 传教士','','');----
INSERT INTO classwords VALUES ('23390a8db2d14f1d80231abf1f75b5d5','2be52bbb63b944a0b7cc7d53d45a4445','12');----
INSERT INTO word VALUES ('7fb36a6e341e4d8cbe8a2204a2924855','nursery','[ˈnə:səri]','http://res.iciba.com/resource/amp3/oxford/0/6c/03/6c0331bc3bcf04baac7ca44cf3d5faf4.mp3','n. 苗圃；儿童房；托儿所；幼儿园','','');----
INSERT INTO classwords VALUES ('61ac54e2778840ed9a5f30909489ed63','7fb36a6e341e4d8cbe8a2204a2924855','12');----
INSERT INTO word VALUES ('9bb0e354482c46e79150adca6a929246','mobilize','[ˈməubilaiz]','http://res.iciba.com/resource/amp3/oxford/0/e4/94/e4943483821b2920ea78c36d4dcd6bdc.mp3','vi. 动员起来','','');----
INSERT INTO classwords VALUES ('afb9bcdd78a14d11aa1e55b1b1598f4e','9bb0e354482c46e79150adca6a929246','12');----
INSERT INTO word VALUES ('671d028035c7497abd3a6b22e666ec17','observe','[əbˈzə:v]','http://res.iciba.com/resource/amp3/0/0/1b/65/1b65e84b7aa724b3f34c7dede00d439c.mp3','vt. 观察；看到；遵守','','');----
INSERT INTO classwords VALUES ('7191b65bafd747569074bc81da9dd6fa','671d028035c7497abd3a6b22e666ec17','12');----
INSERT INTO word VALUES ('dd3fc4d02b03493ab346d0d7aaea71b8','fortress','[ˈfɔ:tris]','http://res.iciba.com/resource/amp3/oxford/0/dd/68/dd686e7d2ce50309f28be55319649201.mp3','n. 堡垒，要塞','','');----
INSERT INTO classwords VALUES ('1885cc6288744318967ee1ec15b9fdfb','dd3fc4d02b03493ab346d0d7aaea71b8','12');----
INSERT INTO word VALUES ('c8803dfef9574511bc48037f906c83ee','initiate','[iˈniʃieit]','http://res.iciba.com/resource/amp3/oxford/0/a7/01/a7017a6d3e5f471f6b86299068d3b510.mp3','vt. 开始，创始；使初步了解；接纳，使...','','');----
INSERT INTO classwords VALUES ('0b7e289b1f79481c96b149d287837cbd','c8803dfef9574511bc48037f906c83ee','12');----
INSERT INTO word VALUES ('735f0aa671924fe8a6bd4339b5b3e63a','mount','[maunt]','http://res.iciba.com/resource/amp3/oxford/0/27/d4/27d4e4ea06026cf9da6ca673e9f12725.mp3','n. 山峰；坐骑','','');----
INSERT INTO classwords VALUES ('3940186de2ba42728566e6c40a663b34','735f0aa671924fe8a6bd4339b5b3e63a','12');----
INSERT INTO word VALUES ('9deec8b6774848459b7d7420e34c153a','pressure','[ˈpreʃə]','http://res.iciba.com/resource/amp3/oxford/0/f4/89/f48999a0279fe0ef4dd14eda72c975af.mp3','n. 压力；气压','','');----
INSERT INTO classwords VALUES ('0843308a202543a0a40d1fc98d4d0ee5','9deec8b6774848459b7d7420e34c153a','12');----
INSERT INTO word VALUES ('9cfe44b233914e9583188534634984c2','deem','[di:m]','http://res.iciba.com/resource/amp3/oxford/0/e1/a2/e1a28a03f2d5e7055a594ff7315f439b.mp3','vi. 认为','','');----
INSERT INTO classwords VALUES ('8fac1056defb43d1946524402ef453ed','9cfe44b233914e9583188534634984c2','12');----
INSERT INTO word VALUES ('c2b7a9df3024401b96617a23ee986602','deputy','[ˈdepjuti]','http://res.iciba.com/resource/amp3/oxford/0/45/2a/452ad35376d4a19654729a6c03dca373.mp3','adj. 副的','','');----
INSERT INTO classwords VALUES ('ff6fce6312d24a929c55778890630b3f','c2b7a9df3024401b96617a23ee986602','12');----
INSERT INTO word VALUES ('d4ceef39bcfe49c88b5887a9953f2a89','composition','[ˌkɔmpəˈziʃən]','http://res.iciba.com/resource/amp3/oxford/0/59/cc/59ccf5492d3a526808672dacf90754fd.mp3','n. 组成，构成；作品；作文','','');----
INSERT INTO classwords VALUES ('a9ca05d3b28e46d1a98077374cfc79d7','d4ceef39bcfe49c88b5887a9953f2a89','12');----
INSERT INTO word VALUES ('dbcf52b4367f43ec9dbb402a3a1d5a72','diesel','[ˈdi:zəl]','http://res.iciba.com/resource/amp3/oxford/0/a5/61/a5610738d8c767f70a3b9399af0b52c0.mp3','n. 柴油；柴油车','','');----
INSERT INTO classwords VALUES ('0431ebd2a6f147f8aecca62987016e65','dbcf52b4367f43ec9dbb402a3a1d5a72','12');----
INSERT INTO word VALUES ('96577149f13f4744a16d2ab0113248d6','exceptional','[ikˈsepʃənl]','http://res.iciba.com/resource/amp3/oxford/0/cf/6f/cf6f59b7ed3818a8c268b093009ff388.mp3','adj. 例外的；优越的，非凡的','','');----
INSERT INTO classwords VALUES ('1589af0b0e4d43d5be283d973d34570f','96577149f13f4744a16d2ab0113248d6','12');----
INSERT INTO word VALUES ('09100efa6c37457180b6d1881ededcd3','versatile','[ˈvə:sətail]','http://res.iciba.com/resource/amp3/0/0/e9/0f/e90f7a541023c8effeee9f2dca9e69ce.mp3','adj. 多才多艺的；多功能的','','');----
INSERT INTO classwords VALUES ('ad05f552bd6c4b91bd0a266069358785','09100efa6c37457180b6d1881ededcd3','12');----
INSERT INTO word VALUES ('9859dca914eb48aea539c8ce5bec8001','measurement','[ˈmeʒəmənt]','http://res.iciba.com/resource/amp3/oxford/0/6c/a9/6ca99478cb3f97a91d693e5d31deb8bd.mp3','n. （身材）尺寸；测量；测量结果','','');----
INSERT INTO classwords VALUES ('4f1452b0bfa34fccbe10e80f940a9841','9859dca914eb48aea539c8ce5bec8001','12');----
INSERT INTO word VALUES ('f24aabd8a7a2495eac8168ab07c0c2b8','advocate','[ˈædvəkeit]','http://res.iciba.com/resource/amp3/oxford/0/b4/3d/b43d3d48170094a7cd370c8da470d148.mp3','vt. 拥护；提倡；主张','','');----
INSERT INTO classwords VALUES ('6c0d4a92906d4cb4a7203f6a4cc533a8','f24aabd8a7a2495eac8168ab07c0c2b8','12');----
INSERT INTO word VALUES ('216f85893e7a4197957cdac935adbd12','dove','[dʌv]','http://res.iciba.com/resource/amp3/oxford/0/20/eb/20eb238f23583c899721b2404b2babc4.mp3','n. 鸽子；（政界的）鸽派人士','','');----
INSERT INTO classwords VALUES ('ec7ab8615e984acc9f1cc7fd03ffd71e','216f85893e7a4197957cdac935adbd12','12');----
INSERT INTO word VALUES ('4efaaabd512f4288aa66c28542120da6','decay','[diˈkei]','http://res.iciba.com/resource/amp3/oxford/0/1c/f3/1cf35274d66018c6056900bb0cc738a2.mp3','vt. 使腐朽，使腐烂；衰败，衰落','','');----
INSERT INTO classwords VALUES ('73672bfcc31b48d6afa37c91b61c529a','4efaaabd512f4288aa66c28542120da6','12');----
INSERT INTO word VALUES ('50f7a850cfae4b5e8240e8cb21d15392','outlet','[ˈautlet]','http://res.iciba.com/resource/amp3/oxford/0/88/70/8870fd18a64c8f1d5220b6535fc89768.mp3','n. 出口；排放管；（情感的）发泄途径；...','','');----
INSERT INTO classwords VALUES ('01c0d791e17f43edbafa21b62ff2eadd','50f7a850cfae4b5e8240e8cb21d15392','12');----
INSERT INTO word VALUES ('8fd51cb2db9f484cb87d667053364b70','hospitality','[ˌhɔspiˈtæliti]','http://res.iciba.com/resource/amp3/oxford/0/56/45/5645321a66aa336a704947c3d1ce4e06.mp3','n. 殷勤好客；热情友好；款待','','');----
INSERT INTO classwords VALUES ('2807835adfb14e44a9f41a3468c00a1c','8fd51cb2db9f484cb87d667053364b70','12');----
INSERT INTO word VALUES ('5a93ab0ead644d9c99c5d7ce3a83fa81','guilt','[gɪlt]','http://res.iciba.com/resource/amp3/oxford/0/82/21/8221e1d6b61758f3cc0d70775c1768d2.mp3','n. 有罪，犯罪；内疚','','');----
INSERT INTO classwords VALUES ('d640fbc056d24c028171d300deadbcf8','5a93ab0ead644d9c99c5d7ce3a83fa81','12');----
INSERT INTO word VALUES ('e01ff8960ea34c98b3b300fcdc1d91f0','yolk','[jəuk]','http://res.iciba.com/resource/amp3/0/0/2e/35/2e35089b56096e03266a341c01189609.mp3','n. 蛋黄','','');----
INSERT INTO classwords VALUES ('3cb6c10baa1342699aad11fb1c302c1d','e01ff8960ea34c98b3b300fcdc1d91f0','12');----
INSERT INTO word VALUES ('3000c50c8283496bb4dee12294ffd2f8','bank','[bæŋk]','http://res.iciba.com/resource/amp3/oxford/0/2b/33/2b33201c40a8e30f98ad796bba746759.mp3','vi. 把钱存入银行；开户','','');----
INSERT INTO classwords VALUES ('35d00d865b6a438ca83d384d851881a3','3000c50c8283496bb4dee12294ffd2f8','12');----
INSERT INTO word VALUES ('51bfa5e30fcd4456a7cb37f92a161b48','excuse','[iksˈkju:z]','http://res.iciba.com/resource/amp3/oxford/0/1b/18/1b185a1f02e60d9497e3fcf168f363c7.mp3','vt. 为…辩解；使免除；原谅','','');----
INSERT INTO classwords VALUES ('368d5cfe16204c03a91288d609012224','51bfa5e30fcd4456a7cb37f92a161b48','12');----
INSERT INTO word VALUES ('4d97ccd24e38434c90a44d6019175c2e','uncertain','[ʌnˈsɜ:tn]','http://res.iciba.com/resource/amp3/0/0/cd/df/cddf37909838913ffe0f7e9b316fc312.mp3','adj. 不确定的；迟疑的；未知的','','');----
INSERT INTO classwords VALUES ('4721a6465b9b4036a351750e093e8b2f','4d97ccd24e38434c90a44d6019175c2e','12');----
INSERT INTO word VALUES ('401e15105b0641dc9eb6f0b1d104075f','grassy','[ˈgræsi:]','http://res.iciba.com/resource/amp3/0/0/28/fb/28fbc31a4842758760ac932a7458b9bc.mp3','adj. 长满草的；覆盖着草的','','');----
INSERT INTO classwords VALUES ('9fdb68009579424882d1ab04373391be','401e15105b0641dc9eb6f0b1d104075f','12');----
INSERT INTO word VALUES ('37ec9002d2514fd5ac033764a4947a66','deepen','[ˈdi:pən]','http://res.iciba.com/resource/amp3/oxford/0/76/4b/764bb7b8ee92adc542de4606b6971d9f.mp3','vt.&vi. 加深；使加剧；使变深；使...','','');----
INSERT INTO classwords VALUES ('c922c5f13972480f9141548f3fed9375','37ec9002d2514fd5ac033764a4947a66','12');----
INSERT INTO word VALUES ('504f7ae7ecc246a593d6a7a569cac167','hazard','[ˈhæzəd]','http://res.iciba.com/resource/amp3/oxford/0/69/6a/696a56b18d1447b67196f6b5d889f2ac.mp3','n. 危险','','');----
INSERT INTO classwords VALUES ('f00df230d05b41b3a7045fbae897a99a','504f7ae7ecc246a593d6a7a569cac167','12');----
INSERT INTO word VALUES ('2b8d3e40822948ae96b1f79012016f2d','perception','[pəˈsepʃən]','http://res.iciba.com/resource/amp3/oxford/0/2f/4b/2f4bc0dabb525b5a6aca6fff144fa314.mp3','n. 感觉；洞察力；理解','','');----
INSERT INTO classwords VALUES ('6c556a3940b740fd8314a7537d1b478d','2b8d3e40822948ae96b1f79012016f2d','12');----
INSERT INTO word VALUES ('fee2ac77b2904395b845b6f173e5e2f4','shower','[ˈʃauə]','http://res.iciba.com/resource/amp3/oxford/0/1d/2b/1d2b347ccb9cb68047cd6dc90d359890.mp3','n. 浴室；淋浴器；淋浴；阵雨','','');----
INSERT INTO classwords VALUES ('35a562b4ef0f49be9d1ed63aa3e5e2a8','fee2ac77b2904395b845b6f173e5e2f4','12');----
INSERT INTO word VALUES ('7ce50788e90b4248996b3941e08e5300','molecular','[məˈlekjələ]','http://res.iciba.com/resource/amp3/0/0/46/be/46beaaa025713845ddb9aa798edc3b18.mp3','adj. 分子的；与分子有关的','','');----
INSERT INTO classwords VALUES ('c41e28a7c3004aeebbca0b9ae6e96e34','7ce50788e90b4248996b3941e08e5300','12');----
INSERT INTO word VALUES ('5ee18df93328489a86521348dd6aa288','patent','[ˈpeitənt]','http://res.iciba.com/resource/amp3/oxford/0/fb/08/fb086b313572d9f10342f9270aaed06b.mp3','n. 专利','','');----
INSERT INTO classwords VALUES ('b5647d4c4bf14233a80051e9757eb0f5','5ee18df93328489a86521348dd6aa288','12');----
INSERT INTO word VALUES ('153d2f0d97894bf29b24e61ee53d9a5c','goddess','[ˈgɔdɪs]','http://res.iciba.com/resource/amp3/0/0/5e/37/5e37719b351ec7f65a4464da9b50cdeb.mp3','n. 女神；被崇拜的女人','','');----
INSERT INTO classwords VALUES ('533528fb74f841479e4cfe266865430b','153d2f0d97894bf29b24e61ee53d9a5c','12');----
INSERT INTO word VALUES ('05b792fb1e0e4c5d93e7efdb2b9eeb67','transform','[trænsˈfɔ:m]','http://res.iciba.com/resource/amp3/oxford/0/6d/33/6d330fa99ea079bc22f629872cb0677e.mp3','vt. 转变；使改观；使改头换面','','');----
INSERT INTO classwords VALUES ('1ecc80676aec499ba24ac287cd3d92b3','05b792fb1e0e4c5d93e7efdb2b9eeb67','12');----
INSERT INTO word VALUES ('91ef3aa216934aed9f25444806a741b8','network','[ˈnetwə:k]','http://res.iciba.com/resource/amp3/oxford/0/62/24/622401715a601bbdfecbb36cbf580b88.mp3','n. 网络；广播网；网状物','','');----
INSERT INTO classwords VALUES ('bd9b759fa8fb4f15899419973bf5b5be','91ef3aa216934aed9f25444806a741b8','12');----
INSERT INTO word VALUES ('79e09607801a450a98af550c8d292ea2','commonplace','[ˈkɔmənpleis]','http://res.iciba.com/resource/amp3/oxford/0/3b/4c/3b4c80f27118e9962c00f66e6acc7579.mp3','n. 平常的事；老生常谈','','');----
INSERT INTO classwords VALUES ('8a062662c93a478e964f6bc1203cc455','79e09607801a450a98af550c8d292ea2','12');----
INSERT INTO word VALUES ('54138bbdce35413eb020589cbb0a843b','merciful','[ˈmɜ:sɪfəl]','http://res.iciba.com/resource/amp3/oxford/0/c2/05/c205b21e793ed3d4058845b08cab8e48.mp3','adj. 仁慈的，宽厚的；幸运的','','');----
INSERT INTO classwords VALUES ('8bb3e59e09714382964b6f35f3315830','54138bbdce35413eb020589cbb0a843b','12');----
INSERT INTO word VALUES ('d47e5ee1cf0749119094236c1ea9eac2','prairie','[ˈprɛəri]','http://res.iciba.com/resource/amp3/0/0/ee/ae/eeae14f67be37cbd87313eb174bfb980.mp3','n. 大草原','','');----
INSERT INTO classwords VALUES ('906a1798a4cd4887bcc60a201b0c910e','d47e5ee1cf0749119094236c1ea9eac2','12');----
INSERT INTO word VALUES ('1267fbc290294846a582cef4b3604c38','distort','[disˈtɔ:t]','http://res.iciba.com/resource/amp3/0/0/2b/9c/2b9c721ff9154576ca4898cc871aee62.mp3','vt. 歪曲，曲解，扭曲；使变形','','');----
INSERT INTO classwords VALUES ('620b2c2b08ab469b8c3b5745ec715681','1267fbc290294846a582cef4b3604c38','12');----
INSERT INTO word VALUES ('be8317981cdc4583af838995bbda9c2c','invariably','[ɪnˈveəriəbli]','http://res.iciba.com/resource/amp3/oxford/0/47/44/4744d86d13fe04a2e7ef75cdb25e311a.mp3','adv. 不变地；总是','','');----
INSERT INTO classwords VALUES ('97c5a1bebd764f10886a208443190b50','be8317981cdc4583af838995bbda9c2c','12');----
INSERT INTO word VALUES ('0f991d1b6dc7477a87c4a4f117cd2c41','mess','[mes]','http://res.iciba.com/resource/amp3/oxford/0/ab/5d/ab5d9136ad37d30a0f54268de83ae9c3.mp3','vt. 弄脏；弄乱','','');----
INSERT INTO classwords VALUES ('33400c8750f34dfbb5a7b2ff1fee09c8','0f991d1b6dc7477a87c4a4f117cd2c41','12');----
INSERT INTO word VALUES ('04b1c9aa2a57412dbe0d42e7040dd645','stiffness','[ˈstɪfnɪs]','http://res.iciba.com/resource/amp3/0/0/08/6e/086e8b527490b8abe606a8dd76586ab1.mp3','n. 僵硬；生硬；不自然','','');----
INSERT INTO classwords VALUES ('12be382afdc643e9b2e10accc17144c3','04b1c9aa2a57412dbe0d42e7040dd645','12');----
INSERT INTO word VALUES ('1ac6918a9a50401c9fc3b36bddcc3f84','ambassador','[æmˈbæsədə]','http://res.iciba.com/resource/amp3/oxford/0/42/80/428038b05d140ed6ef5f4078e2876f93.mp3','n. 大使；代表','','');----
INSERT INTO classwords VALUES ('ebb4eb0076ad483e86a1cfb229921d51','1ac6918a9a50401c9fc3b36bddcc3f84','12');----
INSERT INTO word VALUES ('f6fca6175132456dbaea5a262cd3ca5d','agreeable','[əˈɡri:əbl]','http://res.iciba.com/resource/amp3/oxford/0/a4/06/a406c0981c01bd79169b8126dff78892.mp3','adj. 愉快的；同意的；亲切的','','');----
INSERT INTO classwords VALUES ('6cd1568910fd429984a5d601b4e937b4','f6fca6175132456dbaea5a262cd3ca5d','12');----
INSERT INTO word VALUES ('e3db05159cbf43049cb1052a3cee850e','hydrocarbon','[ˌhaɪdrəˈkɑ:bən]','http://res.iciba.com/resource/amp3/oxford/0/fc/f9/fcf9af1d672aa7096df50b71bf7646a9.mp3','n. 烃，碳氢化合物','','');----
INSERT INTO classwords VALUES ('ed6359abe02a4cc9a42944e6590083fc','e3db05159cbf43049cb1052a3cee850e','12');----
INSERT INTO word VALUES ('b187403524d44496a2623ebd43fb381d','crank','[kræŋk]','http://res.iciba.com/resource/amp3/oxford/0/be/7a/be7a8a91c781f1bfa7c069b6ca74344f.mp3','v. （尤指用手摇曲柄）转动（或启动）','','');----
INSERT INTO classwords VALUES ('d188f113757f44ab99085fcad52e9273','b187403524d44496a2623ebd43fb381d','12');----
INSERT INTO word VALUES ('2a39d02396c5411e8080d0a4c052594b','rapidity','[rəˈpɪdɪtɪ]','http://res.iciba.com/resource/amp3/0/0/27/91/2791569f4b3a2c60d217a991936f0e31.mp3','n. 急速，迅速；陡，险峻','','');----
INSERT INTO classwords VALUES ('f42478561f704dc99d8cba71cda4691f','2a39d02396c5411e8080d0a4c052594b','12');----
INSERT INTO word VALUES ('77b0c7955a0b4577b28253331c885114','float','[fləut]','http://res.iciba.com/resource/amp3/0/0/54/6a/546ade640b6edfbc8a086ef31347e768.mp3','v. 使漂浮；飘荡；（声音或气味）飘到；...','','');----
INSERT INTO classwords VALUES ('6ea6e0ef5e5f473f83027bf51282b0b6','77b0c7955a0b4577b28253331c885114','12');----
INSERT INTO word VALUES ('13e048ed8a3e412786697e4ba915655d','plague','[pleiɡ]','http://res.iciba.com/resource/amp3/oxford/0/6f/0f/6f0fa9a7e398feec8a18399ecfa5f97e.mp3','n. 瘟疫；鼠疫；灾难','','');----
INSERT INTO classwords VALUES ('187f127ce82345f9a329302999e59894','13e048ed8a3e412786697e4ba915655d','12');----
INSERT INTO word VALUES ('bc848b49a6be4ae3beb2f0decb97ddb9','essential','[iˈsenʃəl]','http://res.iciba.com/resource/amp3/oxford/0/bf/18/bf18959973ca98c9fc0bbade8ade6e74.mp3','adj. 绝对必要的；基本的','','');----
INSERT INTO classwords VALUES ('b9f48d2c32e54640857b5f466cdd2b83','bc848b49a6be4ae3beb2f0decb97ddb9','12');----
INSERT INTO word VALUES ('22384c2cbed6402c9bde82c2149cbbe6','capability','[ˌkeɪpəˈbɪlɪti:]','http://res.iciba.com/resource/amp3/oxford/0/1e/32/1e32355108d3316d5d0e07d481c243be.mp3','n. 能力；容量；（国家的）军事力量','','');----
INSERT INTO classwords VALUES ('15079400a8e5474d9d9e63d67c006fdf','22384c2cbed6402c9bde82c2149cbbe6','12');----
INSERT INTO word VALUES ('1fc4b50a7be84932bedb2f00660b8595','profound','[prəˈfaund]','http://res.iciba.com/resource/amp3/oxford/0/94/a7/94a71d31988b08df3b82b98e70a2ddb8.mp3','adj. 深刻的；知识渊博的','','');----
INSERT INTO classwords VALUES ('345b75b127dc44f48ec9a4ad075a6e36','1fc4b50a7be84932bedb2f00660b8595','12');----
INSERT INTO word VALUES ('5d89c19e0c5148f592ea1c86b6ea30e5','generalize','[ˈdʒenərəlaiz]','http://res.iciba.com/resource/amp3/oxford/0/31/47/31471c9a2458b0d5117fc3d63db2128c.mp3','vi. 形成概念','','');----
INSERT INTO classwords VALUES ('45b56d6b65ea4878b1af810b2d717e03','5d89c19e0c5148f592ea1c86b6ea30e5','12');----
INSERT INTO word VALUES ('6c9d6255dedc40d790ade87730fa2148','adore','[əˈdɔ:]','http://res.iciba.com/resource/amp3/oxford/0/d2/3f/d23f38625650dfb30db3c0c13e2841bb.mp3','vt. 崇拜；热爱','','');----
INSERT INTO classwords VALUES ('6b8a1d174f5f43e081262850863abdff','6c9d6255dedc40d790ade87730fa2148','12');----
INSERT INTO word VALUES ('c0aa6b7337414aaa9ca546c9af0da2ed','trench','[trentʃ]','http://res.iciba.com/resource/amp3/oxford/0/c2/29/c229fe0b854532258f2c9bc8f152a3dd.mp3','n. 深沟，地沟；战壕','','');----
INSERT INTO classwords VALUES ('b59a9945384b4628ad33605518344046','c0aa6b7337414aaa9ca546c9af0da2ed','12');----
INSERT INTO word VALUES ('0f23670d15344a3f8ab8b82c2dc92a0a','lump','[lʌmp]','http://res.iciba.com/resource/amp3/oxford/0/06/85/068562f1ed389bdab4170100562e3a0c.mp3','vi. 结成块','','');----
INSERT INTO classwords VALUES ('16d89f57401a494fab5d422b29277730','0f23670d15344a3f8ab8b82c2dc92a0a','12');----
INSERT INTO word VALUES ('85f642de84754757843095643db19bb6','flexible','[ˈfleksəbl]','http://res.iciba.com/resource/amp3/oxford/0/06/38/06388ffa0f377f25f8b39a810055fb2b.mp3','adj. 灵活的；可变通的；可弯曲的','','');----
INSERT INTO classwords VALUES ('6c9eb444c08d480bbc7b979aa62f409b','85f642de84754757843095643db19bb6','12');----
INSERT INTO word VALUES ('f199220e402747d1afe6ac73104c47ef','energetic','[ˌenəˈdʒetik]','http://res.iciba.com/resource/amp3/oxford/0/f3/f8/f3f8e5f411089ec4a9f862393b6ef337.mp3','adj. 积极主动的；精力旺盛的；充满活...','','');----
INSERT INTO classwords VALUES ('0ae05135313a40b489159dfe6b9f4eca','f199220e402747d1afe6ac73104c47ef','12');----
INSERT INTO word VALUES ('c382f7b5788b4aff844558520540c5e4','nought','[nɔ:t]','http://res.iciba.com/resource/amp3/oxford/0/08/48/0848436ba2991d8a042b7c25f2ddf47b.mp3','n. 零；无；没有','','');----
INSERT INTO classwords VALUES ('0bb7c6ac5530472e8f30a1e51fd3d7ea','c382f7b5788b4aff844558520540c5e4','12');----
INSERT INTO word VALUES ('42c2e3bd6e22440a9d44e85749fc90ca','firework','[ˈfaɪəˌwɜ:k]','http://res.iciba.com/resource/amp3/1/0/b8/0f/b80f781f281cb33422627be1815c5181.mp3','n. 焰火，烟花；焰火晚会','','');----
INSERT INTO classwords VALUES ('eb229679a55e4a6aa83d90896dd953cf','42c2e3bd6e22440a9d44e85749fc90ca','12');----
INSERT INTO word VALUES ('b2b94eb616a149fc9d2efc8cd7cf649f','clinic','[ˈklinik]','http://res.iciba.com/resource/amp3/oxford/0/f8/4c/f84c3cdf43fcfa252e6e755729a17f6d.mp3','n. 诊所','','');----
INSERT INTO classwords VALUES ('a37be890caea4adfa6f0e054ac305fb7','b2b94eb616a149fc9d2efc8cd7cf649f','12');----
INSERT INTO word VALUES ('4191f734eb8648358d20967e6315d1c1','tranquil','[ˈtræŋkwil]','http://res.iciba.com/resource/amp3/oxford/0/b7/91/b7911fa959134565fa62b5639666d178.mp3','adj. 平静的，宁静的','','');----
INSERT INTO classwords VALUES ('276f6616b488483ebeba2d5043c46676','4191f734eb8648358d20967e6315d1c1','12');----
INSERT INTO word VALUES ('5a0b24dea94b4b7a919f5276ffba7fd7','resolute','[ˈrezəˌlu:t]','http://res.iciba.com/resource/amp3/oxford/0/cd/ae/cdaed26d2c65963f202377679fe5efc5.mp3','adj. 坚决的，果断的','','');----
INSERT INTO classwords VALUES ('e94c08acb71f4c03af020fccdd6d5854','5a0b24dea94b4b7a919f5276ffba7fd7','12');----
INSERT INTO word VALUES ('aebd8f49a7474bf3b5794aa039b810a7','finite','[ˈfainait]','http://res.iciba.com/resource/amp3/oxford/0/a4/0f/a40ff385a4ae84f2077d347adb963642.mp3','adj. 有限的；有尽的；限定的','','');----
INSERT INTO classwords VALUES ('27558a26c5da4a73805844d8db059ee3','aebd8f49a7474bf3b5794aa039b810a7','12');----
INSERT INTO word VALUES ('6d577341429b42cb94100d29ea2f6e74','repel','[riˈpel]','http://res.iciba.com/resource/amp3/oxford/0/df/a8/dfa85862b9c3c8e35cb841ed3b4fcfef.mp3','vt. 击退；使厌恶','','');----
INSERT INTO classwords VALUES ('afd7cd6a19c84b539750f10e5a0a3297','6d577341429b42cb94100d29ea2f6e74','12');----
INSERT INTO word VALUES ('bca63849e1104f2f9a876d49cd428890','dreadful','[ˈdredful]','http://res.iciba.com/resource/amp3/oxford/0/ba/cb/bacb5e65d00d383805c633c480f2599b.mp3','adj. 可怕的；糟糕透顶的；极严重的','','');----
INSERT INTO classwords VALUES ('6127f26707e749b88099eb722b64b5d3','bca63849e1104f2f9a876d49cd428890','12');----
INSERT INTO word VALUES ('1f01d5e82e2f4e4ca553c4ab7535cf37','perch','[pə:tʃ]','http://res.iciba.com/resource/amp3/0/0/4e/d1/4ed1ad576f2e38076e7af388b56d3139.mp3','n. （禽鸟的）栖息；高位','','');----
INSERT INTO classwords VALUES ('6c90875d356d4104b1a9ff7c9e19a470','1f01d5e82e2f4e4ca553c4ab7535cf37','12');----
INSERT INTO word VALUES ('0123653f19e1446182e67dfc0fa50dd8','rim','[rim]','http://res.iciba.com/resource/amp3/oxford/0/2d/29/2d29cfb37625fa90b4a9ed88c8b49cc4.mp3','n. 边沿，边缘；边框；（污垢等）一周','','');----
INSERT INTO classwords VALUES ('216f8c225ad243bf8014a4e4cac09836','0123653f19e1446182e67dfc0fa50dd8','12');----
INSERT INTO word VALUES ('f772e68c6e8741339dbd0f9a2c0aa903','butt','[bʌt]','http://res.iciba.com/resource/amp3/oxford/0/0e/99/0e99a12514e358cc4603769ae30f7161.mp3','n. 大酒桶；烟蒂','','');----
INSERT INTO classwords VALUES ('f2b20c29eb3e41508bcb44935ca6df55','f772e68c6e8741339dbd0f9a2c0aa903','12');----
INSERT INTO word VALUES ('3f9fdcff8e19495ca618d34427bf4447','prejudice','[ˈpredʒudis]','http://res.iciba.com/resource/amp3/oxford/0/fe/9d/fe9dd8925a7512f5d4f9f8968de87fc8.mp3','n. 偏见，成见','','');----
INSERT INTO classwords VALUES ('6fbaa9fdf5a64137bb449ed6539627ee','3f9fdcff8e19495ca618d34427bf4447','12');----
INSERT INTO word VALUES ('d27d8a43657e46f191ef9d72292ed5d2','intellect','[ˈintəlekt]','http://res.iciba.com/resource/amp3/oxford/0/3c/45/3c4572b101b7a1aac14f8625ba495468.mp3','n. 智力，理解力；才智非凡的人；出众的...','','');----
INSERT INTO classwords VALUES ('fc436188ca1944ab8fc4d7f60029f110','d27d8a43657e46f191ef9d72292ed5d2','12');----
INSERT INTO word VALUES ('9ba49d222dae484db4475dc3fae3a0ab','homogeneous','[ˌhɔməˈdʒi:njəs]','http://res.iciba.com/resource/amp3/oxford/0/31/44/31448170d5dc1797556548fb63533bbb.mp3','adj. 同类的，同性质的','','');----
INSERT INTO classwords VALUES ('5c7d2ad5367242e8ba8fd4dc5c65f5d0','9ba49d222dae484db4475dc3fae3a0ab','12');----
INSERT INTO word VALUES ('6e9d3cdfe3f94262962dbcabf2b2ddf6','drain','[drein]','http://res.iciba.com/resource/amp3/oxford/0/87/c2/87c29a5859eecf2e258efc1b009824c5.mp3','v. 使流出；使排干；喝光','','');----
INSERT INTO classwords VALUES ('a6624f0fa73246f581d4aeccc8f71fcd','6e9d3cdfe3f94262962dbcabf2b2ddf6','12');----
INSERT INTO word VALUES ('448bae1ba0d84314b7abbec66f75a020','count','[kaunt]','http://res.iciba.com/resource/amp3/oxford/0/ba/5c/ba5c94d577695967b0eb39779968222b.mp3','n. 指控；罪状；事项；计数','','');----
INSERT INTO classwords VALUES ('46a03c5014d24ba0ac210f62dbb77428','448bae1ba0d84314b7abbec66f75a020','12');----
INSERT INTO word VALUES ('fdfebb2a2bce482088aac1a0e45c1cf4','shipwreck','[ˈʃɪpˌrek]','http://res.iciba.com/resource/amp3/oxford/0/a3/e2/a3e26407125ba2e1e4613e8c3effea51.mp3','n. 船舶失事；海难','','');----
INSERT INTO classwords VALUES ('9312d71a88ec42b1b41d6f23357dc3d2','fdfebb2a2bce482088aac1a0e45c1cf4','12');----
INSERT INTO word VALUES ('2230eb79696241468597622e8b8814be','follower','[ˈfɔləʊə]','http://res.iciba.com/resource/amp3/oxford/0/a2/4c/a24ce62872a63b980d8265a41efce787.mp3','n. 信徒；追随者，支持者','','');----
INSERT INTO classwords VALUES ('3665e34a31da461da81f6444979ce6ae','2230eb79696241468597622e8b8814be','12');----
INSERT INTO word VALUES ('9a90488d57d04831b6af28d6323863a9','incomplete','[ˌɪnkəmˈpli:t]','http://res.iciba.com/resource/amp3/oxford/0/3f/36/3f36a234a3c5a0c94e51cd14304c97f7.mp3','adj. 不完全的；未完成的','','');----
INSERT INTO classwords VALUES ('1aa6f12328e44b81b626116a19aa8513','9a90488d57d04831b6af28d6323863a9','12');----
INSERT INTO word VALUES ('6aa9f0d68d36483f8a77bb22abb73983','disillusion','[ˌdisiˈlu:ʒən]','http://res.iciba.com/resource/amp3/oxford/0/ca/29/ca2940cc27d4e053919f31abad854692.mp3','vt. 使醒悟；使不再抱幻想；使理想破灭','','');----
INSERT INTO classwords VALUES ('d3d051d3fc6e42ff88892cdca5b69406','6aa9f0d68d36483f8a77bb22abb73983','12');----
INSERT INTO word VALUES ('ae17b6ccb22f4b0f905ce3d6b0902629','corrupt','[kəˈrʌpt]','http://res.iciba.com/resource/amp3/oxford/0/e6/2a/e62a5a6e5f795e2d9d6b739bb0088ddd.mp3','adj. 腐败的，贪污的','','');----
INSERT INTO classwords VALUES ('176556a0a789492491a0afa90fd46a35','ae17b6ccb22f4b0f905ce3d6b0902629','12');----
INSERT INTO word VALUES ('aea3837dcac54a049c520ce94e466f9e','dynamo','[ˈdaɪnəˌməʊ]','http://res.iciba.com/resource/amp3/oxford/0/09/86/09862d048e221c0c3ec608a05f50d6f7.mp3','n. 发电机；精力充沛的人','','');----
INSERT INTO classwords VALUES ('e2da0c3972eb4a7eb1cfc6a655310081','aea3837dcac54a049c520ce94e466f9e','12');----
INSERT INTO word VALUES ('a69493687026497fbe3da7a89d753c86','overwhelm','[ˌəuvəˈhwelm]','http://res.iciba.com/resource/amp3/oxford/0/ab/00/ab00898d493a3a9aeeed7577b823a4d9.mp3','vt. 压倒；使不知所措；征服','','');----
INSERT INTO classwords VALUES ('a2ce2492bb964ec6968367e54a9bae39','a69493687026497fbe3da7a89d753c86','12');----
INSERT INTO word VALUES ('be82c526a93b43c4a92abbbaf605068f','cling','[kliŋ]','http://res.iciba.com/resource/amp3/oxford/0/76/9d/769d60f93f7d6e8ac4077326dd915355.mp3','vi. 粘住；依附；紧紧抓住','','');----
INSERT INTO classwords VALUES ('f256e02a16b74f00bc2fec6339b9e10f','be82c526a93b43c4a92abbbaf605068f','12');----
INSERT INTO word VALUES ('adda2f0c3e2e4c2086ff194b93bd7518','hearty','[ˈhɑ:ti:]','http://res.iciba.com/resource/amp3/0/0/51/68/51688f9124d2da430001dc9f20950e84.mp3','adj. 衷心的；（饭菜）丰盛的；强烈的','','');----
INSERT INTO classwords VALUES ('2542852874a74cc7af25e8d88ac75ecf','adda2f0c3e2e4c2086ff194b93bd7518','12');----
INSERT INTO word VALUES ('c64112087eaf49478938da376df89cff','gleam','[ɡli:m]','http://res.iciba.com/resource/amp3/oxford/0/71/9b/719b5297703053f7fe6cc2662700527d.mp3','vt.&vi. 发微光；闪烁','','');----
INSERT INTO classwords VALUES ('b598917765de47aea930478757e7ae1d','c64112087eaf49478938da376df89cff','12');----
INSERT INTO word VALUES ('429649812e004e3997aafd28832f0b69','merit','[ˈmerit]','http://res.iciba.com/resource/amp3/oxford/0/12/13/121328fe476a954eac1ac11daebcfdfe.mp3','n. 价值；优点','','');----
INSERT INTO classwords VALUES ('b714866c64aa4072a3a497da5f8db94a','429649812e004e3997aafd28832f0b69','12');----
INSERT INTO word VALUES ('9a16d89b3a9341e6a7a1ca7360be7dda','environmental','[enˌvaɪərənˈmentl]','http://res.iciba.com/resource/amp3/oxford/0/48/13/48130a8fb7c39fd2ab262945439b4001.mp3','adj. 环境的；由生存环境引起的','','');----
INSERT INTO classwords VALUES ('48b69a140634402eb44bb663403456b7','9a16d89b3a9341e6a7a1ca7360be7dda','12');----
INSERT INTO word VALUES ('03ffaa25d5c34b14837eff8c736302aa','junction','[ˈdʒʌnkʃən]','http://res.iciba.com/resource/amp3/oxford/0/e8/f1/e8f16313e328297b97cb29204ce30ddf.mp3','n. 连接；交叉路口；汇合处','','');----
INSERT INTO classwords VALUES ('dae144e40f3e4bbe9e401bc1ed9600cf','03ffaa25d5c34b14837eff8c736302aa','12');----
INSERT INTO word VALUES ('caf60cf3496c42bf82f428d508230477','nominate','[ˈnɔmineit]','http://res.iciba.com/resource/amp3/oxford/0/4a/29/4a297f3adf76c4225ce8b9d809b58b85.mp3','vt. 提名，推荐；任命','','');----
INSERT INTO classwords VALUES ('e2f01dbbed15490f9bb132c8c8fa77da','caf60cf3496c42bf82f428d508230477','12');----
INSERT INTO word VALUES ('4a9f5053da01465a876809fdd80a4abe','marginal','[ˈmɑ:dʒinəl]','http://res.iciba.com/resource/amp3/oxford/0/80/64/80642b7508636d8455f718a4bb507a0b.mp3','adj. 微小的；边缘的；（土地）贫瘠的','','');----
INSERT INTO classwords VALUES ('61223d2adb714634bd2f1652320fb538','4a9f5053da01465a876809fdd80a4abe','12');----
INSERT INTO word VALUES ('0809130a08584b31a75c0fa31505623b','storage','[ˈstɔ:ridʒ]','http://res.iciba.com/resource/amp3/oxford/0/a5/45/a5453a6d729371297627fa2fd05d12aa.mp3','n. 贮藏，贮存；存储','','');----
INSERT INTO classwords VALUES ('6c54afacba814f5c8d942c0d5025abe7','0809130a08584b31a75c0fa31505623b','12');----
INSERT INTO word VALUES ('a86ae5e640a34705ab59c6cdc9cb75fa','budget','[ˈbʌdʒit]','http://res.iciba.com/resource/amp3/oxford/0/35/d9/35d9aef78bc6c6c4e3dc3ae7edb477b2.mp3','n. 预算；预算案','','');----
INSERT INTO classwords VALUES ('ebf86618d34247e19d43a192e37adf85','a86ae5e640a34705ab59c6cdc9cb75fa','12');----
INSERT INTO word VALUES ('7765c25b9f9d41d1b99a065fa0f87b81','late','[leit]','http://res.iciba.com/resource/amp3/oxford/0/93/7a/937ae65ac728c03bdc1f8a668c69c96f.mp3','adj. 已故的；近日暮的；近深夜的','','');----
INSERT INTO classwords VALUES ('06d67ec6b1ba437ca4c9ebca0f9aa33a','7765c25b9f9d41d1b99a065fa0f87b81','12');----
INSERT INTO word VALUES ('4c05ca0be93245fc9a4f8e87c2d35ea6','gravel','[ˈɡrævəl]','http://res.iciba.com/resource/amp3/oxford/0/ed/b1/edb100223b6cee7c71dcc34e659f1f4a.mp3','n. 砂跞；砾石；结石','','');----
INSERT INTO classwords VALUES ('e09c40b162c14a8c91fe74c45cb6595f','4c05ca0be93245fc9a4f8e87c2d35ea6','12');----
INSERT INTO word VALUES ('bb679f9156fe4bc083910282571bfaea','prolong','[prəˈlɔŋ]','http://res.iciba.com/resource/amp3/oxford/0/ab/7d/ab7d39741a865d92c3d33ba4fd5ec43f.mp3','vt. 延长；拉长；拖延','','');----
INSERT INTO classwords VALUES ('059bcd1e089648ac94c0264c6a8914c3','bb679f9156fe4bc083910282571bfaea','12');----
INSERT INTO word VALUES ('2462a82980c64c4592da70b891320265','workpiece','[ˈwɜ:kpi:s]','http://res.iciba.com/resource/amp3/0/0/8e/bb/8ebbc800a2b045dea10c3c5e433993e4.mp3','n. 工件，工作部件','','');----
INSERT INTO classwords VALUES ('a6134eff591c4d5d895126e08a4ca924','2462a82980c64c4592da70b891320265','12');----
INSERT INTO word VALUES ('2a2b1fa734014744b340ba89a1178fdb','retort','[riˈtɔ:t]','http://res.iciba.com/resource/amp3/0/0/c1/30/c130b9383104a1e3f90c6124dd5fc536.mp3','vi. 回嘴；反驳','','');----
INSERT INTO classwords VALUES ('5e93c6faf31d4e4aae30e86b611ec1a0','2a2b1fa734014744b340ba89a1178fdb','12');----
INSERT INTO word VALUES ('41a28a14094547808146e6ca532a8201','enterprise','[ˈentəpraiz]','http://res.iciba.com/resource/amp3/oxford/0/cf/13/cf136fe8460b79673ae468d0d5e49ccc.mp3','n. 事业；进取心；创业；企业','','');----
INSERT INTO classwords VALUES ('d248609d9cd34d6ea2dfd919630bb459','41a28a14094547808146e6ca532a8201','12');----
INSERT INTO word VALUES ('290b4d10927146ce9f1bda1d06ef5831','influence','[ ˈinfluəns]','http://res.iciba.com/resource/amp3/oxford/0/aa/de/aade1ae7eaa44ad7645139c2946fe440.mp3','n. 势力，权势；影响力','','');----
INSERT INTO classwords VALUES ('f4b42d1be21740efa2c2b4b6cdcf2ac4','290b4d10927146ce9f1bda1d06ef5831','12');----
INSERT INTO word VALUES ('805f2fe17fcd4ea2902cf5e5d0b2e7da','jam','[dʒæm]','http://res.iciba.com/resource/amp3/oxford/0/0b/ab/0babc0ce6eb892498fe00adbf2299f94.mp3','vt. 硬塞；使劲放；使卡住；堵塞（道路...','','');----
INSERT INTO classwords VALUES ('4435663c502b474babb7717fd835d89e','805f2fe17fcd4ea2902cf5e5d0b2e7da','12');----
INSERT INTO word VALUES ('f94b3cb4eba14a03900acd188e66fca9','lace','[leis]','http://res.iciba.com/resource/amp3/oxford/0/ba/1b/ba1ba74e7bd2e19c327566b9aea70d65.mp3','vt. 用鞋带系（鞋）；在…里掺入；在…...','','');----
INSERT INTO classwords VALUES ('19d0d5de0a774805b78a2ca8fad65513','f94b3cb4eba14a03900acd188e66fca9','12');----
INSERT INTO word VALUES ('379b9193db35432b97f3d8b0cec953dd','arch','[ɑ:tʃ]','http://res.iciba.com/resource/amp3/0/0/d6/19/d6194c68fcc7e79bb57401be603cb1cc.mp3','vt. 成拱形；拱起','','');----
INSERT INTO classwords VALUES ('631dbefa6bf54d009e9a21cf1cc3c829','379b9193db35432b97f3d8b0cec953dd','12');----
INSERT INTO word VALUES ('95fc511e73c54b959fc4c98fb0a2ea10','regularity','[ˌregjʊˈlærɪtɪ]','http://res.iciba.com/resource/amp3/oxford/0/64/4b/644bc9762786146a38d6295de8778d17.mp3','n. 规则性；整齐','','');----
INSERT INTO classwords VALUES ('d36afbfbc6b84284b0930d0470c62490','95fc511e73c54b959fc4c98fb0a2ea10','12');----
INSERT INTO word VALUES ('f28f18b2de0f4148a1f5774d1c930317','repay','[ri:ˈpei]','http://res.iciba.com/resource/amp3/oxford/0/67/f1/67f105eeb5ae8ed393e7eb959c433e80.mp3','vt. 偿还；报答','','');----
INSERT INTO classwords VALUES ('69f50f85298f4b12a88ea15057ad6287','f28f18b2de0f4148a1f5774d1c930317','12');----
INSERT INTO word VALUES ('92ee7157d4a44c1d837db4ba549cbfc7','option','[ˈɔpʃən]','http://res.iciba.com/resource/amp3/oxford/0/93/3c/933c6164f7c1a99be269582dac84db3e.mp3','n. 选择；可选择的事物；选修课','','');----
INSERT INTO classwords VALUES ('adccd5849f364b7f9e09d7bd88a1fe49','92ee7157d4a44c1d837db4ba549cbfc7','12');----
INSERT INTO word VALUES ('f9b62f396e6b476fbbafda720846e8f6','limp','[limp]','http://res.iciba.com/resource/amp3/oxford/0/84/19/8419103de3d47ab362127183bce9a657.mp3','n. 跛行','','');----
INSERT INTO classwords VALUES ('7f2bd35db6d34fdc8e3f92c6b067a1fc','f9b62f396e6b476fbbafda720846e8f6','12');----
INSERT INTO word VALUES ('5eed17ca122f48cfa4e8df5ac5b365d0','nucleus','[ˈnju:kliəs]','http://res.iciba.com/resource/amp3/oxford/0/9c/7d/9c7de9db6c899fc42f020c9b20c56e5a.mp3','n. 原子核；核心，中心','','');----
INSERT INTO classwords VALUES ('e14cc1a902d04f1e865d68283833f298','5eed17ca122f48cfa4e8df5ac5b365d0','12');----
INSERT INTO word VALUES ('6360c32f024e45c0a35d22b4a5cba8db','indicative','[inˈdikətiv]','http://res.iciba.com/resource/amp3/oxford/0/2e/18/2e18e5ed583374539ec3f5c98aee1a3f.mp3','adj. 指示的；象征的','','');----
INSERT INTO classwords VALUES ('fe4fd9b0754e4994a95c799fe3d1f798','6360c32f024e45c0a35d22b4a5cba8db','12');----
INSERT INTO word VALUES ('34a110a0923944e5beb18d31741ee41c','serpent','[ˈsɜ:pənt]','http://res.iciba.com/resource/amp3/oxford/0/19/0f/190f09e13faaf6aa66c01c808a113907.mp3','n. 蛇；狡猾的人','','');----
INSERT INTO classwords VALUES ('7f74c79ba9c34bfcb3d0618c188ba8bf','34a110a0923944e5beb18d31741ee41c','12');----
INSERT INTO word VALUES ('cc40a641b9a541109dff88db6b97d93a','petty','[ˈpeti]','http://res.iciba.com/resource/amp3/oxford/0/69/64/69649332414d49edd82b0d37ae6bd717.mp3','adj. 不重要的；小题大做的；下级的','','');----
INSERT INTO classwords VALUES ('524d987846e743c0b6a4c9ae2a6500d7','cc40a641b9a541109dff88db6b97d93a','12');----
INSERT INTO word VALUES ('3ca76ab187b548c0a021d779272385d2','gossip','[ˈɡɔsip]','http://res.iciba.com/resource/amp3/0/0/cb/ab/cbab2b0ff9a8a5f7b39084060eef2eda.mp3','n. 流言蜚语；爱说长道短的人；闲话','','');----
INSERT INTO classwords VALUES ('5b99459b1d264c51913a0b1aff4bd3e7','3ca76ab187b548c0a021d779272385d2','12');----
INSERT INTO word VALUES ('787340a1ca164e6a966f81607d8526aa','notwithstandi...','[ˌnɔtwiθˈstændiŋ]','http://res.iciba.com/resource/amp3/oxford/0/ec/4a/ec4afcf0634efedbf8026a7423d96806.mp3','prep. 尽管；虽然','','');----
INSERT INTO classwords VALUES ('3826d3f2957646469ea7cb1ff59aa38f','787340a1ca164e6a966f81607d8526aa','12');----
INSERT INTO word VALUES ('9c3361ffd48c4635a1ccaa719a59df35','obstinate','[ˈɔbstənɪt]','http://res.iciba.com/resource/amp3/oxford/0/15/4e/154e07f37c06e3a0bc53dbd20d9ff59a.mp3','adj. 固执的，执拗的；难以移动的','','');----
INSERT INTO classwords VALUES ('559521d0d23b40618a2f7fc3b2a9fbcb','9c3361ffd48c4635a1ccaa719a59df35','12');----
INSERT INTO word VALUES ('8298284362e74cc99435de12394d87e2','baby','[ˈbeibi]','http://res.iciba.com/resource/amp3/oxford/0/38/63/3863946c5b590136f176ef51229885b1.mp3','n. 婴儿；宝贝儿','','');----
INSERT INTO classwords VALUES ('b720d390e94548d0bc6a125fb192392b','8298284362e74cc99435de12394d87e2','12');----
INSERT INTO word VALUES ('067a3c3c35ed44429cd26d9da6f4faeb','diploma','[diˈpləumə]','http://res.iciba.com/resource/amp3/oxford/0/ca/1e/ca1eb85ad99096b6171dc5fa2687fb6d.mp3','n. 毕业文凭；学位证书','','');----
INSERT INTO classwords VALUES ('23f2ea6675ba4b678caa8a2c8004916e','067a3c3c35ed44429cd26d9da6f4faeb','12');----
INSERT INTO word VALUES ('3d47c4c0f8554b87a37117a7522b0045','notable','[ˈnəutəbl]','http://res.iciba.com/resource/amp3/oxford/0/9e/7d/9e7dc7218e7eec587c8b7c244a0cf0fd.mp3','adj. 值得注意的；显著的','','');----
INSERT INTO classwords VALUES ('d0efc35023c24129bc9a0b88d4da9cf0','3d47c4c0f8554b87a37117a7522b0045','12');----
INSERT INTO word VALUES ('3f297de4aec44625b1db8587be3460fa','bacterium','[bækˈtɪəri:əm]','http://res.iciba.com/resource/amp3/0/0/2d/6e/2d6ee2e64f1f9bb581ad7b179a6f6b5e.mp3','n. 细菌','','');----
INSERT INTO classwords VALUES ('43ef6510e9ec4bba87b838ebe215174e','3f297de4aec44625b1db8587be3460fa','12');----
INSERT INTO word VALUES ('702d120f7b0e42f690a0e71e96dc7ae0','lengthen','[ˈleŋθən]','http://res.iciba.com/resource/amp3/oxford/0/5f/01/5f01c73d95eda368491aa55902684372.mp3','vt.&vi. 延长；伸长','','');----
INSERT INTO classwords VALUES ('e3980e7d7e5845e0bda1218a5e04d051','702d120f7b0e42f690a0e71e96dc7ae0','12');----
INSERT INTO word VALUES ('293c88ba277044b6a2f32aafa5cb1910','windy','[ˈwɪndi:]','http://res.iciba.com/resource/amp3/oxford/0/c2/08/c208406d1397d48d9664ac4cc29cac1d.mp3','adj. 多风的，大风的','','');----
INSERT INTO classwords VALUES ('89b1cd7519b5450684cedcf75e073608','293c88ba277044b6a2f32aafa5cb1910','12');----
INSERT INTO word VALUES ('82079aad1a9849dbad793b37e9ce3bf3','drastic','[ˈdræstik]','http://res.iciba.com/resource/amp3/oxford/0/77/c0/77c0819458498aa4951d17d99144e99f.mp3','adj. 激烈的；严厉的','','');----
INSERT INTO classwords VALUES ('92c059ebb588448eb9f0fc0a560416e0','82079aad1a9849dbad793b37e9ce3bf3','12');----
INSERT INTO word VALUES ('4b6505e2c117479ea25c95ba5caf3e39','germ','[dʒə:m]','http://res.iciba.com/resource/amp3/0/0/f0/1d/f01d8c3f0a498f90ad5cac2201a11cc4.mp3','n. 细菌；病菌；起源，发端','','');----
INSERT INTO classwords VALUES ('97c15bcf4e10496a9dd4fb6f10df59c2','4b6505e2c117479ea25c95ba5caf3e39','12');----
INSERT INTO word VALUES ('7dbca4bab4974a38b42c08257678703e','gathering','[ˈgæðərɪŋ]','http://res.iciba.com/resource/amp3/oxford/0/9c/e7/9ce7224c3776390009f1426becb01de1.mp3','n. 集会；聚会；聚集','','');----
INSERT INTO classwords VALUES ('4fe970f72fa94dd3ba886f791ff45a63','7dbca4bab4974a38b42c08257678703e','12');----
INSERT INTO word VALUES ('d2f14e80c1304e4b9f1b39167e13c065','thesis','[ˈθi:sis]','http://res.iciba.com/resource/amp3/oxford/0/cc/9c/cc9c579b7a4b6bdb54219757444db7c1.mp3','n. 命题，论点；论文','','');----
INSERT INTO classwords VALUES ('5c02618c9a704de58c9c72fd454e5162','d2f14e80c1304e4b9f1b39167e13c065','12');----
INSERT INTO word VALUES ('7c0edcd6c41b4637b3d9029dc132d7e6','burner','[ˈbɜ:nə]','http://res.iciba.com/resource/amp3/oxford/0/ce/9d/ce9ddc254db24c1c160c78456b19697a.mp3','n. 炉头，燃烧器','','');----
INSERT INTO classwords VALUES ('6dd14ed7e6494833a01fa786175ae262','7c0edcd6c41b4637b3d9029dc132d7e6','12');----
INSERT INTO word VALUES ('6f484962e2e648fc9c68e3d18bf70238','violent','[ˈvaiələnt]','http://res.iciba.com/resource/amp3/oxford/0/55/bb/55bb6c413c84a11a8e2ff76a0e9cb417.mp3','adj. 粗暴的；剧烈的；强烈的','','');----
INSERT INTO classwords VALUES ('b9bba49212db4cca888c3cda9649fb24','6f484962e2e648fc9c68e3d18bf70238','12');----
INSERT INTO word VALUES ('2852da1cc570432cb69795d62c61ce75','prudent','[ˈpru:dnt]','http://res.iciba.com/resource/amp3/oxford/0/15/80/1580640dc7894b98aa057d10b2c2a6c2.mp3','adj. 谨慎的；精明的','','');----
INSERT INTO classwords VALUES ('342f4ba6f84e4f1e9add441584adb7c0','2852da1cc570432cb69795d62c61ce75','12');----
INSERT INTO word VALUES ('1bff0933ff614022a16ea474ddc2f0f3','retard','[rɪˈtɑ:d]','http://res.iciba.com/resource/amp3/0/0/1d/12/1d123b3c5603b87fd84e1a48ba0bed6c.mp3','vt. 延迟，减缓','','');----
INSERT INTO classwords VALUES ('f8da9a6fb1af4aafb5c0d628d83f95d3','1bff0933ff614022a16ea474ddc2f0f3','12');----
INSERT INTO word VALUES ('ba6f484ad1c34051846a81a218848f3f','subdivide','[ˌsʌbdɪˈvaɪd]','http://res.iciba.com/resource/amp3/oxford/0/8d/94/8d940fcc6f2906ad6e7b2efbd69ef0f2.mp3','vt. 把…再分','','');----
INSERT INTO classwords VALUES ('60418315155647ce837204c075cf5e72','ba6f484ad1c34051846a81a218848f3f','12');----
INSERT INTO word VALUES ('3b7682d233ec41e09753106698696243','proficiency','[prəˈfiʃənsi]','http://res.iciba.com/resource/amp3/0/0/bb/e5/bbe573f4fc17a9c1900d559b703221fc.mp3','n. 熟练，精通','','');----
INSERT INTO classwords VALUES ('572b43a39aea407cb09071d9213f7673','3b7682d233ec41e09753106698696243','12');----
INSERT INTO word VALUES ('194094104bd14403bcb774c922cbcc2a','doctrine','[ˈdɔktrin]','http://res.iciba.com/resource/amp3/oxford/0/bf/21/bf21190f4e13a122546635e6e5aad2b7.mp3','n. 信条；主义；学说；正式声明','','');----
INSERT INTO classwords VALUES ('a0aa216831574f14860015a443136d3e','194094104bd14403bcb774c922cbcc2a','12');----
INSERT INTO word VALUES ('5369741e672c462e875e8accc46cbccf','spectator','[spekˈteitə]','http://res.iciba.com/resource/amp3/1/0/a9/bf/a9bfaef562396c30abed90577ebc00c1.mp3','n. 旁观者，观众','','');----
INSERT INTO classwords VALUES ('8b624c39517640e7bb5664b4e738efe0','5369741e672c462e875e8accc46cbccf','12');----
INSERT INTO word VALUES ('cb8bb5d173754a8488f4e3e0dee8ef40','resign','[rɪˈzaɪn]','http://res.iciba.com/resource/amp3/oxford/0/5d/04/5d04157174c0ead9a374e1eb20d11bab.mp3','vt. 使顺从；辞职；放弃','','');----
INSERT INTO classwords VALUES ('0b8b47b0784544fb8bec5857c0340fbb','cb8bb5d173754a8488f4e3e0dee8ef40','12');----
INSERT INTO word VALUES ('efead6128846420ca4d4e5f23160a606','reverse','[riˈvə:s]','http://res.iciba.com/resource/amp3/0/0/4d/9c/4d9c2073afa3c2abb817dceb22c34de6.mp3','vt.&vi. 逆转；颠倒；交换；倒车','','');----
INSERT INTO classwords VALUES ('24565e02a23f44ceb86ca68c9651adf5','efead6128846420ca4d4e5f23160a606','12');----
INSERT INTO word VALUES ('dca2b5b3efb0477ca1eb2d2054879496','humanitarian','[hju:ˌmænɪˈteəri:ən]','http://res.iciba.com/resource/amp3/oxford/0/33/dd/33dd0f2afd86661060a6caaedc8642c4.mp3','n. 慈善家；人道主义者','','');----
INSERT INTO classwords VALUES ('4efe96b139374985b80b3cb0455211fd','dca2b5b3efb0477ca1eb2d2054879496','12');----
INSERT INTO word VALUES ('b5ede354ba9c4aa983728b520d9ee9c0','ascertain','[ˌæsəˈtein]','http://res.iciba.com/resource/amp3/oxford/0/2b/ca/2bca411f9e90706c20f14c226b2892d9.mp3','vt. 查明，确定，弄清','','');----
INSERT INTO classwords VALUES ('b612e153b2234d9790c2ddfdafe5146d','b5ede354ba9c4aa983728b520d9ee9c0','12');----
INSERT INTO word VALUES ('d3acabbbe3a0427f9041fefed572454a','versus','[ˈvə:səs]','http://res.iciba.com/resource/amp3/0/0/da/cf/dacf99808118dddb6c58361ee2ba6a6a.mp3','prep. 与…相对；与…对阵','','');----
INSERT INTO classwords VALUES ('51a04b62c8d541f99e1ee63c5af9785c','d3acabbbe3a0427f9041fefed572454a','12');----
INSERT INTO word VALUES ('58993d88b29f4613ad5e2a99ff8be3ab','summon','[ˈsʌmən]','http://res.iciba.com/resource/amp3/oxford/0/b9/42/b9428f189d2cee0fd9e8d1bb6317dd3c.mp3','vt. 召唤；鼓起（勇气）','','');----
INSERT INTO classwords VALUES ('2878804148044894821d5f2344442e4a','58993d88b29f4613ad5e2a99ff8be3ab','12');----
INSERT INTO word VALUES ('dba85bb1cd274a808d36048a56ae9aba','inject','[inˈdʒekt]','http://res.iciba.com/resource/amp3/oxford/0/85/30/85306b33d2cc8d29304537bdbac52999.mp3','vt. 注射；添加；投入','','');----
INSERT INTO classwords VALUES ('70f5cf083186460790aa3efcfb5d8c3c','dba85bb1cd274a808d36048a56ae9aba','12');----
INSERT INTO word VALUES ('664c0073225d4ee498227df24dbabac2','maiden','[ˈmeidn]','http://res.iciba.com/resource/amp3/oxford/0/c0/42/c04236229bab8c0731eb4ab187ee3d69.mp3','n. 少女；未婚女子','','');----
INSERT INTO classwords VALUES ('f0ec36e9908d4bda89a4081147bab9a5','664c0073225d4ee498227df24dbabac2','12');----
INSERT INTO word VALUES ('f44318878eac45849c73aa0c44e09568','lathe','[leɪð]','http://res.iciba.com/resource/amp3/oxford/0/a9/b0/a9b08d71eed1a7f5be7a8bceff9b77e4.mp3','vt. 用车床加工','','');----
INSERT INTO classwords VALUES ('fcdbd07ba2974af7a0c81fba156d2347','f44318878eac45849c73aa0c44e09568','12');----
INSERT INTO word VALUES ('e5d92963eee24ffebbf1fd3fef6020e7','affirm','[əˈfə:m]','http://res.iciba.com/resource/amp3/0/0/9d/15/9d15030baa03875c241ef89f58d36faa.mp3','vt. 断言；证实','','');----
INSERT INTO classwords VALUES ('f1b81af6f31042b9a849d7b1ee063551','e5d92963eee24ffebbf1fd3fef6020e7','12');----
INSERT INTO word VALUES ('a89c043a6b794fefba1ebccd7ca3672e','check','[tʃek]','http://res.iciba.com/resource/amp3/oxford/0/69/32/69323f2723475c7d55ebe5e1bf277b8f.mp3','n. 支票；结帐单','','');----
INSERT INTO classwords VALUES ('440da6d3706049139442d10a10520fb7','a89c043a6b794fefba1ebccd7ca3672e','12');----
INSERT INTO word VALUES ('37514809a13e49fab07a1e88b4c83534','suitcase','[ˈsju:tkeis]','http://res.iciba.com/resource/amp3/oxford/0/fd/fc/fdfc16076b288d5aa87167d791437ae8.mp3','n. 手提箱，衣箱','','');----
INSERT INTO classwords VALUES ('904be13158024955a66ca786f8d62266','37514809a13e49fab07a1e88b4c83534','12');----
INSERT INTO word VALUES ('b09dc63a96b140e7b074acab208467cf','routine','[ru:ˈti:n]','http://res.iciba.com/resource/amp3/oxford/0/3a/bd/3abd6e9c6f4abb4b327822b8b45a637f.mp3','n. 常规；例行公事；平淡乏味','','');----
INSERT INTO classwords VALUES ('ea23ee444fed4bcdba995cf1d5baf72f','b09dc63a96b140e7b074acab208467cf','12');----
INSERT INTO word VALUES ('76a8c0fe8edc48bca6c62f048b942f7d','hostile','[ˈhɔstail]','http://res.iciba.com/resource/amp3/0/0/8e/20/8e20e5f0a627b4dd4dedc41a597ab672.mp3','adj. 敌对的；怀有敌意的；不友善的；...','','');----
INSERT INTO classwords VALUES ('d0d7279c49824e46b226c4ef08236fe8','76a8c0fe8edc48bca6c62f048b942f7d','12');----
INSERT INTO word VALUES ('2174b35e74c14572b3309a14be288e34','split','[split]','http://res.iciba.com/resource/amp3/oxford/0/99/76/9976787c9b6ff2c2cee4bc6480450b87.mp3','v. 使分裂；使裂开；开裂','','');----
INSERT INTO classwords VALUES ('136b21ae26724514bff121db27b11b28','2174b35e74c14572b3309a14be288e34','12');----
INSERT INTO word VALUES ('afe3d4d2cef445b59742d91d32074621','album','[ˈælbəm]','http://res.iciba.com/resource/amp3/oxford/0/fa/af/faaf5f19cbd636955bcba226d3a68939.mp3','n. 唱片集；相册','','');----
INSERT INTO classwords VALUES ('ed0e8217a69a4b2284ef83ae150d7b63','afe3d4d2cef445b59742d91d32074621','12');----
INSERT INTO word VALUES ('9ad6905c3c894e69b66da0307345016d','symposium','[simˈpəuziəm]','http://res.iciba.com/resource/amp3/oxford/0/ea/39/ea39079ba009bc8584d3202ee59291f9.mp3','n. 专题讨论会，研讨会','','');----
INSERT INTO classwords VALUES ('715a6e84d9b548aa93309419a283553d','9ad6905c3c894e69b66da0307345016d','12');----
INSERT INTO word VALUES ('45024669af854a4e8f99c088c4fc6f2a','likeness','[ˈlaɪknɪs]','http://res.iciba.com/resource/amp3/oxford/0/26/4e/264ef4fcbf55896f8119d8e0d23fda96.mp3','n. 相象，相似；肖像，照片','','');----
INSERT INTO classwords VALUES ('fb0639018c2040b2932cbddf9800a7c1','45024669af854a4e8f99c088c4fc6f2a','12');----
INSERT INTO word VALUES ('510e414e4fd7407d8f0129b4b536f32f','speculate','[ˈspekjuleit]','http://res.iciba.com/resource/amp3/oxford/0/a4/cd/a4cd5c99e02d5da72f79e302670b55f2.mp3','vi. 思索；推测；投机','','');----
INSERT INTO classwords VALUES ('29d0df84bae2430c9762b73bf317927d','510e414e4fd7407d8f0129b4b536f32f','12');----
INSERT INTO word VALUES ('81aedf065ac445129d32af26f51b71df','suit','[sju:t]','http://res.iciba.com/resource/amp3/oxford/0/f0/0e/f00ec0b42db2ee16b6fdd4e2266ea411.mp3','n. 套装；套裙','','');----
INSERT INTO classwords VALUES ('96d263c2af704ef89bdfda345a9629f4','81aedf065ac445129d32af26f51b71df','12');----
INSERT INTO word VALUES ('b5222988e9f9472191f62f1e0863cdd8','marvel','[ˈmɑ:vəl]','http://res.iciba.com/resource/amp3/0/0/0e/56/0e561187d51609f59a35e1079f062c7a.mp3','vt. 惊叹不已','','');----
INSERT INTO classwords VALUES ('057669afff0e4974b7da6d54f8511d65','b5222988e9f9472191f62f1e0863cdd8','12');----
INSERT INTO word VALUES ('c94ac66a0dbc4b01ad7329bd2acaca27','ingenious','[inˈdʒi:njəs]','http://res.iciba.com/resource/amp3/oxford/0/5e/ec/5eec56987d5307e611e234b9f1b247eb.mp3','adj. 机灵的；制作精巧的','','');----
INSERT INTO classwords VALUES ('70542cec8c724e1998ebbd9d5b6f54cc','c94ac66a0dbc4b01ad7329bd2acaca27','12');----
INSERT INTO word VALUES ('b0fb05ff969449e4a93b075de89d3cb0','shrill','[ʃrɪl]','http://res.iciba.com/resource/amp3/oxford/0/d3/a1/d3a1b04d1ca3cb3a2b39d96dc872aad9.mp3','vt. 尖声地叫；发出刺耳的声音','','');----
INSERT INTO classwords VALUES ('43b6e31bc02d41cc98c0198b1a410077','b0fb05ff969449e4a93b075de89d3cb0','12');----
INSERT INTO word VALUES ('3b7ced7f25ce449399b9095cfca5e082','constituent','[kənˈstitjuənt]','http://res.iciba.com/resource/amp3/oxford/0/e9/3a/e93ad9e0132eaf7cb356f0d1cfd48603.mp3','n. 选民；成分','','');----
INSERT INTO classwords VALUES ('53c49b6966534eaba6523119787b6d3c','3b7ced7f25ce449399b9095cfca5e082','12');----
INSERT INTO word VALUES ('7a165f99b03148c49396d09a3e1c59fe','assault','[əˈsɔ:lt]','http://res.iciba.com/resource/amp3/oxford/0/7c/67/7c673335bb127deef9ca036a936a7528.mp3','n. 攻击；猛攻；人身攻击','','');----
INSERT INTO classwords VALUES ('225c7e50bd04409d8629855dc68f20ce','7a165f99b03148c49396d09a3e1c59fe','12');----
INSERT INTO word VALUES ('ad03fe0ed0774363a00769e5ae8c6956','orient','[ˈɔ:riənt]','http://res.iciba.com/resource/amp3/oxford/0/8f/79/8f792fe0caf71a041114723e2d756bc7.mp3','n. 东方，亚洲','','');----
INSERT INTO classwords VALUES ('fabab0084cc0496d95efeafdedde4085','ad03fe0ed0774363a00769e5ae8c6956','12');----
INSERT INTO word VALUES ('db24e66befb340e69f2fe939bc62cdda','disturbance','[disˈtə:bəns]','http://res.iciba.com/resource/amp3/oxford/0/bf/ba/bfba299c18a3e52234fe5747b5f0d26f.mp3','n. 动乱，骚乱；干扰；困扰','','');----
INSERT INTO classwords VALUES ('b5b212313a6545bfab8bd864d9f61560','db24e66befb340e69f2fe939bc62cdda','12');----
INSERT INTO word VALUES ('561eb36ba31e47ceb01f28949ed49e8f','mountainous','[ˈmaʊntənəs]','http://res.iciba.com/resource/amp3/oxford/0/84/6a/846ad82aa050ba4bcf7caee75ebeece4.mp3','adj. 多山的；波涛汹涌的；庞大的','','');----
INSERT INTO classwords VALUES ('574bd7a11696401ba9f61a346494c1eb','561eb36ba31e47ceb01f28949ed49e8f','12');----
INSERT INTO word VALUES ('cb06f8b924554b42836132738bf95fcd','jack','[dʒæk]','http://res.iciba.com/resource/amp3/oxford/0/cf/85/cf85d456dc59933abe74ccf56a9c0c77.mp3','n. 千斤顶','','');----
INSERT INTO classwords VALUES ('e0c4feac24d94877a236f4e0f20b2049','cb06f8b924554b42836132738bf95fcd','12');----
INSERT INTO word VALUES ('1d18f4f26bc34264b4ba9f0518c2157d','reptile','[ˈreptail]','http://res.iciba.com/resource/amp3/oxford/0/23/ad/23ada9eed4e1e6fbb859d847df581a30.mp3','n. 爬行动物','','');----
INSERT INTO classwords VALUES ('ef1174ee849d48bc850f39d667718297','1d18f4f26bc34264b4ba9f0518c2157d','12');----
INSERT INTO word VALUES ('4dd8352429304a83a25f856cdd330439','enrich','[inˈritʃ]','http://res.iciba.com/resource/amp3/oxford/0/fc/c5/fcc58464b3801319603d64e2d56ccd99.mp3','vt. 使富裕；使丰富','','');----
INSERT INTO classwords VALUES ('2f50e36da20e4d91a7ff13bd171f6dcb','4dd8352429304a83a25f856cdd330439','12');----
INSERT INTO word VALUES ('44f0627f7f3d4ab19e995a915913da3c','lunar','[ˈlju:nə]','http://res.iciba.com/resource/amp3/oxford/0/6b/9a/6b9ac107aa48206f45b11ff3ba1e3a7e.mp3','adj. 月亮的；月球的','','');----
INSERT INTO classwords VALUES ('5dd3d03c68204edaa4e3c7c77cd9567f','44f0627f7f3d4ab19e995a915913da3c','12');----
INSERT INTO word VALUES ('bf198f3f3eee4da69e3114e1cc2b99be','idealism','[aɪˈdi:əˌlɪzəm]','http://res.iciba.com/resource/amp3/oxford/0/b5/ad/b5ad7ec211bc11520e79e09e5a46680d.mp3','n. 理想主义','','');----
INSERT INTO classwords VALUES ('3d1b16aea5e949c79ee336429e8c96e2','bf198f3f3eee4da69e3114e1cc2b99be','12');----
INSERT INTO word VALUES ('84a7595e7f954e00b4a371dd02bd5cc9','quantify','[ˈkwɔntifai]','http://res.iciba.com/resource/amp3/oxford/0/0e/c6/0ec6888d1d1b7e1dd6eccf13dc42b926.mp3','vt. 确定…的数量','','');----
INSERT INTO classwords VALUES ('40d71b741bfa4db284ecb14390cbca55','84a7595e7f954e00b4a371dd02bd5cc9','12');----
INSERT INTO word VALUES ('b8bd8e16123e441e8e8535dcfc16457e','elliptical','[iˈliptikəl]','http://res.iciba.com/resource/amp3/oxford/0/2a/9d/2a9d0117c101bbf742b3cc23fc01eb56.mp3','adj. 椭圆的；隐讳的，间接的','','');----
INSERT INTO classwords VALUES ('42331c1461554c6ab9ba29fb4ae24e2a','b8bd8e16123e441e8e8535dcfc16457e','12');----
INSERT INTO word VALUES ('36ee13f6023f4bd9a70902cf781ccb08','symmetry','[ˈsimitri]','http://res.iciba.com/resource/amp3/oxford/0/8f/8b/8f8b4943198f8bb862ad1b006a29e3ea.mp3','n. 对称，匀称；相等，相当','','');----
INSERT INTO classwords VALUES ('69d271d3f4bb45f2b1699b2c492afd25','36ee13f6023f4bd9a70902cf781ccb08','12');----
INSERT INTO word VALUES ('76fb098bce2f41a89fca050ec581be62','presentation','[ˌprezənˈteiʃən]','http://res.iciba.com/resource/amp3/oxford/0/de/c7/dec779898fa1489c5c3ea00d9ec83450.mp3','n. 介绍；报告；外观；表演','','');----
INSERT INTO classwords VALUES ('facce301801d4cd5829322996feb7163','76fb098bce2f41a89fca050ec581be62','12');----
INSERT INTO word VALUES ('c343e43ae09b468999341a4d56cb786b','ohm','[əʊm]','http://res.iciba.com/resource/amp3/0/0/35/46/35464785f1a8901da7d158145ec47417.mp3','n. 欧姆（电阻单位）','','');----
INSERT INTO classwords VALUES ('3227c88c07ef46738148822b00bc67ae','c343e43ae09b468999341a4d56cb786b','12');----
INSERT INTO word VALUES ('db8d9da470154e36b4b5a3e734bb7587','illiterate','[ɪˈlɪtərɪt]','http://res.iciba.com/resource/amp3/oxford/0/83/b4/83b40ad1b6eb2e52bcec344e5fa8b941.mp3','n. 文盲','','');----
INSERT INTO classwords VALUES ('1cc782d00c064636a9cc608c587d30da','db8d9da470154e36b4b5a3e734bb7587','12');----
INSERT INTO word VALUES ('31154285a5324f68b351dec11a7d92a8','dissipate','[ˈdisipeit]','http://res.iciba.com/resource/amp3/oxford/0/86/2f/862f9848015b7a04c4375cc0b490b268.mp3','vi. 消散','','');----
INSERT INTO classwords VALUES ('444eb07a47034351b8ddcd80716bce4a','31154285a5324f68b351dec11a7d92a8','12');----
INSERT INTO word VALUES ('978b81345a6c4c34b3634dd0fb8f1aa0','uproar','[ˈʌpˌrɔ:]','http://res.iciba.com/resource/amp3/oxford/0/50/ae/50ae106b0b99c402172e3ac16d012ec4.mp3','n. 骚动；喧嚣','','');----
INSERT INTO classwords VALUES ('6acf329aae504a268270bfc08a96ce82','978b81345a6c4c34b3634dd0fb8f1aa0','12');----
INSERT INTO word VALUES ('250313f56afd4c13b045d3267c5b8087','momentary','[ˈməʊmənˌteri:]','http://res.iciba.com/resource/amp3/0/0/ab/0d/ab0dec207767fe63fee0b3d374dff6c6.mp3','adj. 瞬息的，片刻的','','');----
INSERT INTO classwords VALUES ('5cbbd39055f342aaa29b0036497fa09a','250313f56afd4c13b045d3267c5b8087','12');----
INSERT INTO word VALUES ('11747f431bc848b19c831f28acb685a9','ornament','[ˈɔ:nəmənt]','http://res.iciba.com/resource/amp3/oxford/0/12/c6/12c6cf8f21baf436c18aed8320401d29.mp3','vt. 装饰，点缀','','');----
INSERT INTO classwords VALUES ('3d29220b906241a2afa4277fec2e9970','11747f431bc848b19c831f28acb685a9','12');----
INSERT INTO word VALUES ('54218240bb7e4b33bbbd83dcfa34b3b2','bandit','[ˈbændit]','http://res.iciba.com/resource/amp3/oxford/0/a5/8c/a58cd4532bfc7e0c59766c0a538360fe.mp3','n. 土匪，盗匪，歹徒','','');----
INSERT INTO classwords VALUES ('09794b3d337d4edc814df6b3d044bdde','54218240bb7e4b33bbbd83dcfa34b3b2','12');----
INSERT INTO word VALUES ('2dab0f64aa2a4374829928a0c00054c3','straighten','[ˈstreɪtn]','http://res.iciba.com/resource/amp3/oxford/0/03/68/0368ad660f1e920f56948e4af68c70d8.mp3','vi. 挺起来','','');----
INSERT INTO classwords VALUES ('665145226d4146adab9e20612a288738','2dab0f64aa2a4374829928a0c00054c3','12');----
INSERT INTO word VALUES ('e3763463959c4a63a2bd4dd34dabfd44','intercourse','[ˈintəkɔ:s]','http://res.iciba.com/resource/amp3/0/0/03/fd/03fdf643b20c097d77daa3e8066d5554.mp3','n. 交际，往来，交往','','');----
INSERT INTO classwords VALUES ('0f824687b08249ebad467a32032f90c3','e3763463959c4a63a2bd4dd34dabfd44','12');----
INSERT INTO word VALUES ('c4af2ead59c4462aa4b0a6b7ccec0b84','numerical','[nju:ˈmerikəl]','http://res.iciba.com/resource/amp3/oxford/0/af/a0/afa059e8ca4b23dd11d23feb73e7fba6.mp3','adj. 数字的，数值的','','');----
INSERT INTO classwords VALUES ('51b0f6fcf00d4cc0b4fcc50175f41c12','c4af2ead59c4462aa4b0a6b7ccec0b84','12');----
INSERT INTO word VALUES ('1a95a2cb46aa4023bc20072c5c8bd701','scorch','[skɔ:tʃ]','http://res.iciba.com/resource/amp3/0/0/bf/4d/bf4d9300fc35431eb3ac982c17b6dd0d.mp3','vi. 烧焦；疾驰','','');----
INSERT INTO classwords VALUES ('9b42eb38ac79470087b58ba73b4a32d2','1a95a2cb46aa4023bc20072c5c8bd701','12');----
INSERT INTO word VALUES ('88e734ad3be44a61a8d48444f7c9fb8b','martyr','[ˈmɑ:tə]','http://res.iciba.com/resource/amp3/oxford/0/1a/ee/1aeee0d49f15ecde37243c25626d8a84.mp3','n. 烈士，殉难者；深受…之苦者','','');----
INSERT INTO classwords VALUES ('e70925742ae24a8cac85857a51d33c9f','88e734ad3be44a61a8d48444f7c9fb8b','12');----
INSERT INTO word VALUES ('d8a685f20ffb4e40997d165d224c3971','stray','[strei]','http://res.iciba.com/resource/amp3/oxford/0/ce/a1/cea18c9e29264f48d40bc23e31011ff1.mp3','adj. 迷路的；零星的','','');----
INSERT INTO classwords VALUES ('46ff963e5da04399a9fc1654da26d464','d8a685f20ffb4e40997d165d224c3971','12');----
INSERT INTO word VALUES ('e18d1e1d5b7b473d86909b7780b6d347','cheat','[tʃi:t]','http://res.iciba.com/resource/amp3/oxford/0/6f/be/6fbe9c18d0e861d817831cbe60db0c69.mp3','v. 欺诈；骗取；作弊','','');----
INSERT INTO classwords VALUES ('2a4e99f8912d4495ba6434fb9489e149','e18d1e1d5b7b473d86909b7780b6d347','12');----
INSERT INTO word VALUES ('4e5eb58c91df4aa68990b5501962e12b','ferry','[ˈferi]','http://res.iciba.com/resource/amp3/oxford/0/70/06/70068b63b1b4e21b0df9380edecceaf5.mp3','vt. 运送，渡运','','');----
INSERT INTO classwords VALUES ('4dc0c53481ac4222be9ff2a200515456','4e5eb58c91df4aa68990b5501962e12b','12');----
INSERT INTO word VALUES ('8670018c6b7b431cac1a3d3023e75d5e','fret','[fret]','http://res.iciba.com/resource/amp3/oxford/0/71/9d/719d94911480be19e9c7786a4ff13814.mp3','vt.&vi. 烦恼；苦恼；发愁','','');----
INSERT INTO classwords VALUES ('503905a8e60e4fd59013a3a7da86c6c9','8670018c6b7b431cac1a3d3023e75d5e','12');----
INSERT INTO word VALUES ('dbc285251c85431d9cad470c52380a79','notorious','[nəuˈtɔ:riəs]','http://res.iciba.com/resource/amp3/oxford/0/af/a1/afa158b3f43e5851c734cc8f3e50b5a9.mp3','adj. 臭名昭著的；声名狼藉的','','');----
INSERT INTO classwords VALUES ('b5b6b86a399842159635ba36fb40ea45','dbc285251c85431d9cad470c52380a79','12');----
INSERT INTO word VALUES ('053b938517b94363be6e68f862ba2c19','construction','[kənˈstrʌkʃən]','http://res.iciba.com/resource/amp3/oxford/0/f3/d0/f3d014ca2cc17b374cd92fc6040ffc54.mp3','n. 建筑；建造；创建；建造物','','');----
INSERT INTO classwords VALUES ('d6da2d0884f84e9db24b52c8596dafbc','053b938517b94363be6e68f862ba2c19','12');----
INSERT INTO word VALUES ('25a0f9f9bcbe49bb971b30ef02dc3756','combat','[ˈkɔmbət]','http://res.iciba.com/resource/amp3/oxford/0/b9/9f/b99f163514899ec3f6fed16d0de83d72.mp3','n. 格斗，斗争，战斗','','');----
INSERT INTO classwords VALUES ('8814bb94b7e146a090002d85cbbb0c51','25a0f9f9bcbe49bb971b30ef02dc3756','12');----
INSERT INTO word VALUES ('ea22e749fe164b5c8298421c1b4de98d','panel','[ˈpænəl]','http://res.iciba.com/resource/amp3/oxford/0/fe/76/fe76246caa43680316d9b71e79c697ab.mp3','n. 专门小组；镶板；面板','','');----
INSERT INTO classwords VALUES ('46088082088541d0a147d8466817284f','ea22e749fe164b5c8298421c1b4de98d','12');----
INSERT INTO word VALUES ('e3e6b207e6a940d695d1c9bc3bd8dc5e','cosmos','[ˈkɔzməs]','http://res.iciba.com/resource/amp3/0/0/39/89/3989da4eb832867da1eb82598a780c37.mp3','n. 宇宙','','');----
INSERT INTO classwords VALUES ('72f3c465547a4910bb7a63a4f8e385d9','e3e6b207e6a940d695d1c9bc3bd8dc5e','12');----
INSERT INTO word VALUES ('59911f539310457eba7375f59325a581','otherwise','[ˈʌðəwaiz]','http://res.iciba.com/resource/amp3/0/0/72/99/72992fb088bfa63dcb49ef663fcdfe53.mp3','adv. 否则；另外；与之不同地','','');----
INSERT INTO classwords VALUES ('269336d42a0a4ebeacfbb455aed16f1a','59911f539310457eba7375f59325a581','12');----
INSERT INTO word VALUES ('0c77d3f9f50f4e58845aad98a775f8ea','tiresome','[ˈtaiəsəm]','http://res.iciba.com/resource/amp3/0/0/ab/51/ab511d4e113201f15d116a1bef03634f.mp3','adj. 使人厌倦的，讨厌的，烦人的','','');----
INSERT INTO classwords VALUES ('a8201b5cc334431bb34c47cf6564ada1','0c77d3f9f50f4e58845aad98a775f8ea','12');----
INSERT INTO word VALUES ('4ef4154f2afe4f92978d73c52615b0da','finely','[ˈfaɪnlɪ]','http://res.iciba.com/resource/amp3/oxford/0/fc/34/fc34e5cf6a121de3b7c927efb26c606b.mp3','adv. 精细地；微细地','','');----
INSERT INTO classwords VALUES ('3de19648d8cb4b21b31a63331fd97786','4ef4154f2afe4f92978d73c52615b0da','12');----
INSERT INTO word VALUES ('62aa5b0b26a44ea39b27781f16101849','correlate','[ˈkɔrileit]','http://res.iciba.com/resource/amp3/oxford/0/0d/b4/0db4a19210c8924f915b97f4bffc7bad.mp3','v. 相互关联；使显示联系','','');----
INSERT INTO classwords VALUES ('7c3a94df39774c1eb9e4cb3f18f7bbbd','62aa5b0b26a44ea39b27781f16101849','12');----
INSERT INTO word VALUES ('4085742370034c059129a9300b283c8e','thrash','[θræʃ]','http://res.iciba.com/resource/amp3/oxford/0/3b/15/3b158cde21d1f68e3815c4d5f8f471b1.mp3','vi. 拍打','','');----
INSERT INTO classwords VALUES ('7641e7430c38493e81447871f5d27736','4085742370034c059129a9300b283c8e','12');----
INSERT INTO word VALUES ('fe8f2ef1fe0046c8b1fd6ba7b6b95314','pacific','[pəˈsɪfɪk]','http://res.iciba.com/resource/amp3/oxford/0/1b/8a/1b8a63ec9b672b3878d82e2c6f27b0f2.mp3','adj. 爱好和平的','','');----
INSERT INTO classwords VALUES ('d52b1761c53d49cbb90eb3085d88df29','fe8f2ef1fe0046c8b1fd6ba7b6b95314','12');----
INSERT INTO word VALUES ('dfdb80a79fd942248c896e3be3489e03','elegant','[ˈeliɡənt]','http://res.iciba.com/resource/amp3/oxford/0/14/ea/14ea83cd88f2eaf06bcc3234f52eaf53.mp3','adj. （人或物）典雅的；简洁的，简练...','','');----
INSERT INTO classwords VALUES ('8e4226fd7e2c430680cc252a8df7810e','dfdb80a79fd942248c896e3be3489e03','12');----
INSERT INTO word VALUES ('b75e880054324df097191976054439a6','parachute','[ˈpærəʃu:t]','http://res.iciba.com/resource/amp3/oxford/0/73/3b/733b58eb170c4695831bf2daf0c16805.mp3','n. 降落伞；风散种子','','');----
INSERT INTO classwords VALUES ('248153c6692e4bfb80fb6cf6dde9a614','b75e880054324df097191976054439a6','12');----
INSERT INTO word VALUES ('5d149895417b46a1983715c50c0edf89','extreme','[iksˈtri:m]','http://res.iciba.com/resource/amp3/oxford/0/62/fb/62fb6fdf09375c48d8a77646e1888713.mp3','adj. 极其的；极端的；偏激的；末端的','','');----
INSERT INTO classwords VALUES ('67d311e3022042178b8f12b12f563802','5d149895417b46a1983715c50c0edf89','12');----
INSERT INTO word VALUES ('80b7c3d64d214afc91da98a555105167','experimentall...','[ɪksˌperɪˈmentəlɪ]','http://res.iciba.com/resource/amp3/0/0/0e/93/0e937eead81622a87b0e5e61caacf60e.mp3','adv. 实验上；实验性地','','');----
INSERT INTO classwords VALUES ('886103cdf52f496e98372800dbb7a310','80b7c3d64d214afc91da98a555105167','12');----
INSERT INTO word VALUES ('e0746edab58c492694987093f67e3424','impress','[imˈpres]','http://res.iciba.com/resource/amp3/oxford/0/c2/86/c286dd07bf71418ab67a4f39dd9cc0ef.mp3','vt. 给…深刻印象；使铭记；使…注意到','','');----
INSERT INTO classwords VALUES ('3f89a143732441c7877e035e0703e3d3','e0746edab58c492694987093f67e3424','12');----
INSERT INTO word VALUES ('941794ec2b6f4c388cd5f8daa423de34','limestone','[ˈlaɪmˌstəʊn]','http://res.iciba.com/resource/amp3/oxford/0/d6/ec/d6ec0b1bc2edbc5098af11c7d8568159.mp3','n. 石灰岩','','');----
INSERT INTO classwords VALUES ('19127afe6b954c2f89b3aeb859169e51','941794ec2b6f4c388cd5f8daa423de34','12');----
INSERT INTO word VALUES ('39b57d172dea4d64b1adb0ea5bce9d3e','refugee','[ˌrefjuˈdʒi:]','http://res.iciba.com/resource/amp3/oxford/0/43/2d/432d0d7cc3f54341c1c2126195898c79.mp3','n. 难民，避难者','','');----
INSERT INTO classwords VALUES ('3ebee915330d42eb8921e91bdd177cf9','39b57d172dea4d64b1adb0ea5bce9d3e','12');----
INSERT INTO word VALUES ('d5b5a2c2b010432cb755468bcc4ca2c0','second-hand','','http://res.iciba.com/resource/amp3/0/0/86/bf/86bf57b79644bcb534effdc613820d8b.mp3','n. 旧的，第二手的','','');----
INSERT INTO classwords VALUES ('e236d3eece6048b6bcd8d9797ced51e1','d5b5a2c2b010432cb755468bcc4ca2c0','12');----
INSERT INTO word VALUES ('44432c58ef8741a89e0fdef61b10083c','outline','[ˈautlain]','http://res.iciba.com/resource/amp3/oxford/0/27/b2/27b22ed6ae0bb24c53e794afcbd5ba5d.mp3','vt. 概述，概括；显示…的轮廓','','');----
INSERT INTO classwords VALUES ('f7c12ef86e25403db5cf839f2fa9db25','44432c58ef8741a89e0fdef61b10083c','12');----
INSERT INTO word VALUES ('022ab145cb674064ab00b0d2ddd33034','stairway','[ˈsteəˌweɪ]','http://res.iciba.com/resource/amp3/0/0/b2/75/b27513b9ec8d20ca3ed722acf7b702d5.mp3','n. 楼梯','','');----
INSERT INTO classwords VALUES ('f293127531224be1a6c2c31284f77fb4','022ab145cb674064ab00b0d2ddd33034','12');----
INSERT INTO word VALUES ('668d25f212794aaa9e1ce691ba232b9c','torment','[ˈtɔ:ment]','http://res.iciba.com/resource/amp3/oxford/0/67/d9/67d978110f47d8bbb6b70f4a78265d17.mp3','vt. 折磨；戏弄','','');----
INSERT INTO classwords VALUES ('3d6b3caf16cc4d7aabdf53c7d716e108','668d25f212794aaa9e1ce691ba232b9c','12');----
INSERT INTO word VALUES ('b7037a5837864fcd91e7e748ac8deaa6','locust','[ˈləʊkəst]','http://res.iciba.com/resource/amp3/oxford/0/7e/21/7e212cb22b91ad289cefe7b599899d04.mp3','n. 蝗虫','','');----
INSERT INTO classwords VALUES ('f31aec5ab6df460790f16af019e459bc','b7037a5837864fcd91e7e748ac8deaa6','12');----
INSERT INTO word VALUES ('5dedca281648439d8dc46b46a1dcc64f','magnetism','[ˈmægnɪˌtɪzəm]','http://res.iciba.com/resource/amp3/oxford/0/37/26/3726d221ba3ba2d57e61ef9e641e76da.mp3','n. 磁性；魅力','','');----
INSERT INTO classwords VALUES ('8e35addeb21b49ff800196417334155a','5dedca281648439d8dc46b46a1dcc64f','12');----
INSERT INTO word VALUES ('1f2371ea107e4dfb8cc3a0e3090ca446','warehouse','[ˈwɛəhaus]','http://res.iciba.com/resource/amp3/oxford/0/b5/e6/b5e6eae4900928997e520f5d3e4a6596.mp3','n. 仓库，货栈','','');----
INSERT INTO classwords VALUES ('5076f13aabf441b0bd784a183ffd30d2','1f2371ea107e4dfb8cc3a0e3090ca446','12');----
INSERT INTO word VALUES ('6da15296b1c945c2ae832a3f10cebbec','ear','[iə]','http://res.iciba.com/resource/amp3/0/0/d8/ff/d8ff99616fc9df8a54a32eec86ba8109.mp3','n. （谷类作物的）穗；耳朵；听觉，听力','','');----
INSERT INTO classwords VALUES ('cd7ed257325847ec8482b39e31f3ac8e','6da15296b1c945c2ae832a3f10cebbec','12');----
INSERT INTO word VALUES ('47ccab99117d42bdbddeb527f5dabd6e','mammal','[ˈmæməl]','http://res.iciba.com/resource/amp3/oxford/0/98/a3/98a3889833203e53c746db6eda62c45e.mp3','n. 哺乳动物','','');----
INSERT INTO classwords VALUES ('1e37ecb93fef43818bff4aba2d9d048c','47ccab99117d42bdbddeb527f5dabd6e','12');----
INSERT INTO word VALUES ('8f181e93b27d4275b95457d81c4054c1','tangle','[ˈtæŋɡl]','http://res.iciba.com/resource/amp3/oxford/0/4a/ef/4aef8b802cb214c980a279a8bb68daf1.mp3','vt. 使缠结；使缠绕；混乱','','');----
INSERT INTO classwords VALUES ('57ce9f639c9a4556a0cd69ba3d1a7eb0','8f181e93b27d4275b95457d81c4054c1','12');----
INSERT INTO word VALUES ('a5b3e0907712432bb2f79140905e02d1','persuasion','[pəˈsweiʒən]','http://res.iciba.com/resource/amp3/oxford/0/85/47/85479a0ad84c26e9b220ea07c43a7293.mp3','n. 劝说，说服；信仰','','');----
INSERT INTO classwords VALUES ('6cadd2445c234ca5943045670d1b7f79','a5b3e0907712432bb2f79140905e02d1','12');----
INSERT INTO word VALUES ('9f498a83544f4a2f9ba98ba3d2824500','exert','[iɡˈzə:t]','http://res.iciba.com/resource/amp3/0/0/ec/11/ec11570ae8cfaf0ae1ac496f897ec12a.mp3','vt. 施加（影响、压力等）；运用（权威...','','');----
INSERT INTO classwords VALUES ('fa510d86c7014423a7ee95e81ad50be5','9f498a83544f4a2f9ba98ba3d2824500','12');----
INSERT INTO word VALUES ('ede2437bbc014baebef8b17a3d3467e9','assert','[əˈsə:t]','http://res.iciba.com/resource/amp3/0/0/e4/4e/e44e4612f62d2fb8f8738bab118a9850.mp3','vt. 断言，宣称；维护；坚持','','');----
INSERT INTO classwords VALUES ('c8b4bf7713034563a85c58bbb8bcc3c4','ede2437bbc014baebef8b17a3d3467e9','12');----
INSERT INTO word VALUES ('556ceedcb55c452397ae4c5a376764ef','fixture','[ˈfikstʃə]','http://res.iciba.com/resource/amp3/oxford/0/d6/f2/d6f288dc49f700dd49bb3e9d4bfeac0a.mp3','n. 固定装置；定期存款；体育活动；常客','','');----
INSERT INTO classwords VALUES ('932982dc726949759882e2c9f4e98997','556ceedcb55c452397ae4c5a376764ef','12');----
INSERT INTO word VALUES ('63f0bec4e9de4903aabb1a26b99ab09d','grief','[ɡri:f]','http://res.iciba.com/resource/amp3/oxford/0/44/d5/44d533777e95f3e89fcf83755e71d3a7.mp3','n. 悲痛，悲伤','','');----
INSERT INTO classwords VALUES ('4d3f727c62dd45e48804889d72524238','63f0bec4e9de4903aabb1a26b99ab09d','12');----
INSERT INTO word VALUES ('16206bea19754a5b96d0eee05e02b48b','overall','[ˈəuvərɔ:l]','http://res.iciba.com/resource/amp3/oxford/0/c5/44/c544a920cceac1dcd363d1f2dd74f42e.mp3','n. 工作服；工装裤；罩衣','','');----
INSERT INTO classwords VALUES ('bf6cef1e74ab4ad1a722064b44c76b4c','16206bea19754a5b96d0eee05e02b48b','12');----
INSERT INTO word VALUES ('c66497913b9e4c6189495379a2d93450','souvenir','[ˈsu:vəniə]','http://res.iciba.com/resource/amp3/oxford/0/f7/ed/f7ed0aa930163f06fc1931bcb822d5b5.mp3','n. 纪念品','','');----
INSERT INTO classwords VALUES ('467607bb7a704a70a383fdab8389b5db','c66497913b9e4c6189495379a2d93450','12');----
INSERT INTO word VALUES ('a3814c3cc21343f2a8f19bf67a7a656d','manipulate','[məˈnipjuleit]','http://res.iciba.com/resource/amp3/oxford/0/62/93/62931c1573b701c7b24bc427cf4b6864.mp3','vt. 操作；控制；处理','','');----
INSERT INTO classwords VALUES ('4309a368bf384edd9852c18adc8f94c8','a3814c3cc21343f2a8f19bf67a7a656d','12');----
INSERT INTO word VALUES ('395031b6035547618be434f78b9aad83','endanger','[enˈdeɪndʒə]','http://res.iciba.com/resource/amp3/oxford/0/0f/25/0f25b5fb1ed0e17c9418e6e281ff5eda.mp3','vt. 危及；使遭遇危险','','');----
INSERT INTO classwords VALUES ('ac6c9687350b4dcea39f92106d17c9e3','395031b6035547618be434f78b9aad83','12');----
INSERT INTO word VALUES ('f58193157ce445d287216583b177b2a9','underestimate','[ˌʌndərˈestimeit]','http://res.iciba.com/resource/amp3/oxford/0/bc/b9/bcb95e2a79307bb841a012c7cf37d3e0.mp3','vt. 低估；轻视','','');----
INSERT INTO classwords VALUES ('621b3517c0d745ad87cb26ee96945b55','f58193157ce445d287216583b177b2a9','12');----
INSERT INTO word VALUES ('cf4134fbb0e245ce808500aedc77119b','cylinder','[ˈsilində]','http://res.iciba.com/resource/amp3/oxford/0/25/92/2592c262657cedc4fcaedbf015269248.mp3','n. 圆筒；圆筒状物；汽缸','','');----
INSERT INTO classwords VALUES ('4fad3ed63846412781b71a274b1b0f87','cf4134fbb0e245ce808500aedc77119b','12');----
INSERT INTO word VALUES ('ea06c704d66742f4a7ce42e2e4e66f50','bitterness','[ˈbɪtənɪs]','http://res.iciba.com/resource/amp3/0/0/e4/5b/e45bbd83418f126a4c0145f583b3b5c4.mp3','n. 苦味；悲痛','','');----
INSERT INTO classwords VALUES ('055388db1b2d496c88b66385209619c5','ea06c704d66742f4a7ce42e2e4e66f50','12');----
INSERT INTO word VALUES ('b43fc3f771df41a994839741fe8eb92f','analogy','[əˈnælədʒi]','http://res.iciba.com/resource/amp3/oxford/0/31/55/31554cf1ea787cd7c630e11b5f7cb0db.mp3','n. 相似，类似；类比；类推','','');----
INSERT INTO classwords VALUES ('9042124294b34625b10a06f9f44e8645','b43fc3f771df41a994839741fe8eb92f','12');----
INSERT INTO word VALUES ('eae23c54419048b8be725e621eda1e7a','inland','[ˈinlənd]','http://res.iciba.com/resource/amp3/oxford/0/96/65/9665c3802523aec3467ef234511ad346.mp3','adj. 内陆的；内地的','','');----
INSERT INTO classwords VALUES ('1275411b0fa14699adc762410903e03f','eae23c54419048b8be725e621eda1e7a','12');----
INSERT INTO word VALUES ('2a6d4f6cb2b24555a5609f4922a1a726','wholesome','[ˈhəulsəm]','http://res.iciba.com/resource/amp3/oxford/0/e5/2a/e52a2cff82c4530c210c9dcbf7028b1b.mp3','adj. 健康的；有益健康的','','');----
INSERT INTO classwords VALUES ('53bec5c5045b48aca7e30d271a85d2eb','2a6d4f6cb2b24555a5609f4922a1a726','12');----
INSERT INTO word VALUES ('cfe0f8172414431990ded8978fad1579','principally','[ˈprɪnsəplɪ]','http://res.iciba.com/resource/amp3/oxford/0/e1/64/e1649c895cedd5e2091272f1d0a444a5.mp3','adv. 主要地，首要地','','');----
INSERT INTO classwords VALUES ('0cf390b2d9a94bc8858d8bbb12df437a','cfe0f8172414431990ded8978fad1579','12');----
INSERT INTO word VALUES ('77a6094a99ef4111a6988ce5e398b380','press','[pres]','http://res.iciba.com/resource/amp3/oxford/0/43/10/4310355cd040bae1078cd935cce012e2.mp3','v. 压，按；用力踩；用力挤压；竭力劝说','','');----
INSERT INTO classwords VALUES ('40a61482ace04cee9a6fa4b1125d718a','77a6094a99ef4111a6988ce5e398b380','12');----
INSERT INTO word VALUES ('c81263f0dc454f15b3a960c444f58d51','uphold','[ʌpˈhəuld]','http://res.iciba.com/resource/amp3/oxford/0/4b/bd/4bbd267a5de511649c0cb9a58eaa12e9.mp3','vt. 拥护；支持；维持','','');----
INSERT INTO classwords VALUES ('7e4530b6a1a6474d9197e683069285d8','c81263f0dc454f15b3a960c444f58d51','12');----
INSERT INTO word VALUES ('4d06411ce52b4c15a08fa6a1acf3dabc','pathetic','[pəˈθetik]','http://res.iciba.com/resource/amp3/oxford/0/aa/2c/aa2c7882f4c414e49e965f04988f49ad.mp3','adj. 差劲的；可怜的','','');----
INSERT INTO classwords VALUES ('08bbe08fe3114c3ab622ade07eb2cf0f','4d06411ce52b4c15a08fa6a1acf3dabc','12');----
INSERT INTO word VALUES ('26102bbdaa5e4cd4ab87c08db6a75b32','yoke','[jəuk]','http://res.iciba.com/resource/amp3/0/0/5d/b8/5db89605720873a17b80474d07f76a32.mp3','n. 牛轭；枷锁','','');----
INSERT INTO classwords VALUES ('0fec77f3fcff469db3227d867646cb4d','26102bbdaa5e4cd4ab87c08db6a75b32','12');----
INSERT INTO word VALUES ('8f7dd1653cf44931921166e7927f2826','wring','[riŋ]','http://res.iciba.com/resource/amp3/oxford/0/e6/aa/e6aa9d8e72964b688aa76efd9d9a419e.mp3','vt. 拧，挤，扭；握紧','','');----
INSERT INTO classwords VALUES ('b288a1f86d4f4bbfb1df561a6c784149','8f7dd1653cf44931921166e7927f2826','12');----
INSERT INTO word VALUES ('37613c5ede09438abd89158f792c6e12','excess','[ˈekses]','http://res.iciba.com/resource/amp3/oxford/0/37/33/373306ac8c86715cc82d335754e26061.mp3','n. 过多，过量；无节制；（保险中的）免...','','');----
INSERT INTO classwords VALUES ('6991014792da46baa18286f93d4a5361','37613c5ede09438abd89158f792c6e12','12');----
INSERT INTO word VALUES ('8bb7d4b425144b3a8f57772bd294e0ce','undertaking','[ˈʌndəˌteɪkɪŋ]','http://res.iciba.com/resource/amp3/oxford/0/22/ab/22abb7fcf3a78cdfa3db258723452074.mp3','n. 任务，事业；承诺','','');----
INSERT INTO classwords VALUES ('ff08e0412e724f57ab3d0998871d775d','8bb7d4b425144b3a8f57772bd294e0ce','12');----
INSERT INTO word VALUES ('b31ac10b234440a18553f9567b570638','evolution','[ˌi:vəˈlu:ʃən]','http://res.iciba.com/resource/amp3/oxford/0/dd/63/dd6348e39d4a628e77622175fc80528d.mp3','n. 进化；（天体的）形成；演变','','');----
INSERT INTO classwords VALUES ('2ee3f405121b47ad851f65a94c7b710b','b31ac10b234440a18553f9567b570638','12');----
INSERT INTO word VALUES ('fbc2b7973f634dc3b0a8d2f7a17ac627','uranium','[juəˈreinjəm]','http://res.iciba.com/resource/amp3/oxford/0/01/37/013716d08c9c94bd9f9f4edf2d036abb.mp3','n. 铀','','');----
INSERT INTO classwords VALUES ('a1407bd6d87f4e1495949570ecdb19ab','fbc2b7973f634dc3b0a8d2f7a17ac627','12');----
INSERT INTO word VALUES ('94423c275fb54c159368203a03dafee5','situated','[ˈsitjueitid]','http://res.iciba.com/resource/amp3/oxford/0/99/ad/99add7c491d32a7d8b3f475ba9c6454b.mp3','adj. 位于…的，坐落在…的','','');----
INSERT INTO classwords VALUES ('79d6f2b663454362a56257840e335660','94423c275fb54c159368203a03dafee5','12');----
INSERT INTO word VALUES ('9f978d4fa8404116b3f8b75fb17f7be5','slang','[slæŋ]','http://res.iciba.com/resource/amp3/oxford/0/94/c6/94c69f35cf375e119257d6215dbe712a.mp3','n. 俚语；行话','','');----
INSERT INTO classwords VALUES ('b74d5373d3f5494fbc17be96a8c9f8fc','9f978d4fa8404116b3f8b75fb17f7be5','12');----
INSERT INTO word VALUES ('d2aef8cecb764eb1a41972db3e5998c4','wade','[weid]','http://res.iciba.com/resource/amp3/oxford/0/9a/6e/9a6e7143b2726515f8199d82b93869f2.mp3','vt. 蹚，跋涉','','');----
INSERT INTO classwords VALUES ('2f974960953746cf8f4813e1823b1faa','d2aef8cecb764eb1a41972db3e5998c4','12');----
INSERT INTO word VALUES ('96de094808344759a65edb805601762e','regenerative','[rɪˈdʒenəˌreɪtɪv]','http://res.iciba.com/resource/amp3/0/0/a1/94/a194c2f974dbddf76f25452e42b0d694.mp3','adj. 再生的；恢复的','','');----
INSERT INTO classwords VALUES ('843ce322df9d4fdc86962e207c53059a','96de094808344759a65edb805601762e','12');----
INSERT INTO word VALUES ('a3fbc1671e294c52a64fd7b8ba318713','indoor','[ˈindɔ:]','http://res.iciba.com/resource/amp3/oxford/0/00/5f/005f8c37a9f91ab821b41399c04a2e8f.mp3','adj. 室内的，户内的','','');----
INSERT INTO classwords VALUES ('a8eb6a9e15bd497b9e64acc6cefa940b','a3fbc1671e294c52a64fd7b8ba318713','12');----
INSERT INTO word VALUES ('da2184d5975d4854ace71c6e9299e3f9','spatial','[ˈspeiʃəl]','http://res.iciba.com/resource/amp3/oxford/0/85/a6/85a6295f99400de5f2497507895183ce.mp3','adj. 空间的；与空间有关的','','');----
INSERT INTO classwords VALUES ('a8137be119674a28b4355e7d0d02e257','da2184d5975d4854ace71c6e9299e3f9','12');----
INSERT INTO word VALUES ('b21bc23bf31f4807b1c283f15bac5d79','intent','[inˈtent]','http://res.iciba.com/resource/amp3/oxford/0/c5/a7/c5a79d375e93ce45bdce0cd56f3ae32b.mp3','adj. 坚决的；专心的，专注的','','');----
INSERT INTO classwords VALUES ('fe1c13423c9f44a89fe2ae5e8ccb8ba5','b21bc23bf31f4807b1c283f15bac5d79','12');----
INSERT INTO word VALUES ('901a6e415f064d4bb54516e2fb4ebfb1','regulate','[ˈreɡjuleit]','http://res.iciba.com/resource/amp3/oxford/0/e6/d4/e6d4ec356d6b4a2700c8c60736a3658d.mp3','vt. 调整，调节；管理','','');----
INSERT INTO classwords VALUES ('a290b057ef93407a8343f5af1ac40e68','901a6e415f064d4bb54516e2fb4ebfb1','12');----
INSERT INTO word VALUES ('203069956d8c465bb82e3f88d18d81a9','deviate','[ˈdi:vieit]','http://res.iciba.com/resource/amp3/oxford/0/84/b2/84b2cb8c4d129bac4d61fe4f384832de.mp3','v. （使）背离，偏离','','');----
INSERT INTO classwords VALUES ('99a945898c314d7b9bd8196a1fa96625','203069956d8c465bb82e3f88d18d81a9','12');----
INSERT INTO word VALUES ('5a3d663b206145ecb54b4d0e7c828254','jean','[dʒi:n]','http://res.iciba.com/resource/amp3/0/0/b7/19/b71985397688d6f1820685dde534981b.mp3','n. 斜纹棉布；牛仔裤','','');----
INSERT INTO classwords VALUES ('c901af5351374df38f65eab0aba27ed4','5a3d663b206145ecb54b4d0e7c828254','12');----
INSERT INTO word VALUES ('0c391a4bdbfe48c7a7ab96fe41aa48aa','raisin','[ˈreɪzɪn]','http://res.iciba.com/resource/amp3/oxford/0/4f/ec/4fec1f16aa32a66de6142ce2a876816d.mp3','n. 葡萄干','','');----
INSERT INTO classwords VALUES ('ef7188c3af3648cf95b5ee49628c3688','0c391a4bdbfe48c7a7ab96fe41aa48aa','12');----
INSERT INTO word VALUES ('cf0523d1f11e4c139eaa6efdcdbc8c3a','alternate','[ˈɔːltə(r)neɪt]','http://res.iciba.com/resource/amp3/0/0/a1/3a/a13a40f51bb5a8bd2a918d20d2e1fa41.mp3','adj. 交替的；轮流的','','');----
INSERT INTO classwords VALUES ('550e494424534e6685fbd3d14935eb14','cf0523d1f11e4c139eaa6efdcdbc8c3a','12');----
INSERT INTO word VALUES ('66a34cd161fd4500a4d943f9ceea27cf','rascal','[ˈræskəl]','http://res.iciba.com/resource/amp3/0/0/bc/a5/bca592ad6fb48ae994c0a2d9382061a8.mp3','n. 流氓；淘气鬼；家伙','','');----
INSERT INTO classwords VALUES ('fd1ef212f540433490e4192c175e32de','66a34cd161fd4500a4d943f9ceea27cf','12');----
INSERT INTO word VALUES ('9119112e81c347c6883cf1f9c1439950','alongside','[əˈlɔŋˈsaid]','http://res.iciba.com/resource/amp3/oxford/0/44/78/4478c00ea6b24715438991b345fc1be4.mp3','prep. 在…旁边；与…一起','','');----
INSERT INTO classwords VALUES ('ccc0293f0e61493287c3dbf08c70b8f0','9119112e81c347c6883cf1f9c1439950','12');----
INSERT INTO word VALUES ('42702bc91a424303a6e492a3d0eed1e9','postulate','[ˈpɔstʃəˌleɪt]','http://res.iciba.com/resource/amp3/oxford/0/5a/4e/5a4e415836748a5110a4503ba4aac9b8.mp3','vt. 假定，假设','','');----
INSERT INTO classwords VALUES ('e7e8be79462b4971b3d872d09b1cee11','42702bc91a424303a6e492a3d0eed1e9','12');----
INSERT INTO word VALUES ('202f6f1218e947bf82b4f57029d20d80','illuminate','[iˈlju:mineit]','http://res.iciba.com/resource/amp3/oxford/0/15/45/1545a4de43cbbec1840a53a9a91384d2.mp3','vt. 照明，照亮；阐明','','');----
INSERT INTO classwords VALUES ('2b6c49bd2b294eef8f18e16a9cd13061','202f6f1218e947bf82b4f57029d20d80','12');----
INSERT INTO word VALUES ('2f41bd0f18eb45d9908f160607260ee9','anniversary','[ˌæniˈvə:səri]','http://res.iciba.com/resource/amp3/oxford/0/ef/f0/eff05ebd88a49e026b21a1d016b42d1d.mp3','n. 周年纪念日','','');----
INSERT INTO classwords VALUES ('0178355619b64e4daf7fed17492d9e15','2f41bd0f18eb45d9908f160607260ee9','12');----
INSERT INTO word VALUES ('4591def8d9f9468ea1c7a49d19ecf0ad','fission','[ˈfɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/b0/a7/b0a744afcc6f5c20c1e45e7fe54bdca7.mp3','n. （核）裂变，分裂；分裂生殖','','');----
INSERT INTO classwords VALUES ('34cd5e7b8caf4132aabead802940be9b','4591def8d9f9468ea1c7a49d19ecf0ad','12');----
INSERT INTO word VALUES ('86690a759cf74097a656f9b554e52beb','rate','[reit]','http://res.iciba.com/resource/amp3/oxford/0/44/db/44dbcadb3c9116919c6b18be34d191e6.mp3','vt. 对…评定；看好；把…认定为；应该...','','');----
INSERT INTO classwords VALUES ('0f96ea3406034d07a6c308928ba5cdef','86690a759cf74097a656f9b554e52beb','12');----
INSERT INTO word VALUES ('a7a56b123eef445b8f09853cdcccd0c5','flatter','[ˈflætə]','http://res.iciba.com/resource/amp3/oxford/0/83/45/834568be2991c4501215fbade2347a9f.mp3','vt. 奉承，阿谀，谄媚；自认为','','');----
INSERT INTO classwords VALUES ('4e29956a5dbb4629b6c29bcb7cc36fad','a7a56b123eef445b8f09853cdcccd0c5','12');----
INSERT INTO word VALUES ('6487685e72164fe493f91a3e7a7dd03d','silicon','[ˈsilikən]','http://res.iciba.com/resource/amp3/oxford/0/d0/f1/d0f11b6b9a7e0c386772b3f7da84f8e9.mp3','n. 硅','','');----
INSERT INTO classwords VALUES ('6a2d867bb98b4960a9a3828650809a07','6487685e72164fe493f91a3e7a7dd03d','12');----
INSERT INTO word VALUES ('6c3d30098d654c96bd70d7fecf97e085','impulse','[ˈimpʌls]','http://res.iciba.com/resource/amp3/oxford/0/95/d6/95d69551234e002156500c975b73dda2.mp3','n. 一时兴起的念头；冲动；脉冲','','');----
INSERT INTO classwords VALUES ('0a7c8fd5e8f148c4b529b7f3b5cd4105','6c3d30098d654c96bd70d7fecf97e085','12');----
INSERT INTO word VALUES ('d3a1595e58af40fd9fb331f252b6214e','convert','[kənˈvə:t]','http://res.iciba.com/resource/amp3/oxford/0/60/f1/60f197ea76a90c50da87dca214cf0657.mp3','vt. 转变，改变；改建；改装；换算','','');----
INSERT INTO classwords VALUES ('7557c35218a540c4a83386af1fb30f0e','d3a1595e58af40fd9fb331f252b6214e','12');----
INSERT INTO word VALUES ('08ae068db7304c9e8586a871a94425df','move','[mu:v]','http://res.iciba.com/resource/amp3/oxford/0/0f/71/0f71650b6f8a121dca24f3056005d62b.mp3','n. 措施，步骤','','');----
INSERT INTO classwords VALUES ('5c4ce8d6bfa545339c1477fb7f5a1c72','08ae068db7304c9e8586a871a94425df','12');----
INSERT INTO word VALUES ('fabd81ddce90423ba83869f28bbfbd1e','generate','[ˈdʒenəreit]','http://res.iciba.com/resource/amp3/oxford/0/d8/f7/d8f7a9e3a86f8963cc1950ddce953272.mp3','vt. 发电；产生（能量）；造成；引起','','');----
INSERT INTO classwords VALUES ('9c6e1eaca81d48148ca13ae8e21ff01d','fabd81ddce90423ba83869f28bbfbd1e','12');----
INSERT INTO word VALUES ('bf81ade1f2cc4528be9f84c67659b6ed','exclusive','[iksˈklu:siv]','http://res.iciba.com/resource/amp3/oxford/0/2e/cb/2ecbd9926fec77cceaa1ca5167d6ae00.mp3','adj. 排外的；高级的；独用的；独家的','','');----
INSERT INTO classwords VALUES ('ee16f923f8af4219b650532bc5d0d99f','bf81ade1f2cc4528be9f84c67659b6ed','12');----
INSERT INTO word VALUES ('fd7e15f43dbd418694c56bade070d1bb','discount','[ˈdiskaunt]','http://res.iciba.com/resource/amp3/oxford/0/7b/fa/7bfa1a836c1410dd5f1b8f40ded45d45.mp3','n. 折扣','','');----
INSERT INTO classwords VALUES ('500c239ce9ff4539aaa1b77b23912780','fd7e15f43dbd418694c56bade070d1bb','12');----
INSERT INTO word VALUES ('a75863638734416094ae8bc2edb4f217','correspondenc...','[ˌkɔrisˈpɔndəns]','http://res.iciba.com/resource/amp3/oxford/0/28/9e/289e8bba9482feeda3ca17436101ea4c.mp3','n. 通信；符合；相似','','');----
INSERT INTO classwords VALUES ('ecedbf98b0464cadb39cd30423f97d3e','a75863638734416094ae8bc2edb4f217','12');----
INSERT INTO word VALUES ('f06898043f8b438d8b99330953204de0','transmission','[trænzˈmiʃən]','http://res.iciba.com/resource/amp3/oxford/0/4f/16/4f16d9ad838cd7caac0afe102c9b73f2.mp3','n. 传送，传递；播送；变速器','','');----
INSERT INTO classwords VALUES ('fe6d56bd112345f9a0c07f0761b25ed1','f06898043f8b438d8b99330953204de0','12');----
INSERT INTO word VALUES ('00dcb295c5e449f9acb924b9303eeca4','testify','[ˈtestɪfaɪ]','http://res.iciba.com/resource/amp3/oxford/0/83/f4/83f4d85e1e51d68593ae904810226844.mp3','v. 证明，作证；证实','','');----
INSERT INTO classwords VALUES ('60a14744ec5d45ba956782b80b42374f','00dcb295c5e449f9acb924b9303eeca4','12');----
INSERT INTO word VALUES ('9739698a4e0643b28e532468fab317ce','prophecy','[ˈprɔfisi]','http://res.iciba.com/resource/amp3/oxford/0/55/f5/55f575c4e09892eeffef7e4c47167940.mp3','n. 预言，预言能力','','');----
INSERT INTO classwords VALUES ('c96b875730c846aeb5189f18a9928353','9739698a4e0643b28e532468fab317ce','12');----
INSERT INTO word VALUES ('90e2a33669af4e2bb1c5552fcd5511ee','oath','[əuθ]','http://res.iciba.com/resource/amp3/0/0/f1/08/f10822a83aaf430d7fb710e99d9fd8ed.mp3','n. 誓言，誓约；咒骂','','');----
INSERT INTO classwords VALUES ('fc5acab8eb3a49d780c23a08a32ffa0a','90e2a33669af4e2bb1c5552fcd5511ee','12');----
INSERT INTO word VALUES ('ef7e6ad7c4554bfc87d67041af6bc599','house','[haus]','http://res.iciba.com/resource/amp3/oxford/0/a5/6d/a56dbc0c371c2aa4150ab906dfdeee27.mp3','n. 议院；公司；住宅； 家庭','','');----
INSERT INTO classwords VALUES ('027ddb9197864b16a7aa64fa4e661ad8','ef7e6ad7c4554bfc87d67041af6bc599','12');----
INSERT INTO word VALUES ('e58e236a5eb4423ebaf28eca7e0f8e08','straightforwa...','[streitˈfɔ:wəd]','http://res.iciba.com/resource/amp3/oxford/0/28/b9/28b926659f8d3cab1cb94220260fb387.mp3','adv. 坦率地','','');----
INSERT INTO classwords VALUES ('d3723139aaae4cb099b9d234172481a5','e58e236a5eb4423ebaf28eca7e0f8e08','12');----
INSERT INTO word VALUES ('1894a29b352a40dcae93aca459bbf46a','watertight','[ˈwɔ:tətait]','http://res.iciba.com/resource/amp3/oxford/0/57/eb/57ebbfe9a24821f3971b557c208f9e53.mp3','adj. 不透水的；严密的','','');----
INSERT INTO classwords VALUES ('2c3c7038901f4ef1995a8a192865d88b','1894a29b352a40dcae93aca459bbf46a','12');----
INSERT INTO word VALUES ('fb00558fe22c4fb8bf8d1c53c708bf54','way','[wei]','http://res.iciba.com/resource/amp3/oxford/0/f4/99/f4995e940d0ee6f10722c12499243972.mp3','n. 方法；方式；形式；作风','','');----
INSERT INTO classwords VALUES ('96923b31e2194feeb94575383c682654','fb00558fe22c4fb8bf8d1c53c708bf54','12');----
INSERT INTO word VALUES ('9fa3c7c8552a408c8f6bb9acb22d5f85','kernel','[ˈkɜ:nəl]','http://res.iciba.com/resource/amp3/0/0/50/48/50484c19f1afdaf3841a0d821ed393d2.mp3','n. （果实的）核；谷粒；核心；要点','','');----
INSERT INTO classwords VALUES ('bd06b0fb95784ce882197e69d9d73587','9fa3c7c8552a408c8f6bb9acb22d5f85','12');----
INSERT INTO word VALUES ('1b0c13197fd74266b87f70a173afdff9','reject','[riˈdʒekt]','http://res.iciba.com/resource/amp3/oxford/0/48/d2/48d24fa3cfdd42730eac4ac77dc1f9d4.mp3','vt. 拒绝；抛弃；不录用','','');----
INSERT INTO classwords VALUES ('53be9836ce0047ca8cca1a00d2959495','1b0c13197fd74266b87f70a173afdff9','12');----
INSERT INTO word VALUES ('fe997d1f1ca34fcf81b23a59a65f7527','settlement','[ˈsetlmənt]','http://res.iciba.com/resource/amp3/oxford/0/fb/64/fb64f9242357063fd095d17519d6bed8.mp3','n. 正式协议；和解；偿付；定居点；殖民','','');----
INSERT INTO classwords VALUES ('1919999f06c146cb8250569add504103','fe997d1f1ca34fcf81b23a59a65f7527','12');----
INSERT INTO word VALUES ('cafbd7311ce54bcd849d063885fbbdb8','incapable','[ɪnˈkeɪpəbəl]','http://res.iciba.com/resource/amp3/oxford/0/95/3e/953e2f483eb3bc7abd2ceb933b7b532a.mp3','adj. 无能力的；不能的；软弱无能的','','');----
INSERT INTO classwords VALUES ('b2e1082b268a415b8e1143a271ce5c1f','cafbd7311ce54bcd849d063885fbbdb8','12');----
INSERT INTO word VALUES ('11a66dcce11646fa8515aa142ba8f9a7','currently','[ˈkʌrɵntlɪ]','http://res.iciba.com/resource/amp3/oxford/0/e1/57/e157ba8624736235cc0337a0a9f1776f.mp3','adv. 目前，当前','','');----
INSERT INTO classwords VALUES ('f1124dc5032e4fa38a269080d613caf9','11a66dcce11646fa8515aa142ba8f9a7','12');----
INSERT INTO word VALUES ('9415dc027e224976b1418b40d2de3c6f','emerge','[iˈmə:dʒ]','http://res.iciba.com/resource/amp3/0/0/81/12/811268aaf816faaef03ade5c52127d97.mp3','vi. 出现；显露','','');----
INSERT INTO classwords VALUES ('03fa95adaec342d396e10196e748c684','9415dc027e224976b1418b40d2de3c6f','12');----
INSERT INTO word VALUES ('77d14dff62e14653abcb999043568fa8','nice','[nais]','http://res.iciba.com/resource/amp3/oxford/0/24/8a/248a2aa9259a98ecb7a1ff677a0feed2.mp3','adj. 美好的；好心的；友好的；亲切的','','');----
INSERT INTO classwords VALUES ('6f5e938cb5eb4f039c848ae808a945a9','77d14dff62e14653abcb999043568fa8','12');----
INSERT INTO word VALUES ('e248b863c17b4a719946facd205d7f1a','challenge','[ˈtʃælindʒ]','http://res.iciba.com/resource/amp3/oxford/0/8e/a0/8ea0dd07afe78e0f966b28115a8a431d.mp3','n. 挑战，难题；质疑','','');----
INSERT INTO classwords VALUES ('0061e709af2743a69b3d5e51fa2fec74','e248b863c17b4a719946facd205d7f1a','12');----
INSERT INTO word VALUES ('cf9c23227cb346cab44fc4a2c25d2a2a','echo','[ˈekəʊ]','http://res.iciba.com/resource/amp3/0/0/cb/b1/cbb11ed87dc8a95d81400c7f33c7c171.mp3','vt. 重复；随声附和','','');----
INSERT INTO classwords VALUES ('895b1649ea9343e9b3b957c15079e019','cf9c23227cb346cab44fc4a2c25d2a2a','12');----
INSERT INTO word VALUES ('8f4094715a4d46cda8c1b8061111649a','seam','[si:m]','http://res.iciba.com/resource/amp3/oxford/0/e1/e1/e1e16e30f208d2014ee946d6053c736b.mp3','n. 接缝；煤层','','');----
INSERT INTO classwords VALUES ('a29519e0620247ada8ed701125775703','8f4094715a4d46cda8c1b8061111649a','12');----
INSERT INTO word VALUES ('0fd5c3878b414af1b2283a563b8505f4','vein','[vein]','http://res.iciba.com/resource/amp3/oxford/0/26/b0/26b0944f7d4b363b6a2c6a10dea9b988.mp3','n. 静脉；矿脉；（叶子的）纹路','','');----
INSERT INTO classwords VALUES ('a33e034fa37748548a5d375d695565a8','0fd5c3878b414af1b2283a563b8505f4','12');----
INSERT INTO word VALUES ('a5785a6c6d0b49b59cbdc87e86950050','clasp','[klɑ:sp]','http://res.iciba.com/resource/amp3/0/0/79/ce/79ce520d0091f0ce94ff8cc7845c0131.mp3','vt. 扣住，扣紧；握紧，抱紧','','');----
INSERT INTO classwords VALUES ('4464c41bc45441799d8a791d62fd3572','a5785a6c6d0b49b59cbdc87e86950050','12');----
INSERT INTO word VALUES ('c76851d15dc145b9a173b3e02a745d93','wrinkle','[ˈriŋkl]','http://res.iciba.com/resource/amp3/oxford/0/e0/0e/e00e225e6c71c88a7a6c55c73bd4192d.mp3','vt. 使起皱纹；使起皱，使起褶','','');----
INSERT INTO classwords VALUES ('94ab5e0a01074faaa431aa7918a5606a','c76851d15dc145b9a173b3e02a745d93','12');----
INSERT INTO word VALUES ('13463d66981545b0b0f266d571c63f5c','maintenance','[ˈmeintinəns]','http://res.iciba.com/resource/amp3/oxford/0/e4/9d/e49d2592e850318b8f35bcc55a070fd3.mp3','n. 生活费；维持；定期维修','','');----
INSERT INTO classwords VALUES ('08f44f07c57046d4a8fa59440b9ed1b5','13463d66981545b0b0f266d571c63f5c','12');----
INSERT INTO word VALUES ('e4246663f508432e9fad01684fb4c581','diversion','[daiˈvə:ʃən]','http://res.iciba.com/resource/amp3/oxford/0/2f/0a/2f0a6c91c0288d72104a03b26f99e160.mp3','n. 转移；临时绕行路；娱乐；转向','','');----
INSERT INTO classwords VALUES ('e3e2fe67299841ceab3d2348132c9645','e4246663f508432e9fad01684fb4c581','12');----
INSERT INTO word VALUES ('87e7eab150c34c8aa43736ee3ba2bd87','brood','[bru:d]','http://res.iciba.com/resource/amp3/oxford/0/4b/5e/4b5e75d482c5d27de294b8a79f0a17dd.mp3','n. 一窝，一伙，一群孩子','','');----
INSERT INTO classwords VALUES ('2e01bd4f9073418683f0f5c340e4691a','87e7eab150c34c8aa43736ee3ba2bd87','12');----
INSERT INTO word VALUES ('d05f9940eb634ece80f44db5d3dcc575','warning','[ˈwɔ:nɪŋ]','http://res.iciba.com/resource/amp3/oxford/0/ff/11/ff11b118cac01b0bb5efa72d9725077d.mp3','n. 警告；预告，预兆','','');----
INSERT INTO classwords VALUES ('b7231c488941469289c361dd4aeba2c1','d05f9940eb634ece80f44db5d3dcc575','12');----
INSERT INTO word VALUES ('323a56b19e2344388f9ff667fd24cf0d','colonial','[kəˈləunjəl]','http://res.iciba.com/resource/amp3/oxford/0/d9/b1/d9b12ca06a622f80710a0f36bb503003.mp3','adj. 殖民地的，殖民主义的','','');----
INSERT INTO classwords VALUES ('82c8b182b2b2412eaf0b4bc51fcf49ed','323a56b19e2344388f9ff667fd24cf0d','12');----
INSERT INTO word VALUES ('4b80933c49e34b3e8078dff5cd5024f0','initial','[iˈniʃəl]','http://res.iciba.com/resource/amp3/oxford/0/bd/0e/bd0e780d9e2728fd281f261e021a59a4.mp3','adj. 开始的；最初的','','');----
INSERT INTO classwords VALUES ('58e1734231834ca6802deaece1dd090f','4b80933c49e34b3e8078dff5cd5024f0','12');----
INSERT INTO word VALUES ('e7babad85a8746c487b0ff0744eda78d','ticket','[ˈtikit]','http://res.iciba.com/resource/amp3/oxford/0/3b/87/3b8700858e204e5a983b473af5c6ad11.mp3','n. 门票；违章通知单；兑奖券','','');----
INSERT INTO classwords VALUES ('6f3571626fa141fd96be0f3838dbe400','e7babad85a8746c487b0ff0744eda78d','12');----
INSERT INTO word VALUES ('8da9e40ae3734397a141cfb019cd20b7','corrosion','[kəˈrəʊʒən]','http://res.iciba.com/resource/amp3/0/0/f6/ce/f6ce236e18a9828109cfb1b231ff6373.mp3','n. 腐蚀，侵蚀','','');----
INSERT INTO classwords VALUES ('2aa6b36fdc9d451ebe6b4361db2d52f1','8da9e40ae3734397a141cfb019cd20b7','12');----
INSERT INTO word VALUES ('348cd37f172f42a78f948688e9c40634','province','[ˈprɔvins]','http://res.iciba.com/resource/amp3/oxford/0/58/ca/58ca15d203c74177b3a7438f3d79460e.mp3','n. 领域，范围；外省','','');----
INSERT INTO classwords VALUES ('a1a6f1c3d8ad41c8b1983166317edf4a','348cd37f172f42a78f948688e9c40634','12');----
INSERT INTO word VALUES ('1ab4dba778c94ad990781795cc24d55e','buzz','[bʌz]','http://res.iciba.com/resource/amp3/oxford/0/73/6b/736b2f11db9b52b94563493c9502e265.mp3','vi. （蜂等）嗡嗡叫；匆忙地走动','','');----
INSERT INTO classwords VALUES ('fb0fe3f2f114465d9b6b0716cbe29a46','1ab4dba778c94ad990781795cc24d55e','12');----
INSERT INTO word VALUES ('e69c0cf2aed64e879252e9a437c875b1','climax','[ˈklaimæks]','http://res.iciba.com/resource/amp3/oxford/0/ea/7d/ea7d43daba631b55a62540327ba81bb3.mp3','n. （兴趣的）顶点；高潮，最精彩处','','');----
INSERT INTO classwords VALUES ('bfea3d2850be4d0984b06e9f101e25a3','e69c0cf2aed64e879252e9a437c875b1','12');----
INSERT INTO word VALUES ('31bd51daaaf24f0ca65cc6511651a813','degrade','[diˈɡreid]','http://res.iciba.com/resource/amp3/oxford/0/e7/fe/e7febcfd77e3b54e3956a40b52f3ad75.mp3','vt. 使丢脸；使退化；使降解','','');----
INSERT INTO classwords VALUES ('06a915f89f704670b1e5f5616686a255','31bd51daaaf24f0ca65cc6511651a813','12');----
INSERT INTO word VALUES ('f095c1da20454f4989d579d3c52d1bf7','prescription','[prisˈkripʃən]','http://res.iciba.com/resource/amp3/oxford/0/04/10/0410653b0a2823dd592e7195f21521db.mp3','n. 药方，处方；处方药','','');----
INSERT INTO classwords VALUES ('e8a69856d8504c499d6c8e2e9604d3bc','f095c1da20454f4989d579d3c52d1bf7','12');----
INSERT INTO word VALUES ('25e1806c0b6147e19b0a5cda9cdb73e2','tragic','[ˈtrædʒik]','http://res.iciba.com/resource/amp3/oxford/0/e8/ec/e8ec5ad4c52672f41b885099ff395903.mp3','adj. 悲剧的；可叹的；悲惨的','','');----
INSERT INTO classwords VALUES ('4dc213ea98d34189b92c9ac9874da150','25e1806c0b6147e19b0a5cda9cdb73e2','12');----
INSERT INTO word VALUES ('f428ee561b704a80926a3ab593db8453','scandal','[ˈskændl]','http://res.iciba.com/resource/amp3/oxford/0/16/99/1699beaa96ad4053c0e2eefecef99718.mp3','n. 丑事，丑闻；耻辱；谣言','','');----
INSERT INTO classwords VALUES ('8c82f2f45583443ea13219f9fb0967f9','f428ee561b704a80926a3ab593db8453','12');----
INSERT INTO word VALUES ('39fb92bbe6b544c2952e8ed7da94cf92','earthenware','[ˈɜ:θənˌweə]','http://res.iciba.com/resource/amp3/0/0/c4/ac/c4aca128cb8b20976b4977165185790f.mp3','n. 陶器','','');----
INSERT INTO classwords VALUES ('4ee205ffb8b44029a49be79a61c65007','39fb92bbe6b544c2952e8ed7da94cf92','12');----
INSERT INTO word VALUES ('e8c76442bee54ce38e8a05173cf23e2c','incompatible','[ˌɪnkəmˈpætəbəl]','http://res.iciba.com/resource/amp3/oxford/0/cf/5c/cf5c10ec026d5b9b3610389dfba2edd5.mp3','adj. 不相容的；不协调的，不一致的','','');----
INSERT INTO classwords VALUES ('9173f57d34524ef3b0b98c100b7d8556','e8c76442bee54ce38e8a05173cf23e2c','12');----
INSERT INTO word VALUES ('4933c6db4c29416bb5cc9daaaa83bbb7','harp','[hɑ:p]','http://res.iciba.com/resource/amp3/0/0/8a/f0/8af0537e9a6ef798b9a8eeefbc54c8b4.mp3','n. 竖琴；天琴座','','');----
INSERT INTO classwords VALUES ('6f1fe31e5b264c299c4d229f950209ad','4933c6db4c29416bb5cc9daaaa83bbb7','12');----
INSERT INTO word VALUES ('e5454aa52dad4dfb9b9adf2dafc0ef0f','widely','[ ˈwaɪdlɪ]','http://res.iciba.com/resource/amp3/oxford/0/8d/fa/8dfa0615b86fdd4d289affc3e86c0244.mp3','adv. 广泛地；大量地','','');----
INSERT INTO classwords VALUES ('75c6551cbab04cf4bc7e84d3c2675fcb','e5454aa52dad4dfb9b9adf2dafc0ef0f','12');----
INSERT INTO word VALUES ('b9483404b7364e758f7f95d62d23c4de','obscure','[əbˈskjuə]','http://res.iciba.com/resource/amp3/0/0/a6/6e/a66e8d6325ddde409a049548d7e986a1.mp3','adj. 鲜为人知的；晦涩的','','');----
INSERT INTO classwords VALUES ('e47a14b183b94f4387f3da103b3e450e','b9483404b7364e758f7f95d62d23c4de','12');----
INSERT INTO word VALUES ('44a804f57891421a8289d26419ad05f1','sight','[sait]','http://res.iciba.com/resource/amp3/oxford/0/47/a6/47a6ab0300f87614af6beed74efac45c.mp3','n. 名胜，风景；景象；目睹；视力','','');----
INSERT INTO classwords VALUES ('1586751af44b43608e8ddc9096850c62','44a804f57891421a8289d26419ad05f1','12');----
INSERT INTO word VALUES ('39d6ec581e16412398be0dec00bfb1ee','emission','[ɪˈmɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/38/69/38696194db598266727115d16edf1f0e.mp3','n. 散发；释放；放射','','');----
INSERT INTO classwords VALUES ('ff11b63189bc413d8d692326b1f131a4','39d6ec581e16412398be0dec00bfb1ee','12');----
INSERT INTO word VALUES ('50e7cae8aeaf47479fbc9232e3c4512f','fragrant','[ˈfreɪgrənt]','http://res.iciba.com/resource/amp3/oxford/0/f0/6d/f06d12d3ecf7845ec0c0193444ff7f05.mp3','adj. 芳香的，芬芳的','','');----
INSERT INTO classwords VALUES ('b69f647f0fcd4b5c85f3104865b23992','50e7cae8aeaf47479fbc9232e3c4512f','12');----
INSERT INTO word VALUES ('21f0d5d523a14f8aaa5614a72a654d4b','ornamental','[ˌɔ:nəˈmentl]','http://res.iciba.com/resource/amp3/oxford/0/2b/33/2b33d9e68b8bbb38cf3ddc23674c9354.mp3','n. 装饰品','','');----
INSERT INTO classwords VALUES ('ac69eeb14d1f4a0598efb8082d06f707','21f0d5d523a14f8aaa5614a72a654d4b','12');----
INSERT INTO word VALUES ('ddcfa2262e6b4ffaa54233b75ed4b2f2','domestic','[dəˈmestik]','http://res.iciba.com/resource/amp3/oxford/0/9e/e8/9ee8e806c16059112953bccfe878f977.mp3','adj. 国内的；家务的；家用的；训养的','','');----
INSERT INTO classwords VALUES ('48aa1107dd7b4af684a61c37fdf3aa15','ddcfa2262e6b4ffaa54233b75ed4b2f2','12');----
INSERT INTO word VALUES ('78a7473a35f6414c9f7e26a50d3a93ce','simultaneous','[ˌsiməlˈteinjəs]','http://res.iciba.com/resource/amp3/oxford/0/18/12/1812850fc213deebe6c7cdf9c4574078.mp3','adj. 同步的，同时存在的','','');----
INSERT INTO classwords VALUES ('fa07ff8e9e9343bd87d78f246e88426c','78a7473a35f6414c9f7e26a50d3a93ce','12');----
INSERT INTO word VALUES ('184ba314301a4cb2a1008faf4dd326b8','tulip','[ˈtju:lip]','http://res.iciba.com/resource/amp3/oxford/0/d7/34/d73435b6f73380f7827568e43f3e769e.mp3','n. 郁金香','','');----
INSERT INTO classwords VALUES ('212a14de9f7b41deacd08ad975ae9b6b','184ba314301a4cb2a1008faf4dd326b8','12');----
INSERT INTO word VALUES ('ef8f18b267a843e69a730737e754c428','unfit','[ʌnˈfɪt]','http://res.iciba.com/resource/amp3/oxford/0/5e/8d/5e8d3d397773b368c0424a2e507077ec.mp3','adj. 不健康的；不适宜的；不合适的','','');----
INSERT INTO classwords VALUES ('7ef1cc3be258417bbf50a5fea1e97c7f','ef8f18b267a843e69a730737e754c428','12');----
INSERT INTO word VALUES ('c4fdf2fcbd514525a80e027d71b15789','gigantic','[dʒaiˈɡæntik]','http://res.iciba.com/resource/amp3/oxford/0/d3/f4/d3f4ff3c791ab3edc8f4c8356eb6727c.mp3','adj. 巨大的，庞大的','','');----
INSERT INTO classwords VALUES ('335ff432027f419fbf803fb0b4cccfe0','c4fdf2fcbd514525a80e027d71b15789','12');----
INSERT INTO word VALUES ('eab96408dbdf4cac95ad6c8623c7415a','insulator','[ˈɪnsəˌleɪtə]','http://res.iciba.com/resource/amp3/oxford/0/3b/ef/3befcb27f5b9a612b95d0eed5280ebfa.mp3','n. 绝缘体；绝热体','','');----
INSERT INTO classwords VALUES ('d08288f190cc46269263f558a12494d9','eab96408dbdf4cac95ad6c8623c7415a','12');----
INSERT INTO word VALUES ('7c03f15c775444d8a3100421815e5265','intermediate','[ˌɪntəˈmi:djət]','http://res.iciba.com/resource/amp3/oxford/0/f4/86/f486d330f9487c1682d05717258b4baf.mp3','adj. 中间的；中等程度的','','');----
INSERT INTO classwords VALUES ('d0219c67ea3a4685b8b9f1522d885702','7c03f15c775444d8a3100421815e5265','12');----
INSERT INTO word VALUES ('c3ba9653b5774d5b9163caf823d1ff9a','ideally','[aɪˈdi:əli:]','http://res.iciba.com/resource/amp3/0/0/68/91/689122cfbdb6ec6010f7d074deeb74c1.mp3','adv. 理想地；完美地','','');----
INSERT INTO classwords VALUES ('cfb729ad416e41e0ad78390eb8952084','c3ba9653b5774d5b9163caf823d1ff9a','12');----
INSERT INTO word VALUES ('72f75e19f02145e2b9cf4d2bf1474ff3','embassy','[ˈembəsi]','http://res.iciba.com/resource/amp3/oxford/0/fb/ca/fbca97e4b15ddbec00ff3ab2072709f0.mp3','n. 大使馆；大使的职务；大使馆全体成员','','');----
INSERT INTO classwords VALUES ('89f05cda65db4e70a6782c17b7b2a573','72f75e19f02145e2b9cf4d2bf1474ff3','12');----
INSERT INTO word VALUES ('7fedf1df91ab4dfb99048df56dccb04a','specialize','[ˈspeʃəlaiz]','http://res.iciba.com/resource/amp3/oxford/0/a6/05/a605676e47c5f0c76dc18186545a4b53.mp3','vt. 使专门化；专攻','','');----
INSERT INTO classwords VALUES ('07a71aa902474c8baf2741188017ac18','7fedf1df91ab4dfb99048df56dccb04a','12');----
INSERT INTO word VALUES ('689594bdd8c7487d9fee6a917235bea4','catalogue','[ˈkætəlɔɡ]','http://res.iciba.com/resource/amp3/oxford/0/82/6f/826fbc6dc55107e9a27d51cba0c33c20.mp3','vt. 为…编目录；列举，历数','','');----
INSERT INTO classwords VALUES ('db2926a4930849758a76a4fa7058fb9d','689594bdd8c7487d9fee6a917235bea4','12');----
INSERT INTO word VALUES ('bfe01169ae8447dd90cabe8174d4e36e','confidential','[ˌkɔnfiˈdenʃəl]','http://res.iciba.com/resource/amp3/oxford/0/36/a7/36a73d884596be7fda9e24ae55cb0db9.mp3','adj. 秘密的；机密的；悄悄的','','');----
INSERT INTO classwords VALUES ('13cd1f250f7c47a789bc1b793610e50a','bfe01169ae8447dd90cabe8174d4e36e','12');----
INSERT INTO word VALUES ('b6bd33f9a6f8495285c9c9bac8efa968','stillness','[ˈstɪlnɪs]','http://res.iciba.com/resource/amp3/oxford/0/b5/1c/b51cfd080f481e02f38764ab64f406a8.mp3','n. 寂静；静止，不动','','');----
INSERT INTO classwords VALUES ('9d380d17907d4247870ee7c668c9e21a','b6bd33f9a6f8495285c9c9bac8efa968','12');----
INSERT INTO word VALUES ('1db24be2d816435bb401327ae8fae969','reference','[ˈrefrəns]','http://res.iciba.com/resource/amp3/oxford/0/1d/9f/1d9f8e7098c91d7a7a60771ab2a7d7d2.mp3','n. 提及；咨询；引语；索引，编号；介绍...','','');----
INSERT INTO classwords VALUES ('88882cbcffd744e197193448b6106f1e','1db24be2d816435bb401327ae8fae969','12');----
INSERT INTO word VALUES ('290e8e6945e343f9893491749abcaacf','block','[blɔk]','http://res.iciba.com/resource/amp3/0/0/14/51/14511f2f5564650d129ca7cabc333278.mp3','n. 阻塞；障碍物；街区；大楼','','');----
INSERT INTO classwords VALUES ('ddfeb8d581e94efa9dfe1cbecb76f74f','290e8e6945e343f9893491749abcaacf','12');----
INSERT INTO word VALUES ('889c3daa8aed4c579c086d7289555647','nut','[nʌt]','http://res.iciba.com/resource/amp3/oxford/0/60/8a/608a0b8a8b466d9899c17164babe5fcd.mp3','n. 螺帽，螺母；坚果','','');----
INSERT INTO classwords VALUES ('a52e4e24fd3041a7b7748b2d2fb8b9db','889c3daa8aed4c579c086d7289555647','12');----
INSERT INTO word VALUES ('114b96bd82034b82b1d3a69a3877b2fa','dust','[dʌst]','http://res.iciba.com/resource/amp3/oxford/0/75/87/7587558be03e78791e4798b7e8d300cc.mp3','n. 尘土；灰尘；粉末','','');----
INSERT INTO classwords VALUES ('14ba84a683314da78deb8b9a213e3805','114b96bd82034b82b1d3a69a3877b2fa','12');----
INSERT INTO word VALUES ('9f5cfe83350b4c2185a4f65281237323','melody','[ˈmelədi]','http://res.iciba.com/resource/amp3/oxford/0/fe/81/fe817d574bdb07c26cbc896683f56d4c.mp3','n. 旋律，曲调；婉转，悦耳','','');----
INSERT INTO classwords VALUES ('bae9b32a5dad44529c0ebb5452d46f65','9f5cfe83350b4c2185a4f65281237323','12');----
INSERT INTO word VALUES ('dbbcc11feb054ee0aa2e89a144c7c836','ham','[hæm]','http://res.iciba.com/resource/amp3/oxford/0/b0/2c/b02c8a8c60675ef4092c10ee168e49b6.mp3','n. 火腿；蹩脚演员','','');----
INSERT INTO classwords VALUES ('c0c058eba04f4e838bf9b7f0d336b3bb','dbbcc11feb054ee0aa2e89a144c7c836','12');----
INSERT INTO word VALUES ('1a14e488cab74a1abd7bbf900680a78d','physically','[ˈfɪzɪkəlɪ]','http://res.iciba.com/resource/amp3/oxford/0/84/c8/84c807036f414fba167346185cecc306.mp3','adv. 身体上，体格上','','');----
INSERT INTO classwords VALUES ('c37785b6b60e49f6a9ed71f17db2775c','1a14e488cab74a1abd7bbf900680a78d','12');----
INSERT INTO word VALUES ('35e762d7e34d4c75827b0db485efd245','monk','[mʌŋk]','http://res.iciba.com/resource/amp3/oxford/0/a8/67/a867b63d24711cdda5a1bde27e2100fe.mp3','n. 僧侣，修道士，和尚','','');----
INSERT INTO classwords VALUES ('54f43451525346bbae3f674412f9abd1','35e762d7e34d4c75827b0db485efd245','12');----
INSERT INTO word VALUES ('9e17565787724fe595e2eda85415a345','erect','[iˈrekt]','http://res.iciba.com/resource/amp3/oxford/0/27/86/27868734b6d0b0b600b9c3bba67e1d4f.mp3','adj. 直立的；竖直的','','');----
INSERT INTO classwords VALUES ('d0a9f9edc57f45309b947814c1a9650e','9e17565787724fe595e2eda85415a345','12');----
INSERT INTO word VALUES ('58de81bbc2d04aad9faca4a3d45fabf9','mist','[mist]','http://res.iciba.com/resource/amp3/oxford/0/d2/2a/d22aab0fcaec7d4e1c302c2a397f8e78.mp3','vi. 结雾；变模糊','','');----
INSERT INTO classwords VALUES ('517f8f5ca1ba4a4ab21215da312b5d21','58de81bbc2d04aad9faca4a3d45fabf9','12');----
INSERT INTO word VALUES ('9dd59da7942d428cbcc44737afdecba0','disastrous','[diˈzɑ:strəs]','http://res.iciba.com/resource/amp3/oxford/0/4a/2d/4a2d7bc914cc75f28549515b0d194cbe.mp3','adj. 灾难性的；完全失败的；极糟的','','');----
INSERT INTO classwords VALUES ('f81999ce2de04b1db1accf4411d6bcc7','9dd59da7942d428cbcc44737afdecba0','12');----
INSERT INTO word VALUES ('63991a0f1389453b979d7c28f1456013','pedestrian','[piˈdestriən]','http://res.iciba.com/resource/amp3/oxford/0/51/46/5146ec7cb0820d31ca878cbdaf970b9e.mp3','n. 行人，步行者','','');----
INSERT INTO classwords VALUES ('e321ec3383a147f49706917b271041db','63991a0f1389453b979d7c28f1456013','12');----
INSERT INTO word VALUES ('373e7de182c3477a92b370db3cfbf405','track','[træk]','http://res.iciba.com/resource/amp3/oxford/0/de/6f/de6f8570959d976d775cd0b0e1b7b4f2.mp3','vi. 追踪；追踪…的动向；探究','','');----
INSERT INTO classwords VALUES ('91b9db199eee429d9e0732816ee7f64c','373e7de182c3477a92b370db3cfbf405','12');----
INSERT INTO word VALUES ('70151cf154114d8fb2b9150b52efe61b','bureaucracy','[bjuəˈrɔkrəsi]','http://res.iciba.com/resource/amp3/oxford/0/94/ba/94baeda9bc86a056dbd7853debdfe59c.mp3','n. 官僚主义；官僚制度','','');----
INSERT INTO classwords VALUES ('e34ffc3c00d6450dbb51c76dfa6f7bf3','70151cf154114d8fb2b9150b52efe61b','12');----
INSERT INTO word VALUES ('39de49d1fdd849179b033626bd73700a','evil','[ˈi:vəl]','http://res.iciba.com/resource/amp3/oxford/0/a5/00/a50066945df0a9c04caf591824e9dea6.mp3','n. 邪恶，罪恶；祸害；恶行','','');----
INSERT INTO classwords VALUES ('d73d0204212e482c9303e4f6107bd5d1','39de49d1fdd849179b033626bd73700a','12');----
INSERT INTO word VALUES ('8dfa85ba0ba542a780c93cd46fb3c154','hoist','[hɔist]','http://res.iciba.com/resource/amp3/oxford/0/59/ae/59aea452c9cacaebb9138ad821a198fa.mp3','n. 起重机','','');----
INSERT INTO classwords VALUES ('102d42d6cc6242529298d2e6eae7cc58','8dfa85ba0ba542a780c93cd46fb3c154','12');----
INSERT INTO word VALUES ('66ebe8da9a4a4b87ac96c6e8214adcda','lily','[ˈlɪli]','http://res.iciba.com/resource/amp3/oxford/0/80/e3/80e30aa2f828dbdbafc02c7042497921.mp3','n. 百合花','','');----
INSERT INTO classwords VALUES ('7f8f457a1d2843e6a52c6af8815867d2','66ebe8da9a4a4b87ac96c6e8214adcda','12');----
INSERT INTO word VALUES ('d278c5d8163846c9871ddbacfad07d96','introduce','[ˌɪntrəˈdju:s]','http://res.iciba.com/resource/amp3/0/0/71/88/718863f992362b7ba323aa59a2a44ed1.mp3','vt. 引进；介绍；使了解；主持','','');----
INSERT INTO classwords VALUES ('52f5b3e3bbcc4848ac25b2aaff8e4574','d278c5d8163846c9871ddbacfad07d96','12');----
INSERT INTO word VALUES ('78c7f36c5e1b4a0f9f6fa05e2cb6d7d6','ignite','[iɡˈnait]','http://res.iciba.com/resource/amp3/oxford/0/21/85/2185d78ef105ed5a3e8f20ba90611814.mp3','vi. 点火','','');----
INSERT INTO classwords VALUES ('c4b65fd39369414f811bdb15530734cf','78c7f36c5e1b4a0f9f6fa05e2cb6d7d6','12');----
INSERT INTO word VALUES ('5a9a4ad0807645009d60fe0870812695','lining','[ˈlaɪnɪŋ]','http://res.iciba.com/resource/amp3/oxford/0/0c/2a/0c2adc11e59d3b3df6b717a858b5f2a2.mp3','n. （衣服的）衬里，里子；内衬，衬垫','','');----
INSERT INTO classwords VALUES ('2b72955bd0384bd4bb08a4d265d36c3f','5a9a4ad0807645009d60fe0870812695','12');----
INSERT INTO word VALUES ('bcc050c9ba164695aea7106094436468','verse','[və:s]','http://res.iciba.com/resource/amp3/0/0/8d/94/8d949bb0adb9d31a749810f79aada76a.mp3','n. 诗，韵文；诗行','','');----
INSERT INTO classwords VALUES ('0686f470be0a4b2f81d9227eeaad8dfa','bcc050c9ba164695aea7106094436468','12');----
INSERT INTO word VALUES ('b1b0fffda3f247d997ef4cd959087b20','implement','[ˈimplimənt]','http://res.iciba.com/resource/amp3/oxford/0/71/37/71377ee16a9e050aaf16a61a8f5229e4.mp3','vt. 履行，实施','','');----
INSERT INTO classwords VALUES ('a7e78b9bd78a42728eb3a74d937db7f9','b1b0fffda3f247d997ef4cd959087b20','12');----
INSERT INTO word VALUES ('2b25a665f80548c1bedf52628357c9d0','distinctly','[dɪˈstɪŋktlɪ]','http://res.iciba.com/resource/amp3/1/0/e9/55/e955c2142549ffe817e1ba3c015bf0f5.mp3','adv. 无疑地；清楚地','','');----
INSERT INTO classwords VALUES ('4656be66c4ec4320afe4ef9f358b06ea','2b25a665f80548c1bedf52628357c9d0','12');----
INSERT INTO word VALUES ('da242946790a4cadb03c138c93fc98f9','flatten','[ˈflætn]','http://res.iciba.com/resource/amp3/oxford/0/ad/e8/ade87b1eb0d070dc27e5a3cf4a82b3ad.mp3','vt. 把…弄平；打倒；摧毁','','');----
INSERT INTO classwords VALUES ('6711f8ad4e9f4807876e235ed42fe35d','da242946790a4cadb03c138c93fc98f9','12');----
INSERT INTO word VALUES ('f2e5463f68c54d268d0d442e4f385a8f','default','[diˈfɔ:lt]','http://res.iciba.com/resource/amp3/oxford/0/8e/7f/8e7ff71dc79c42f6b0bb4992f0fad565.mp3','vi. 不履行；未支付','','');----
INSERT INTO classwords VALUES ('a42e3426929146569fd8de09b6e8f8c2','f2e5463f68c54d268d0d442e4f385a8f','12');----
INSERT INTO word VALUES ('b3fd47e531554f68b190f4eab0c19af2','tar','[tɑː(r)]','http://res.iciba.com/resource/amp3/oxford/0/0f/cb/0fcb24847e8a89ff8c143707ea192957.mp3','n. 柏油，沥青；焦油','','');----
INSERT INTO classwords VALUES ('16a0d2ac4548448593315b659345f9c1','b3fd47e531554f68b190f4eab0c19af2','12');----
INSERT INTO word VALUES ('efca41350b6e4b1388b9b859917dbdeb','positively','[ˈpɔzətɪvlɪ]','http://res.iciba.com/resource/amp3/oxford/0/f6/c5/f6c565457898d8e0bc65b510667e6f93.mp3','adv. 确实；的的确确','','');----
INSERT INTO classwords VALUES ('4133ac2725c448d480e15d601e3620a9','efca41350b6e4b1388b9b859917dbdeb','12');----
INSERT INTO word VALUES ('c896a8c04e5f4c51b1e33020d683e666','jealousy','[ˈdʒeləsi:]','http://res.iciba.com/resource/amp3/oxford/0/e8/34/e834eb2a1afdd4e23e1e8f5f28b2f375.mp3','n. 妒忌；小心提防；羡慕','','');----
INSERT INTO classwords VALUES ('84b2ccc90d7341d08882823ed06eff52','c896a8c04e5f4c51b1e33020d683e666','12');----
INSERT INTO word VALUES ('af03722dc4e84bf288c55b3ad42b61d4','embarrass','[imˈbærəs]','http://res.iciba.com/resource/amp3/oxford/0/f4/af/f4afa80da4d947b8e26cdba302af6f8e.mp3','vt. 使尴尬；使…难堪；给…出难题','','');----
INSERT INTO classwords VALUES ('62c88e649bcc4d009b9d8a0492ea7c2f','af03722dc4e84bf288c55b3ad42b61d4','12');----
INSERT INTO word VALUES ('2665ac9d4592412d92364e0ef43eaf20','doom','[du:m]','http://res.iciba.com/resource/amp3/oxford/0/5b/76/5b769be7a7f935ad159c23bce3e6984e.mp3','vt. 注定','','');----
INSERT INTO classwords VALUES ('b736720911654aefa2a5e05374bdcdfe','2665ac9d4592412d92364e0ef43eaf20','12');----
INSERT INTO word VALUES ('b024db8373814da58bcd07bd49ca6eb5','recognition','[ˌrekəɡˈniʃən]','http://res.iciba.com/resource/amp3/oxford/0/ed/3a/ed3aad9c11a5b9826367729a116af6d7.mp3','n. 认出，识别；正式承认；认可','','');----
INSERT INTO classwords VALUES ('97d263992c364d31881cc4d44ab31b24','b024db8373814da58bcd07bd49ca6eb5','12');----
INSERT INTO word VALUES ('902b4257c55640cdb679b9c8bc2a7008','gross','[ɡrəus]','http://res.iciba.com/resource/amp3/0/0/58/d9/58d949771b2a49016259a9fb4fa7499e.mp3','adj. 严重的；（语言、举止）粗俗的；...','','');----
INSERT INTO classwords VALUES ('c3f6f9d06c4e4a7eb965563fd2debde8','902b4257c55640cdb679b9c8bc2a7008','12');----
INSERT INTO word VALUES ('8db3a47aa3e54674a7234c000e51dc89','classic','[ ˈklæsik]','http://res.iciba.com/resource/amp3/oxford/0/23/ac/23acd013030523e8bbf7771c1d368bb0.mp3','adj. 典型的；经典的；传统的，古雅的','','');----
INSERT INTO classwords VALUES ('d8fbdf696df3447b94c7f91ba93e6a20','8db3a47aa3e54674a7234c000e51dc89','12');----
INSERT INTO word VALUES ('dc49db5e1c5c43aebe99c091fb8120c2','handy','[ˈhændi]','http://res.iciba.com/resource/amp3/oxford/0/c4/08/c408aef0b17d6b66d311745d35b5eede.mp3','adj. 方便的；有用的；便于使用的；手...','','');----
INSERT INTO classwords VALUES ('39954e9188694653abfb0b9dfcf83870','dc49db5e1c5c43aebe99c091fb8120c2','12');----
INSERT INTO word VALUES ('3935af6c6c2d4d36ad77b26a62fdd8ab','cigar','[siˈɡɑ:]','http://res.iciba.com/resource/amp3/oxford/0/83/e2/83e24302a9047104352763c40fcedfed.mp3','n. 雪茄烟','','');----
INSERT INTO classwords VALUES ('d3c66ca0a2c04e87a00dddc77cb48a18','3935af6c6c2d4d36ad77b26a62fdd8ab','12');----
INSERT INTO word VALUES ('82100225d17a4437999702ba0fd96bd8','romantic','[rəuˈmæntik]','http://res.iciba.com/resource/amp3/oxford/0/d2/4f/d24f4999c3561a1b260055a272f7789a.mp3','adj. 不切实际的；关于爱情的；浪漫的','','');----
INSERT INTO classwords VALUES ('6a854774f76d4cfc83d0c74c57f0ed75','82100225d17a4437999702ba0fd96bd8','12');----
INSERT INTO word VALUES ('5efe1ded81624b9a91651d4187662507','consumer','[kənˈsju:mə]','http://res.iciba.com/resource/amp3/oxford/0/b8/02/b802585a5731a66465f6ba8af278db55.mp3','n. 消费者，顾客','','');----
INSERT INTO classwords VALUES ('54af2a97ca974beab32eb8597f0b7cbf','5efe1ded81624b9a91651d4187662507','12');----
INSERT INTO word VALUES ('2ac3e5e2b6d74118bb405a79ff4aa9a8','derivation','[ˌderəˈveɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/36/3a/363a439d3e02d5f325f4662b008476fb.mp3','n. 引出；起源，由来','','');----
INSERT INTO classwords VALUES ('12a195a9da95468ba5bdbf1b8c724a32','2ac3e5e2b6d74118bb405a79ff4aa9a8','12');----
INSERT INTO word VALUES ('0efb6c09bb844934b032ed53bc9e598a','penalty','[ˈpenəlti]','http://res.iciba.com/resource/amp3/oxford/0/20/30/2030475392e7dbaef3bc8c4a0a2dca85.mp3','n. 处罚；刑罚；点球；惩罚','','');----
INSERT INTO classwords VALUES ('9172c9b892aa4870ba724c99177a48fd','0efb6c09bb844934b032ed53bc9e598a','12');----
INSERT INTO word VALUES ('f61c3b9add3544399e691e4b89c66821','normalization','[ˌnɔ:məlaɪˈzeɪʃən]','http://res.iciba.com/resource/amp3/0/0/1d/a3/1da34445d471debe3d23b3716ae11498.mp3','n. 正常化，标准化','','');----
INSERT INTO classwords VALUES ('33cca2b1fb4d47c18cb6d67043dcccb9','f61c3b9add3544399e691e4b89c66821','12');----
INSERT INTO word VALUES ('3590047361554294ac2770b0312e1a5c','visit','[ˈvizit]','http://res.iciba.com/resource/amp3/oxford/0/2d/3d/2d3d153ba925b64e73edf98db5201dba.mp3','vt. 看望，拜访；访问；上门咨询','','');----
INSERT INTO classwords VALUES ('cf32c9c21ee6459c92e22213f8b5cec9','3590047361554294ac2770b0312e1a5c','12');----
INSERT INTO word VALUES ('112a9654a5fb4cac84e9ca7ce23c4935','can','[kæn]','http://res.iciba.com/resource/amp3/oxford/0/6c/fe/6cfe3df615507fb3114323f19a5661b5.mp3','vt. 装罐头；解雇，开除','','');----
INSERT INTO classwords VALUES ('a9eec27d6038447aba324099be0403b7','112a9654a5fb4cac84e9ca7ce23c4935','12');----
INSERT INTO word VALUES ('4f9daf2c6412438bbe5df2b437ad23f2','dissolve','[diˈzɔlv]','http://res.iciba.com/resource/amp3/oxford/0/db/e2/dbe21017adc42458e48682c477fb41c3.mp3','vt. 解除（婚约等）；（使）溶解；解散...','','');----
INSERT INTO classwords VALUES ('a990fe8182f844cf9da15cb28b7dc8f1','4f9daf2c6412438bbe5df2b437ad23f2','12');----
INSERT INTO word VALUES ('e3fe60a1d83b4b02b34362f49f0879c8','sweeten','[ˈswi:tn]','http://res.iciba.com/resource/amp3/oxford/0/4b/36/4b36f3dfae482d67a2a57979331ff044.mp3','vi. 变甜','','');----
INSERT INTO classwords VALUES ('4fdad638ee9e4be3a05f8a3b3a17708a','e3fe60a1d83b4b02b34362f49f0879c8','12');----
INSERT INTO word VALUES ('6d239fe5d7fb4f8d8a7bfe5e8d408ef9','sneer','[sniə]','http://res.iciba.com/resource/amp3/0/0/8a/2f/8a2f6ad17ae763c575d286bc62731bc3.mp3','vi. 冷笑；嘲笑','','');----
INSERT INTO classwords VALUES ('388d14c822b242d4aa15e6326e81fe28','6d239fe5d7fb4f8d8a7bfe5e8d408ef9','12');----
INSERT INTO word VALUES ('ecf6a4cc00e44be9ba837fe39e1351b3','mirror','[ˈmirə]','http://res.iciba.com/resource/amp3/oxford/0/1c/63/1c638bf0478313a67c95ad0bff3044d3.mp3','v. 反映；（水）照出','','');----
INSERT INTO classwords VALUES ('e1318ad881c24548af3c9402a37ee329','ecf6a4cc00e44be9ba837fe39e1351b3','12');----
INSERT INTO word VALUES ('0e4a28a3c62a45aa9f1614b06cb73db9','capacitor','[kəˈpæsɪtə]','http://res.iciba.com/resource/amp3/oxford/0/94/0d/940d45341bd7a2bf00091865ad6c9d34.mp3','n. 电容器','','');----
INSERT INTO classwords VALUES ('709d09cd305f42418f4fc826d5f84e84','0e4a28a3c62a45aa9f1614b06cb73db9','12');----
INSERT INTO word VALUES ('42ed7b8dbd8347a8bd622b6fbb638f88','formerly','[ˈfɔ:məli:]','http://res.iciba.com/resource/amp3/0/0/fc/e0/fce091a8755c8079212ca8beccea8a24.mp3','adv. 以前，从前','','');----
INSERT INTO classwords VALUES ('95a3fcba69de4ee4b10370b7f2f6019d','42ed7b8dbd8347a8bd622b6fbb638f88','12');----
INSERT INTO word VALUES ('4c8841d8197b4e84b448acba78602945','subsidiary','[səbˈsidiəri]','http://res.iciba.com/resource/amp3/oxford/0/9b/0b/9b0bc4d756be3296f9aa1cd640589817.mp3','adj. 辅助的，次要的','','');----
INSERT INTO classwords VALUES ('ec9a52b3be084d17b23b3cf4f10054ea','4c8841d8197b4e84b448acba78602945','12');----
INSERT INTO word VALUES ('a2dabdadb6fd43738bf10d494bfbdaee','extinct','[iksˈtiŋkt]','http://res.iciba.com/resource/amp3/oxford/0/9c/a7/9ca7e7417f6f869f0a9c646050512cc4.mp3','adj. 绝种的；不复存在的；（火山）死...','','');----
INSERT INTO classwords VALUES ('0055ec7dbfb24435b1577ae30ae0d667','a2dabdadb6fd43738bf10d494bfbdaee','12');----
INSERT INTO word VALUES ('c6452d60bdbe4aaa83671d26d4a86766','propel','[prəˈpel]','http://res.iciba.com/resource/amp3/oxford/0/1b/05/1b054000d7e3590ab69942af527f13d0.mp3','vt. 推进；推动','','');----
INSERT INTO classwords VALUES ('6cc8653a84ef49548a5083a42724a999','c6452d60bdbe4aaa83671d26d4a86766','12');----
INSERT INTO word VALUES ('f6bf0582821042f295a70b95f42f314a','appreciation','[əˌpri:ʃi:ˈeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/b8/75/b875c0f4d40f7f40e36694fe3ae15862.mp3','n. 欣赏；鉴赏；感激；增值','','');----
INSERT INTO classwords VALUES ('b25e7d648358458db3db7bc69db70469','f6bf0582821042f295a70b95f42f314a','12');----
INSERT INTO word VALUES ('0fb1416115a6414a89ab379b4a2d86eb','define','[diˈfain]','http://res.iciba.com/resource/amp3/oxford/0/b6/b1/b6b1e1b3633f8a7b1eadf0cb614344ff.mp3','vt. 规定；阐明；给…下定义','','');----
INSERT INTO classwords VALUES ('8dee94fa7509478f855e5d054fb8545f','0fb1416115a6414a89ab379b4a2d86eb','12');----
INSERT INTO word VALUES ('76a0f986880f4ee7988d76136590e93e','abolish','[əˈbɔliʃ]','http://res.iciba.com/resource/amp3/oxford/0/aa/f6/aaf624f7f627d0c77b67324afc845753.mp3','vt. 废除，废止','','');----
INSERT INTO classwords VALUES ('a1b5985382e24cbca38be4a4f314765a','76a0f986880f4ee7988d76136590e93e','12');----
INSERT INTO word VALUES ('3d8e11e24e904e3eb7cf99a9ba8f9823','fluctuate','[ˈflʌktjueit]','http://res.iciba.com/resource/amp3/oxford/0/3d/0c/3d0c70ebce32d43e3958eabc0769cc6b.mp3','vt. 使波动','','');----
INSERT INTO classwords VALUES ('cd4acff833824423853e09b4b4466e1e','3d8e11e24e904e3eb7cf99a9ba8f9823','12');----
INSERT INTO word VALUES ('48ab08a473e94edda9c81af25c5c20a4','trifle','[ˈtraifl]','http://res.iciba.com/resource/amp3/oxford/0/aa/dd/aadd96a28dabd73feda96efc7f3c943b.mp3','n. 琐事；少量','','');----
INSERT INTO classwords VALUES ('63e2bcbea1ec4a80a2601d3d9198356d','48ab08a473e94edda9c81af25c5c20a4','12');----
INSERT INTO word VALUES ('f7d0b677b7c348a2841ce313a794e115','position','[pəˈziʃən]','http://res.iciba.com/resource/amp3/oxford/0/a1/39/a13957fb846ed7f3002cb93e4d17b818.mp3','n. 位置，方位；姿势；社会地位；职务；...','','');----
INSERT INTO classwords VALUES ('83fca5bfd6e246babfb6583a679692f0','f7d0b677b7c348a2841ce313a794e115','12');----
INSERT INTO word VALUES ('c522a8475b044e429a0feb207a219cb6','residual','[rɪˈzɪdʒu:əl]','http://res.iciba.com/resource/amp3/oxford/0/65/9c/659cb7c6de0ad81858c9a35b785e7f45.mp3','adj. 剩余的；残留的','','');----
INSERT INTO classwords VALUES ('fa4edcafd67346fe99e212d7c4da8fce','c522a8475b044e429a0feb207a219cb6','12');----
INSERT INTO word VALUES ('d1ee4922846c4522a4e4f7b923b51358','frequent','[ˈfri:kwənt]','http://res.iciba.com/resource/amp3/0/0/03/0b/030bb043d582f8f5569a8be85ea51911.mp3','adj. 经常性的，频繁的','','');----
INSERT INTO classwords VALUES ('7120f2c41f5141bcae5947517521c434','d1ee4922846c4522a4e4f7b923b51358','12');----
INSERT INTO word VALUES ('eb7e6ab171214822ac5364a208154baa','howl','[haul]','http://res.iciba.com/resource/amp3/oxford/0/65/fe/65feb30f4c822de5cf78c038b558de69.mp3','vi. 嚎叫；哀号；放声大笑','','');----
INSERT INTO classwords VALUES ('a4e3f312015c472d91271230b63bdc16','eb7e6ab171214822ac5364a208154baa','12');----
INSERT INTO word VALUES ('c8c98eaf46dc47b6be801a79d8c2331a','hose','[həʊz]','http://res.iciba.com/resource/amp3/0/0/31/88/3188206324b062751ce36d4251c19c94.mp3','n. 袜类；软管；水管','','');----
INSERT INTO classwords VALUES ('f5fc492cc8a14a1b897d1432b66f7745','c8c98eaf46dc47b6be801a79d8c2331a','12');----
INSERT INTO word VALUES ('23e71ed577af4e3c9d6640c582125e36','dependant','[dɪˈpendənt]','http://res.iciba.com/resource/amp3/oxford/0/69/ae/69ae8c61d48389f30744d2112c2d7a73.mp3','n. 受赡养者；侍从；家眷','','');----
INSERT INTO classwords VALUES ('6a6754a92e114b6d8f29baf85fdb0f03','23e71ed577af4e3c9d6640c582125e36','12');----
INSERT INTO word VALUES ('a4d58e92c079457bad5c192a92688553','mob','[mɔb]','http://res.iciba.com/resource/amp3/0/0/41/f0/41f02b07e8e203d3260facb55b2f4b1b.mp3','vi. 团团围住，成群围住','','');----
INSERT INTO classwords VALUES ('ba9515eea8bf480b80b857a2105d268c','a4d58e92c079457bad5c192a92688553','12');----
INSERT INTO word VALUES ('cafe4146c94f45088739dcbb6616e52f','confront','[kənˈfrʌnt]','http://res.iciba.com/resource/amp3/oxford/0/61/af/61afbfca3297691aa49423377dcb8abb.mp3','vt. 使面临；面对；与…对峙','','');----
INSERT INTO classwords VALUES ('531c81eab09f461ba910904eba103170','cafe4146c94f45088739dcbb6616e52f','12');----
INSERT INTO word VALUES ('798469dc1dfd4178ba3d0a259f7c0c00','prototype','[ˈprəutətaip]','http://res.iciba.com/resource/amp3/oxford/0/50/25/50259c077c4d940c8355f7e2d5a6e106.mp3','n. 原型；典型，范例','','');----
INSERT INTO classwords VALUES ('5ff1028a8a1e4b1b922a12d65f820145','798469dc1dfd4178ba3d0a259f7c0c00','12');----
INSERT INTO word VALUES ('71d7c787904248989d79d314c70a8896','terminate','[ˈtə:mineit]','http://res.iciba.com/resource/amp3/oxford/0/06/65/066566413cebed6158830829dab51385.mp3','vt.&vi. 使终止，使结束；到达终点','','');----
INSERT INTO classwords VALUES ('a5c350c5f0a74352991ecc94cc1a38de','71d7c787904248989d79d314c70a8896','12');----
INSERT INTO word VALUES ('db664376275a4501aee12feb55f494f9','mint','[mint]','http://res.iciba.com/resource/amp3/oxford/0/20/70/207005f646ed0f819e87826063f5afac.mp3','n. 薄荷；薄荷糖；铸币厂；巨额钱财','','');----
INSERT INTO classwords VALUES ('dad9ee1311d943f18f229e14ba997508','db664376275a4501aee12feb55f494f9','12');----
INSERT INTO word VALUES ('059ffa9b485c443e9ee1a12619689f64','stagger','[ˈstæɡə]','http://res.iciba.com/resource/amp3/oxford/0/e6/a3/e6a309efa05b4104c8ebeb8af18657c0.mp3','vt. 使摇晃；使震惊；使错开','','');----
INSERT INTO classwords VALUES ('7bb463c6b0ee4559b6352127e4d619be','059ffa9b485c443e9ee1a12619689f64','12');----
INSERT INTO word VALUES ('87a97584fbe94016907e495a0b669d65','foster','[ˈfɒstə(r)]','http://res.iciba.com/resource/amp3/0/0/96/85/96853c0e2dd18a1ef79b19f485d60290.mp3','vt. 养育，收养；培养，促进','','');----
INSERT INTO classwords VALUES ('28bf144a8aca4029a410ae097ff24a30','87a97584fbe94016907e495a0b669d65','12');----
INSERT INTO word VALUES ('1ecfc93b7be142cc80c7258cd777c340','refrain','[riˈfrein]','http://res.iciba.com/resource/amp3/oxford/0/7d/e9/7de90c8cfdc19a73d806740c9a6aedc7.mp3','vi. 克制；忍住','','');----
INSERT INTO classwords VALUES ('84f8ecb52a584d66a834d7a5494118fc','1ecfc93b7be142cc80c7258cd777c340','12');----
INSERT INTO word VALUES ('c5b4223fb51b410ba954352103062f6f','vulgar','[ˈvʌlɡə]','http://res.iciba.com/resource/amp3/oxford/0/8d/21/8d21c3ebdd53b0a401b808683b8e35e2.mp3','adj. 粗俗的，庸俗的；粗鲁的','','');----
INSERT INTO classwords VALUES ('e45bce6ea0e04766b6ffcd2178217ea5','c5b4223fb51b410ba954352103062f6f','12');----
INSERT INTO word VALUES ('2c71c0fa90984849bf4b6511acafab03','penetration','[ˌpenɪˈtreɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/29/35/2935cd155a78373eda803473147417f8.mp3','n. 穿透；渗透；侵入','','');----
INSERT INTO classwords VALUES ('5593c0ecaa5f4deda010a3c7f394f29f','2c71c0fa90984849bf4b6511acafab03','12');----
INSERT INTO word VALUES ('9adcb8a509644782b60e79557328f630','virgin','[ˈvə:dʒin]','http://res.iciba.com/resource/amp3/oxford/0/5d/6b/5d6b572aa6adc259aa977ba4c144fef8.mp3','adj. 未使用的','','');----
INSERT INTO classwords VALUES ('967401c9c6f94e359762fc300aaf0166','9adcb8a509644782b60e79557328f630','12');----
INSERT INTO word VALUES ('1f76e41362914ffa827caa58e4dcc5c6','rash','[ræʃ]','http://res.iciba.com/resource/amp3/oxford/0/26/8c/268c820a722c9e86bf53377da0922237.mp3','adj. 轻率的；鲁莽的','','');----
INSERT INTO classwords VALUES ('ec0901ba0e5745a59840dab43212ea98','1f76e41362914ffa827caa58e4dcc5c6','12');----
INSERT INTO word VALUES ('cd8b6bcae2f2445e9ecaeb9af0f989b1','watchful','[ˈwɔtʃfəl]','http://res.iciba.com/resource/amp3/oxford/0/43/fa/43fa658fa208852a031b354b0dc53f8c.mp3','adj. 警觉的，警惕的','','');----
INSERT INTO classwords VALUES ('be738be26c6a42a7ae1b005ac471e2b0','cd8b6bcae2f2445e9ecaeb9af0f989b1','12');----
INSERT INTO word VALUES ('fcf3e124e6d74248ae19fabe0c16027d','lubricate','[ˈlu:brikeit]','http://res.iciba.com/resource/amp3/oxford/0/fe/dd/fedd9a583d2891ce8249675c6116c2f9.mp3','vi. 润滑','','');----
INSERT INTO classwords VALUES ('09f2f2b6e5c94944bba90f5d3ca95c74','fcf3e124e6d74248ae19fabe0c16027d','12');----
INSERT INTO word VALUES ('c71c583cac6145c9a9d1ed87087a2dab','pasture','[ˈpɑ:stʃə]','http://res.iciba.com/resource/amp3/oxford/0/2a/db/2adba855ad1a9d95161df49a6ee04f6e.mp3','n. 牧场；牧草地','','');----
INSERT INTO classwords VALUES ('d0d24c511a35426d91340ba455aad0b7','c71c583cac6145c9a9d1ed87087a2dab','12');----
INSERT INTO word VALUES ('de42c4d82a494b32b459e247b1b8b6cb','orchard','[ˈɔ:tʃəd]','http://res.iciba.com/resource/amp3/0/0/7c/ab/7cab6d16a7336d435757504337dd4a92.mp3','n. 果园','','');----
INSERT INTO classwords VALUES ('61122d56eb21483094943be130f16e41','de42c4d82a494b32b459e247b1b8b6cb','12');----
INSERT INTO word VALUES ('7a3711eaf4ea4c2895d89f07a5626d00','softness','[ˈsɔftnɪs]','http://res.iciba.com/resource/amp3/0/0/53/5c/535c96109c40130b2631c56f22d3bff7.mp3','n. 温和，柔和；柔软','','');----
INSERT INTO classwords VALUES ('baeafff62bcf47ff8572610325439e13','7a3711eaf4ea4c2895d89f07a5626d00','12');----
INSERT INTO word VALUES ('f7d51d3ae0dc44159c93744f3689d178','clip','[klip]','http://res.iciba.com/resource/amp3/oxford/0/80/e9/80e93c52881d615d674fe7c3f4e693c7.mp3','n. 夹子，回形针；剪辑','','');----
INSERT INTO classwords VALUES ('6502034c93344cb194f2d4bd9984af9d','f7d51d3ae0dc44159c93744f3689d178','12');----
INSERT INTO word VALUES ('b6c04602580b45329c1a91910c5ff5a8','author','[ˈɔ:θə]','http://res.iciba.com/resource/amp3/0/0/02/bd/02bd92faa38aaa6cc0ea75e59937a1ef.mp3','n. 著作者；作家','','');----
INSERT INTO classwords VALUES ('2882d30b015f4deba65b61ff46e7cb9d','b6c04602580b45329c1a91910c5ff5a8','12');----
INSERT INTO word VALUES ('00521352961b4723807687ce17f8bf76','stuffy','[ˈstʌfi:]','http://res.iciba.com/resource/amp3/oxford/0/b0/9b/b09b53804ee127fe1366203efd5ce811.mp3','adj. 古板的；闷热的；（鼻子）不通的','','');----
INSERT INTO classwords VALUES ('5287108d904a461f977855c04a729ec9','00521352961b4723807687ce17f8bf76','12');----
INSERT INTO word VALUES ('1334354f671f4ddf90861b6e54504c7c','hum','[hʌm]','http://res.iciba.com/resource/amp3/oxford/0/4c/82/4c82ca352a5524ac39f862a9e4ee87fe.mp3','vt. 哼曲子','','');----
INSERT INTO classwords VALUES ('0012a28757fd4a21909954091cb7477b','1334354f671f4ddf90861b6e54504c7c','12');----
INSERT INTO word VALUES ('a041ca72a54a480c957ed461e6209d82','destructive','[disˈtrʌktiv]','http://res.iciba.com/resource/amp3/oxford/0/54/fc/54fcfe2de5d848c4204fc1bbbce4be44.mp3','adj. 破坏性的，毁灭性的','','');----
INSERT INTO classwords VALUES ('6213fa18b36047b19945378faefe1755','a041ca72a54a480c957ed461e6209d82','12');----
INSERT INTO word VALUES ('04eadd5e500a40b1a715b9390ede8920','sweetness','[ˈswi:tnəs]','http://res.iciba.com/resource/amp3/oxford/0/aa/d0/aad0f1a3c1cf7fc453fe63efb5c4fe55.mp3','n. 令人愉快；芬芳','','');----
INSERT INTO classwords VALUES ('9348077b6b5a42fbb034d1087693cd20','04eadd5e500a40b1a715b9390ede8920','12');----
INSERT INTO word VALUES ('532e47bd1a074c8d846a70924107b1f4','constitute','[ˈkɔnstitju:t]','http://res.iciba.com/resource/amp3/0/0/d2/37/d23760c15fa2397e602125e28a670ba1.mp3','vt. 构成，组成；被视为；设立，成立','','');----
INSERT INTO classwords VALUES ('523a05f8656d43a58fb96c5b07951923','532e47bd1a074c8d846a70924107b1f4','12');----
INSERT INTO word VALUES ('94b0130855484c0cb6d88d5c3fd7b828','systematic','[ˌsistəˈmætik]','http://res.iciba.com/resource/amp3/oxford/0/a4/54/a45430714beab90b8babde5638cff8b0.mp3','adj. 成体系的；有条理的','','');----
INSERT INTO classwords VALUES ('becb106c107546558270038988c02a03','94b0130855484c0cb6d88d5c3fd7b828','12');----
INSERT INTO word VALUES ('fbe557cdbd77425a864df7acca124eed','comedy','[ˈkɔmidi]','http://res.iciba.com/resource/amp3/oxford/0/c6/bf/c6bf2fb6de6c9dc01f14fb83c0721c23.mp3','n. 喜剧；喜剧性；喜剧效果','','');----
INSERT INTO classwords VALUES ('2e86f65450aa4bb6a15f901b2167bc41','fbe557cdbd77425a864df7acca124eed','12');----
INSERT INTO word VALUES ('5720279aa5614f0abc548785e7b9b871','confidence','[ˈkɔnfidəns]','http://res.iciba.com/resource/amp3/oxford/0/a0/9a/a09aae1ee197685c0035caf400d175ae.mp3','n. 信任；自信；肯定；秘密','','');----
INSERT INTO classwords VALUES ('8a87d80541714159b122d589b01d6c56','5720279aa5614f0abc548785e7b9b871','12');----
INSERT INTO word VALUES ('3fef525090464ec9ba9495b109617444','reef','[ri:f]','http://res.iciba.com/resource/amp3/oxford/0/e2/da/e2dacece7f1d9cdd0dbf573b2998c560.mp3','n. 礁，礁脉','','');----
INSERT INTO classwords VALUES ('0708f68c0119402b8ae902ad46e74dfa','3fef525090464ec9ba9495b109617444','12');----
INSERT INTO word VALUES ('54c481e3a4af4b938638bbfc301e3c06','pope','[pu:p]','http://res.iciba.com/resource/amp3/0/0/73/d6/73d6323223b2413e5bfa9c6307a76a49.mp3','n. （天主教）教皇','','');----
INSERT INTO classwords VALUES ('e295b7b9540542eca7b54204fe3deffd','54c481e3a4af4b938638bbfc301e3c06','12');----
INSERT INTO word VALUES ('a52ddea563fa48578d170d08b0944538','violate','[ˈvaiəleit]','http://res.iciba.com/resource/amp3/oxford/0/44/48/4448044b7c82e5f7b7e074463c1f7772.mp3','vt. 违反，违背；侵犯；亵渎','','');----
INSERT INTO classwords VALUES ('f206a1196e9845fbbd37e7eb1f745957','a52ddea563fa48578d170d08b0944538','12');----
INSERT INTO word VALUES ('c235d89c47a0485d99bf299e9afcbae7','frail','[freil]','http://res.iciba.com/resource/amp3/oxford/0/21/c1/21c1288c12e06e55dd4409d26d0af808.mp3','adj. 虚弱的，体弱的；易碎的','','');----
INSERT INTO classwords VALUES ('4efe737d62704912885b21f25a9363e9','c235d89c47a0485d99bf299e9afcbae7','12');----
INSERT INTO word VALUES ('3c6a9a24cdf0495480f4619829cea301','fellowship','[ˈfeləuʃip]','http://res.iciba.com/resource/amp3/oxford/0/03/54/0354ede0572ef35109d1ef7aa42fe5a9.mp3','n. 友谊；联谊会；研究员职位','','');----
INSERT INTO classwords VALUES ('ec28415d60d3443dbf666ba81062b648','3c6a9a24cdf0495480f4619829cea301','12');----
INSERT INTO word VALUES ('2a9cc54693954313b1b643b94b0ab95c','pant','[pænt]','http://res.iciba.com/resource/amp3/oxford/0/19/9a/199a96a7be3a86585ed6e872e0fb09c9.mp3','vi. 喘气；喘息','','');----
INSERT INTO classwords VALUES ('b44aa546df5048b1acb7532e63938e53','2a9cc54693954313b1b643b94b0ab95c','12');----
INSERT INTO word VALUES ('4f70b5e55eb74531a3ce92b0063f8eab','ecology','[iˈkɔlədʒi]','http://res.iciba.com/resource/amp3/oxford/0/1d/6c/1d6cba999a759b348a220ad1ba2c9608.mp3','n. 生态学；生态系统','','');----
INSERT INTO classwords VALUES ('97ce192b563642309407cec63234d258','4f70b5e55eb74531a3ce92b0063f8eab','12');----
INSERT INTO word VALUES ('01712b2454e345bdbbe19ce0f288316a','dwell','[dwel]','http://res.iciba.com/resource/amp3/oxford/0/bf/36/bf36656ca4592e42f98be98797472862.mp3','vi. 居住；沉湎于','','');----
INSERT INTO classwords VALUES ('e5dabfe471254b1fa016ec0ae0b2614f','01712b2454e345bdbbe19ce0f288316a','12');----
INSERT INTO word VALUES ('c826528bc3b04ce8afe81cd0b445ca6c','loosen','[ˈlu:sən]','http://res.iciba.com/resource/amp3/oxford/0/a2/d8/a2d82e36e6afb8334afb00741a2d988f.mp3','vt. 变松；放松（限制、法律等）；使…...','','');----
INSERT INTO classwords VALUES ('a38ab36095a24997bb196631bf59ae5e','c826528bc3b04ce8afe81cd0b445ca6c','12');----
INSERT INTO word VALUES ('5ee2b1e7020b4e9c8ea8f962fcd2ea5a','fraction','[ˈfrækʃən]','http://res.iciba.com/resource/amp3/oxford/0/e7/a4/e7a418cd2552ec8ed75376e174c3a02d.mp3','n. 分数；少量；一点儿','','');----
INSERT INTO classwords VALUES ('7f16e06beb444a81a50edacbb220ff0a','5ee2b1e7020b4e9c8ea8f962fcd2ea5a','12');----
INSERT INTO word VALUES ('35374d42c24c4e54a4238f66a21b3cbf','ginger','[ˈdʒindʒə]','http://res.iciba.com/resource/amp3/oxford/0/b4/bf/b4bf6bfed836d9d4572e8b43ed8844b1.mp3','n. 姜，生姜；姜黄色','','');----
INSERT INTO classwords VALUES ('5d1612706e964659842b4da0eac2acc3','35374d42c24c4e54a4238f66a21b3cbf','12');----
INSERT INTO word VALUES ('f14de5a833954c08b75401b5011209ea','pierce','[piəs]','http://res.iciba.com/resource/amp3/0/0/2f/e2/2fe2888dfbc236be05bd44b1e7a05263.mp3','vt. 刺穿；（光线）穿透；突破','','');----
INSERT INTO classwords VALUES ('7963377ae3fb46fb8b722575de0b075f','f14de5a833954c08b75401b5011209ea','12');----
INSERT INTO word VALUES ('922a2ddf36e44337946962e2697bda67','witty','[ˈwɪti:]','http://res.iciba.com/resource/amp3/oxford/0/b3/a7/b3a71f8e559c481dd8cb48ab8d33d7cd.mp3','adj. 机智的；风趣的；妙趣横生的','','');----
INSERT INTO classwords VALUES ('e169af72ae6a4c39b495b6baeb5a25e5','922a2ddf36e44337946962e2697bda67','12');----
INSERT INTO word VALUES ('62b5eee6a4b941a199a8cd4797a29593','manuscript','[ˈmænjuskript]','http://res.iciba.com/resource/amp3/oxford/0/ca/9a/ca9a1eb54eb3f319edf681508a218992.mp3','n. 手稿，原稿；手抄本','','');----
INSERT INTO classwords VALUES ('f3a0cecaa3514fa2afd2fdc7f68db441','62b5eee6a4b941a199a8cd4797a29593','12');----
INSERT INTO word VALUES ('a8bc61a580144edc83c5e8570f324a69','explicit','[iksˈplisit]','http://res.iciba.com/resource/amp3/oxford/0/5a/34/5a344d816e9121f924009596cf6f236a.mp3','adj. 清晰的；直率的','','');----
INSERT INTO classwords VALUES ('a1b69c6d35f440388007ed9b81323ad1','a8bc61a580144edc83c5e8570f324a69','12');----
INSERT INTO word VALUES ('343bce6665e247cca1f35be09290313a','software','[ˈsɔftwɛə]','http://res.iciba.com/resource/amp3/0/0/f9/fa/f9fa10ba956cacf91d7878861139efb9.mp3','n. （计算机的）软件','','');----
INSERT INTO classwords VALUES ('c853f1436f8d49c8987ae04f50247e57','343bce6665e247cca1f35be09290313a','12');----
INSERT INTO word VALUES ('869dbc691f5340b4b45a888805f8c847','economics','[ˌɪkəˈnɔmiks]','http://res.iciba.com/resource/amp3/oxford/0/3c/be/3cbe1133b4b0c5ea32e69ad68c74bc52.mp3','n. 经济学；经济体制','','');----
INSERT INTO classwords VALUES ('e8aeadda3e4b47158c31d486fc066e57','869dbc691f5340b4b45a888805f8c847','12');----
INSERT INTO word VALUES ('dd661e65db724294b862514bc8d60360','commend','[kəˈmend]','http://res.iciba.com/resource/amp3/oxford/0/73/fe/73fe3a2f6e6f09906746e386cdbd2c8b.mp3','vt. 称赞，表扬；推荐','','');----
INSERT INTO classwords VALUES ('1eb628de605d4608ae65d3f1d1d51f1b','dd661e65db724294b862514bc8d60360','12');----
INSERT INTO word VALUES ('8417dc5a19de447cb2e5f184657acedb','category','[ˈkætiɡəri]','http://res.iciba.com/resource/amp3/oxford/0/24/b4/24b45e973bf05282c1bfa4b2cf2356d4.mp3','n. 种类，类别','','');----
INSERT INTO classwords VALUES ('8714d58187454d28a14887d9fa00264b','8417dc5a19de447cb2e5f184657acedb','12');----
INSERT INTO word VALUES ('985ef15bb5004a17aff783aa3fc03d92','litter','[ˈlitə]','http://res.iciba.com/resource/amp3/oxford/0/fa/e8/fae8c4e5a9495bbacd701f7f207a832c.mp3','vt. 使凌乱','','');----
INSERT INTO classwords VALUES ('64f040f5c3204c53bb92858a238fe34f','985ef15bb5004a17aff783aa3fc03d92','12');----
INSERT INTO word VALUES ('66d36ed365fd43c5966bc936efcb69c6','haunt','[hɔ:nt]','http://res.iciba.com/resource/amp3/oxford/0/b7/6e/b76e6ad3a933945ec6f81254fc52516a.mp3','n. 常去的地方','','');----
INSERT INTO classwords VALUES ('29f5e38c1e044883bcfbd6b2b9063aa0','66d36ed365fd43c5966bc936efcb69c6','12');----
INSERT INTO word VALUES ('06ab157705d2458f81da7d00efd02f9e','outermost','[ˈaʊtəˌməʊst]','http://res.iciba.com/resource/amp3/0/0/55/de/55def926bb8a568b32936253ccca7a13.mp3','adj. 最外面的；最远的','','');----
INSERT INTO classwords VALUES ('e9398f2f5c214e5882cce1947408b9ce','06ab157705d2458f81da7d00efd02f9e','12');----
INSERT INTO word VALUES ('16d13763a2ab43cbb213b3b8c8282129','suppress','[səˈpres]','http://res.iciba.com/resource/amp3/oxford/0/e8/76/e876703c24a99564e65faf2cb53ff66d.mp3','vt. 镇压；抑制；隐瞒','','');----
INSERT INTO classwords VALUES ('3a5cd8d996854688bf9d23d480446207','16d13763a2ab43cbb213b3b8c8282129','12');----
INSERT INTO word VALUES ('a75d6ab826724a4785a1da11ee23384a','nest','[nest]','http://res.iciba.com/resource/amp3/oxford/0/03/37/033783a94538c561edf3774cac706a03.mp3','n. 鸟巢；安乐窝','','');----
INSERT INTO classwords VALUES ('81086524eb794f5a98175b92fed9ccfa','a75d6ab826724a4785a1da11ee23384a','12');----
INSERT INTO word VALUES ('da657e93485d46dc935187531bf46fc6','develop','[diˈveləp]','http://res.iciba.com/resource/amp3/oxford/0/9d/bc/9dbc69184866f2ca3785fa12d4ad8b77.mp3','vt. 发展；出现，产生；开发（土地或地...','','');----
INSERT INTO classwords VALUES ('804f163a9ede4b6bb888d6ff7f69625f','da657e93485d46dc935187531bf46fc6','12');----
INSERT INTO word VALUES ('3525b56e95d04cf5a051f768f454d731','poultry','[ˈpəultri]','http://res.iciba.com/resource/amp3/oxford/0/b6/c4/b6c46d15929c28c2c8db8c197b9e8ee0.mp3','n. 家禽','','');----
INSERT INTO classwords VALUES ('68089fd24847442a8be78b2e41636118','3525b56e95d04cf5a051f768f454d731','12');----
INSERT INTO word VALUES ('af61f77982c941bfbcc9f8cd4b6a61ec','quench','[kwentʃ]','http://res.iciba.com/resource/amp3/oxford/0/63/93/6393ea3cd5dca761bf05be46253daa60.mp3','vt. 扑灭；解渴，止渴','','');----
INSERT INTO classwords VALUES ('74d2338b4b3a4284aef8b71d170981b4','af61f77982c941bfbcc9f8cd4b6a61ec','12');----
INSERT INTO word VALUES ('e9a2828d8b404bf3b333746c4b9ff373','capacitance','[kəˈpæsɪtəns]','http://res.iciba.com/resource/amp3/oxford/0/5f/8c/5f8ca97f1bc016b3db5cfac53974e4bc.mp3','n. 电容，电容量','','');----
INSERT INTO classwords VALUES ('8e7f4ffb5c0d49d4be93e060b5393cfc','e9a2828d8b404bf3b333746c4b9ff373','12');----
INSERT INTO word VALUES ('aff244d745844c90814c14a2cf957d79','fracture','[ˈfræktʃə]','http://res.iciba.com/resource/amp3/oxford/0/f3/b6/f3b6b3d224dfcc159d8f88e1a786a50f.mp3','vt.&vi. 使断裂；使骨折；使分裂','','');----
INSERT INTO classwords VALUES ('599e095eedf9448aab099b85a97f2aaa','aff244d745844c90814c14a2cf957d79','12');----
INSERT INTO word VALUES ('630b862870d7486995b280d093f89540','suffice','[səˈfais]','http://res.iciba.com/resource/amp3/oxford/0/5d/63/5d636ce1cd1b53f00038c6365683514d.mp3','vi. 足够，充足','','');----
INSERT INTO classwords VALUES ('9b285efd1b1f46b6bb893a0e29c06a97','630b862870d7486995b280d093f89540','12');----
INSERT INTO word VALUES ('2c7ca59d2c374ee0a1ac9c7fa011ef5d','soften','[ˈsɔ:fən]','http://res.iciba.com/resource/amp3/0/0/2f/b9/2fb93a8ef86ff969c9cd6b57cd6ba4da.mp3','vi. 变软，变柔和；变温和','','');----
INSERT INTO classwords VALUES ('f921a3835ac347759a906450d7713b66','2c7ca59d2c374ee0a1ac9c7fa011ef5d','12');----
INSERT INTO word VALUES ('af8a4b2cd54c4a4a80849440552af2bb','whisper','[ˈhwispə]','http://res.iciba.com/resource/amp3/oxford/0/38/f1/38f18e96febbb79a0487aae9b2dc7992.mp3','vt. 低声地讲；私下谈论；沙沙作响','','');----
INSERT INTO classwords VALUES ('0e3c78fbe0b446b6854eb28b5598f7a0','af8a4b2cd54c4a4a80849440552af2bb','12');----
INSERT INTO word VALUES ('041fa997cb694215af84c41658a9dc2c','pious','[ˈpaɪəs]','http://res.iciba.com/resource/amp3/oxford/0/8a/2a/8a2af3186accde01f9c3b0f697ef72f5.mp3','adj. 虔诚的；伪善的','','');----
INSERT INTO classwords VALUES ('a23ce2981f384bd68afca236a510d6e5','041fa997cb694215af84c41658a9dc2c','12');----
INSERT INTO word VALUES ('52b1d247196a48b8a0d4ad186545847a','minimize','[ˈminimaiz]','http://res.iciba.com/resource/amp3/oxford/0/95/91/959189e195844738315f4640fa8f6d6d.mp3','vt. 使减至最低程度；对…轻描淡写','','');----
INSERT INTO classwords VALUES ('b4c3ec522e24476fa64d05db8b9e6754','52b1d247196a48b8a0d4ad186545847a','12');----
INSERT INTO word VALUES ('58ae8887038742a1a28d21fbd3c641b8','assessment','[əˈsesmənt]','http://res.iciba.com/resource/amp3/oxford/0/3d/54/3d54dd133f95e86d44585df5e6df07e5.mp3','n. 评估；评定；评价','','');----
INSERT INTO classwords VALUES ('362055cbf7244278b91be72e430274e6','58ae8887038742a1a28d21fbd3c641b8','12');----
INSERT INTO word VALUES ('c10c40d8e1b84ce4a53946347e5f4aeb','awake','[əˈweik]','http://res.iciba.com/resource/amp3/oxford/0/cb/b2/cbb217e287117defc3038c99ae360f18.mp3','vi. 唤起，唤醒，醒来','','');----
INSERT INTO classwords VALUES ('51805f844a3945128ac64bd8b7b17cbd','c10c40d8e1b84ce4a53946347e5f4aeb','12');----
INSERT INTO word VALUES ('13a578b482f0497cbcd2c87de1feb09f','stereo','[ˈstiəriəu]','http://res.iciba.com/resource/amp3/oxford/0/4e/86/4e86fa6bbd4b6e26eec3d6ea8ddba8af.mp3','adj. 立体声的','','');----
INSERT INTO classwords VALUES ('04413345be0d49a5b470f6aea9d9e4a8','13a578b482f0497cbcd2c87de1feb09f','12');----
INSERT INTO word VALUES ('b84bbe3059734bd6ab24e8d6f94be5d1','historic','[hisˈtɔrik]','http://res.iciba.com/resource/amp3/oxford/0/f1/d8/f1d8d431924988ac1e46b2213c045201.mp3','adj. 历史的；历史性的','','');----
INSERT INTO classwords VALUES ('ab8379ab836b48d9a3708316728eb885','b84bbe3059734bd6ab24e8d6f94be5d1','12');----
INSERT INTO word VALUES ('e8b501b3efd5440c8ed6c4fd91339654','mop','[mɔp]','http://res.iciba.com/resource/amp3/0/0/b7/20/b7208774faea1d155062bdb773b5f221.mp3','v. 用拖把拖；擦拭','','');----
INSERT INTO classwords VALUES ('de70517c4eef4056a6333a3545db8d9f','e8b501b3efd5440c8ed6c4fd91339654','12');----
INSERT INTO word VALUES ('c4e62a27b8314c2aa19085d868cf608a','luminous','[ˈlu:minəs]','http://res.iciba.com/resource/amp3/oxford/0/a6/56/a656e61f78355fb4afca23ad7e2eef01.mp3','adj. 发光的；发亮的','','');----
INSERT INTO classwords VALUES ('c40e1d4224fa48fd9a73cbd25b7b5285','c4e62a27b8314c2aa19085d868cf608a','12');----
INSERT INTO word VALUES ('b655cb3c3ede4063b17d5499c05f5f52','irrigation','[ˌɪrɪˈɡeɪʃn]','http://res.iciba.com/resource/amp3/0/0/53/8b/538b1a3a2a9a124696eb5f197298d3e7.mp3','n. 灌溉；[医]冲洗','','');----
INSERT INTO classwords VALUES ('563cf24a0e354ebca235b72bd84bec12','b655cb3c3ede4063b17d5499c05f5f52','12');----
INSERT INTO word VALUES ('e06a1d2e051b4679920d528aec46ea1c','laundry','[ˈlɔ:ndri]','http://res.iciba.com/resource/amp3/oxford/0/93/23/932370ec697b9b0e6c0d5075e729d815.mp3','n. 洗衣店；洗衣房；洗好的衣服；待洗的...','','');----
INSERT INTO classwords VALUES ('c798d107a4654bceb4abe274b1da6414','e06a1d2e051b4679920d528aec46ea1c','12');----
INSERT INTO word VALUES ('288375f72f42412695141326f0cc8029','ripple','[ˈripl]','http://res.iciba.com/resource/amp3/oxford/0/a6/75/a6755b30728f06fe229e25cb5493d8c8.mp3','n. 涟漪，细浪；波痕','','');----
INSERT INTO classwords VALUES ('06455d1d8f8b4d97b06280af85161019','288375f72f42412695141326f0cc8029','12');----
INSERT INTO word VALUES ('a1e3be8d6427437296057a57e93e824f','magistrate','[ˈmædʒistrit]','http://res.iciba.com/resource/amp3/oxford/0/3f/fc/3ffc7374886476c03d2072a4e9199262.mp3','n. 地方法官，治安法官','','');----
INSERT INTO classwords VALUES ('42fc1de023124fccb4600eff1f385661','a1e3be8d6427437296057a57e93e824f','12');----
INSERT INTO word VALUES ('0031ab937d634899b231224f6e6511da','herd','[hə:d]','http://res.iciba.com/resource/amp3/0/0/cc/24/cc249d0a9116e1ab890d8b52586bc702.mp3','n. 兽群','','');----
INSERT INTO classwords VALUES ('f26806e6d7fc4cc58f696b6bea46df11','0031ab937d634899b231224f6e6511da','12');----
INSERT INTO word VALUES ('7b4847fb5e804b8b90cbd95b9ea2de2f','correctly','[kəˈrektlɪ]','http://res.iciba.com/resource/amp3/0/0/45/2f/452faada9535dd2c46b4a95ff0cbc35c.mp3','adv. 正确地，得体地','','');----
INSERT INTO classwords VALUES ('ca9f434766e64b149b15cf8359d718aa','7b4847fb5e804b8b90cbd95b9ea2de2f','12');----
INSERT INTO word VALUES ('c24ca7ddbc6c421fa3ad096e2700dbd6','commodity','[kəˈmɔditi]','http://res.iciba.com/resource/amp3/oxford/0/22/5f/225f1ae5ead6f6affd90ef20a8b3561c.mp3','n. 商品','','');----
INSERT INTO classwords VALUES ('5550b42cf1b14a1faacd85dee7dabecd','c24ca7ddbc6c421fa3ad096e2700dbd6','12');----
INSERT INTO word VALUES ('adb9593edec14fd89d73c3f03961058b','input','[ˈinput]','http://res.iciba.com/resource/amp3/oxford/0/67/7e/677ec63ddd3caa9cbeca609e850b3756.mp3','n. 输入；投入物（指信息、资源等）','','');----
INSERT INTO classwords VALUES ('85aaf716f4ac4dd691928f0175a4f4a9','adb9593edec14fd89d73c3f03961058b','12');----
INSERT INTO word VALUES ('8766b8ce1fe94f54a091398ee24ba233','hearth','[hɑ:θ]','http://res.iciba.com/resource/amp3/0/0/e3/92/e3920be4c1e4d4d12888f1ec8a03ce9e.mp3','n. 壁炉地面；壁炉炉床','','');----
INSERT INTO classwords VALUES ('ff80d1ecaf664d56965ae909318dcd62','8766b8ce1fe94f54a091398ee24ba233','12');----
INSERT INTO word VALUES ('096b465041a340c8b93f8c262775e177','motel','[məuˈtel]','http://res.iciba.com/resource/amp3/oxford/0/df/66/df66b29ed57675e5c848456b92a8b3a0.mp3','n. 汽车旅馆','','');----
INSERT INTO classwords VALUES ('399423cd26f04fd2a21e024524c90d02','096b465041a340c8b93f8c262775e177','12');----
INSERT INTO word VALUES ('471eb6589494463382a2cedfbc9722ea','subject','[ˈsʌbdʒikt]','http://res.iciba.com/resource/amp3/oxford/0/66/c4/66c41973aecd189e1cc48f7e6f7a8251.mp3','n. 主题；对象；科目；研究对象','','');----
INSERT INTO classwords VALUES ('583b25101f484734a0ad3a3fffe89be0','471eb6589494463382a2cedfbc9722ea','12');----
INSERT INTO word VALUES ('432ad477803b49748d22e6204c0f0c84','cartridge','[ˈkɑ:tridʒ]','http://res.iciba.com/resource/amp3/oxford/0/68/3e/683ee6ccadac2c0d1d0b3eb3c6810ac8.mp3','n. 弹药筒；子弹','','');----
INSERT INTO classwords VALUES ('fcc8c6e6006346038d36af2dc351fd78','432ad477803b49748d22e6204c0f0c84','12');----
INSERT INTO word VALUES ('3b1ea038625344bd91f5d68512d13d46','milky','[ˈmɪlki:]','http://res.iciba.com/resource/amp3/oxford/0/09/46/09469d9e6f2048256087fc814c3ce5fd.mp3','adj. 含奶多的；掺奶的；乳白色的','','');----
INSERT INTO classwords VALUES ('4e21bb4d909a458c8d7fdcb195469759','3b1ea038625344bd91f5d68512d13d46','12');----
INSERT INTO word VALUES ('b68ac19fb53e4f74bea755db3f9451b9','tilt','[tilt]','http://res.iciba.com/resource/amp3/oxford/0/52/21/5221d817df4b725747cf0f685bc5ad42.mp3','vt. 使倾斜；倾侧；使倾向于','','');----
INSERT INTO classwords VALUES ('4d26501d3b8f496d98414324418ef4f0','b68ac19fb53e4f74bea755db3f9451b9','12');----
INSERT INTO word VALUES ('1be7584d9b354b638f2bb7bec2b778b1','dedicate','[ˈdedikeit]','http://res.iciba.com/resource/amp3/oxford/0/8b/a8/8ba826d039975c1b6ce079d7c58df7be.mp3','vt. 致力，献身，投身','','');----
INSERT INTO classwords VALUES ('82905d37d86f47fe84c4199e226780cd','1be7584d9b354b638f2bb7bec2b778b1','12');----
INSERT INTO word VALUES ('c595b64d99ac44b780305fc0e8d06a6f','heave','[hi:v]','http://res.iciba.com/resource/amp3/oxford/0/c4/9f/c49f4f9e8aae20d18946328c664826c0.mp3','vt. （用力地）举起；使起伏；呕吐','','');----
INSERT INTO classwords VALUES ('9d20f932f33744d6a741f01c1903423f','c595b64d99ac44b780305fc0e8d06a6f','12');----
INSERT INTO word VALUES ('e54eff0c03ff451a887437bfb52a9304','overseas','[ˌəuvəˈsi:z]','http://res.iciba.com/resource/amp3/oxford/0/28/9a/289a06b3d31fb81855df1608e4caaaa7.mp3','adj. 在海外的，在国外的；来自海外的','','');----
INSERT INTO classwords VALUES ('9c7a297394b6428b861085470a27ea60','e54eff0c03ff451a887437bfb52a9304','12');----
INSERT INTO word VALUES ('9ec6fb4063634509ab162524581ca48b','hook','[huk]','http://res.iciba.com/resource/amp3/oxford/0/09/63/09632efd54105a00d66a96d1558f5fac.mp3','vt. 用钩吊住；（用手臂、腿或脚）钩住...','','');----
INSERT INTO classwords VALUES ('3ec75d75a7374338a23eeb7863f58174','9ec6fb4063634509ab162524581ca48b','12');----
INSERT INTO word VALUES ('ba1c80dc95574191b8c09a4849d0951e','slave','[sleiv]','http://res.iciba.com/resource/amp3/oxford/0/97/b1/97b19ac9486b2525f08bc48fc8cfd8d1.mp3','n. 奴隶；被控制的人','','');----
INSERT INTO classwords VALUES ('d7e2196684284a77952ea35bc106aaa6','ba1c80dc95574191b8c09a4849d0951e','12');----
INSERT INTO word VALUES ('d17645d8788641ac99c75eea1b4782d4','divert','[daiˈvə:t]','http://res.iciba.com/resource/amp3/oxford/0/64/84/6484000f5fb236a9f28d8da37cf1ad6d.mp3','vi. 转移','','');----
INSERT INTO classwords VALUES ('7e35c886f64c4086b30233bcde33479a','d17645d8788641ac99c75eea1b4782d4','12');----
INSERT INTO word VALUES ('622763eac9f64d25af2ee97d9ad0ea0f','sodium','[ˈsəʊdi:əm]','http://res.iciba.com/resource/amp3/oxford/0/ef/d3/efd353f12a6aef185083aa756fed794f.mp3','n. 钠','','');----
INSERT INTO classwords VALUES ('91a5faeaebbc43fb8c580866d50a6b2a','622763eac9f64d25af2ee97d9ad0ea0f','12');----
INSERT INTO word VALUES ('5a9b8b4ef36343dc9f0b111a432f9eb0','web','[web]','http://res.iciba.com/resource/amp3/oxford/0/31/44/3144bd439aa47f49c6fcc17bc983658e.mp3','n. 蜘蛛网；网络；错综复杂的联系（或关...','','');----
INSERT INTO classwords VALUES ('c9d7b5c0a9734b0bbea3c921d97647b3','5a9b8b4ef36343dc9f0b111a432f9eb0','12');----
INSERT INTO word VALUES ('f7b4c07fa6864a81b8e67671aa0ccfcf','abundance','[əˈbʌndəns]','http://res.iciba.com/resource/amp3/oxford/0/94/58/945864aa28a2115cc9e07bcd1439756c.mp3','n. 丰富，充裕','','');----
INSERT INTO classwords VALUES ('8bcd29b35bdb480faf22985d34ee75cb','f7b4c07fa6864a81b8e67671aa0ccfcf','12');----
INSERT INTO word VALUES ('b2329edf48a442958de69831b4af9aad','valve','[vælv]','http://res.iciba.com/resource/amp3/oxford/0/54/c5/54c55537e149ff01610ba445d906c9dc.mp3','n. 阀，阀门；（心脏的）瓣','','');----
INSERT INTO classwords VALUES ('e6618fd8e7a74a25b1136813675a2647','b2329edf48a442958de69831b4af9aad','12');----
INSERT INTO word VALUES ('a397569bddde4cfd8714806dadada685','analogue','[ˈænəˌlɔ:g]','http://res.iciba.com/resource/amp3/oxford/0/eb/f2/ebf2798954699bc46a60aa87d39dd20a.mp3','n. 类似物','','');----
INSERT INTO classwords VALUES ('059b4c8b22e3427093f91242e26f0b44','a397569bddde4cfd8714806dadada685','12');----
INSERT INTO word VALUES ('845dd753e7374b4fae3086442f7c7fb4','preach','[pri:tʃ]','http://res.iciba.com/resource/amp3/oxford/0/bb/4d/bb4d55b7e2477e644ecb30e621c858fc.mp3','vt. 说教；布道；鼓吹','','');----
INSERT INTO classwords VALUES ('958c087f498d44dfb1c9110d7312fbe5','845dd753e7374b4fae3086442f7c7fb4','12');----
INSERT INTO word VALUES ('01fffe121dde437aadf4f402fd869c5b','dean','[di:n]','http://res.iciba.com/resource/amp3/oxford/0/2b/f3/2bf3661c53da590830ad63a9a4a14450.mp3','n. （大学）院长，教务长；[宗]主任牧...','','');----
INSERT INTO classwords VALUES ('c4804cacb6164d84b2d4010dd5e10cab','01fffe121dde437aadf4f402fd869c5b','12');----
INSERT INTO word VALUES ('373bb0eaf6c849bb94f0d734a07d7db9','spectrum','[ˈspektrəm]','http://res.iciba.com/resource/amp3/oxford/0/f3/87/f387a329b0004e3de161d0f576438007.mp3','n. 系列，范围；波谱','','');----
INSERT INTO classwords VALUES ('09cce4928fbf4d7eae8c55a5eb496fe7','373bb0eaf6c849bb94f0d734a07d7db9','12');----
INSERT INTO word VALUES ('079f40d3544746649b22f9dd5f87b479','denote','[diˈnəut]','http://res.iciba.com/resource/amp3/0/0/60/84/60847167b54cca7e61cf2781a28002e3.mp3','vt. 预示；是…的标记；意思是','','');----
INSERT INTO classwords VALUES ('ff51d01ee92d49ccbc1a342bab733b2d','079f40d3544746649b22f9dd5f87b479','12');----
INSERT INTO word VALUES ('eb2b1bda6d1c43c584370c3f2c935b38','section','[ ˈsekʃən]','http://res.iciba.com/resource/amp3/oxford/0/14/a5/14a54bc6594a3b3d4768d3cecd35497d.mp3','n. 部分；节，章；剖面图','','');----
INSERT INTO classwords VALUES ('23d06e1c8fa242ecb8b274be4f0ade2c','eb2b1bda6d1c43c584370c3f2c935b38','12');----
INSERT INTO word VALUES ('238cfc5e2d8b41fdb92f8344af97e995','melancholy','[ˈmelənkəli]','http://res.iciba.com/resource/amp3/oxford/0/f5/c6/f5c604b12ca22e24b5e6562254b27bfb.mp3','adj. 忧郁的；悲伤的','','');----
INSERT INTO classwords VALUES ('85e472c8dc634113b4092535e970233f','238cfc5e2d8b41fdb92f8344af97e995','12');----
INSERT INTO word VALUES ('bb4d437b79f4484ebe499d6581678e89','validity','[vəˈlɪdɪtɪ]','http://res.iciba.com/resource/amp3/oxford/0/09/73/0973f7e1bb08b56bff49ca5923418f9f.mp3','n. 有效，效力；可信性','','');----
INSERT INTO classwords VALUES ('c5038dcbb58745b79937cfcf05e559dc','bb4d437b79f4484ebe499d6581678e89','12');----
INSERT INTO word VALUES ('8650bc101d5548b4881679e0a3c86843','trade','[treid]','http://res.iciba.com/resource/amp3/oxford/0/c1/18/c1180b7a54e3f34067b595b61ece8a5f.mp3','vi. 做买卖；交换；用…进行交换','','');----
INSERT INTO classwords VALUES ('3ab1ecb00328408bb2ce9b53a43eae0c','8650bc101d5548b4881679e0a3c86843','12');----
INSERT INTO word VALUES ('952f2f0c9bb745ba8f235f1886854a9e','groove','[ɡru:v]','http://res.iciba.com/resource/amp3/oxford/0/98/5b/985bb2f65bcf2953128c0b44aafbd974.mp3','vt. 开槽于','','');----
INSERT INTO classwords VALUES ('6c45801ee393471aa83772651e9825f8','952f2f0c9bb745ba8f235f1886854a9e','12');----
INSERT INTO word VALUES ('90c258d1de8b4e5dbea7e02a1cb71ac6','crack','[kræk]','http://res.iciba.com/resource/amp3/oxford/0/6c/87/6c87f04708048eaf6222a2e569542094.mp3','vt. 破裂，裂开；发出爆裂声；重击；打...','','');----
INSERT INTO classwords VALUES ('d1025c595b2347ed82c7b4701b7408d6','90c258d1de8b4e5dbea7e02a1cb71ac6','12');----
INSERT INTO word VALUES ('b69fb8b0f8fa4fb79b50f6f50bd22dac','algebra','[ˈældʒibrə]','http://res.iciba.com/resource/amp3/oxford/0/5e/a8/5ea8ed62fc20b5a4322948ee63d1708c.mp3','n. 代数学，代数','','');----
INSERT INTO classwords VALUES ('2da10062f42b406d83dcfa73032fdddc','b69fb8b0f8fa4fb79b50f6f50bd22dac','12');----
INSERT INTO word VALUES ('d4f3b8599c784453bd67021a427ba0f9','reckless','[ˈreklis]','http://res.iciba.com/resource/amp3/oxford/0/4f/88/4f8888b3032cbdfc24ae79759d50c892.mp3','adj. 粗心大意的；鲁莽的','','');----
INSERT INTO classwords VALUES ('475d53d7f0dc4dc0b96101302e6c33e0','d4f3b8599c784453bd67021a427ba0f9','12');----
INSERT INTO word VALUES ('ec62cf6193e449eea2dad5eaf61ca4df','replacement','[riˈpleismənt]','http://res.iciba.com/resource/amp3/oxford/0/6f/58/6f580f228a61a5b1e8ed4e31e30afd2d.mp3','n. 接替者；替代，替换','','');----
INSERT INTO classwords VALUES ('c917d97196cf45d48715f4871d779880','ec62cf6193e449eea2dad5eaf61ca4df','12');----
INSERT INTO word VALUES ('c7abae7ae97a4b68bc308d371763d723','cluster','[ˈklʌstə]','http://res.iciba.com/resource/amp3/oxford/0/b2/73/b2734bbe343c34c375924b73190f8527.mp3','vt. 使聚集','','');----
INSERT INTO classwords VALUES ('dd7ad94aef2a4d2c9e90019d910509eb','c7abae7ae97a4b68bc308d371763d723','12');----
INSERT INTO word VALUES ('f8c447cbbb9d4a6bb707a5a8225b8bfd','mighty','[ˈmaɪti:]','http://res.iciba.com/resource/amp3/oxford/0/01/1b/011b8c553772de1bc899f3e26bec7eef.mp3','adj. 强大的；巨大的','','');----
INSERT INTO classwords VALUES ('db3b06bc68cc4e05b68da3bcbf2b8af3','f8c447cbbb9d4a6bb707a5a8225b8bfd','12');----
INSERT INTO word VALUES ('562d101f536a4812838169a1be2a7918','responsible','[ riˈspɔnsəbl]','http://res.iciba.com/resource/amp3/oxford/0/73/8e/738e6d8e4326f8cd538ccb3f90ead70b.mp3','adj. 负有责任的；对…负责的；有责任...','','');----
INSERT INTO classwords VALUES ('10e1ce0485f24dd788f8205a46f2ef45','562d101f536a4812838169a1be2a7918','12');----
INSERT INTO word VALUES ('20a2411a028d43c3b4ffbaeacea93031','paragraph','[ˈpærəɡrɑ:f]','http://res.iciba.com/resource/amp3/oxford/0/3b/02/3b023117051a5823a56c7abe13cc2e74.mp3','n. 段，段落','','');----
INSERT INTO classwords VALUES ('7acdbc60e17744f8bfde041181d655a3','20a2411a028d43c3b4ffbaeacea93031','12');----
INSERT INTO word VALUES ('e9689b7aa82945dca24cc38d3c5a88d3','troublesome','[ˈtrʌblsəm]','http://res.iciba.com/resource/amp3/oxford/0/ba/7f/ba7fda6aa1298bd3174f581e5f5fc298.mp3','adj. 令人烦恼的；麻烦的','','');----
INSERT INTO classwords VALUES ('6fb602b4e39a401bbcf5e17416fc8db9','e9689b7aa82945dca24cc38d3c5a88d3','12');----
INSERT INTO word VALUES ('dcc6667168b7463e8c527ec59bf560e6','question','[ˈkwestʃən]','http://res.iciba.com/resource/amp3/oxford/0/d8/9f/d89fd180a68c09f0b767651fdfcdf231.mp3','vt. 盘问，询问；对…有疑问','','');----
INSERT INTO classwords VALUES ('e12ef76e556e43138e78d2687f34021a','dcc6667168b7463e8c527ec59bf560e6','12');----
INSERT INTO word VALUES ('5fc9fbf34f284c14b5537b5029ee61ae','vault','[vɔ:lt]','http://res.iciba.com/resource/amp3/oxford/0/85/d0/85d022c5304e98edfe339db4e112dcd9.mp3','n. 拱顶；金库；墓穴','','');----
INSERT INTO classwords VALUES ('ea7d0b3d82da45089a2f86e643f5bdf8','5fc9fbf34f284c14b5537b5029ee61ae','12');----
INSERT INTO word VALUES ('d1e5f3ab0a9c49ffa93dfcaf282ea81f','apparent','[əˈpærənt]','http://res.iciba.com/resource/amp3/oxford/0/f5/2a/f52a9c9e9b1a91816ecee3c2e0f69cbe.mp3','adj. 明显的；显而易见的；表面上的','','');----
INSERT INTO classwords VALUES ('ba3178a919d04528b59dc8aaf4e234ac','d1e5f3ab0a9c49ffa93dfcaf282ea81f','12');----
INSERT INTO word VALUES ('65ba3fc7ec3045ed8ac0fef203636e23','grove','[ɡrəuv]','http://res.iciba.com/resource/amp3/0/0/0d/55/0d559e519daf758269afa7f35cedb103.mp3','n. 小树林；树丛','','');----
INSERT INTO classwords VALUES ('8bd926cb75f44f79a2203f81e31f8634','65ba3fc7ec3045ed8ac0fef203636e23','12');----
INSERT INTO word VALUES ('3338ef37ba9b41049eaa3c46bf89e21f','pipe','[paip]','http://res.iciba.com/resource/amp3/oxford/0/e6/a6/e6a61fb4604d3f94e62fe9d555fbbc5c.mp3','n. 管乐器；管道；烟斗','','');----
INSERT INTO classwords VALUES ('4ec7210a3d65490b9b7a4f48ae6a84b4','3338ef37ba9b41049eaa3c46bf89e21f','12');----
INSERT INTO word VALUES ('1bfe294c65864d448304c3af52c3312a','scripture','[ˈskrɪptʃə]','http://res.iciba.com/resource/amp3/oxford/0/d8/aa/d8aa965d7782ef03ba41e73b702ad0c6.mp3','n. 经典，经文','','');----
INSERT INTO classwords VALUES ('7895b25333cf4e11b40c014bb6b2a6f5','1bfe294c65864d448304c3af52c3312a','12');----
INSERT INTO word VALUES ('eb0afd28c6ab4b1f86821c5fb8321d46','tickle','[ˈtikl]','http://res.iciba.com/resource/amp3/oxford/0/5d/98/5d9830155b378a3fc87c0294366182e4.mp3','vt. 胳肢；使笑个不停；使发痒；使开心','','');----
INSERT INTO classwords VALUES ('edc0fecf5457404badefb702d0102237','eb0afd28c6ab4b1f86821c5fb8321d46','12');----
INSERT INTO word VALUES ('a8bb665756b84d10a450c8292e2a4e6f','mast','[mɑ:st]','http://res.iciba.com/resource/amp3/0/0/ce/b7/ceb74219d144ab5760a228e71440c5ca.mp3','vt. 在…上装桅杆','','');----
INSERT INTO classwords VALUES ('a2d7e8433a2245f39e31070292a5cae7','a8bb665756b84d10a450c8292e2a4e6f','12');----
INSERT INTO word VALUES ('db8a297c862e473493ce58384130ac71','persistence','[pəˈsɪstəns]','http://res.iciba.com/resource/amp3/oxford/0/4a/82/4a822fa7d4a2d41d6145464ce332377c.mp3','n. 锲而不舍；持续','','');----
INSERT INTO classwords VALUES ('8071b996a7524bf78b8bdadf87a1cb11','db8a297c862e473493ce58384130ac71','12');----
INSERT INTO word VALUES ('07b03f4e4f9f4e558047b06b8ad00365','deposit','[diˈpɔzit]','http://res.iciba.com/resource/amp3/oxford/0/22/e2/22e2f2523b249552caed30d4d02df3fe.mp3','n. 押金；寄存物；保证金；存款','','');----
INSERT INTO classwords VALUES ('c045dd72696846278e3a3213855d6dc6','07b03f4e4f9f4e558047b06b8ad00365','12');----
INSERT INTO word VALUES ('b1bb79ec59ce4efd9e80b607f421d153','first-rate','[ˈfɜ:stˈreɪt]','http://res.iciba.com/resource/amp3/1/0/29/27/2927099c7129e5e67b031f9eb65b6349.mp3','adj. 一流的；高级的','','');----
INSERT INTO classwords VALUES ('16dc78ea7bdd486c99b0202337ecfc8e','b1bb79ec59ce4efd9e80b607f421d153','12');----
INSERT INTO word VALUES ('e6a58d5b95214bb1850026dab06fee8c','snore','[snɔ:]','http://res.iciba.com/resource/amp3/oxford/0/7f/04/7f041bed375cb65c18108e4885411fd7.mp3','vi. 打鼾，打呼噜','','');----
INSERT INTO classwords VALUES ('0a9e5044974e4f768e54913dce5f5ef7','e6a58d5b95214bb1850026dab06fee8c','12');----
INSERT INTO word VALUES ('333d6e0c31c44e439b2275f7eae86231','concession','[kənˈseʃən]','http://res.iciba.com/resource/amp3/oxford/0/76/f1/76f1e69c949f0750c275e577ba0d93e5.mp3','n. 让步，妥协；特许权','','');----
INSERT INTO classwords VALUES ('02ff8885f03543d39e30a8ecc36593ff','333d6e0c31c44e439b2275f7eae86231','12');----
INSERT INTO word VALUES ('277952b6b3aa48449381ef70ba859e56','forge','[fɔ:dʒ]','http://res.iciba.com/resource/amp3/0/0/22/84/228410f5c71f8af2b1266b70fa7824eb.mp3','vt. 缔造；创造，开创；伪造','','');----
INSERT INTO classwords VALUES ('2f070aa2db554f7197d52a636c3323ff','277952b6b3aa48449381ef70ba859e56','12');----
INSERT INTO word VALUES ('217d1e43e6cd4425bab5ade076250f85','charcoal','[ˈtʃɑ:kəul]','http://res.iciba.com/resource/amp3/0/0/42/13/42133a3dcbeafd8d1b0a68cae646de2a.mp3','n. 木炭；炭笔','','');----
INSERT INTO classwords VALUES ('8fa2c3f50f8544259ef219169126396f','217d1e43e6cd4425bab5ade076250f85','12');----
INSERT INTO word VALUES ('56761ec4200f4a4aace721c03acb797f','noted','[ˈnəʊtɪd]','http://res.iciba.com/resource/amp3/oxford/0/6c/14/6c14d56421bb39c89cc47ff0f22aec2f.mp3','adj. 著名的，知名的','','');----
INSERT INTO classwords VALUES ('148ed1b5b0a541d18f73bbb7e2a5ec2b','56761ec4200f4a4aace721c03acb797f','12');----
INSERT INTO word VALUES ('424f0e32c13c41d4bbe1bcdad519d2e6','pitch','[pitʃ]','http://res.iciba.com/resource/amp3/oxford/0/99/7a/997ad83c1ee5ee490bd0d33b6a71dccf.mp3','n. 球场；音高；程度；沥青','','');----
INSERT INTO classwords VALUES ('e998e8d475e447f5b771e9186135e561','424f0e32c13c41d4bbe1bcdad519d2e6','12');----
INSERT INTO word VALUES ('25b083d7116948e49defe9fec88df1c8','pedal','[ˈpedl]','http://res.iciba.com/resource/amp3/oxford/0/8e/a8/8ea8998cc2c7c4e943d43abcbc614711.mp3','n. 踏板，脚蹬','','');----
INSERT INTO classwords VALUES ('b722e6f0ccf14711ad8307c56cdb6e9d','25b083d7116948e49defe9fec88df1c8','12');----
INSERT INTO word VALUES ('aedcf53c2ac041d390a564290fc4af7a','kilowatt','[ˈkɪləˌwɔt]','http://res.iciba.com/resource/amp3/oxford/0/b6/0c/b60ce104625875cb02c9ce72555f5d6b.mp3','n. 千瓦','','');----
INSERT INTO classwords VALUES ('357d84f28a4b4d01845085ed9a8db297','aedcf53c2ac041d390a564290fc4af7a','12');----
INSERT INTO word VALUES ('33e69545df02420b8ac7423e28a7fa56','annually','[ˈænjʊəlɪ]','http://res.iciba.com/resource/amp3/oxford/0/7e/9d/7e9d143ee851f7914e26dc2599ca4bb3.mp3','adv. 年年，每年','','');----
INSERT INTO classwords VALUES ('d9286a89a8614c10b45981ce8a31b6b6','33e69545df02420b8ac7423e28a7fa56','12');----
INSERT INTO word VALUES ('3a6d8d2fddd849c3b936d16eaa3260f5','propagation','[ˌprɔpəˈgeɪʃən]','http://res.iciba.com/resource/amp3/0/0/89/3f/893fb301f2b5178c2652c2e72e0ccb34.mp3','n. 繁殖；宣传；传播','','');----
INSERT INTO classwords VALUES ('8c0e3bab65da461bad65835618246a8d','3a6d8d2fddd849c3b936d16eaa3260f5','12');----
INSERT INTO word VALUES ('84e3c7fac5b548758e77c972d6f8eb34','drawback','[ˈdrɔ:bæk]','http://res.iciba.com/resource/amp3/oxford/0/b6/6b/b66bf9161b48577a89ab133febf4812f.mp3','n. 缺点，缺陷，不利条件','','');----
INSERT INTO classwords VALUES ('90808d8ad06842089bcdfe34a4801812','84e3c7fac5b548758e77c972d6f8eb34','12');----
INSERT INTO word VALUES ('299f97258102454b91593ec71555019c','cement','[siˈment]','http://res.iciba.com/resource/amp3/oxford/0/82/ca/82ca39e03bb89631e636e972c52143f5.mp3','n. 水泥；接合剂','','');----
INSERT INTO classwords VALUES ('592a21e327d2469a949f9542fdc0f09c','299f97258102454b91593ec71555019c','12');----
INSERT INTO word VALUES ('a393252ba9df4d0e81e7d248cc4f2b23','yacht','[jɔt]','http://res.iciba.com/resource/amp3/0/0/42/3f/423fa120a21678191fc5314ea325039a.mp3','n. 游艇，快艇','','');----
INSERT INTO classwords VALUES ('76f2bbd08a4748598c69261888672d3c','a393252ba9df4d0e81e7d248cc4f2b23','12');----
INSERT INTO word VALUES ('65472a5a8acd425aaa53925995428180','waver','[ˈweivə]','http://res.iciba.com/resource/amp3/oxford/0/6e/01/6e01af7e6a5ce87a2e217af3eaa726bb.mp3','vi. 摇晃；犹豫不决','','');----
INSERT INTO classwords VALUES ('99e823052e2a4bbd9a1f5f9767af19f0','65472a5a8acd425aaa53925995428180','12');----
INSERT INTO word VALUES ('b4595f3f953e43d588de2c65df795860','fitness','[ˈfɪtnɪs]','http://res.iciba.com/resource/amp3/oxford/0/02/30/023048640dbfc89611b36607fde58616.mp3','n. 适当，恰当；健康','','');----
INSERT INTO classwords VALUES ('3433fa9148fd4e38b222ec127023c859','b4595f3f953e43d588de2c65df795860','12');----
INSERT INTO word VALUES ('a06688828cd44ae7a222412a25c9cf13','remainder','[riˈmeində]','http://res.iciba.com/resource/amp3/oxford/0/8e/1b/8e1bcbd90c43e5b71eac81d6e0da448e.mp3','n. 剩余（物）；剩余部分；余数','','');----
INSERT INTO classwords VALUES ('757c6923a6c34703b973ba83c555d5e4','a06688828cd44ae7a222412a25c9cf13','12');----
INSERT INTO word VALUES ('4a38829ae4dd4b9e885ef60ac68bb749','trample','[ˈtræmpl]','http://res.iciba.com/resource/amp3/oxford/0/6f/25/6f25f9a7fda2a2a1afdc7ccb39dcb789.mp3','vt. 践踏；踩伤；踩踏','','');----
INSERT INTO classwords VALUES ('30a212acbf5f430d97be388b4b97dc0d','4a38829ae4dd4b9e885ef60ac68bb749','12');----
INSERT INTO word VALUES ('d6a96a68dd7c46c6959881930aef1ae5','latent','[ˈleitənt]','http://res.iciba.com/resource/amp3/oxford/0/fa/b6/fab67090c728e7c12c3376d64557b505.mp3','adj. 潜在的；潜伏的','','');----
INSERT INTO classwords VALUES ('b4359511965b4a4ea9d157cd98acb59a','d6a96a68dd7c46c6959881930aef1ae5','12');----
INSERT INTO word VALUES ('3f5ae085f5c447079d3779b019822c7b','set','[set]','http://res.iciba.com/resource/amp3/oxford/0/bd/47/bd47e9f2de91e33683c4aa021c4d6936.mp3','n. 集（合）；一套，一组','','');----
INSERT INTO classwords VALUES ('cdbe32a7c86e47409c929141febcc1d9','3f5ae085f5c447079d3779b019822c7b','12');----
INSERT INTO word VALUES ('3ea4b6d6788b441e9d3b2ea714738d1d','compulsory','[kəmˈpʌlsəri]','http://res.iciba.com/resource/amp3/oxford/0/1e/13/1e1366ff3cc8c021bc820e6ead3b96f3.mp3','adj. 强迫的；义务的','','');----
INSERT INTO classwords VALUES ('fc5d2a58b4c949f4856e781cfdaf420e','3ea4b6d6788b441e9d3b2ea714738d1d','12');----
INSERT INTO word VALUES ('d68714e5b2c0490ca25526bcb8b299b4','distinguish','[disˈtiŋɡwiʃ]','http://res.iciba.com/resource/amp3/oxford/0/20/92/20928a2fbeb336ae5a813ba2b8188c11.mp3','v. 区分，辨别；使有别于；辨别出；使出...','','');----
INSERT INTO classwords VALUES ('325af17d82034c12ae31705ac9492be0','d68714e5b2c0490ca25526bcb8b299b4','12');----
INSERT INTO word VALUES ('cce093d4e4d14bc6a61eb46815d61278','devour','[diˈvauə]','http://res.iciba.com/resource/amp3/oxford/0/43/ef/43ef141083734d21a3d919f4465f43e8.mp3','vt. 吞食；狼吞虎咽地吃；如饥似渴地阅...','','');----
INSERT INTO classwords VALUES ('ea28b546481c4f1ab89dc941ea70e0b2','cce093d4e4d14bc6a61eb46815d61278','12');----
INSERT INTO word VALUES ('e2299ac09cc34b0e897b6c3037773a25','thrill','[θril]','http://res.iciba.com/resource/amp3/oxford/0/39/79/3979c46c55c331cd89fd303b2c9a04b9.mp3','vt. 使激动；使狂喜；使极度兴奋','','');----
INSERT INTO classwords VALUES ('f26fcdd8a05b409a85f720961affe2fc','e2299ac09cc34b0e897b6c3037773a25','12');----
INSERT INTO word VALUES ('01f935faeb784d76852f1030c5ea1ab5','random','[ˈrændəm]','http://res.iciba.com/resource/amp3/oxford/0/e2/43/e243855dccdf3bf4c36a60ac0b68e497.mp3','adj. 随机的；偶然的；胡乱的','','');----
INSERT INTO classwords VALUES ('0cf351fc87d541e2a7cf0eb905ad9834','01f935faeb784d76852f1030c5ea1ab5','12');----
INSERT INTO word VALUES ('5eadd50df3a44a5b8081662db3ef8623','slaughter','[ˈslɔ:tə]','http://res.iciba.com/resource/amp3/oxford/0/bb/c6/bbc6db99c0c5e648d564204fdb34bec4.mp3','vt. 屠杀，残杀；屠宰','','');----
INSERT INTO classwords VALUES ('8098e20e6a2b4f97b33c0c47fc05c80c','5eadd50df3a44a5b8081662db3ef8623','12');----
INSERT INTO word VALUES ('c696e74bb421499bb156243f74af911a','initially','[ɪˈnɪʃɵlɪ]','http://res.iciba.com/resource/amp3/oxford/0/d3/35/d335f9c7f788d4dd415fafa8d51e4913.mp3','adv. 最初，开始','','');----
INSERT INTO classwords VALUES ('d92bd7a92dd649bc8361f2614846602b','c696e74bb421499bb156243f74af911a','12');----
INSERT INTO word VALUES ('4dec984095aa423ebb4ac79e46016a1f','persevere','[ˌpə:siˈviə]','http://res.iciba.com/resource/amp3/0/0/80/d2/80d223d110a0f7c4e926f8f6fdaf9325.mp3','vi. 坚持；锲而不舍','','');----
INSERT INTO classwords VALUES ('14c836d70ff142bfb9982aceaac55347','4dec984095aa423ebb4ac79e46016a1f','12');----
INSERT INTO word VALUES ('83d7ef969a9a41c0a5b83e0cd16e87b8','brace','[breis]','http://res.iciba.com/resource/amp3/oxford/0/24/24/2424bd8b60ad22c30e40ff7f7b9a470e.mp3','vt. 准备；使紧靠；绷紧（肩或膝）；支...','','');----
INSERT INTO classwords VALUES ('eeb0db4bae524cfcb645b46f609d9861','83d7ef969a9a41c0a5b83e0cd16e87b8','12');----
INSERT INTO word VALUES ('7e1155b5c959474e93113347287bc834','representativ...','[ˌrepriˈzentətiv]','http://res.iciba.com/resource/amp3/oxford/0/3c/d2/3cd206234b11ca0d26f78159fe933ac2.mp3','adj. 有代表性的；典型的；由代表组成...','','');----
INSERT INTO classwords VALUES ('63a38022acf94c4dafa3c6e2f23744e0','7e1155b5c959474e93113347287bc834','12');----
INSERT INTO word VALUES ('d70e5f0bc76e4969b57338b7e51db175','violation','[ˌvaɪəˈleɪʃən]','http://res.iciba.com/resource/amp3/0/0/31/45/3145c2ef4c310129fb265093244c9c1a.mp3','n. 违反；冒犯','','');----
INSERT INTO classwords VALUES ('ddd28f1539864c9ba2c7bb3ef9234e72','d70e5f0bc76e4969b57338b7e51db175','12');----
INSERT INTO word VALUES ('c99bcaddd71f4d5398dd1ad876d51cd8','regime','[reiˈʒi:m]','http://res.iciba.com/resource/amp3/oxford/0/a5/7d/a57d0856250ad442ad8b865195ea55ac.mp3','n. 政体，政权；制度；养生法','','');----
INSERT INTO classwords VALUES ('89121b66d6474195af8f27d57d11fb8c','c99bcaddd71f4d5398dd1ad876d51cd8','12');----
INSERT INTO word VALUES ('e570ac74eef2494aa2c9a3bfdf5ebcfe','suspicious','[səˈspiʃəs]','http://res.iciba.com/resource/amp3/oxford/0/fe/bc/febca5bb6caae087f011827eab7515b4.mp3','adj. 可疑的；猜疑的','','');----
INSERT INTO classwords VALUES ('d55f756a94134353a6eb8099d8717252','e570ac74eef2494aa2c9a3bfdf5ebcfe','12');----
INSERT INTO word VALUES ('0ab0a3ff7d094600b569786b6c06841f','proposition','[ˌprɔpəˈziʃən]','http://res.iciba.com/resource/amp3/oxford/0/ca/61/ca61710ac43d63b50582d72c124023c8.mp3','n. 观点；建议；提案；命题','','');----
INSERT INTO classwords VALUES ('2adfdb3554ca46a2983b4a347d40af62','0ab0a3ff7d094600b569786b6c06841f','12');----
INSERT INTO word VALUES ('783b457dc2ed4dd09f52c57f6e017fbb','gather','[ˈɡæðə]','http://res.iciba.com/resource/amp3/oxford/0/a5/48/a5483465ab8aaf0ed05637dcf5c826ce.mp3','vt. 聚集；收集；振作（精神）','','');----
INSERT INTO classwords VALUES ('8e6bf41897784aa88df65b674cf49816','783b457dc2ed4dd09f52c57f6e017fbb','12');----
INSERT INTO word VALUES ('1982abe0208b4c6db28b6a048c251cef','snail','[sneil]','http://res.iciba.com/resource/amp3/oxford/0/1a/e7/1ae756fda66bc2d1100576452462bb34.mp3','n. 蜗牛','','');----
INSERT INTO classwords VALUES ('c9f513f4ff414ac08b2950331b1de67b','1982abe0208b4c6db28b6a048c251cef','12');----
INSERT INTO word VALUES ('4ba434dce26d472cb9280ae1be96030a','tower','[ˈtauə]','http://res.iciba.com/resource/amp3/oxford/0/cd/27/cd276a95faeda20694a68b4877f1ab58.mp3','vi. 高耸，屹立','','');----
INSERT INTO classwords VALUES ('952f041e50bd4dd2bba1fab368a06455','4ba434dce26d472cb9280ae1be96030a','12');----
INSERT INTO word VALUES ('49f6c461c8d741a987462fe073b57c6d','amusement','[ˌəˈmju:zmənt]','http://res.iciba.com/resource/amp3/oxford/0/a6/f3/a6f309e71e70eb79bde994c22498293f.mp3','n. 娱乐；消遣','','');----
INSERT INTO classwords VALUES ('db8ada53fb794b948fba4371c88aa77e','49f6c461c8d741a987462fe073b57c6d','12');----
INSERT INTO word VALUES ('cf00c7d518924c5090636a6844855ded','whisker','[ˈhwɪskə]','http://res.iciba.com/resource/amp3/oxford/0/6e/2a/6e2a6c47858d0dc09f8ffc16a41328ac.mp3','n. 络腮胡子；一丝；一点儿','','');----
INSERT INTO classwords VALUES ('f2bac701f8fc4458a6f4481fda5d20c6','cf00c7d518924c5090636a6844855ded','12');----
INSERT INTO word VALUES ('fcf525758c8b43949237f106af5d9226','boycott','[ˈbɔikɔt]','http://res.iciba.com/resource/amp3/oxford/0/6b/36/6b36d594f3a6921134feffc1aff33d6d.mp3','vt. 联合抵制','','');----
INSERT INTO classwords VALUES ('eaa02f8fb3354b1b8c3d21fc23a88543','fcf525758c8b43949237f106af5d9226','12');----
INSERT INTO word VALUES ('9cc57b810d7a4cd7a15445a806b79d07','qualify','[ˈkwɔlifai]','http://res.iciba.com/resource/amp3/oxford/0/2b/da/2bdae7ee2bad9c6db0a7877d4cf8b165.mp3','vt. 取得资格；（使）有资格获得','','');----
INSERT INTO classwords VALUES ('6986ff91314941ce9633ced8d4924435','9cc57b810d7a4cd7a15445a806b79d07','12');----
INSERT INTO word VALUES ('875dbd700acb48dd9f7823db86a55c11','knight','[nait]','http://res.iciba.com/resource/amp3/oxford/0/a3/2f/a32f1728726d221238716612e620388b.mp3','n. 骑士，武士；爵士','','');----
INSERT INTO classwords VALUES ('f8acca11ae2347fe946e446b5e735b33','875dbd700acb48dd9f7823db86a55c11','12');----
INSERT INTO word VALUES ('19db7bcda4c64cc3b705d52da105f116','descendant','[diˈsendənt]','http://res.iciba.com/resource/amp3/oxford/0/79/b6/79b6a18376c34e90833964c851eea5cb.mp3','n. 子孙，后裔；派生物','','');----
INSERT INTO classwords VALUES ('5a57e72f9d1b434ab1ea53d9189490c9','19db7bcda4c64cc3b705d52da105f116','12');----
INSERT INTO word VALUES ('346198f4fb81486199eac8cf1d52a693','breed','[bri:d]','http://res.iciba.com/resource/amp3/oxford/0/73/8a/738af7d711454cfe01bda27f5089def3.mp3','n. （动物）品种','','');----
INSERT INTO classwords VALUES ('c4476d822f08401bb2eabd52ed865a01','346198f4fb81486199eac8cf1d52a693','12');----
INSERT INTO word VALUES ('06eed7d2350e4f4c81df9badccfa9566','prose','[prəuz]','http://res.iciba.com/resource/amp3/0/0/46/a3/46a34d5165307fe02b98b0116da7a9e8.mp3','n. 散文','','');----
INSERT INTO classwords VALUES ('ffe819d31a2242fcb92c05e9716b2bcb','06eed7d2350e4f4c81df9badccfa9566','12');----
INSERT INTO word VALUES ('a73b791ad89c4b84b006fc3da0358b91','idleness','[ˈaɪdlnɪs]','http://res.iciba.com/resource/amp3/0/0/4b/55/4b551f05f80011e4cfbfaf76908fe9e3.mp3','n. 懒惰；闲散','','');----
INSERT INTO classwords VALUES ('2b65a364f93b41d78e37d938cddb1ccc','a73b791ad89c4b84b006fc3da0358b91','12');----
INSERT INTO word VALUES ('f8c8f81f54d84b76acb9bce8ac6dbaf0','shrug','[ʃrʌɡ]','http://res.iciba.com/resource/amp3/oxford/0/dc/07/dc07aecb083720e929466e2b8e1c039d.mp3','n. 耸肩','','');----
INSERT INTO classwords VALUES ('f45d994c4435401e8952ea4fb11b118b','f8c8f81f54d84b76acb9bce8ac6dbaf0','12');----
INSERT INTO word VALUES ('c99beed665e04bf3b494085a714a0bb3','obedience','[əʊˈbi:di:əns]','http://res.iciba.com/resource/amp3/1/0/41/20/412030ff8772918007e79a863d521ff1.mp3','n. 服从，顺从','','');----
INSERT INTO classwords VALUES ('8f393d2aadb74b1a88be0cc57ba15d57','c99beed665e04bf3b494085a714a0bb3','12');----
INSERT INTO word VALUES ('8fac06732fe94fa28c967836f75c5679','complement','[ˈkɔmplimənt]','http://res.iciba.com/resource/amp3/oxford/0/fd/bd/fdbd93c3f634bc31ca5ed826e25a269f.mp3','n. 补足物；衬托物','','');----
INSERT INTO classwords VALUES ('7b898b1b7a4c4c97812fa82bc8f5f21c','8fac06732fe94fa28c967836f75c5679','12');----
INSERT INTO word VALUES ('b30fe2f3d8df4223aef807076fc50800','sincerity','[sɪnˈserɪti:]','http://res.iciba.com/resource/amp3/0/0/ef/67/ef6721dfe69b35edd336c4bc8a106c04.mp3','n. 真诚，诚意','','');----
INSERT INTO classwords VALUES ('ec074e49c645487c9c36edbd3085ab20','b30fe2f3d8df4223aef807076fc50800','12');----
INSERT INTO word VALUES ('09c6c41c682a4480800b76886385064f','over','[ˈəuvə]','http://res.iciba.com/resource/amp3/oxford/0/bb/ae/bbae4acfb7cc581f34b71f0186eac4fe.mp3','prep. 在…的上方；覆盖在…的上面；...','','');----
INSERT INTO classwords VALUES ('98af115879d84ed59cf9c4bbbbe5b6d3','09c6c41c682a4480800b76886385064f','12');----
INSERT INTO word VALUES ('94f05001f0d745b9b75faeac2be893a8','cable','[ˈkeibl]','http://res.iciba.com/resource/amp3/oxford/0/20/ec/20eccb1f0062a4f7f0cc4d77c99ab2c3.mp3','n. 电线，电缆；缆绳；电报','','');----
INSERT INTO classwords VALUES ('fcdc62170b9848678cd252f83506702f','94f05001f0d745b9b75faeac2be893a8','12');----
INSERT INTO word VALUES ('793abf2ba72a487cba7a799483648e0e','champion','[ˈtʃæmpjən]','http://res.iciba.com/resource/amp3/oxford/0/df/8e/df8e51505a4a35574a5d036c8d43f4cc.mp3','n. 冠军；拥护者','','');----
INSERT INTO classwords VALUES ('f6205125adf442bb8d38ff6f65f87f14','793abf2ba72a487cba7a799483648e0e','12');----
INSERT INTO word VALUES ('c2b7fabc9e6a411f961a8164ad73b5c1','watery','[ˈwɔ:təri:]','http://res.iciba.com/resource/amp3/oxford/0/a9/24/a9241ad6e35f5c006f764fe5363d156c.mp3','adj. 水分过多的；微弱的；含水的','','');----
INSERT INTO classwords VALUES ('bd151f7cd7c4404697d15b5685e3487f','c2b7fabc9e6a411f961a8164ad73b5c1','12');----
INSERT INTO word VALUES ('d6a49eea837f4c10a62a282b196b14a5','shoulder','[ˈʃəuldə]','http://res.iciba.com/resource/amp3/oxford/0/8b/0f/8b0f32aef39d887a7075c999304bb7ac.mp3','vt. 承担，肩负；背，扛；用肩推或挤','','');----
INSERT INTO classwords VALUES ('081fbd7aa7f44cf3bb5d903d0ca17a13','d6a49eea837f4c10a62a282b196b14a5','12');----
INSERT INTO word VALUES ('3297a0acbd0844fdadaa9e6faeeecb5f','subordinate','[səˈbɔ:dinit]','http://res.iciba.com/resource/amp3/oxford/0/1b/f9/1bf9609c2a312720cd85238c5f2164db.mp3','adj. 下级的；次要的','','');----
INSERT INTO classwords VALUES ('996fb131f3dd43f6a2bd649a732052ac','3297a0acbd0844fdadaa9e6faeeecb5f','12');----
INSERT INTO word VALUES ('9302ce98aaef46ecb5c433065ba4f242','deficiency','[diˈfiʃənsi]','http://res.iciba.com/resource/amp3/oxford/0/d4/1a/d41a3cb5db5ac4f0bc5150e46f5dfb9e.mp3','n. 缺乏，缺少；缺点','','');----
INSERT INTO classwords VALUES ('2b274f02edc04a8eaae8211188560b9c','9302ce98aaef46ecb5c433065ba4f242','12');----
INSERT INTO word VALUES ('c833492c18004dcca31cdff003391934','destine','[ˈdestɪn]','http://res.iciba.com/resource/amp3/0/0/d8/1f/d81f09cece6834e2e7fdf33dd634631f.mp3','vt. 命定，注定；预定','','');----
INSERT INTO classwords VALUES ('496ddd467ff941d2bb366dff6d2dc8db','c833492c18004dcca31cdff003391934','12');----
INSERT INTO word VALUES ('e80077e238d544d5bb90dd421d91946a','resume','[riˈzju:m]','http://res.iciba.com/resource/amp3/0/0/69/f2/69f2afc2390cec954f7c208b07212d39.mp3','v. 重新开始；恢复（职位）','','');----
INSERT INTO classwords VALUES ('10bf59b256eb4a93b5ed01a4515caf62','e80077e238d544d5bb90dd421d91946a','12');----
INSERT INTO word VALUES ('b5ad7750158446d1884356aac6628ff4','tropic','[ˈtrɔpik]','http://res.iciba.com/resource/amp3/0/0/77/9d/779d453124d71869c93f01e0d181d410.mp3','n. 热带地区；回归线','','');----
INSERT INTO classwords VALUES ('064ad0eace534537b8fd7d93845b362e','b5ad7750158446d1884356aac6628ff4','12');----
INSERT INTO word VALUES ('4d6b27133ca445e1b87a7bb3ca199877','disagreement','[ˌdɪsəˈgri:mənt]','http://res.iciba.com/resource/amp3/oxford/0/f9/8e/f98e6d978aeba90d176b5ba25d54b5d1.mp3','n. 争执；意见不合；异议','','');----
INSERT INTO classwords VALUES ('a264a8e2e72041e6b0bc71c44d1e4072','4d6b27133ca445e1b87a7bb3ca199877','12');----
INSERT INTO word VALUES ('89121db4d7104e2984d88e12f981b605','warrant','[ˈwɔrənt]','http://res.iciba.com/resource/amp3/oxford/0/2a/50/2a50879456c37596729ff5b2d7780ee0.mp3','n. 搜查令；拘捕令；正当理由','','');----
INSERT INTO classwords VALUES ('b1ee4911ca16406d804fafb49a1c2493','89121db4d7104e2984d88e12f981b605','12');----
INSERT INTO word VALUES ('b2a28057cfc34834a5c1eceb7fab4757','shipbuilding','[ˈʃɪpˌbɪldɪŋ]','http://res.iciba.com/resource/amp3/0/0/a8/4d/a84d14032583ebcd637894852a371a3e.mp3','n. 造船（业）；造船学','','');----
INSERT INTO classwords VALUES ('fba7a19a56db40d185be1faa3031074a','b2a28057cfc34834a5c1eceb7fab4757','12');----
INSERT INTO word VALUES ('4c07426754f9408f8de086efd4c162ed','telex','[ˈtelˌeks]','http://res.iciba.com/resource/amp3/oxford/0/39/d1/39d186eaeb694eb56dae61098b3616bc.mp3','v. 给…发电传，用电传发送','','');----
INSERT INTO classwords VALUES ('c118c32e8c5c4a639e4410b190ba5dbd','4c07426754f9408f8de086efd4c162ed','12');----
INSERT INTO word VALUES ('9b6a0fd2e6aa4bc6b679ea65948a8cfb','reconcile','[ˈrekənsail]','http://res.iciba.com/resource/amp3/oxford/0/70/f5/70f59cc5841da6166a87ba74a9da8ad7.mp3','vt. 使和好；调和；顺从','','');----
INSERT INTO classwords VALUES ('bb2cfb10afcd42cf931dba67a486eead','9b6a0fd2e6aa4bc6b679ea65948a8cfb','12');----
INSERT INTO word VALUES ('e93c019c905040f7a6555bf0df6dfeb2','shrine','[ʃrain]','http://res.iciba.com/resource/amp3/oxford/0/49/be/49bea12a5937d5d01d6a065de0840781.mp3','n. 神庙，神龛，圣祠；圣地','','');----
INSERT INTO classwords VALUES ('d8b3fb89682342719a0b137ecc479356','e93c019c905040f7a6555bf0df6dfeb2','12');----
INSERT INTO word VALUES ('348e3649bb944a2db7830beeffc74624','jog','[dʒɔɡ]','http://res.iciba.com/resource/amp3/0/0/c5/18/c518790e0463f2b7db28d50df8dd6c4e.mp3','vt. 慢跑；轻推，轻撞','','');----
INSERT INTO classwords VALUES ('5dcc159bda7a46a282a8a9c79615d813','348e3649bb944a2db7830beeffc74624','12');----
INSERT INTO word VALUES ('fa5f064ce2984980b01371f9f75c8f00','dominate','[ˈdɔmineit]','http://res.iciba.com/resource/amp3/oxford/0/32/c6/32c69caa43e895aaaef969722ae9a004.mp3','vt. 统治，支配，控制；在…中占首要地...','','');----
INSERT INTO classwords VALUES ('7b63e7da316543c1babfb350860b9815','fa5f064ce2984980b01371f9f75c8f00','12');----
INSERT INTO word VALUES ('f8b96204e37a4b4e9f33aad4a6ae085d','dock','[dɔk]','http://res.iciba.com/resource/amp3/0/0/05/de/05debdb8b38c7e1e244dd770b62d1d4f.mp3','vt. 使船停靠码头；领船入港','','');----
INSERT INTO classwords VALUES ('745977c7535d4e84a9b36201911aed71','f8b96204e37a4b4e9f33aad4a6ae085d','12');----
INSERT INTO word VALUES ('3f10bf8be1594c37954dec4c5179ecba','designate','[ˈdeziɡneit]','http://res.iciba.com/resource/amp3/oxford/0/4e/4e/4e4e5bc59bca92eb4fb0979b05f2cbe2.mp3','vt. 指派；指定；标示；把…定名为','','');----
INSERT INTO classwords VALUES ('d7dc14ec9d704b06bb3e11362fa3af72','3f10bf8be1594c37954dec4c5179ecba','12');----
INSERT INTO word VALUES ('3b0b3d44d2ec46bf90dc5b044a1ae34b','ingenuity','[ˌɪndʒiˈnjuiti]','http://res.iciba.com/resource/amp3/oxford/0/41/d3/41d3313a7f4d935e2816d665355a28b5.mp3','n. 心灵手巧','','');----
INSERT INTO classwords VALUES ('cc1efec38aae478dac40fbe20bfe5e0c','3b0b3d44d2ec46bf90dc5b044a1ae34b','12');----
INSERT INTO word VALUES ('32f5c786bb6e45888823b264b54ce7c3','substance','[ˈsʌbstəns]','http://res.iciba.com/resource/amp3/oxford/0/b8/03/b803d282124813f60b011c53c23196e6.mp3','n. 物质；重要性；主旨，要点','','');----
INSERT INTO classwords VALUES ('8e59f5c5b1b1423dbed2090bb3b352ca','32f5c786bb6e45888823b264b54ce7c3','12');----
INSERT INTO word VALUES ('be87c725d6ac4238981864dac484a45f','participate','[pɑ:ˈtisipeit]','http://res.iciba.com/resource/amp3/oxford/0/3f/fc/3ffc90244b21454ac8a2e1b72f3324b3.mp3','vt. 分享','','');----
INSERT INTO classwords VALUES ('7cd387eaf6dd45f69143649ed8261363','be87c725d6ac4238981864dac484a45f','12');----
INSERT INTO word VALUES ('fe95719662a148e0b93552d180ae2188','buffalo','[ˈbʌfələu]','http://res.iciba.com/resource/amp3/oxford/0/05/e6/05e6f0255843ee3925b7ae1d6bdcbf64.mp3','n. 水牛；水陆坦克','','');----
INSERT INTO classwords VALUES ('ad80026bc77e4556a38c49cf13c05fe9','fe95719662a148e0b93552d180ae2188','12');----
INSERT INTO word VALUES ('1fe33eca1e6f4774ad35ecd8692c3f33','miser','[ˈmaɪzə]','http://res.iciba.com/resource/amp3/oxford/0/78/96/7896e4fd16a78d6439c4500cf137a8e0.mp3','n. 守财奴，吝啬鬼','','');----
INSERT INTO classwords VALUES ('500d0e5fd79c44cf81fe99db383d2e8d','1fe33eca1e6f4774ad35ecd8692c3f33','12');----
INSERT INTO word VALUES ('9b37fe24358046db97e3c896f0b55256','industrious','[ɪnˈdʌstri:əs]','http://res.iciba.com/resource/amp3/oxford/0/54/1b/541b7b2d0274b890aa6ffc1a1d267ee5.mp3','adj. 勤劳的，勤奋的','','');----
INSERT INTO classwords VALUES ('650d12a8963a400fb371fed85a43e6d1','9b37fe24358046db97e3c896f0b55256','12');----
INSERT INTO word VALUES ('19818edea06b448e8a18fab23b0459aa','forsake','[fəˈseik]','http://res.iciba.com/resource/amp3/oxford/0/6e/3b/6e3b7aa3a5867f6d2b1499b50db6e1fc.mp3','vt. 遗弃，抛弃；放弃；离开','','');----
INSERT INTO classwords VALUES ('470774fbbd214983a15bb26e94b65bb1','19818edea06b448e8a18fab23b0459aa','12');----
INSERT INTO word VALUES ('1b5c57cd114242ee8632a47856f06a16','species','[ˈspi:ʃi:z]','http://res.iciba.com/resource/amp3/oxford/0/74/84/74841258ce7f13e23f3820f1a9ae3c95.mp3','n. 种，物种；种类','','');----
INSERT INTO classwords VALUES ('712b968b1b16441bac3e73aaa8c9129b','1b5c57cd114242ee8632a47856f06a16','12');----
INSERT INTO word VALUES ('96a97d506caa4927b336711d9548c868','wrench','[rentʃ]','http://res.iciba.com/resource/amp3/oxford/0/fb/d9/fbd99d5ae9b53cef981d98dabdf65559.mp3','n. 痛苦；扳钳','','');----
INSERT INTO classwords VALUES ('64812ea0f381408b81fb3a878b678714','96a97d506caa4927b336711d9548c868','12');----
INSERT INTO word VALUES ('509eae408d994888835f961860548b50','slander','[ˈslændər]','http://res.iciba.com/resource/amp3/oxford/0/56/c9/56c985172c9b03e6cd967b7e7cc08f77.mp3','n. 诽谤，诋毁','','');----
INSERT INTO classwords VALUES ('284f52d18dba47e9a3f27b38a0d307cb','509eae408d994888835f961860548b50','12');----
INSERT INTO word VALUES ('4e50991e0cfa47b2aaf3379e86309238','pluck','[plʌk]','http://res.iciba.com/resource/amp3/oxford/0/cf/68/cf68d191d31af67578fb19cdb39bbdaa.mp3','vt. 采，摘；拔，拉；弹乐器；修（眉毛...','','');----
INSERT INTO classwords VALUES ('a61664d0a4cd45d59cd12cd2f782eac3','4e50991e0cfa47b2aaf3379e86309238','12');----
INSERT INTO word VALUES ('bc00f088eb7d44d0a08fbffbb93bf574','terrorist','[ˈterərɪst]','http://res.iciba.com/resource/amp3/oxford/0/a1/e6/a1e6a1cc9f7d58d87ad713b5458e23d9.mp3','n. 恐怖分子','','');----
INSERT INTO classwords VALUES ('55c091f474ab46eca2e1ee8250a1f3dc','bc00f088eb7d44d0a08fbffbb93bf574','12');----
INSERT INTO word VALUES ('11735169610e4f4084cbeaac2ea0956d','geographical','[dʒɪəˈgræfɪkɵl]','http://res.iciba.com/resource/amp3/0/0/df/4e/df4eebc1cf3f80c6d9a6241601e35dda.mp3','adj. 地理的','','');----
INSERT INTO classwords VALUES ('23665138f7cf4c0f8fc30454a4e60b41','11735169610e4f4084cbeaac2ea0956d','12');----
INSERT INTO word VALUES ('1192731bf9f049ccbca3cef0f4b20efb','embroidery','[imˈbrɔidəri]','http://res.iciba.com/resource/amp3/oxford/0/3e/9e/3e9e2cc8ed3b6a90966dddb12d039e3c.mp3','n. 绣花；刺绣；刺绣品','','');----
INSERT INTO classwords VALUES ('0d16ec2bbc5c410fb97d9d9e2532c4b6','1192731bf9f049ccbca3cef0f4b20efb','12');----
INSERT INTO word VALUES ('43a5c372d86f484f990ea1696c839e79','hollow','[ˈhɔləu]','http://res.iciba.com/resource/amp3/0/0/ff/36/ff362afb00fa83da92fd95b38424a556.mp3','n. 树洞；凹陷处','','');----
INSERT INTO classwords VALUES ('229a756436f34dfcb80fbc12a6cb1d46','43a5c372d86f484f990ea1696c839e79','12');----
INSERT INTO word VALUES ('7edeace87bbd477dbaaebfef270c24c9','decimal','[ˈdesiməl]','http://res.iciba.com/resource/amp3/oxford/0/c5/1b/c51b0b96f5c5a4a63404b9be80f0f001.mp3','adj. 小数的，十进制的','','');----
INSERT INTO classwords VALUES ('1a7c650bb95f4e82804ee6cc2cee497d','7edeace87bbd477dbaaebfef270c24c9','12');----
INSERT INTO word VALUES ('905c4960611f465499f70150e962ccb1','singular','[ˈsiŋɡjulə]','http://res.iciba.com/resource/amp3/oxford/0/92/fa/92fab01f4255392cd8d448285d9aa193.mp3','adj. 异常的；非凡的；单数的','','');----
INSERT INTO classwords VALUES ('2209b682c3e844d59f919f212c899f9b','905c4960611f465499f70150e962ccb1','12');----
INSERT INTO word VALUES ('e71837bb355a4aa1a750fd8c00c95625','membership','[ˈmembəʃip]','http://res.iciba.com/resource/amp3/oxford/0/4e/48/4e48a66cf7ace8ed40f9ae875ee1c237.mp3','n. 成员资格；会员人数','','');----
INSERT INTO classwords VALUES ('9cbf4d14211041df856b5cfd04d0520d','e71837bb355a4aa1a750fd8c00c95625','12');----
INSERT INTO word VALUES ('228f2f672fbd40b2bdbd83ea1ebc42e2','producer','[prəˈdu:sə]','http://res.iciba.com/resource/amp3/oxford/0/43/ba/43baa8fb8560854827b984f96af8078f.mp3','n. 生产商；生产国；制片人','','');----
INSERT INTO classwords VALUES ('bec68de33da440788a874fe8f17bb1d1','228f2f672fbd40b2bdbd83ea1ebc42e2','12');----
INSERT INTO word VALUES ('da91260a56664c5fa563a2071c0efc09','deflect','[diˈflekt]','http://res.iciba.com/resource/amp3/oxford/0/37/23/37233029aabae965fe7d81de8c97be81.mp3','vt.&vi. 转移；使脱离；使放弃；使...','','');----
INSERT INTO classwords VALUES ('52f1a16a6fce4728894de717b2bc693a','da91260a56664c5fa563a2071c0efc09','12');----
INSERT INTO word VALUES ('51ffbe278ed048c9acc4647be731158f','sign','[sain]','http://res.iciba.com/resource/amp3/oxford/0/23/c0/23c05b9efda95fd1754b643555f8c058.mp3','n. 征兆，迹象；招牌；符号；手势','','');----
INSERT INTO classwords VALUES ('2082afe84f77409db28c549493b2676f','51ffbe278ed048c9acc4647be731158f','12');----
INSERT INTO word VALUES ('cbd640679599414fb4587d59f017f5c2','woe','[wəʊ]','http://res.iciba.com/resource/amp3/0/0/b5/3e/b53ea64faef25884c1aa90286804d478.mp3','n. 悲哀，悲痛；麻烦','','');----
INSERT INTO classwords VALUES ('221896e1454a45fbb003df51f92a972d','cbd640679599414fb4587d59f017f5c2','12');----
INSERT INTO word VALUES ('640d299043814c7aaefdc8bdc4e28186','wretched','[ˈretʃid]','http://res.iciba.com/resource/amp3/oxford/0/a9/b6/a9b633f48e946a56fe670f50092b32a4.mp3','adj. 不幸的；讨厌的；苦恼的；难过的','','');----
INSERT INTO classwords VALUES ('2e778caeb6c04ab2a26e8a8d077ab762','640d299043814c7aaefdc8bdc4e28186','12');----
INSERT INTO word VALUES ('8550e8395cc345f688165a4ac8c2fde6','fling','[fliŋ]','http://res.iciba.com/resource/amp3/oxford/0/7b/8f/7b8fce6d308901c3364499b0ef1c42ed.mp3','vt.&vi. 猛掷；突然冲向；急伸','','');----
INSERT INTO classwords VALUES ('b0f2f1ce9f034eef839ba2f9d3af981c','8550e8395cc345f688165a4ac8c2fde6','12');----
INSERT INTO word VALUES ('3f06190ac0324691ba94293160d5729f','bead','[bi:d]','http://res.iciba.com/resource/amp3/oxford/0/f9/91/f9911ae92f46fcbb050d198d7354e263.mp3','n. 珠子；（液体的）小珠','','');----
INSERT INTO classwords VALUES ('6b9bd09baf0a40d893ebdf9a6dfdfa5d','3f06190ac0324691ba94293160d5729f','12');----
INSERT INTO word VALUES ('08eacb8acb9c49b58ea75bb7287088b7','deal','[di:l]','http://res.iciba.com/resource/amp3/oxford/0/cc/7a/cc7a374b65a5a16c5334dd2b2939c3db.mp3','vi. 经营，买卖','','');----
INSERT INTO classwords VALUES ('84cb64d0eb5b4f1dad9bf22d26ac92f8','08eacb8acb9c49b58ea75bb7287088b7','12');----
INSERT INTO word VALUES ('ee2eca1b88464afbb203e1375f682c90','generosity','[ˌdʒenəˈrɔsɪti:]','http://res.iciba.com/resource/amp3/oxford/0/76/20/762026da0de46af6bb037d3108bc639e.mp3','n. 慷慨，大方','','');----
INSERT INTO classwords VALUES ('beedc29d28ae48deb76c488df33eaee0','ee2eca1b88464afbb203e1375f682c90','12');----
INSERT INTO word VALUES ('a7cccb7c92d548bdb8a41c9059134df2','shrub','[ʃrʌb]','http://res.iciba.com/resource/amp3/oxford/0/fb/07/fb07d2dbd1097f6e851bbbefd32365d8.mp3','n. 灌木','','');----
INSERT INTO classwords VALUES ('11cd5dd8167341ac99adcbf979e56458','a7cccb7c92d548bdb8a41c9059134df2','12');----
INSERT INTO word VALUES ('4804adf31bb540bf8c7a7701eb97c314','banquet','[ˈbæŋkwit]','http://res.iciba.com/resource/amp3/oxford/0/d6/39/d639e2a091f9f4a88ff82998c4f7b9a5.mp3','n. 宴会，盛宴','','');----
INSERT INTO classwords VALUES ('c57e150966354565ae449b8d8fc00b19','4804adf31bb540bf8c7a7701eb97c314','12');----
INSERT INTO word VALUES ('6a81eb3c9b7b41ae9a13f9089b79bdc1','expenditure','[ɪkˈspendətʃə]','http://res.iciba.com/resource/amp3/oxford/0/78/90/78901a69bba486bb040f48d510294ffd.mp3','n. （时间等）消耗；花费，开销，支出','','');----
INSERT INTO classwords VALUES ('5b9ceae0f57246ab9f998b9cc7ff8f4f','6a81eb3c9b7b41ae9a13f9089b79bdc1','12');----
INSERT INTO word VALUES ('b3a3dc352fbb4b1ea13b12e568167032','fake','[feik]','http://res.iciba.com/resource/amp3/oxford/0/68/67/686742cc23362540abf1a0c5b8d89f49.mp3','adj. 假冒的，伪造的','','');----
INSERT INTO classwords VALUES ('5b496efc71694b69b18829dca427375b','b3a3dc352fbb4b1ea13b12e568167032','12');----
INSERT INTO word VALUES ('fadc0f595f354092bdd793be56e3d60d','start','[stɑ:t]','http://res.iciba.com/resource/amp3/0/0/ea/2b/ea2b2676c28c0db26d39331a336c6b92.mp3','vt. 使开始；（从…）着手；开办；开动','','');----
INSERT INTO classwords VALUES ('894866a7eeb34b23a9f18181ebd6a999','fadc0f595f354092bdd793be56e3d60d','12');----
INSERT INTO word VALUES ('653e7290924043979bab182d1a114f63','promotion','[prəˈməʊʃən]','http://res.iciba.com/resource/amp3/oxford/0/1c/a4/1ca46716ecc85ba2670873e7eb23903b.mp3','n. 促销；提升','','');----
INSERT INTO classwords VALUES ('da9aced3a039419c840af501f565dd2e','653e7290924043979bab182d1a114f63','12');----
INSERT INTO word VALUES ('3eaac271aff0495bb504b3aa2a569ef6','graphite','[ˈgræfˌaɪt]','http://res.iciba.com/resource/amp3/oxford/0/50/0c/500c67177dad52a3f569d6c40a61a00b.mp3','n. 石墨','','');----
INSERT INTO classwords VALUES ('73c37dddf46a41558ccd8cb78b293945','3eaac271aff0495bb504b3aa2a569ef6','12');----
INSERT INTO word VALUES ('886deea2eb0e4bff9146838cbf2889c3','erosion','[iˈrəuʒən]','http://res.iciba.com/resource/amp3/0/0/2a/48/2a48e58d1351e0855ef9792ebcc6f4fe.mp3','n. 腐蚀，侵蚀；（权利等的）逐渐丧失；...','','');----
INSERT INTO classwords VALUES ('4ca2b7bdfdeb48bf86fdbe69b19e81fc','886deea2eb0e4bff9146838cbf2889c3','12');----
INSERT INTO word VALUES ('ef057eda3219447c9e7d28db37e4f038','Jupiter','[ˈdʒu:pɪtə]','http://res.iciba.com/resource/amp3/oxford/0/a6/14/a6145ec023fca04bcd7ff1b2bd98ed03.mp3','n. 朱庇特；木星','','');----
INSERT INTO classwords VALUES ('439eab82bb854ac3b37d4f2331f4e7a7','ef057eda3219447c9e7d28db37e4f038','12');----
INSERT INTO word VALUES ('c7cc87d329b24720ba09c2d15375081c','rotate','[rəuˈteit]','http://res.iciba.com/resource/amp3/0/0/6f/8c/6f8c8a49f740bca52653317a42933f8c.mp3','vt.&vi. 使旋转；使轮流','','');----
INSERT INTO classwords VALUES ('3fbac4595aad4eff9a8f54412f3c60cb','c7cc87d329b24720ba09c2d15375081c','12');----
INSERT INTO word VALUES ('86eeddf7c5da475eb6436112184553c3','blue','[blu:]','http://res.iciba.com/resource/amp3/oxford/0/a3/6f/a36f10a16ee627c376c13a7893092cd2.mp3','adj. 蓝色的；忧郁的；沮丧的；色情的','','');----
INSERT INTO classwords VALUES ('afab51b0d8724b3d8f77aab7ba8feccb','86eeddf7c5da475eb6436112184553c3','12');----
INSERT INTO word VALUES ('e8eab986ee4b4ac6a1be5d1be2c729f2','Egyptian','[ɪˈdʒɪpʃən]','http://res.iciba.com/resource/amp3/0/0/9e/c3/9ec35cc2bbaa83892af380c6c5b7d1fc.mp3','n. 埃及人','','');----
INSERT INTO classwords VALUES ('bd968c5e480345239a68cc113b4f737b','e8eab986ee4b4ac6a1be5d1be2c729f2','12');----
INSERT INTO word VALUES ('be73f640249640659db673905910556a','inference','[ˈinfərəns]','http://res.iciba.com/resource/amp3/oxford/0/ae/d9/aed904d8bb3de8269e18615af7f3dfec.mp3','n. 推论；推理；推断结果，结论','','');----
INSERT INTO classwords VALUES ('91849f1c3d1045d0b0526da800e2ea22','be73f640249640659db673905910556a','12');----
INSERT INTO word VALUES ('990956bc4b3b4da781ed682d8217e757','novel','[ˈnɔvəl]','http://res.iciba.com/resource/amp3/0/0/d6/38/d638d193eb29ac87c0950ab36b80e0e8.mp3','adj. 新的，新颖的','','');----
INSERT INTO classwords VALUES ('d9d18f98b332450782084c180dd8487d','990956bc4b3b4da781ed682d8217e757','12');----
INSERT INTO word VALUES ('ece6a467d1bf438e9a134de9d0294334','infect','[inˈfekt]','http://res.iciba.com/resource/amp3/oxford/0/af/93/af931cda3fac5597fd4aa3665e577aa6.mp3','vt. 使受影响；传染；污染','','');----
INSERT INTO classwords VALUES ('c80bc8ac14f44f558526fe9a9243680f','ece6a467d1bf438e9a134de9d0294334','12');----
INSERT INTO word VALUES ('5eba658eb22647078503f11c31b8c0c0','peck','[pek]','http://res.iciba.com/resource/amp3/oxford/0/46/37/4637831334b85648da8468478360213c.mp3','vt. 啄，啄食；轻吻','','');----
INSERT INTO classwords VALUES ('c04699ddd34841d7b63c7a8019acdbea','5eba658eb22647078503f11c31b8c0c0','12');----
INSERT INTO word VALUES ('dcf6377653e540d29a7ca66ee53cf0e1','rinse','[rins]','http://res.iciba.com/resource/amp3/oxford/0/7d/aa/7daa115fd7bc1b720abfba6adc7aa39f.mp3','vt. 嗽口；冲洗','','');----
INSERT INTO classwords VALUES ('d6689d14ce9c452f958ebd5f02ec85cc','dcf6377653e540d29a7ca66ee53cf0e1','12');----
INSERT INTO word VALUES ('8dafa068d18b4d47897e82c58eb1d26d','yeast','[ji:st]','http://res.iciba.com/resource/amp3/oxford/0/b9/ca/b9ca58798b67410c4c32f2946871a514.mp3','n. 酵母','','');----
INSERT INTO classwords VALUES ('662835b0b53447acb090cc1533978c08','8dafa068d18b4d47897e82c58eb1d26d','12');----
INSERT INTO word VALUES ('12078193a7194d8c8c09e7ad6167ca1e','flutter','[ˈflʌtə]','http://res.iciba.com/resource/amp3/oxford/0/10/58/1058da6089d25c6d82634fe9f7498689.mp3','vi. （鸟）振翼；飘动','','');----
INSERT INTO classwords VALUES ('998e37ed36874cd08518c260f52b9b8f','12078193a7194d8c8c09e7ad6167ca1e','12');----
INSERT INTO word VALUES ('9c5f9a57b5cf45d2814fd72210eb3cf2','bed','[bed]','http://res.iciba.com/resource/amp3/oxford/0/19/af/19af43896e5b0e7e4d6722a4d7a554b1.mp3','n. 河床；苗床；花圃','','');----
INSERT INTO classwords VALUES ('9cd922e6394f492d8b5fe59cf3d63245','9c5f9a57b5cf45d2814fd72210eb3cf2','12');----
INSERT INTO word VALUES ('723f1fcaaf2c4fdfa142a28f2a1725b6','motorway','[ˈməʊtəˌweɪ]','http://res.iciba.com/resource/amp3/0/0/b2/09/b2092b8d0aada16037c8fbf052ae8cc8.mp3','n. 高速公路','','');----
INSERT INTO classwords VALUES ('53932997205f4222b3d49f08a0b63fca','723f1fcaaf2c4fdfa142a28f2a1725b6','12');----
INSERT INTO word VALUES ('36fa6164cda54982ba537386974d8c27','seaside','[ˈsi:ˌsaɪd]','http://res.iciba.com/resource/amp3/oxford/0/d3/63/d363491ba5f2458f48dd4a138696d941.mp3','n. 海滨；海边','','');----
INSERT INTO classwords VALUES ('0900a08799124d21ace5be8f0ea673fe','36fa6164cda54982ba537386974d8c27','12');----
INSERT INTO word VALUES ('ca32b7e2556c4eae805cb94ab6ac5d7a','preside','[priˈzaid]','http://res.iciba.com/resource/amp3/oxford/0/a9/f7/a9f7403c12ab15ea7f1e6992053e7c61.mp3','vi. 主持；负责','','');----
INSERT INTO classwords VALUES ('fed2f739d0564682b3139f9b0b4f2b6b','ca32b7e2556c4eae805cb94ab6ac5d7a','12');----
INSERT INTO word VALUES ('0b0c4212502a46af8c9eb5f88bd357ba','contrary','[ˈkɔntrəri]','http://res.iciba.com/resource/amp3/1/0/19/58/195811dcbf084e2429cb1a69e4209962.mp3','n. 相反，反面，对立面','','');----
INSERT INTO classwords VALUES ('b6cbf2751811416a9cffd3de740594b0','0b0c4212502a46af8c9eb5f88bd357ba','12');----
INSERT INTO word VALUES ('a8218703b4fc4dd5b7fa97072bc6ec9f','ultraviolet','[ˌʌltrəˈvaiəlit]','http://res.iciba.com/resource/amp3/oxford/0/22/e2/22e251b3f0db95875d868f3ff8f0417f.mp3','n. 紫外线辐射','','');----
INSERT INTO classwords VALUES ('a2d3ae608a8c45f09b9db7c59238e7ba','a8218703b4fc4dd5b7fa97072bc6ec9f','12');----
INSERT INTO word VALUES ('f7335f20c3044f45b22931e5a8f5a47a','vocation','[vəʊˈkeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/f0/75/f0753abe4d0b13d04804ef6c7f8e8923.mp3','n. 职业；使命，天职','','');----
INSERT INTO classwords VALUES ('444625e9f9ef4157ad05aaa554d06ce3','f7335f20c3044f45b22931e5a8f5a47a','12');----
INSERT INTO word VALUES ('2deb2dedcced400c93d4f11d811a8c3c','monstrous','[ˈmɔnstrəs]','http://res.iciba.com/resource/amp3/oxford/0/42/24/4224066abbfb627ba4ed1dc7a79dd1f2.mp3','adj. 骇人听闻的；巨大的；可怕的','','');----
INSERT INTO classwords VALUES ('96ef4f9d237a4d57aa25c68978c21063','2deb2dedcced400c93d4f11d811a8c3c','12');----
INSERT INTO word VALUES ('3e3d1378f56a49a7a4801bd4780f62e1','horizon','[həˈraɪzn]','http://res.iciba.com/resource/amp3/0/0/40/7e/407e3b6b8b88aaf095f15efeb865efd6.mp3','n. 地平线；范围；眼界','','');----
INSERT INTO classwords VALUES ('1b720c0abeaf4b628694078af0631754','3e3d1378f56a49a7a4801bd4780f62e1','12');----
INSERT INTO word VALUES ('cdf0b2fef03d4308bcc1789daa78f513','pirate','[ˈpaiərit]','http://res.iciba.com/resource/amp3/oxford/0/59/85/59852118c11be347b29f81d2e51f46f1.mp3','n. 海盗；道德败坏者','','');----
INSERT INTO classwords VALUES ('376a96df04e84cf68b2a2fd31230f479','cdf0b2fef03d4308bcc1789daa78f513','12');----
INSERT INTO word VALUES ('491ee21a7db44f58a6c400f86d00b5fd','entreat','[enˈtri:t]','http://res.iciba.com/resource/amp3/oxford/0/11/e7/11e74073386d3add19073f74e93e9e45.mp3','vt. 恳求；乞求','','');----
INSERT INTO classwords VALUES ('9957b7293772493dbc77ef47f22e5ca9','491ee21a7db44f58a6c400f86d00b5fd','12');----
INSERT INTO word VALUES ('0560c3db52f04fbe8cb9ced6996fb2b7','exploration','[ˌekspləˈreɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/1d/d8/1dd813adb6d62f93cbec441d1693dde6.mp3','n. 探险；勘探；探测','','');----
INSERT INTO classwords VALUES ('cc00ff317bd645df9c5f5548300c630a','0560c3db52f04fbe8cb9ced6996fb2b7','12');----
INSERT INTO word VALUES ('58d347d295c6422abbce466cd4a354fe','rebuke','[riˈbju:k]','http://res.iciba.com/resource/amp3/oxford/0/b5/c1/b5c170ae108ea3532c88ab91573e01ea.mp3','vt. 指责，非难，斥责','','');----
INSERT INTO classwords VALUES ('3ec671fd179543d8aa9156a7e9a8d5c4','58d347d295c6422abbce466cd4a354fe','12');----
INSERT INTO word VALUES ('a21c4489a6324de08da1387737b43ef8','steak','[steik]','http://res.iciba.com/resource/amp3/oxford/0/56/ae/56ae415b5ab1c477d0f87036d3ca0100.mp3','n. 牛肉；牛排','','');----
INSERT INTO classwords VALUES ('110d9134268b4486abbb1aeb9fe40e11','a21c4489a6324de08da1387737b43ef8','12');----
INSERT INTO word VALUES ('e84b938118a64999afd3fe2ba36bfec1','spite','[spait]','http://res.iciba.com/resource/amp3/oxford/0/6f/5c/6f5ce6be4c1e964ad5a0c0f1ebb6e4c2.mp3','n. 恶意，怨恨','','');----
INSERT INTO classwords VALUES ('a8add7da27e743fb960fdaac0eeb92cf','e84b938118a64999afd3fe2ba36bfec1','12');----
INSERT INTO word VALUES ('6b5e70d2ad1d43fa91320fba47028c13','absent','[ˈæbsənt]','http://res.iciba.com/resource/amp3/oxford/0/1b/29/1b29c0ce28ccf8d61ab5478ee34b7f39.mp3','adj. 缺席的，不在的；出神的','','');----
INSERT INTO classwords VALUES ('99cc955f52c542a0a26a22813734838d','6b5e70d2ad1d43fa91320fba47028c13','12');----
INSERT INTO word VALUES ('66af0d02ff3b498b990d0541ca66b86c','eastward','[ˈi:stwəd]','http://res.iciba.com/resource/amp3/0/0/a7/ca/a7cab8bbec4c7b767a756fcf6596b9a1.mp3','adv. 向东地，朝东地','','');----
INSERT INTO classwords VALUES ('307b968a643648bb83196d9eb47d64e5','66af0d02ff3b498b990d0541ca66b86c','12');----
INSERT INTO word VALUES ('1be0c4e3f4f84e13a49e49164304b8c1','bound','[baund]','http://res.iciba.com/resource/amp3/oxford/0/82/c0/82c06e675f95147d00ae90f9952bfb11.mp3','adj. 一定的，必定的','','');----
INSERT INTO classwords VALUES ('bc171a93eb6e4600aafdccb5facd8092','1be0c4e3f4f84e13a49e49164304b8c1','12');----
INSERT INTO word VALUES ('bc776231d58f498bb0bbd99e9fa91fa7','chord','[kɔ:d]','http://res.iciba.com/resource/amp3/0/0/d2/77/d277c74c6c67461c562bdc2051681029.mp3','vi. 和谐','','');----
INSERT INTO classwords VALUES ('3d5e83f273cc41f2b21b80d79ee550af','bc776231d58f498bb0bbd99e9fa91fa7','12');----
INSERT INTO word VALUES ('750638fa8caf477f9f0c0a026647f949','stout','[staut]','http://res.iciba.com/resource/amp3/oxford/0/bd/2d/bd2d2967e86eb0ff218c7775fd944ae0.mp3','adj. 矮胖的；结实的；坚决的','','');----
INSERT INTO classwords VALUES ('c58268bcad85460094ecdc383aecc1e9','750638fa8caf477f9f0c0a026647f949','12');----
INSERT INTO word VALUES ('b2eb7de7cde84b559ecedc73c8c24991','expel','[iksˈpel]','http://res.iciba.com/resource/amp3/oxford/0/c8/ba/c8ba679fb3908e0c25e73917587db389.mp3','vt. 驱逐；开除；排出','','');----
INSERT INTO classwords VALUES ('4db379daaa164c52bdc3670795512e64','b2eb7de7cde84b559ecedc73c8c24991','12');----
INSERT INTO word VALUES ('1d971e29aca04c7c85faacb5ffe7536e','monarch','[ˈmɔnək]','http://res.iciba.com/resource/amp3/0/0/45/3a/453a9b3bfdab6ea719b2a34f5d2340c6.mp3','n. 君主，帝王','','');----
INSERT INTO classwords VALUES ('87b8d80b293241e293da3d3269583dec','1d971e29aca04c7c85faacb5ffe7536e','12');----
INSERT INTO word VALUES ('b50fa97609314a1da417668b9ac53690','fowl','[faʊl]','http://res.iciba.com/resource/amp3/oxford/0/fa/be/fabe3520192d3844a6b387c4b4261f7b.mp3','n. 家禽；禽肉；鸡','','');----
INSERT INTO classwords VALUES ('fd8fd4048eec4191ae3a5e80a7dee405','b50fa97609314a1da417668b9ac53690','12');----
INSERT INTO word VALUES ('0583e9d409d64a0fb1ba20b6d786c642','garment','[ˈɡɑ:mənt]','http://res.iciba.com/resource/amp3/oxford/0/b4/24/b424cfd6bed86c90b874356341f4c9b4.mp3','n. 衣服；服装','','');----
INSERT INTO classwords VALUES ('2c5966a1a93341eaae7a6805e3608232','0583e9d409d64a0fb1ba20b6d786c642','12');----
INSERT INTO word VALUES ('3e02bdd1430345bc885a92f7db45ddb2','ambitious','[æmˈbiʃəs]','http://res.iciba.com/resource/amp3/oxford/0/61/bb/61bbb4ce00ef7e34a9bfe6d41ed1ec29.mp3','adj. 有雄心的；有抱负的；有野心的','','');----
INSERT INTO classwords VALUES ('346ac3ae7978485b82d23a2d502301f3','3e02bdd1430345bc885a92f7db45ddb2','12');----
INSERT INTO word VALUES ('7382c68f52524c2dae9df01e2fbcdda0','particular','[pəˈtikjulə]','http://res.iciba.com/resource/amp3/oxford/0/e0/a9/e0a9776a0738cb6710439df61d120bd4.mp3','adj. 特指的；特别的；格外的','','');----
INSERT INTO classwords VALUES ('341bb6d084bc4ba0b1c4e1b197a63517','7382c68f52524c2dae9df01e2fbcdda0','12');----
INSERT INTO word VALUES ('0b11ff80daaa433fad28c2cbf60b855c','conceit','[kənˈsi:t]','http://res.iciba.com/resource/amp3/oxford/0/c2/5a/c25a23e3400a566b0cff36d5bb40f5c9.mp3','n. 自负，自高自大','','');----
INSERT INTO classwords VALUES ('fbf155cbbd0440cfb2919635de003e8c','0b11ff80daaa433fad28c2cbf60b855c','12');----
INSERT INTO word VALUES ('2f42019f77c74e4bb387d3940b4be366','irregularity','[ɪˌregjəˈlærɪti:]','http://res.iciba.com/resource/amp3/oxford/0/fa/97/fa973f7901d46db76b2d5195dce5b4ac.mp3','n. 不规则；不整齐','','');----
INSERT INTO classwords VALUES ('c35b249fba43451fb1f574a3128df94f','2f42019f77c74e4bb387d3940b4be366','12');----
INSERT INTO word VALUES ('50c8e51d812d454491162b7460096913','mesh','[meʃ]','http://res.iciba.com/resource/amp3/oxford/0/6a/0c/6a0cf149beb93bfb6283572c6aa96fee.mp3','n. 网眼；网状物','','');----
INSERT INTO classwords VALUES ('a782604a099146449633ce8a959a5ca2','50c8e51d812d454491162b7460096913','12');----
INSERT INTO word VALUES ('8678660ca2434225b086dae69704e7cb','alignment','[əˈlaɪnmənt]','http://res.iciba.com/resource/amp3/oxford/0/f1/fd/f1fdc939d267ce56a57ce58429746bc4.mp3','n. 调准；结盟，联合','','');----
INSERT INTO classwords VALUES ('df52b58470c84774bf82d3bbbd1e26fe','8678660ca2434225b086dae69704e7cb','12');----
INSERT INTO word VALUES ('7f08026557ce4e3aa1dced03fbdfc78f','willow','[ˈwiləu]','http://res.iciba.com/resource/amp3/0/0/59/2c/592cec0a3fc4d8cf9b6e57a09bff554b.mp3','n. 柳树','','');----
INSERT INTO classwords VALUES ('58109251a44049828168d8bf40745658','7f08026557ce4e3aa1dced03fbdfc78f','12');----
INSERT INTO word VALUES ('e90e1941e2a8498d95c966c7d7606998','plain','[plein]','http://res.iciba.com/resource/amp3/oxford/0/9b/e6/9be6045c47e8717dac93ec976c4d7881.mp3','adj. 素色的；朴素的；明显的；相貌平...','','');----
INSERT INTO classwords VALUES ('bdbe3716324d4a9b98c34dcba6ded2af','e90e1941e2a8498d95c966c7d7606998','12');----
INSERT INTO word VALUES ('265e5890e3084e3ead934644b389cf3c','standardize','[ˈstændəˌdaɪz]','http://res.iciba.com/resource/amp3/oxford/0/89/fc/89fcd9eca81b9b366e8db1288475b041.mp3','vt. 使标准化','','');----
INSERT INTO classwords VALUES ('d0343708ab4d4d42a1e2de8aaa28fb16','265e5890e3084e3ead934644b389cf3c','12');----
INSERT INTO word VALUES ('44b3690a7c334e86987fb20d73d4fb45','console','[kənˈsəul]','http://res.iciba.com/resource/amp3/oxford/0/24/95/249502ca338dbd954a2c4239a53f8562.mp3','v. 安慰，慰藉，安抚','','');----
INSERT INTO classwords VALUES ('dd8493ea36dc4677846f1b9e8510cc5d','44b3690a7c334e86987fb20d73d4fb45','12');----
INSERT INTO word VALUES ('49001e7ba0654a668a673f4650be953f','cape','[keip]','http://res.iciba.com/resource/amp3/oxford/0/b2/61/b261cdbc31b9df0cc37e4b2c314e2158.mp3','n. 披肩，斗篷；海角','','');----
INSERT INTO classwords VALUES ('4ff772176ca44f1ba02f93ee3d47ceb8','49001e7ba0654a668a673f4650be953f','12');----
INSERT INTO word VALUES ('b9df4dfa7f54449fab6ee711eb4858e2','sentiment','[ˈsentimənt]','http://res.iciba.com/resource/amp3/oxford/0/5a/71/5a716ecc398473042164a9d6c8391ad9.mp3','n. 情绪；见解；感伤，眷恋','','');----
INSERT INTO classwords VALUES ('51198f91358041f6b2ec6a5bf8993764','b9df4dfa7f54449fab6ee711eb4858e2','12');----
INSERT INTO word VALUES ('74b1f8e7217f41e194cfc029f5d1e1d4','advantageous','[ˌædvænˈteɪdʒəs]','http://res.iciba.com/resource/amp3/oxford/0/6a/11/6a11960e3d604fb84cd65f3fa38deb95.mp3','adj. 有利的，有助的','','');----
INSERT INTO classwords VALUES ('2c2b4e295cfc4d8395e2853793566164','74b1f8e7217f41e194cfc029f5d1e1d4','12');----
INSERT INTO word VALUES ('018ada16a9274c7f9bbb204533233b62','faultless','[ˈfɔ:ltlɪs]','http://res.iciba.com/resource/amp3/oxford/0/04/62/046233f93b66f4476e80e76bafc4af8b.mp3','adj. 无可挑剔的，完美无缺的','','');----
INSERT INTO classwords VALUES ('1a7cc055dd744410833c7aca2b655927','018ada16a9274c7f9bbb204533233b62','12');----
INSERT INTO word VALUES ('141e73f955fb407fb404883573a2b7b8','gamble','[ˈɡæmbl]','http://res.iciba.com/resource/amp3/oxford/0/1f/7a/1f7a035143e485d1b9add518125dc4e7.mp3','vt. 冒险；以…为赌注','','');----
INSERT INTO classwords VALUES ('041339aad82243a9a79f0101c7ac72ce','141e73f955fb407fb404883573a2b7b8','12');----
INSERT INTO word VALUES ('651c0411636d409c8c915fe1e43dbc6c','regulation','[ˌreɡjuˈleiʃən]','http://res.iciba.com/resource/amp3/oxford/0/73/f4/73f4accd3f2eb8e9773159afc7f42513.mp3','n. 规章，规则；调控，管理','','');----
INSERT INTO classwords VALUES ('23c738607f164ecb862b9325672f0111','651c0411636d409c8c915fe1e43dbc6c','12');----
INSERT INTO word VALUES ('1eb64364eb1b45d78285a1fd782ebb20','patrol','[pəˈtrəul]','http://res.iciba.com/resource/amp3/0/0/7e/39/7e39411afa494a20a2b1a11eff1fe660.mp3','v. 巡逻，巡查','','');----
INSERT INTO classwords VALUES ('b51dcab646d64450bfc787b8977c2b77','1eb64364eb1b45d78285a1fd782ebb20','12');----
INSERT INTO word VALUES ('c94e4c960e894f13b0403ad1b48d0839','choice','[tʃɔis]','http://res.iciba.com/resource/amp3/oxford/0/63/14/63149479546b0bdebfe7d832bd92ec2a.mp3','adj. 优等的','','');----
INSERT INTO classwords VALUES ('973de69e13314a26a058d8301ee97562','c94e4c960e894f13b0403ad1b48d0839','12');----
INSERT INTO word VALUES ('23c9a58854124d14a57e8a57db0f1f84','frequency','[ˈfri:kwənsi]','http://res.iciba.com/resource/amp3/oxford/0/85/23/852367da9594752387aa0c1270c6df7f.mp3','n. 频率；发生次数','','');----
INSERT INTO classwords VALUES ('f3c38a7ff1f6440c970cb799fb0f9f24','23c9a58854124d14a57e8a57db0f1f84','12');----
INSERT INTO word VALUES ('c8d293ccc9e9485bbe41c6ee9bccca97','muse','[mju:z]','http://res.iciba.com/resource/amp3/oxford/0/82/a7/82a7c30ed666895a5811c285243fc90b.mp3','vi. 沉思，冥想','','');----
INSERT INTO classwords VALUES ('a4caefc23e0e416f84e427f751f3cc58','c8d293ccc9e9485bbe41c6ee9bccca97','12');----
INSERT INTO word VALUES ('bc42800dd474461caae8f6d233aeae94','salute','[səˈlu:t]','http://res.iciba.com/resource/amp3/oxford/0/c8/66/c866ae44f0276bfd9a31234502dbe2ea.mp3','vt. 向…致敬；赞扬，颂扬','','');----
INSERT INTO classwords VALUES ('aa81521e7e5c482b80ea24c0134838c8','bc42800dd474461caae8f6d233aeae94','12');----
INSERT INTO word VALUES ('5966d9fd836449c58d0b7bb895bfc803','aerospace','[ˈeərəʊˌspeɪs]','http://res.iciba.com/resource/amp3/oxford/0/d2/ff/d2ff12a1c48efeb6af1a11a5dfcd3af3.mp3','n. 航空航天（工业）','','');----
INSERT INTO classwords VALUES ('d215ad021c294b5db80b0c108b5986cb','5966d9fd836449c58d0b7bb895bfc803','12');----
INSERT INTO word VALUES ('289e431b576f4b00b510766668758acb','proton','[ˈprəʊˌtɔn]','http://res.iciba.com/resource/amp3/0/0/91/df/91df09b569af69b5e64d1506f50fa4bb.mp3','n. 质子','','');----
INSERT INTO classwords VALUES ('c02b6bc528434dbfb2ff0c2c38aff7bf','289e431b576f4b00b510766668758acb','12');----
INSERT INTO word VALUES ('618b06cf8b254c5d83c3ff432a29cfc4','negative','[ˈneɡətiv]','http://res.iciba.com/resource/amp3/oxford/0/46/aa/46aa05fdf577025a90c3e8181341dfc7.mp3','adj. 消极的；否定的；呈阴性的；沮丧...','','');----
INSERT INTO classwords VALUES ('f10f9594222f46ae9043064474bfe7b5','618b06cf8b254c5d83c3ff432a29cfc4','12');----
INSERT INTO word VALUES ('432b829211cd403d921ea2fc7ee27e44','norm','[nɔːm]','http://res.iciba.com/resource/amp3/0/0/58/92/589275fdd4e5908f18310b56beaf439b.mp3','n. 准则；规范；常规','','');----
INSERT INTO classwords VALUES ('2fda80744ce24e58a77c44f529198a63','432b829211cd403d921ea2fc7ee27e44','12');----
INSERT INTO word VALUES ('984e0ef2a84741dc9afa646f6b845c10','chestnut','[ˈtʃesˌnʌt]','http://res.iciba.com/resource/amp3/oxford/0/92/29/922910cccb891e5a0c4099f7dcab89c0.mp3','n. 栗子；栗树；栗色','','');----
INSERT INTO classwords VALUES ('4d0f30dff31f4bf3a6c2ae5ffd760c03','984e0ef2a84741dc9afa646f6b845c10','12');----
INSERT INTO word VALUES ('219f482a831649139f072afa25a49a39','hike','[haik]','http://res.iciba.com/resource/amp3/oxford/0/3d/41/3d41896eee3e3f05b31ed8ff95a17330.mp3','vi. 徒步旅行；远足；上升','','');----
INSERT INTO classwords VALUES ('e41ea67fe4fe490b9eaae9d52ce7c453','219f482a831649139f072afa25a49a39','12');----
INSERT INTO word VALUES ('25d14d24d04e4a91bd841935f5bd29b4','subdue','[səbˈdju:]','http://res.iciba.com/resource/amp3/oxford/0/fe/98/fe982fb29e55a4801f5447da13c6ed6b.mp3','vt. 征服；克制','','');----
INSERT INTO classwords VALUES ('84deb33a2bf6469a95fb78f26f89fdc7','25d14d24d04e4a91bd841935f5bd29b4','12');----
INSERT INTO word VALUES ('55963eab117540359c03d392238cc2d2','lease','[li:s]','http://res.iciba.com/resource/amp3/oxford/0/f8/7b/f87bedce77eaa908a50497b39081e984.mp3','n. 租约，租契','','');----
INSERT INTO classwords VALUES ('b4e29a687f674aaebf00fa815f3324b8','55963eab117540359c03d392238cc2d2','12');----
INSERT INTO word VALUES ('45c372fe302a4a2fa3f16c7a649f3b82','pace','[peis]','http://res.iciba.com/resource/amp3/1/0/5b/a1/5ba1c4ecf208b1757df653813416a886.mp3','vt. 在…踱步；放稳步调','','');----
INSERT INTO classwords VALUES ('7a8140381d4f4feabc153569f7895397','45c372fe302a4a2fa3f16c7a649f3b82','12');----
INSERT INTO word VALUES ('f8506918eded48f7914e999da86e7cfa','thermal','[ˈθə:məl]','http://res.iciba.com/resource/amp3/0/0/26/a2/26a27f04d02b653b4b5b77b5d11d7bb9.mp3','adj. 热的；天然温热的；保暖的','','');----
INSERT INTO classwords VALUES ('b3eafe716ee644b0abb045f366729562','f8506918eded48f7914e999da86e7cfa','12');----
INSERT INTO word VALUES ('4d30d2f5e5d54c00bc3868e2fc823055','sink','[siŋk]','http://res.iciba.com/resource/amp3/oxford/0/5b/96/5b9640977cb68aca7efdeb707eeb06b8.mp3','n. （厨房内的）洗涤槽，洗涤池','','');----
INSERT INTO classwords VALUES ('bba37bafffad4ac4a455244a5cd53ce3','4d30d2f5e5d54c00bc3868e2fc823055','12');----
INSERT INTO word VALUES ('3fa4049d9351463a9d48bb3f73a3cdf3','simplicity','[simˈplisiti]','http://res.iciba.com/resource/amp3/oxford/0/12/80/1280f41a7f276f14427c4c12fa039773.mp3','n. 单纯，质朴；简单','','');----
INSERT INTO classwords VALUES ('911054c461134476b05c23aeea4ae44f','3fa4049d9351463a9d48bb3f73a3cdf3','12');----
INSERT INTO word VALUES ('71f99bce282e4ae2a6ef8500154a3acf','lofty','[ˈlɔfti]','http://res.iciba.com/resource/amp3/0/0/5f/3f/5f3f454c6828937c9a8ade8cb5a3f425.mp3','adj. 高耸的；崇高的；傲慢的','','');----
INSERT INTO classwords VALUES ('0d3c312587974499a7b7dd909ead9472','71f99bce282e4ae2a6ef8500154a3acf','12');----
INSERT INTO word VALUES ('e1f41b322a8347508f6f2c67b259dfb5','claim','[kleim]','http://res.iciba.com/resource/amp3/oxford/0/f3/24/f3247e0bd9973f1ba7cdad1b08ca5dca.mp3','n. 声称；断言；要求；权利，要求权','','');----
INSERT INTO classwords VALUES ('58a5677698d44d19a9c733083a8a0952','e1f41b322a8347508f6f2c67b259dfb5','12');----
INSERT INTO word VALUES ('ca8fc67880ff40cfbd00934788588723','detail','[ˈdi:teil]','http://res.iciba.com/resource/amp3/oxford/0/9d/7a/9d7a6da793467f15ed4d40863bc8de94.mp3','n. 细节；详情；末节，琐事','','');----
INSERT INTO classwords VALUES ('b137c815d8af427d8fe2b01c2c1bf707','ca8fc67880ff40cfbd00934788588723','12');----
INSERT INTO word VALUES ('067e41a4cdc241479246712c5664d318','chill','[tʃil]','http://res.iciba.com/resource/amp3/oxford/0/99/3c/993c9bff59ae400435d96c639124cb6d.mp3','vt.&vi. 使变冷；使冷却；使恐惧','','');----
INSERT INTO classwords VALUES ('a3d187d6a52546058f0ad7c3e3fd6a82','067e41a4cdc241479246712c5664d318','12');----
INSERT INTO word VALUES ('be401463b1a24da48af2933cb3116f5c','bankrupt','[ˈbæŋkrʌpt]','http://res.iciba.com/resource/amp3/oxford/0/88/eb/88eb99cb219e2670832549ff271e1ef6.mp3','vt. 使破产；使倒闭','','');----
INSERT INTO classwords VALUES ('2b068e06e34e41b9afc9fb011bd41051','be401463b1a24da48af2933cb3116f5c','12');----
INSERT INTO word VALUES ('e88f8ec7feb74c2aaef575fc152e86cc','pulley','[ˈpʊli]','http://res.iciba.com/resource/amp3/oxford/0/79/9e/799ec27da624fe9227165642046255e4.mp3','n. 滑轮，皮带轮','','');----
INSERT INTO classwords VALUES ('417849525c8b4d58a7a2f69f48aaee38','e88f8ec7feb74c2aaef575fc152e86cc','12');----
INSERT INTO word VALUES ('235c68a6a4e04192832bd65008f4cf30','herb','[hə:b]','http://res.iciba.com/resource/amp3/0/0/4f/c2/4fc237f42cffa981ab21bfbe879c25c4.mp3','n. 芳草；香草；药草','','');----
INSERT INTO classwords VALUES ('ec219459cca94a60aa5ef973029419de','235c68a6a4e04192832bd65008f4cf30','12');----
INSERT INTO word VALUES ('bc05f34916d74e15bcac8d2f2a38ea2e','ruthless','[ˈru:θlis]','http://res.iciba.com/resource/amp3/oxford/0/67/40/6740b6a1720992a3a946b4197ba78287.mp3','adj. 无情的，冷酷的；坚决的','','');----
INSERT INTO classwords VALUES ('d60a21f9c8084e10b55a25d3f806c5ae','bc05f34916d74e15bcac8d2f2a38ea2e','12');----
INSERT INTO word VALUES ('f616aaa4a5f14435b07fe27a7cdf2940','yearn','[jə:n]','http://res.iciba.com/resource/amp3/0/0/34/b7/34b7e63f50e62ebc12026f9a23a5ce9d.mp3','vi. 渴望，渴求，向往','','');----
INSERT INTO classwords VALUES ('c937192f80884df2afa940bc319fddf7','f616aaa4a5f14435b07fe27a7cdf2940','12');----
INSERT INTO word VALUES ('af0a4607ad99432082fa08a512dd4782','reproduction','[ˌri:prəˈdʌkʃən]','http://res.iciba.com/resource/amp3/oxford/0/87/d8/87d8c95e589841e9ac6c7524cc063533.mp3','n. 繁殖；复制品','','');----
INSERT INTO classwords VALUES ('081e516b40b24c0ca6dc9645ee3602a1','af0a4607ad99432082fa08a512dd4782','12');----
INSERT INTO word VALUES ('b18f9be2eada4f3080b28ae1c5bc78e5','exposition','[ˌekspəˈziʃən]','http://res.iciba.com/resource/amp3/oxford/0/84/3a/843adb5e674e1a7a01e56cbe6ef0b623.mp3','n. 说明，解释；展览会，博览会','','');----
INSERT INTO classwords VALUES ('5f7b3e5672044cc98fcabef8fc4858c0','b18f9be2eada4f3080b28ae1c5bc78e5','12');----
INSERT INTO word VALUES ('861b2a136d174d7d91ce345a6c7668d1','anybody','[ˈeniˌbɔdi]','http://res.iciba.com/resource/amp3/oxford/0/27/a7/27a71e80bd53d1f8269aa076d448d9a0.mp3','pron. 任何人','','');----
INSERT INTO classwords VALUES ('cccd6cf76bf74725a440563eb65147c6','861b2a136d174d7d91ce345a6c7668d1','12');----
INSERT INTO word VALUES ('d49b5779c922455689490067583b6b30','panic','[ˈpænik]','http://res.iciba.com/resource/amp3/oxford/0/8b/02/8b02828eaf353e8b07d5aac9ec28a98e.mp3','n. 恐慌，惊慌；恐慌局面','','');----
INSERT INTO classwords VALUES ('1a805c9b69c64385b46912e9ea58d611','d49b5779c922455689490067583b6b30','12');----
INSERT INTO word VALUES ('84bb87895efa404a82ea9aadf2c1a33c','completion','[kəmˈpli:ʃən]','http://res.iciba.com/resource/amp3/oxford/0/6c/5b/6c5bc041ff8cc7cd5398749e37e0853b.mp3','n. 完成，结束','','');----
INSERT INTO classwords VALUES ('6b11b50877e04f2992e52a4042126d63','84bb87895efa404a82ea9aadf2c1a33c','12');----
INSERT INTO word VALUES ('df1be3e98fe446f6aac7a03b41595e12','overwhelming','[ˌəuvəˈhwelmiŋ]','http://res.iciba.com/resource/amp3/oxford/0/e6/fc/e6fc33ea4377be6b5e0399cd42307cf6.mp3','adj. 巨大的，势不可挡的','','');----
INSERT INTO classwords VALUES ('a177e189ffc240f59d014d7d26957e9c','df1be3e98fe446f6aac7a03b41595e12','12');----
INSERT INTO word VALUES ('cb848ec702594b49b2d5adfebb03a271','evaporate','[iˈvæpəreit]','http://res.iciba.com/resource/amp3/oxford/0/b5/dd/b5dd58ae6baba07a6a377f31f73aa165.mp3','vi. 消失','','');----
INSERT INTO classwords VALUES ('4b95c256ff214297bd9cbe5e168d0ea7','cb848ec702594b49b2d5adfebb03a271','12');----
INSERT INTO word VALUES ('1f1f97b3c14e430397ae75e8a3a1a72c','outlaw','[ˈautlɔ:]','http://res.iciba.com/resource/amp3/oxford/0/e4/ce/e4cec869b75368553bc68f423c73f94e.mp3','n. 逃犯；亡命之徒','','');----
INSERT INTO classwords VALUES ('6a26065cbbc44dd29e8d10778e1d9c46','1f1f97b3c14e430397ae75e8a3a1a72c','12');----
INSERT INTO word VALUES ('015cebf6b0fa4679bd10e51bec998808','what','[hwɔt]','http://res.iciba.com/resource/amp3/0/0/4a/20/4a2028eceac5e1f4d252ea13c71ecec6.mp3','conj. 所…的是','','');----
INSERT INTO classwords VALUES ('3a0bb171f429490ab20314a1bb472279','015cebf6b0fa4679bd10e51bec998808','12');----
INSERT INTO word VALUES ('3e4ab8cde084449db15b58b884aa735c','insistent','[ɪnˈsɪstənt]','http://res.iciba.com/resource/amp3/oxford/0/4f/70/4f70b7a201601bd151c11f3f14782e93.mp3','adj. 坚持的；持续的，经久不息的','','');----
INSERT INTO classwords VALUES ('ca0fa4c16de6435a984bbdd34fa47456','3e4ab8cde084449db15b58b884aa735c','12');----
INSERT INTO word VALUES ('151e8799213c41fab5a2e4604f4e140d','endow','[inˈdau]','http://res.iciba.com/resource/amp3/oxford/0/c1/e4/c1e4b118cd4ea67ae8153cf6409c62bf.mp3','vt. 资助；赋予；使天生拥有','','');----
INSERT INTO classwords VALUES ('354086f85d644093991cf46e7f4ac190','151e8799213c41fab5a2e4604f4e140d','12');----
INSERT INTO word VALUES ('46769d73141d4529ba7d4c477fab1dbd','bugle','[ˈbju:gəl]','http://res.iciba.com/resource/amp3/oxford/0/84/c7/84c778325b6ec5dba92c2b92ea4e7ed0.mp3','n. 军号；喇叭','','');----
INSERT INTO classwords VALUES ('e7059cb016214bbaa4f8d1274e7d316f','46769d73141d4529ba7d4c477fab1dbd','12');----
INSERT INTO word VALUES ('a663d7f243ea4318a0dc6cc7f45c6faf','kidney','[ˈkidni]','http://res.iciba.com/resource/amp3/oxford/0/9b/8a/9b8a73960c3bc6f620855adc2cacc10a.mp3','n. 肾，肾脏；（供食用的）腰子','','');----
INSERT INTO classwords VALUES ('b0ca145e112c47038132cf34c38881f9','a663d7f243ea4318a0dc6cc7f45c6faf','12');----
INSERT INTO word VALUES ('f6f7c03b6df6472e8c33e18bf1941aca','barren','[ˈbærən]','http://res.iciba.com/resource/amp3/oxford/0/1d/02/1d02d12c2970e64c2267617ae3d9939c.mp3','adj. 贫瘠的；荒芜的；无用的；不孕的','','');----
INSERT INTO classwords VALUES ('dbfd173279384ac39d8f5394669e0e82','f6f7c03b6df6472e8c33e18bf1941aca','12');----
INSERT INTO word VALUES ('6fdfac7ac6104f7888fa70924e375bcb','follow','[ˈfɔləu]','http://res.iciba.com/resource/amp3/0/0/a4/01/a4010945e4bd924bc2a890a2effea0e6.mp3','vt. 追踪；信奉；理解，跟得上；沿袭，...','','');----
INSERT INTO classwords VALUES ('879bc30219cc47caaaf8677bb76d8397','6fdfac7ac6104f7888fa70924e375bcb','12');----
INSERT INTO word VALUES ('541f1ef271ad48319a348010f26a434f','striking','[ˈstraikiŋ]','http://res.iciba.com/resource/amp3/oxford/0/e2/4f/e24f89b3f484661dac5fc9287cb29f29.mp3','adj. 显著的；妩媚动人的','','');----
INSERT INTO classwords VALUES ('e4cd72c1c43b4b04b81d14910475efb2','541f1ef271ad48319a348010f26a434f','12');----
INSERT INTO word VALUES ('53829ea21a8043d78042ff076d5d2ab1','ballet','[ˈbælei]','http://res.iciba.com/resource/amp3/oxford/0/60/16/6016f7ae1b015621afc772a011d50233.mp3','n. 芭蕾舞；芭蕾舞剧','','');----
INSERT INTO classwords VALUES ('6b52667ce1f64731a74d8bc838b3a8b5','53829ea21a8043d78042ff076d5d2ab1','12');----
INSERT INTO word VALUES ('5d51d7dffa1f46f2b6cdff2d363d15fa','gradient','[ˈgreɪdi:ənt]','http://res.iciba.com/resource/amp3/oxford/0/5d/e3/5de39c8febf9b57489e1d16366ee65ca.mp3','adj. 倾斜的','','');----
INSERT INTO classwords VALUES ('6116b0d9ee034b5797c00743360489ce','5d51d7dffa1f46f2b6cdff2d363d15fa','12');----
INSERT INTO word VALUES ('8ff05d13660b4bf48ad38ccd768d529f','dynamic(al)','','','adj. 力的；有活力的；力学的；动态的','','');----
INSERT INTO classwords VALUES ('3788ab2511af46d7b72b2f88e03351c8','8ff05d13660b4bf48ad38ccd768d529f','12');----
INSERT INTO word VALUES ('aae8a45768ae48e9b2e5842bfbc5cee1','abbreviation','[əˌbri:viˈeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/57/12/5712374057da9aa7fe3fd26931b4403b.mp3','n. 缩写；缩略形式','','');----
INSERT INTO classwords VALUES ('79f01efdc164441e9ae83d7e6fb54727','aae8a45768ae48e9b2e5842bfbc5cee1','12');----
INSERT INTO word VALUES ('4e907db03be6465ab4224f3912a20071','strange','[streindʒ]','http://res.iciba.com/resource/amp3/oxford/0/a4/2a/a42a30425b448279b9adfb6424dd3edf.mp3','adj. 奇怪的；陌生的；不自在的','','');----
INSERT INTO classwords VALUES ('f5a316d5c3e74e82a0f797340fcec198','4e907db03be6465ab4224f3912a20071','12');----
INSERT INTO word VALUES ('cc864b6f792e45bfba930127cc1556fe','hostage','[ˈhɔstidʒ]','http://res.iciba.com/resource/amp3/oxford/0/b5/ea/b5ea5fcccebe7a0d67c4b7663d20a8ec.mp3','n. 人质；受限制的人','','');----
INSERT INTO classwords VALUES ('449a7978b8bb43198c1251d104b94219','cc864b6f792e45bfba930127cc1556fe','12');----
INSERT INTO word VALUES ('ce39a80b28fb49589688b3cd3c5bc8e9','administratio...','[ ədˌminisˈtreiʃən]','http://res.iciba.com/resource/amp3/oxford/0/ab/22/ab225929c4137ef505034d3dfb398871.mp3','n. 管理；实施；行政部门','','');----
INSERT INTO classwords VALUES ('71b96bd07c6243839bb61fca7beddd55','ce39a80b28fb49589688b3cd3c5bc8e9','12');----
INSERT INTO word VALUES ('3ff41d66ab584ecd82812d8d6d37147a','stroll','[strəul]','http://res.iciba.com/resource/amp3/0/0/84/f0/84f0fdce91bef1da01ba9f1de7ac8e7f.mp3','v. 散步，溜达，闲逛','','');----
INSERT INTO classwords VALUES ('efb31233d7714621ab4e72e0dce0812f','3ff41d66ab584ecd82812d8d6d37147a','12');----
INSERT INTO word VALUES ('9c2884d5d36a4477ae3c9873da2bb2ac','charm','[tʃɑ:m]','http://res.iciba.com/resource/amp3/0/0/13/b5/13b5eb84acdcb1fbf868afe503584827.mp3','vt. 迷住，吸引；使倾倒；使中魔法','','');----
INSERT INTO classwords VALUES ('89dfcd16cd324bdf8fa3db10e6c5d203','9c2884d5d36a4477ae3c9873da2bb2ac','12');----
INSERT INTO word VALUES ('244d052e0978461ebab5a84f9061408e','cooperative','[kəuˈɔpərətiv]','http://res.iciba.com/resource/amp3/oxford/0/4c/19/4c19a8c1274b6483979578bfc59fe288.mp3','n. 合作社','','');----
INSERT INTO classwords VALUES ('c1eea9818dea4966999cfec04e1ce2b9','244d052e0978461ebab5a84f9061408e','12');----
INSERT INTO word VALUES ('35683c2e84504603bb22b3280ebe4e78','bridle','[ˈbraɪdl]','http://res.iciba.com/resource/amp3/oxford/0/78/8f/788f954988434d5d7d643217f07df4cd.mp3','vt. 控制；给…套笼头','','');----
INSERT INTO classwords VALUES ('d6bdd5a2536346e98316101c9bbe8db9','35683c2e84504603bb22b3280ebe4e78','12');----
INSERT INTO word VALUES ('fcb1da26e1454f37b3218ea2661e33d7','qualification','[ˌkwɔlifiˈkeiʃən]','http://res.iciba.com/resource/amp3/0/0/93/4b/934bc20046509870e266117294898038.mp3','n. 资格；素质，资历；限制条件','','');----
INSERT INTO classwords VALUES ('6f61ee16f50f4a008d169ad3c93149f8','fcb1da26e1454f37b3218ea2661e33d7','12');----
INSERT INTO word VALUES ('be40225858c6457db2cd027a3c5adfb9','between','[biˈtwi:n]','http://res.iciba.com/resource/amp3/oxford/0/0d/3d/0d3d5d9322cc3103942fd4de11fac8ae.mp3','prep. 在…之间；介于…之间；总计','','');----
INSERT INTO classwords VALUES ('6a55028afcb34f089eb32bee44212e5f','be40225858c6457db2cd027a3c5adfb9','12');----
INSERT INTO word VALUES ('5ef8292b719f4ffdad1b29ee1f343a34','message','[ˈmesidʒ]','http://res.iciba.com/resource/amp3/oxford/0/91/c6/91c62a82d847c5ab0081d6f86a2404ae.mp3','n. 消息；主题思想','','');----
INSERT INTO classwords VALUES ('cfaac93fb41a4addbdb1fbc8e11f80af','5ef8292b719f4ffdad1b29ee1f343a34','12');----
INSERT INTO word VALUES ('6c387260e9d24a18ac9fd595cd77e371','thicken','[ˈθɪkən]','http://res.iciba.com/resource/amp3/oxford/0/7f/8a/7f8a9fdc7a2e483893af0f00111462d2.mp3','vt. 使…变浓稠；变密集','','');----
INSERT INTO classwords VALUES ('7896638c1bd74b2fa960968f45be9211','6c387260e9d24a18ac9fd595cd77e371','12');----
INSERT INTO word VALUES ('3ea6a1fe7451434db7460156f48d52af','flake','[fleik]','http://res.iciba.com/resource/amp3/oxford/0/2e/2d/2e2d3eb3618668787d3c1cfac8a6e6a4.mp3','n. 小薄片；（尤指）碎片','','');----
INSERT INTO classwords VALUES ('c8e03c655bd54fbd955eacdf618e39b3','3ea6a1fe7451434db7460156f48d52af','12');----
INSERT INTO word VALUES ('ce57862c1481429aa1be7823498851dc','bearing','[ˈbɛəriŋ]','http://res.iciba.com/resource/amp3/oxford/0/4d/71/4d7115499467c06d974ebb503e2f120f.mp3','n. 忍受；举止；方位；轴承','','');----
INSERT INTO classwords VALUES ('4dff1a52719d446a80bc0513caae49f1','ce57862c1481429aa1be7823498851dc','12');----
INSERT INTO word VALUES ('c2c53dece7c74d81bfb9f43c528489c3','coach','[kəutʃ]','http://res.iciba.com/resource/amp3/0/0/f9/31/f931b13aead002d7fcdb02f84e0f794f.mp3','vt. 辅导，指导，训练','','');----
INSERT INTO classwords VALUES ('f263ebb1eab34472b1f67465012bca6f','c2c53dece7c74d81bfb9f43c528489c3','12');----
INSERT INTO word VALUES ('c5d6cf7c4ff042a593c08efd1a4ce8ba','undesirable','[ˌʌndɪˈzaɪərəbəl]','http://res.iciba.com/resource/amp3/oxford/0/eb/a4/eba4b1a504d0434fa1ed1558819535b3.mp3','adj. 不受欢迎的；不良的；有害的','','');----
INSERT INTO classwords VALUES ('7a4b2a394da74c60b137e371731e43d8','c5d6cf7c4ff042a593c08efd1a4ce8ba','12');----
INSERT INTO word VALUES ('ea77819bc2474625b722d9e704d51fa7','stitch','[stitʃ]','http://res.iciba.com/resource/amp3/oxford/0/ea/f1/eaf1591aad5d5df557e185b5c6a33d30.mp3','vt. 缝；缝补；缝合（伤口）','','');----
INSERT INTO classwords VALUES ('bd3fb45ff5b440918c7875ad98745516','ea77819bc2474625b722d9e704d51fa7','12');----
INSERT INTO word VALUES ('34f0fd8fe0bd480997352320fd170bca','reel','[ri:l]','http://res.iciba.com/resource/amp3/oxford/0/8c/ae/8cae1d4afc8bdc5ca6ad38cd4d615393.mp3','v. 蹒跚，摇摆，踉跄；卷，绕','','');----
INSERT INTO classwords VALUES ('5c3cb3a3fb504dbaac9bcf2b66dd3f7a','34f0fd8fe0bd480997352320fd170bca','12');----
INSERT INTO word VALUES ('5a328430ddc44b73afbba0dd12b67c9f','nightmare','[ˈnaitmɛə]','http://res.iciba.com/resource/amp3/oxford/0/42/1d/421db9f074039e910cd511fb748254a8.mp3','n. 恶梦；可怕的情景；恼人的情景','','');----
INSERT INTO classwords VALUES ('134eddecea414c69bb2d9253fce944e1','5a328430ddc44b73afbba0dd12b67c9f','12');----
INSERT INTO word VALUES ('75aaa31bbc4e42dda557455b8bfc3160','infinitely','[ˈɪnfɪnɪtlɪ]','http://res.iciba.com/resource/amp3/oxford/0/ad/67/ad67764102627cfae6d733a1a5fccfdf.mp3','adv. 无限地，无穷地','','');----
INSERT INTO classwords VALUES ('379cb918494f43eb8287289cdea1ef66','75aaa31bbc4e42dda557455b8bfc3160','12');----
INSERT INTO word VALUES ('0d5ab85cdf4a4106984184e2e86e94cf','underwear','[ˈʌndəwɛə]','http://res.iciba.com/resource/amp3/0/0/2a/8b/2a8b43825bcc4554fef2bc356ea52173.mp3','n. 内衣，衬衣','','');----
INSERT INTO classwords VALUES ('72f33800e23a4964a27dfb6ad89cc374','0d5ab85cdf4a4106984184e2e86e94cf','12');----
INSERT INTO word VALUES ('dcb317c42e7948be8c02ea3dd401a226','Saturn','[ˈsætən]','http://res.iciba.com/resource/amp3/oxford/0/e2/7c/e27c587a7df11212db1e0c11a3277645.mp3','n. [罗神]农神；土星','','');----
INSERT INTO classwords VALUES ('a71cf1a1663947cd8e85b04602b51089','dcb317c42e7948be8c02ea3dd401a226','12');----
INSERT INTO word VALUES ('8917e8a103d14dfc83c1c86b4e7d860e','fastener','[ˈfɑ:sənə]','http://res.iciba.com/resource/amp3/oxford/0/ce/ff/ceff32c6e234a2133d3518abf6e974c4.mp3','n. 扣件，钮扣，拉链','','');----
INSERT INTO classwords VALUES ('19f7b85ab49b4933a40dc93595f3e215','8917e8a103d14dfc83c1c86b4e7d860e','12');----
INSERT INTO word VALUES ('5fb5188a358a40f887e8d624ffba4dcb','foam','[fəum]','http://res.iciba.com/resource/amp3/0/0/24/ea/24ea74fcea339d95e6d925184bd7d5f7.mp3','n. 泡沫；泡沫产品；泡沫橡胶','','');----
INSERT INTO classwords VALUES ('e31a305445e44951b265db0fc885e2fe','5fb5188a358a40f887e8d624ffba4dcb','12');----
INSERT INTO word VALUES ('a7571b5c7f754a388c2de418cd33c0f5','arctic','[ˈɑ:ktɪk]','http://res.iciba.com/resource/amp3/0/0/32/34/32343e35c68568f548cb66b3e25f1d6e.mp3','n. 北极','','');----
INSERT INTO classwords VALUES ('914cd296d8bf400cb6fbf1073b083855','a7571b5c7f754a388c2de418cd33c0f5','12');----
INSERT INTO word VALUES ('fe5565a009f143c692a335240e071cc2','scholarship','[ˈskɔləʃip]','http://res.iciba.com/resource/amp3/0/0/f0/3d/f03d4854848716a1087ee0bdbe549594.mp3','n. 学问，学识；奖学金','','');----
INSERT INTO classwords VALUES ('9263236ad6f2459891da1f0d14dfdbb4','fe5565a009f143c692a335240e071cc2','12');----
INSERT INTO word VALUES ('002a4cbac8684cc7b773858bf1f32aca','misery','[ˈmizəri]','http://res.iciba.com/resource/amp3/oxford/0/94/c7/94c78b898ccfb68b25309b0274a3fe6e.mp3','n. 痛苦；不幸；穷困','','');----
INSERT INTO classwords VALUES ('1faca41f005d40bd9fa181dea20095c9','002a4cbac8684cc7b773858bf1f32aca','12');----
INSERT INTO word VALUES ('83d6a3a4929f4ece854963ba28cfc362','epoch','[ˈi:pɔk]','http://res.iciba.com/resource/amp3/1/0/33/88/3388c74e6308ba994ce6b75fd4710251.mp3','n. 时代；历元；（地质中的）世，纪','','');----
INSERT INTO classwords VALUES ('e550168513144d7d8037e30183202eb6','83d6a3a4929f4ece854963ba28cfc362','12');----
INSERT INTO word VALUES ('dad4e45230e44338ad18e2f41c737757','questionable','[ˈkwestʃənəbəl]','http://res.iciba.com/resource/amp3/oxford/0/c4/84/c4846dd40f5c21f6384e2415c7d3bd1d.mp3','adj. 可疑的，不可靠的；有问题的','','');----
INSERT INTO classwords VALUES ('bdf05b7caf354fe99981a753dddec73b','dad4e45230e44338ad18e2f41c737757','12');----
INSERT INTO word VALUES ('9879200b1039464990516b30165d9a50','amplitude','[ˈæmplɪˌtu:d]','http://res.iciba.com/resource/amp3/oxford/0/cd/b5/cdb5d0b3e7f2f36a410d7ffe83d0ac80.mp3','n. 广大，广阔，大量；[物]振幅','','');----
INSERT INTO classwords VALUES ('d64589faef2f4221a1616a9368b16740','9879200b1039464990516b30165d9a50','12');----
INSERT INTO word VALUES ('f67ee1aa48db4f98bd8e030eae9a6485','preservation','[ˌprezəˈveiʃən]','http://res.iciba.com/resource/amp3/oxford/0/60/2b/602bee9cd28d2ae386e962a85c2d21f3.mp3','n. 保存，储藏；保持','','');----
INSERT INTO classwords VALUES ('cb8ee058bd624d169de6cc4c118feae8','f67ee1aa48db4f98bd8e030eae9a6485','12');----
INSERT INTO word VALUES ('d84b203751ce4f919046ad04a0eb71c2','profitable','[ˈprɔfitəbl]','http://res.iciba.com/resource/amp3/oxford/0/70/f4/70f443b25d479193782a6e30712f7de2.mp3','adj. 有利润的；有益的','','');----
INSERT INTO classwords VALUES ('f2ed4fb5901549a99838533fe88d6793','d84b203751ce4f919046ad04a0eb71c2','12');----
INSERT INTO word VALUES ('0bb270ac2a224f2f9406da32bf3f3eed','refinery','[rɪˈfaɪnəri:]','http://res.iciba.com/resource/amp3/oxford/0/8f/f4/8ff430c156aefaafafb18719fe18d585.mp3','n. 精炼厂，提炼厂','','');----
INSERT INTO classwords VALUES ('d93c9423cf2846c69f526a30e40d9f80','0bb270ac2a224f2f9406da32bf3f3eed','12');----
INSERT INTO word VALUES ('f55a9e4b36014cf5922301adbe2ba359','insulate','[ˈinsjuleit]','http://res.iciba.com/resource/amp3/oxford/0/30/0b/300bcd54415bdbb663f15c35fe615a82.mp3','vt. 将…隔离；使隔热；使隔音；使绝缘','','');----
INSERT INTO classwords VALUES ('71d783ab1bef45499786c11aa32550c0','f55a9e4b36014cf5922301adbe2ba359','12');----
INSERT INTO word VALUES ('c7d9552ffbe2451a964d86dab9c05bdc','conceive','[kənˈsi:v]','http://res.iciba.com/resource/amp3/oxford/0/56/a9/56a96d3509ef764f37b230140834c25b.mp3','vt. 设想，想像；以为；怀孕','','');----
INSERT INTO classwords VALUES ('14355ccf442a45d282d189e8bcf4b4e2','c7d9552ffbe2451a964d86dab9c05bdc','12');----
INSERT INTO word VALUES ('bd43dd4d666445169d7e009547c6ed1f','southwards','[ˈsaʊθwədz]','http://res.iciba.com/resource/amp3/oxford/0/e2/de/e2de4597a18eecda08d11e4bcea57cef.mp3','adv. 向南方','','');----
INSERT INTO classwords VALUES ('706be860cc3045de9d0c8c009dc670bb','bd43dd4d666445169d7e009547c6ed1f','12');----
INSERT INTO word VALUES ('5c1f5a05b7344d9e9d7468520951cb77','thorough','[ˈθʌrə]','http://res.iciba.com/resource/amp3/0/0/c8/a9/c8a9e11795d8d009e8ad65ab24264104.mp3','adj. 彻底的；仔细的，严谨的；完全的','','');----
INSERT INTO classwords VALUES ('6ffe25e0a963495dbf75c52f1496d0a2','5c1f5a05b7344d9e9d7468520951cb77','12');----
INSERT INTO word VALUES ('c1218887403c43edb8e17e89cd1d319d','sovereign','[ˈsɔvrin]','http://res.iciba.com/resource/amp3/0/0/e8/10/e81038ad9c2f81e75f03a52c9574b8b6.mp3','adj. 拥有最高统治权的；独立自主的','','');----
INSERT INTO classwords VALUES ('5cfe988beaa146bbb70dc04839dc83ff','c1218887403c43edb8e17e89cd1d319d','12');----
INSERT INTO word VALUES ('abb9220aa4544e849cd2cdb6dd3baea3','poll','[pəul]','http://res.iciba.com/resource/amp3/0/0/b0/f6/b0f6dfb42fa80caee6825bfecd30f094.mp3','vi. 对…进行民意测验；获得（…票数）','','');----
INSERT INTO classwords VALUES ('d3e79d30645146d6a5f4ceb747e79c87','abb9220aa4544e849cd2cdb6dd3baea3','12');----
INSERT INTO word VALUES ('c074819b73814f4f9878ca80decf9f51','negotiate','[niˈɡəuʃieit]','http://res.iciba.com/resource/amp3/oxford/0/65/ce/65ce700591e8929c4d851d9f35a6824f.mp3','v. 谈判，协商；顺利通过','','');----
INSERT INTO classwords VALUES ('651ace7ad5c247e59427ce11a889050a','c074819b73814f4f9878ca80decf9f51','12');----
INSERT INTO word VALUES ('8d24a931189d4d9e9d0ede44aad02068','reproduce','[ˌri:prəˈdju:s]','http://res.iciba.com/resource/amp3/oxford/0/7c/6c/7c6c722fc762f63e369152b81986d9f5.mp3','vt. 模拟；复制；重复；繁殖','','');----
INSERT INTO classwords VALUES ('d43f70e4fc0a412a87f878ca051b6a27','8d24a931189d4d9e9d0ede44aad02068','12');----
INSERT INTO word VALUES ('f86db3895db2440bb3366646bbed7a6b','raise','[reiz]','http://res.iciba.com/resource/amp3/oxford/0/0e/6f/0e6fe0b5cdb94580b850bad135eaac37.mp3','vt. 提出；举起；起身；提高；筹集','','');----
INSERT INTO classwords VALUES ('7bb3e07353ac4ba391d9f5a3c8db9e89','f86db3895db2440bb3366646bbed7a6b','12');----
INSERT INTO word VALUES ('91f8305a8ec7499fa10594cc633ba117','sculpture','[ˈskʌlptʃə]','http://res.iciba.com/resource/amp3/oxford/0/0e/7c/0e7c6351ffda5c15df4fda2967f47748.mp3','n. 雕刻艺术；雕刻品','','');----
INSERT INTO classwords VALUES ('07dfa8c67efa417a9662743f0a6db18f','91f8305a8ec7499fa10594cc633ba117','12');----
INSERT INTO word VALUES ('4607ce887efb4940ba18b7c317b13e42','squat','[skwɔt]','http://res.iciba.com/resource/amp3/0/0/67/01/6701b56ab3ff30bb18225de93c864367.mp3','vt. （使）蹲下；擅自占用','','');----
INSERT INTO classwords VALUES ('a1a10bd486f8488ea87def8a3418c32d','4607ce887efb4940ba18b7c317b13e42','12');----
INSERT INTO word VALUES ('ce92c0dbb5d24638bc7e47daa6fbe872','adjoin','[əˈdʒɔin]','http://res.iciba.com/resource/amp3/oxford/0/f9/32/f9327d0798fce9881e1ba2516cbe937a.mp3','vt. 邻接；毗连','','');----
INSERT INTO classwords VALUES ('096f457adf6545398d68f36e8b1e2d55','ce92c0dbb5d24638bc7e47daa6fbe872','12');----
INSERT INTO word VALUES ('41d90060fd1f4d9d85e9a17eea590e94','modesty','[ˈmɔdɪsti:]','http://res.iciba.com/resource/amp3/oxford/0/23/45/2345601decc8055af7435201694406bc.mp3','n. 谦逊；端庄；（地方）小','','');----
INSERT INTO classwords VALUES ('42c64420ee7e47eaa9537d4b684b3a70','41d90060fd1f4d9d85e9a17eea590e94','12');----
INSERT INTO word VALUES ('c85d0200c41d4f0a855135cfd9b55079','filth','[filθ]','http://res.iciba.com/resource/amp3/oxford/0/82/b3/82b3559d9c3ecd5d07d0c03a50abcd2b.mp3','n. 污秽，污物；淫秽','','');----
INSERT INTO classwords VALUES ('2624abf84aab4797b4ae4dd4c274cd6f','c85d0200c41d4f0a855135cfd9b55079','12');----
INSERT INTO word VALUES ('046e1e2c92e541fd92f15cfe3a25c6c8','terrace','[ˈterəs]','http://res.iciba.com/resource/amp3/oxford/0/56/5b/565b5cdc32e87ac69779588fdb0a9064.mp3','n. 排屋；平台；梯田','','');----
INSERT INTO classwords VALUES ('ed297c22978f4d3ca60d4b68efad709d','046e1e2c92e541fd92f15cfe3a25c6c8','12');----
INSERT INTO word VALUES ('70908f4ee5b14345b6c72976ca39cbda','warfare','[ˈwɔ:fɛə]','http://res.iciba.com/resource/amp3/0/0/2e/90/2e9037ef894d289038a8899ad63cb80f.mp3','n. 战争；冲突，斗争','','');----
INSERT INTO classwords VALUES ('48ef096cb07547269747d2c921be3283','70908f4ee5b14345b6c72976ca39cbda','12');----
INSERT INTO word VALUES ('8d746161322d48c3824da24b9bca49b5','battery','[ˈbætəri]','http://res.iciba.com/resource/amp3/oxford/0/a2/f6/a2f6e467f9f9a92aa11af81f1dcee6c7.mp3','n. 电池；（设备的）一排；一系列；炮兵...','','');----
INSERT INTO classwords VALUES ('58ff506688c04dadbb8b5c5c8afb554b','8d746161322d48c3824da24b9bca49b5','12');----
INSERT INTO word VALUES ('90c6460958b6419aac98ab3b898e4508','reclaim','[riˈkleim]','http://res.iciba.com/resource/amp3/oxford/0/a2/88/a2888f9f423ceca20a23a91d379c88a4.mp3','vt. 开垦，开拓；收回；申请退税','','');----
INSERT INTO classwords VALUES ('a0a3403053ad440bbb24e9954a9f6f15','90c6460958b6419aac98ab3b898e4508','12');----
INSERT INTO word VALUES ('b966bf98fb3c4b67bff6b194f161791e','conform','[kənˈfɔ:m]','http://res.iciba.com/resource/amp3/oxford/0/31/34/3134ef74ada526f720f3d86fb33acd7b.mp3','vi. 符合；遵照','','');----
INSERT INTO classwords VALUES ('4f13e8e57ba94bb3afae2dd7d7dc762d','b966bf98fb3c4b67bff6b194f161791e','12');----
INSERT INTO word VALUES ('e3be663ac74f4215bc6f39073a3c3081','pattern','[ˈpætən]','http://res.iciba.com/resource/amp3/1/0/24/0b/240bf022e685b0ee30ad9fe9e1fb5d5b.mp3','vt. 仿制，模仿；以图案装饰','','');----
INSERT INTO classwords VALUES ('f0446be0e7154083bc697f8096f7d707','e3be663ac74f4215bc6f39073a3c3081','12');----
INSERT INTO word VALUES ('5e5bd8f0a4a040dd967c15821fed5045','allowance','[əˈlauəns]','http://res.iciba.com/resource/amp3/oxford/0/4f/5a/4f5a03ef9fca52bedc450245424052e5.mp3','n. 津贴，补助；零用钱','','');----
INSERT INTO classwords VALUES ('ef767d5e997648bcbd05d8e35aef8514','5e5bd8f0a4a040dd967c15821fed5045','12');----
INSERT INTO word VALUES ('2d8f5f0134d540318814de10f207ecea','indispensable','[ˌɪndisˈpensəbl]','http://res.iciba.com/resource/amp3/oxford/0/6f/a3/6fa3656121bda61e99007324f6eaa25b.mp3','adj. 必不可少的，不可或缺的','','');----
INSERT INTO classwords VALUES ('413141daf9444e24826cc188b94f0188','2d8f5f0134d540318814de10f207ecea','12');----
INSERT INTO word VALUES ('8296a0c847a5465884bd427e40e91f71','invalid','[inˈvælid]','http://res.iciba.com/resource/amp3/oxford/0/39/da/39dae0c119fbdfaff58414406ce5d700.mp3','adj. 无效的；（论据、结论）站不住脚...','','');----
INSERT INTO classwords VALUES ('b7989204be6043bab5468dbce5d9a4c2','8296a0c847a5465884bd427e40e91f71','12');----
INSERT INTO word VALUES ('592e5ed470334b1ebce7cd81d1097cc3','usage','[ˈju:zidʒ]','http://res.iciba.com/resource/amp3/oxford/0/be/7b/be7b18f7980813dd3d125cf73431e7e7.mp3','n. 使用；惯用法','','');----
INSERT INTO classwords VALUES ('c1498ab783b242baa11b838628d016a3','592e5ed470334b1ebce7cd81d1097cc3','12');----
INSERT INTO word VALUES ('b023268f46b44bd78f4ea2c0f907cb78','quartz','[kwɔ:ts]','http://res.iciba.com/resource/amp3/0/0/1d/41/1d419d26520cc8e553f4259d9a12402e.mp3','n. 石英','','');----
INSERT INTO classwords VALUES ('c487a7e35b5d47e8a7d67d2dd56541e0','b023268f46b44bd78f4ea2c0f907cb78','12');----
INSERT INTO word VALUES ('53bc7e0e56b44e98ad1cf031e10c868d','incidence','[ˈinsidəns]','http://res.iciba.com/resource/amp3/oxford/0/00/75/00753ff902803fbeb7a49d6cf84da3de.mp3','n. 发生，发生率；[物]入射','','');----
INSERT INTO classwords VALUES ('11f0921724844cc1b0b4f0c24346590f','53bc7e0e56b44e98ad1cf031e10c868d','12');----
INSERT INTO word VALUES ('84d4ae30c6954e849fcba7ee91c1c16b','snob','[snɔb]','http://res.iciba.com/resource/amp3/0/0/3a/60/3a60abe88dbeb7cea3af7ea70c97fc74.mp3','n. 势利小人','','');----
INSERT INTO classwords VALUES ('b568e8cd67714f01abb48a13bbf33043','84d4ae30c6954e849fcba7ee91c1c16b','12');----
INSERT INTO word VALUES ('71e529770df645ee8cd588d1e5653186','credit','[ˈkredit]','http://res.iciba.com/resource/amp3/oxford/0/c8/4f/c84f80f61bba42e35af73b17ef1c5ad2.mp3','vt. 相信，信任；认为…有（某种品质）...','','');----
INSERT INTO classwords VALUES ('61f97db7fcc6408ead1b2ffcae83bba8','71e529770df645ee8cd588d1e5653186','12');----
INSERT INTO word VALUES ('42e65f1152a444339674debab9b94560','steal','[sti:l]','http://res.iciba.com/resource/amp3/oxford/0/14/52/145203f4a40324c3faa4882985696668.mp3','vt. 偷；窃取；悄悄走到','','');----
INSERT INTO classwords VALUES ('98457f25c90b4b918fd7cd85f46210fd','42e65f1152a444339674debab9b94560','12');----
INSERT INTO word VALUES ('64ded37811214cd9b8d926fb154ede68','coin','[kɔin]','http://res.iciba.com/resource/amp3/oxford/0/f9/a4/f9a4d1c7991a29224179b6bf5d0c11f9.mp3','vt. 杜撰（单词、短语）；制造硬币','','');----
INSERT INTO classwords VALUES ('75f95da6531b4abe9ea093f17e856cbc','64ded37811214cd9b8d926fb154ede68','12');----
INSERT INTO word VALUES ('b6f265570af64bf6a9c6aac2c6677df8','overhang','[ˌəʊvəˈhæŋ]','http://res.iciba.com/resource/amp3/oxford/0/71/59/7159b96ef6a4dbcfa39ae45439d000ef.mp3','vi. 悬垂','','');----
INSERT INTO classwords VALUES ('33e9c58b3b64484da3c058c6d0e2e923','b6f265570af64bf6a9c6aac2c6677df8','12');----
INSERT INTO word VALUES ('c57756d0442a469d95e766d86e03b08e','scarcity','[ˈskeəsɪti:]','http://res.iciba.com/resource/amp3/oxford/0/0c/b7/0cb79f05783368488bad25a702a71cf2.mp3','n. 缺乏，不足；稀少','','');----
INSERT INTO classwords VALUES ('15e056062a1b4b239b68670d5e0f12c2','c57756d0442a469d95e766d86e03b08e','12');----
INSERT INTO word VALUES ('e344104373624832b9999392c171350f','significant','[siɡˈnifikənt]','http://res.iciba.com/resource/amp3/oxford/0/55/c2/55c28d32c12e901d691361c3a5b4a9ce.mp3','adj. 显著的；重要的；意味深远的','','');----
INSERT INTO classwords VALUES ('514a51b3c251443e9e2a7e17a07bf35c','e344104373624832b9999392c171350f','12');----
INSERT INTO word VALUES ('c20bf1a0d2ed478691608f81d8af9a5f','chorus','[ˈkɔ:rəs]','http://res.iciba.com/resource/amp3/oxford/0/e9/d0/e9d07026930bf252bf0bdf38632e5625.mp3','n. 合唱；合唱团；副歌','','');----
INSERT INTO classwords VALUES ('8d4870e4113949e9b667c18bcc4a29a7','c20bf1a0d2ed478691608f81d8af9a5f','12');----
INSERT INTO word VALUES ('1d584d56a14a4a88a8c485535ee150bf','eternal','[i:ˈtə:nl]','http://res.iciba.com/resource/amp3/0/0/23/d3/23d368dd83af61660b188c71e3a22109.mp3','adj. 永久的；不朽的；没完没了的','','');----
INSERT INTO classwords VALUES ('b34933220b50414f8004d61a63ac96c1','1d584d56a14a4a88a8c485535ee150bf','12');----
INSERT INTO word VALUES ('538be7d095964ae893c018771519b77a','grope','[ɡrəup]','http://res.iciba.com/resource/amp3/0/0/be/4c/be4c9ed8c204a69f91bc43835ba3d31e.mp3','vi. 摸索，探寻','','');----
INSERT INTO classwords VALUES ('340ccbff382146649bbff1f0f365351a','538be7d095964ae893c018771519b77a','12');----
INSERT INTO word VALUES ('badd9164ad3f45a39ac1928540d3e3a7','admiration','[ˌædməˈreɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/79/3d/793d2940dc9fd33da3e0300390f70287.mp3','n. 钦佩；赞赏；羡慕','','');----
INSERT INTO classwords VALUES ('836b940a90174330be0f5921fcaef1a8','badd9164ad3f45a39ac1928540d3e3a7','12');----
INSERT INTO word VALUES ('8bd3b9d7f1154f838b5420f9f0c8518a','pregnant','[ˈpreɡnənt]','http://res.iciba.com/resource/amp3/oxford/0/0b/83/0b83b65756b624573506d2943a1638ff.mp3','adj. 怀孕的；意义深长的；耐人寻味的','','');----
INSERT INTO classwords VALUES ('082a668ecc39433480424002a000ec42','8bd3b9d7f1154f838b5420f9f0c8518a','12');----
INSERT INTO word VALUES ('ab13675767784494bf7f6f7b5417e2e4','interview','[ˈintəvju:]','http://res.iciba.com/resource/amp3/oxford/0/8a/2f/8a2f039c7418598f073c17c33cd19662.mp3','vt. 对…进行面试；采访，访谈；审讯','','');----
INSERT INTO classwords VALUES ('c03b986964714ce1bd50480b61b6f0ca','ab13675767784494bf7f6f7b5417e2e4','12');----
INSERT INTO word VALUES ('b17bacdfe2d34afd9afaf8f2232271a0','coefficient','[ˌkəʊəˈfɪʃənt]','http://res.iciba.com/resource/amp3/oxford/0/fb/da/fbdab7d9e332ea0806880825804cb35d.mp3','n. 协同因素；系数','','');----
INSERT INTO classwords VALUES ('a8d9224458364b16bd9cd9cdde0f6f2d','b17bacdfe2d34afd9afaf8f2232271a0','12');----
INSERT INTO word VALUES ('2c0404673dc24223916926d090caa344','marsh','[mɑːʃ]','http://res.iciba.com/resource/amp3/0/0/d3/ee/d3ee527baae384aad8ef4ba0e308da7c.mp3','n. 沼泽地，湿地','','');----
INSERT INTO classwords VALUES ('7cc9f6c77654449b9c25a6166dc0fd4a','2c0404673dc24223916926d090caa344','12');----
INSERT INTO word VALUES ('6db35108b331438b867fd669c7901218','gorgeous','[ˈɡɔ:dʒəs]','http://res.iciba.com/resource/amp3/0/0/c0/9d/c09d2644aa265a0b675c380b14fe0922.mp3','adj. 令人愉快的；漂亮的；绚丽的，华...','','');----
INSERT INTO classwords VALUES ('156ea472ee1b45b494286f1dc5b28bf0','6db35108b331438b867fd669c7901218','12');----
INSERT INTO word VALUES ('138fcf8b70b54291b71e6cab6104644a','ordinarily','[ˌɔ:dnˈeərəli:]','http://res.iciba.com/resource/amp3/0/0/95/5f/955fb6d3225b5ad542fb0388f64d2dbe.mp3','adv. 通常；正常情况下','','');----
INSERT INTO classwords VALUES ('41342c6bf6e64e48ab9e964ac7624ade','138fcf8b70b54291b71e6cab6104644a','12');----
INSERT INTO word VALUES ('9e4fadaf24de45b89f6ea64f704b650a','menace','[ˈmenəs]','http://res.iciba.com/resource/amp3/oxford/0/1f/69/1f69e9bae1ac8979736bd94ac0f419e8.mp3','vt.&vi. （进行）威胁，恐吓','','');----
INSERT INTO classwords VALUES ('2b2ed1f4ca5f46aeafb88d73b92ba142','9e4fadaf24de45b89f6ea64f704b650a','12');----
INSERT INTO word VALUES ('402bb89ff28a4e33a05fc7990b3091c5','overflow','[ˌəuvəˈfləu]','http://res.iciba.com/resource/amp3/0/0/0b/d9/0bd9f6dd716003f3818d15d2e211ee73.mp3','vt.&vi. 溢出，漫出；挤满；洋溢着','','');----
INSERT INTO classwords VALUES ('3d727b99d7b04e94b3137b9b122fbab1','402bb89ff28a4e33a05fc7990b3091c5','12');----
INSERT INTO word VALUES ('aad2f031d0e9402188cc2d166062dc29','fence','[fens]','http://res.iciba.com/resource/amp3/oxford/0/2d/8f/2d8f9a167f068f951e0daa7fc9570daa.mp3','vi. 击剑；围以栅栏','','');----
INSERT INTO classwords VALUES ('604def155d6f49489bc9e73663205922','aad2f031d0e9402188cc2d166062dc29','12');----
INSERT INTO word VALUES ('7c3997cfde2b4017ad454917f3219f48','complexity','[kəmˈpleksɪti:]','http://res.iciba.com/resource/amp3/oxford/0/0c/6c/0c6cceb419e1c1c056ee770031d019f9.mp3','n. 复杂（性），错综复杂','','');----
INSERT INTO classwords VALUES ('7510d88a12f54328b10b3487402bfe58','7c3997cfde2b4017ad454917f3219f48','12');----
INSERT INTO word VALUES ('3cb3389cfddf4758bae118071e62751d','identical','[aiˈdentikəl]','http://res.iciba.com/resource/amp3/oxford/0/e0/fd/e0fdc58d25895da8f1201a1e5c70b8d6.mp3','adj. 同一的；完全相同的','','');----
INSERT INTO classwords VALUES ('0bac471330724343a3730bae0c59012a','3cb3389cfddf4758bae118071e62751d','12');----
INSERT INTO word VALUES ('368bb6e93d874f0797f62206415b8787','scan','[skæn]','http://res.iciba.com/resource/amp3/oxford/0/4b/2b/4b2bec57fa648591e6f7638418dc7765.mp3','v. 浏览；察看；扫描','','');----
INSERT INTO classwords VALUES ('daef6ca133f64ccbbe10d7295cac55ec','368bb6e93d874f0797f62206415b8787','12');----
INSERT INTO word VALUES ('57f11b4cfe954811a6393754d143ca8e','pumpkin','[ˈpʌmpkin]','http://res.iciba.com/resource/amp3/oxford/0/7d/65/7d65d18f84e505ac9f73d9968c45783b.mp3','n. 南瓜','','');----
INSERT INTO classwords VALUES ('039d63ae022448488cc3831962fd4063','57f11b4cfe954811a6393754d143ca8e','12');----
INSERT INTO word VALUES ('74ee8183961e4bf884f876bde65f745e','resignation','[ˌrezɪgˈneɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/dc/82/dc82b4eeda0771b481f7d9cee1ce8444.mp3','n. 屈从，顺从；辞呈','','');----
INSERT INTO classwords VALUES ('5ad6ec4a553347c1b008a961ad23cd30','74ee8183961e4bf884f876bde65f745e','12');----
INSERT INTO word VALUES ('f815cf29bc6043cb8213f5d01dfa2fbf','predecessor','[ˈpri:disesə]','http://res.iciba.com/resource/amp3/oxford/0/4c/c4/4cc4206053690313d59fd13c11761a72.mp3','n. 前辈；前任；（物件、机器的）前身','','');----
INSERT INTO classwords VALUES ('6c3b26b5d9b6452882fa4151e26a4801','f815cf29bc6043cb8213f5d01dfa2fbf','12');----
INSERT INTO word VALUES ('edc04ed5d3af46c3855d4fdfdc5d37c8','partition','[pɑ:ˈtiʃən]','http://res.iciba.com/resource/amp3/oxford/0/c6/83/c683a8a0a7dd53bbd4015889fca185ca.mp3','n. 隔墙；隔断；分开','','');----
INSERT INTO classwords VALUES ('698bd43fe28048b39422d5589cb185fa','edc04ed5d3af46c3855d4fdfdc5d37c8','12');----
INSERT INTO word VALUES ('5b2aee986c7645909033b27058460ddd','oxide','[ˈɔksaid]','http://res.iciba.com/resource/amp3/oxford/0/4d/d3/4dd30bc7a9cd1a2f5722e3df04622ac0.mp3','n. 氧化物','','');----
INSERT INTO classwords VALUES ('6a696de2959346b0a3ee96827d22db79','5b2aee986c7645909033b27058460ddd','12');----
INSERT INTO word VALUES ('84c03eb2f5bb4cd18e88974f56e33325','diet','[ˈdaiət]','http://res.iciba.com/resource/amp3/oxford/0/9f/c8/9fc8d7ce9d79e82da24aa9d17204da9d.mp3','n. 饮食，食物；特别饮食','','');----
INSERT INTO classwords VALUES ('1dd8c8861f2c4dfbbb608ef3c0c0dcf3','84c03eb2f5bb4cd18e88974f56e33325','12');----
INSERT INTO word VALUES ('3e8ac0f1ee69418eb189a15fd65e83c8','weaver','[ˈwi:və]','http://res.iciba.com/resource/amp3/oxford/0/d5/55/d55592b694533f8abb634ad1ffd8ef2b.mp3','n. 织布工，编织者','','');----
INSERT INTO classwords VALUES ('c2051a30c7d24472abc58ffd3bc822a8','3e8ac0f1ee69418eb189a15fd65e83c8','12');----
INSERT INTO word VALUES ('aee40a154d4444ecbf3f093ccf190e22','electronics','[ilekˈtrɔniks]','http://res.iciba.com/resource/amp3/oxford/0/76/f1/76f1f6f9a404073c6e9a6275e1366e8d.mp3','n. 电子学；电子设备','','');----
INSERT INTO classwords VALUES ('bab328e09b9345f7861175036c5c42e7','aee40a154d4444ecbf3f093ccf190e22','12');----
INSERT INTO word VALUES ('5ea0fd0bb04640b2aa0b7e153b31c568','awful','[ˈɔ:ful]','http://res.iciba.com/resource/amp3/oxford/0/0c/d3/0cd3b353f11c3d768f8c0623041893e8.mp3','adj. 糟糕的；可怕的；生病的','','');----
INSERT INTO classwords VALUES ('ba2e2df976394f6a9f1e7f9eedce93e8','5ea0fd0bb04640b2aa0b7e153b31c568','12');----
INSERT INTO word VALUES ('cfc0864808074fed9c1e8d4ba45e5e4c','rigorous','[ˈriɡərəs]','http://res.iciba.com/resource/amp3/oxford/0/c2/fb/c2fba634ebc437571b94560f8c8ebaf0.mp3','adj. 严格的，严密的；一丝不苟的','','');----
INSERT INTO classwords VALUES ('669bc4a321c344cf94cb268cc601caba','cfc0864808074fed9c1e8d4ba45e5e4c','12');----
INSERT INTO word VALUES ('adab63ae37004248be4a0f0094b52603','forum','[ˈfɔ:rəm]','http://res.iciba.com/resource/amp3/oxford/0/17/e9/17e900ac6c204c8ab08678ad09ed3f1f.mp3','n. 论坛，讨论会','','');----
INSERT INTO classwords VALUES ('02cddd71c14d4ad1b627351e962a1f29','adab63ae37004248be4a0f0094b52603','12');----
INSERT INTO word VALUES ('5241d31d7c4248dfa524f259274ad381','overtake','[ˌəuvəˈteik]','http://res.iciba.com/resource/amp3/oxford/0/1e/ce/1ece42336a8cdd614066da26629601e6.mp3','vt. 突然袭击；压倒；赶上','','');----
INSERT INTO classwords VALUES ('a2ef6aa85c944dd9b8ec2f1e64ee7139','5241d31d7c4248dfa524f259274ad381','12');----
INSERT INTO word VALUES ('9291131ae84741479b87640228ebb91b','bestow','[biˈstəu]','http://res.iciba.com/resource/amp3/0/0/74/c7/74c73672556fec45b14bb1009a192980.mp3','vt. 给予；赠与；授予','','');----
INSERT INTO classwords VALUES ('af129419cfe44efca76ea61bd351ef6a','9291131ae84741479b87640228ebb91b','12');----
INSERT INTO word VALUES ('7dc0b33dbe434a9db8d295022d467f0f','regiment','[ˈredʒimənt]','http://res.iciba.com/resource/amp3/oxford/0/a1/9d/a19d4fba37cd6123cc89e250a45bd020.mp3','n. （军队的）团；一大群','','');----
INSERT INTO classwords VALUES ('aefcdc2716b8451e9445ec530db27588','7dc0b33dbe434a9db8d295022d467f0f','12');----
INSERT INTO word VALUES ('839ab190b9e24b95959ce5d310a34329','literary','[ˈlitərəri]','http://res.iciba.com/resource/amp3/oxford/0/03/0e/030e4f3ff0093b26b9bdadfadc0873d0.mp3','adj. 精通文学的；文学上的','','');----
INSERT INTO classwords VALUES ('f22c366d4789450186cd9209a27bd1a9','839ab190b9e24b95959ce5d310a34329','12');----
INSERT INTO word VALUES ('466ce67a7c624ffe86065e596eda0ef5','bend','[bend]','http://res.iciba.com/resource/amp3/oxford/0/70/18/70188b9c33428496949de235ddab2ae4.mp3','vi. 弯腰；屈从','','');----
INSERT INTO classwords VALUES ('21f825fb833e46468d1f0e03dd3a654a','466ce67a7c624ffe86065e596eda0ef5','12');----
INSERT INTO word VALUES ('8fa2ee1b2e5d4dbc94310559b9625c4c','courtesy','[ˈkə:tisi]','http://res.iciba.com/resource/amp3/oxford/0/62/9a/629abb98cee89d706a67604765cabca6.mp3','n. 礼貌，谦恭，彬彬有礼','','');----
INSERT INTO classwords VALUES ('9ec452e11ca6406ca4a2351091a21d77','8fa2ee1b2e5d4dbc94310559b9625c4c','12');----
INSERT INTO word VALUES ('815d8a0a990f4b8b9d099ff7a1a7c7c4','trigger','[ˈtriɡə]','http://res.iciba.com/resource/amp3/oxford/0/59/6a/596a96236ec430bc2a8190a6fd1edacf.mp3','vt. 触发；引爆；引起','','');----
INSERT INTO classwords VALUES ('fc9728338da14f16bf2c53874ba98f80','815d8a0a990f4b8b9d099ff7a1a7c7c4','12');----
INSERT INTO word VALUES ('c94c7646eb9b4b7b908d90a62bed2fba','onward(s)','','','adj. 向前的','','');----
INSERT INTO classwords VALUES ('8d5e099ecb154fb0b9c56eb4e2056f5f','c94c7646eb9b4b7b908d90a62bed2fba','12');----
INSERT INTO word VALUES ('f3e69d90506f40f3af9c930bd37d6a8f','subscript','[ˈsʌbˌskrɪpt]','http://res.iciba.com/resource/amp3/0/0/87/96/8796114e5be2cd5eb900e81d6b20cf9c.mp3','n. 下标','','');----
INSERT INTO classwords VALUES ('3c5d43f3aa814e55a83c2be12d595566','f3e69d90506f40f3af9c930bd37d6a8f','12');----
INSERT INTO word VALUES ('b2140d4e9bdb47da8602cee460f2d02a','filter','[ˈfiltə]','http://res.iciba.com/resource/amp3/oxford/0/0d/cc/0dcc43075c283dff6dc56ed89f5df5ca.mp3','vi. 过滤；透过；（消息等）走漏，慢慢...','','');----
INSERT INTO classwords VALUES ('d93b7219ca5f491d90afe7d0893a4307','b2140d4e9bdb47da8602cee460f2d02a','12');----
INSERT INTO word VALUES ('b8db8d3d1dd14fa4a54017fda0333783','further','[ˈfə:ðə]','http://res.iciba.com/resource/amp3/oxford/0/f5/ba/f5babd85c0aad047cf309a21551e7d59.mp3','vt. 增进；促进；推进','','');----
INSERT INTO classwords VALUES ('658f555f96914f36bad2026768073b83','b8db8d3d1dd14fa4a54017fda0333783','12');----
INSERT INTO word VALUES ('0c978d7b9d494e76858d83db76401832','correlation','[ˌkɔ:rəˈleɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/6a/08/6a08fab11ff024d35ce1b046c8597078.mp3','n. 关联；联系','','');----
INSERT INTO classwords VALUES ('163e2e61504644eb879a0c361f090a75','0c978d7b9d494e76858d83db76401832','12');----
INSERT INTO word VALUES ('a61f30ed43ba4a9581adb021b379e45c','indulge','[inˈdʌldʒ]','http://res.iciba.com/resource/amp3/oxford/0/39/72/39724745afe3b882f4b1695fa19781bc.mp3','vi. 纵容；娇惯','','');----
INSERT INTO classwords VALUES ('cac80fc5baf34c3db0a777d0ed8270b9','a61f30ed43ba4a9581adb021b379e45c','12');----
INSERT INTO word VALUES ('97d89572a2d044448a8007166a1e7d2b','granite','[ˈɡrænit]','http://res.iciba.com/resource/amp3/oxford/0/43/ae/43aee86b9227a85e788998d3a0707cee.mp3','n. 花岗岩，花岗石','','');----
INSERT INTO classwords VALUES ('ee160b58c29e4a4e90d7338757a6e24b','97d89572a2d044448a8007166a1e7d2b','12');----
INSERT INTO word VALUES ('e8afaf4fcc0149558a928ad3a9fdbc87','fall','[fɔ:l]','http://res.iciba.com/resource/amp3/oxford/0/7c/df/7cdf55e8ff1bd93a411ab852bb0e4a2c.mp3','vi. 落下；摔倒；（数量）减少；（价值...','','');----
INSERT INTO classwords VALUES ('b0d733f8dab04dd3a47519dcfc3088b2','e8afaf4fcc0149558a928ad3a9fdbc87','12');----
INSERT INTO word VALUES ('a56940eb0c304d0d8e7513d4ddec3fa4','bacon','[ˈbeikən]','http://res.iciba.com/resource/amp3/oxford/0/04/48/0448a32549bfbdf04c56f2ad132662ae.mp3','n. 咸猪肉，熏猪肉；培根','','');----
INSERT INTO classwords VALUES ('5f75dd5883fc4d309a8fc6e3306ea3f4','a56940eb0c304d0d8e7513d4ddec3fa4','12');----
INSERT INTO word VALUES ('69d2f078f908498badb1297568213c46','wag','[wæɡ]','http://res.iciba.com/resource/amp3/oxford/0/3d/af/3daf7b9d36cc5bdac80fc13b169267d7.mp3','vt. 摇摆，摇动；摇晃手指','','');----
INSERT INTO classwords VALUES ('623d8735ca7242e0932e97a80806f765','69d2f078f908498badb1297568213c46','12');----
INSERT INTO word VALUES ('ef059f38d06342ada629f6a60434088b','token','[ˈtəukən]','http://res.iciba.com/resource/amp3/oxford/0/b0/00/b000a765389dfed798d04c9db92c5bb1.mp3','n. 记号；礼券，代金券；辅币；表示，证...','','');----
INSERT INTO classwords VALUES ('aa7d418e6c9f4c08a53c5d2f7113f71e','ef059f38d06342ada629f6a60434088b','12');----
INSERT INTO word VALUES ('0410b834eaa24212875f6ae896089c19','jewellery','[ˈdʒuːəlri]','http://res.iciba.com/resource/amp3/oxford/0/07/58/07583cc5c7b2c874a910ddee26e33c72.mp3','n. 珠宝，首饰','','');----
INSERT INTO classwords VALUES ('92d9633c9fc44dde86f18461adc62770','0410b834eaa24212875f6ae896089c19','12');----
INSERT INTO word VALUES ('34de92b8fbf94b69b7026fe042c1e8e3','photoelectric','[ˌfəʊtəʊɪˈlektrɪk]','http://res.iciba.com/resource/amp3/oxford/0/da/39/da399763baed010fb58c773367139b4d.mp3','adj. 光电的','','');----
INSERT INTO classwords VALUES ('de9323ee082541599406c5ab1a2b0646','34de92b8fbf94b69b7026fe042c1e8e3','12');----
INSERT INTO word VALUES ('b83184ffca92404597aa0f1b9b931027','deflection','[dɪˈflekʃən]','http://res.iciba.com/resource/amp3/oxford/0/8a/d7/8ad730d80d7a33057048494ef2c737dc.mp3','n. 偏斜，偏转','','');----
INSERT INTO classwords VALUES ('085913a98a774a92a7ac70322034c02b','b83184ffca92404597aa0f1b9b931027','12');----
INSERT INTO word VALUES ('6955a2c87cc846bbb696e653837009f5','sheer','[ʃiə]','http://res.iciba.com/resource/amp3/0/0/af/a0/afa05a6348902c252ae10d48879826b3.mp3','adj. 纯粹的；陡峭的；极薄的','','');----
INSERT INTO classwords VALUES ('d9300bc99b0a4ba6b5bdc7b0b44fb306','6955a2c87cc846bbb696e653837009f5','12');----
INSERT INTO word VALUES ('59b829f0c6e74815a208208ad9b41e68','pest','[pest]','http://res.iciba.com/resource/amp3/oxford/0/c1/ef/c1efbd20c3fc0b07e9a13b19d0f97aad.mp3','n. 害虫；讨厌鬼','','');----
INSERT INTO classwords VALUES ('35276362d2124a1cb44db2707672b374','59b829f0c6e74815a208208ad9b41e68','12');----
INSERT INTO word VALUES ('85626f47417a46cfa39b59fa7e23cfbd','satisfaction','[ˌsætisˈfækʃən]','http://res.iciba.com/resource/amp3/oxford/0/fb/f4/fbf4f88adcf69ceea8f7aaeb59f6d9bb.mp3','n. 满足，满意；赔偿，补偿','','');----
INSERT INTO classwords VALUES ('d4fea6c0110a4f44ad3a9afcca069760','85626f47417a46cfa39b59fa7e23cfbd','12');----
INSERT INTO word VALUES ('c5212cddc72a41528abd464106a6494b','contend','[kənˈtend]','http://res.iciba.com/resource/amp3/oxford/0/83/bc/83bcff839b3145bb44e0224e7134c029.mp3','vt. 声称；主张','','');----
INSERT INTO classwords VALUES ('a0406eb09070443790d491b2e20f1ee4','c5212cddc72a41528abd464106a6494b','12');----
INSERT INTO word VALUES ('3bd6ac590bb445fcae92e6d2c7472bb4','hurl','[hə:l]','http://res.iciba.com/resource/amp3/0/0/8c/8f/8c8fa00e9cc080fe7d8a08974c7c5299.mp3','vi. 猛投','','');----
INSERT INTO classwords VALUES ('4d90ab7712774e8a88e94af19bc6efd4','3bd6ac590bb445fcae92e6d2c7472bb4','12');----
INSERT INTO word VALUES ('bbab45371b304b9393ed7556e41ff382','olive','[ˈɔliv]','http://res.iciba.com/resource/amp3/0/0/f4/31/f431b0eea3c08186ed101e588bfb3a2f.mp3','n. 橄榄；橄榄树；橄榄色','','');----
INSERT INTO classwords VALUES ('0cacfeab8a5c4359bbb55a56bbb6ad21','bbab45371b304b9393ed7556e41ff382','12');----
INSERT INTO word VALUES ('a6384a0805134c32a05aec947bd2fd31','slack','[slæk]','http://res.iciba.com/resource/amp3/oxford/0/74/ab/74abaa181ed808095f27aac04c07a942.mp3','adj. 萧条的，不景气的；懈怠的；松弛...','','');----
INSERT INTO classwords VALUES ('621d1ea00aa94fac8243f8bf78cb084e','a6384a0805134c32a05aec947bd2fd31','12');----
INSERT INTO word VALUES ('31d9c3819e7e40e2a03f21d87b031c1b','axis','[ˈæksis]','http://res.iciba.com/resource/amp3/oxford/0/b9/71/b971063e4f4caa56f8c7dca47995e386.mp3','n. 轴，轴线','','');----
INSERT INTO classwords VALUES ('dfe9043ddc734434b8d5f96047a63054','31d9c3819e7e40e2a03f21d87b031c1b','12');----
INSERT INTO word VALUES ('9b8efbf4a0984af09de0dbf978b75821','worship','[ˈwə:ʃip]','http://res.iciba.com/resource/amp3/0/0/f7/b0/f7b0e354b768a2e09b31aa55744ef613.mp3','vi. 做礼拜','','');----
INSERT INTO classwords VALUES ('dd4134d6a4f04d59960a4806c0705041','9b8efbf4a0984af09de0dbf978b75821','12');----
INSERT INTO word VALUES ('9331c8e4fff14885895769dc9f1d4783','neutron','[ˈnu:ˌtrɔn]','http://res.iciba.com/resource/amp3/0/0/e9/00/e900a9020bbb5db562fe3b148873a78d.mp3','n. 中子','','');----
INSERT INTO classwords VALUES ('85fdfcc641f14e9ba611af957e9b07d9','9331c8e4fff14885895769dc9f1d4783','12');----
INSERT INTO word VALUES ('40e1dba3f8884e319c3e3255e4f496b5','sitting-room','[ˈsɪtɪŋru:m]','http://res.iciba.com/resource/amp3/1/0/4b/65/4b65bdea83be15c65274cd4145730b47.mp3','n. 起居室，客厅','','');----
INSERT INTO classwords VALUES ('0650dabf68d44dd5854e72af925366f6','40e1dba3f8884e319c3e3255e4f496b5','12');----
INSERT INTO word VALUES ('3455ac37e32e484787e21ae874004a1b','solo','[ˈsəuləu]','http://res.iciba.com/resource/amp3/0/0/56/53/5653c6b1f51852a6351ec69c8452abc6.mp3','n. 独唱，独奏','','');----
INSERT INTO classwords VALUES ('775c81e1ed88405dbc2f09727175f6de','3455ac37e32e484787e21ae874004a1b','12');----
INSERT INTO word VALUES ('89d4244461a641f199844c7a8e4fa9d3','shade','[ʃeid]','http://res.iciba.com/resource/amp3/oxford/0/4b/97/4b979ac555eeab38bfc8ab3cf4ae193e.mp3','n. （色彩的）浓淡，深浅；阴凉处；（绘...','','');----
INSERT INTO classwords VALUES ('ce119c9c1e474d379558f60deeb23606','89d4244461a641f199844c7a8e4fa9d3','12');----
INSERT INTO word VALUES ('b51e72c9d8e14c75bf1086def746b80f','enclosure','[inˈkləuʒə]','http://res.iciba.com/resource/amp3/oxford/0/10/3d/103db2042d4bbbb963fa6615f5eff169.mp3','n. 围绕；围场，圈占地；附件','','');----
INSERT INTO classwords VALUES ('4d3874b6922045989f6311933c655e47','b51e72c9d8e14c75bf1086def746b80f','12');----
INSERT INTO word VALUES ('1a361a87df3c44988524175a6f2434ba','thrifty','[ˈθrɪfti:]','http://res.iciba.com/resource/amp3/oxford/0/e4/28/e428f1a4c1258746f0d724ba38cae95e.mp3','adj. 节俭的；茂盛的','','');----
INSERT INTO classwords VALUES ('cf70993f1f8e4ce2be9e57215c7b301e','1a361a87df3c44988524175a6f2434ba','12');----
INSERT INTO word VALUES ('cc698945e3d74cdcb050056dff2413eb','detector','[dɪˈtektə]','http://res.iciba.com/resource/amp3/oxford/0/01/31/0131ca74fb911391ab65bf99c7d08dc9.mp3','n. 探测器，检测仪','','');----
INSERT INTO classwords VALUES ('9a95192e4d994ea584360e54d7c5b589','cc698945e3d74cdcb050056dff2413eb','12');----
INSERT INTO word VALUES ('38159ed466984c0da8a0d104a3db73f8','subtle','[ˈsʌtl]','http://res.iciba.com/resource/amp3/oxford/0/9d/7d/9d7dbb70555075ada1834d56c4566414.mp3','adj. 微妙的；机巧的；清淡的','','');----
INSERT INTO classwords VALUES ('207600b072cd4cb9a1801efdbb28593d','38159ed466984c0da8a0d104a3db73f8','12');----
INSERT INTO word VALUES ('6bbeec7f9b7145c6b45c04917c11a260','diminish','[diˈminiʃ]','http://res.iciba.com/resource/amp3/oxford/0/9f/f5/9ff58f7335c018a273142f5a765a300a.mp3','vt. 减少，减弱；贬低','','');----
INSERT INTO classwords VALUES ('9f30732667e442119b342d9fc6380e37','6bbeec7f9b7145c6b45c04917c11a260','12');----
INSERT INTO word VALUES ('93979d7599134c1e8602df4704258a18','possibility','[ˌpɔsəˈbiliti]','http://res.iciba.com/resource/amp3/oxford/0/dc/98/dc98552bc73795832065b8ec4e1395f5.mp3','n. 可能的事；可能性','','');----
INSERT INTO classwords VALUES ('e6765db991134992b145e9a3c7b0bcad','93979d7599134c1e8602df4704258a18','12');----
INSERT INTO word VALUES ('cb64800570cf427f8b004b5e40e3a382','integral','[ˈintiɡrəl]','http://res.iciba.com/resource/amp3/oxford/0/54/7b/547bc513a8ad3328dc6d5ee0e563e45d.mp3','adj. 基本的；构成整体所必需的','','');----
INSERT INTO classwords VALUES ('362e2fe81c7d4b60b9b0eb0f55cbf360','cb64800570cf427f8b004b5e40e3a382','12');----
INSERT INTO word VALUES ('55f5695c0f4f4cd09d02ae9bb2de8e4b','wasp','[wɔsp]','http://res.iciba.com/resource/amp3/0/0/96/f3/96f303a127451b47c693499d271871d4.mp3','n. 黄蜂','','');----
INSERT INTO classwords VALUES ('8ddaba3aa71b43d7b823af75fa82a85b','55f5695c0f4f4cd09d02ae9bb2de8e4b','12');----
INSERT INTO word VALUES ('4b63e7ba32be4cc983ee56e298a9b274','interface','[ˈintəfeis]','http://res.iciba.com/resource/amp3/oxford/0/98/72/9872347fd26018fa1488df6e9fbb6f4b.mp3','n. 界面；[机]接口','','');----
INSERT INTO classwords VALUES ('9fa9859cbff04032989d068f69ae6861','4b63e7ba32be4cc983ee56e298a9b274','12');----
INSERT INTO word VALUES ('a6a04944c29a4261a52068b85d3ea775','vicinity','[viˈsiniti]','http://res.iciba.com/resource/amp3/oxford/0/1a/03/1a03c483a3a415c1946dd0d8f6d2cc46.mp3','n. 邻近；附近地区','','');----
INSERT INTO classwords VALUES ('d377b94337994f2a8d7d5f4feb9e3dfe','a6a04944c29a4261a52068b85d3ea775','12');----
INSERT INTO word VALUES ('29ddab8ef6a340b59a6ef219a8c524ed','displacement','[dɪsˈpleɪsmənt]','http://res.iciba.com/resource/amp3/oxford/0/3e/37/3e3733d1e093dc97f6b706e8d234b2e3.mp3','n. 取代，代替；免职；迫使背井离乡','','');----
INSERT INTO classwords VALUES ('9600d304c1d14070a6610fbc77abd25d','29ddab8ef6a340b59a6ef219a8c524ed','12');----
INSERT INTO word VALUES ('f4cb78a81f6045a0ab6e6a6595cd371a','accessory','[ækˈsesəri]','http://res.iciba.com/resource/amp3/oxford/0/03/23/03238b532e20a2451c3ed9118812e1bb.mp3','adj. 附属的；同谋的','','');----
INSERT INTO classwords VALUES ('8742e4eee3e3461d82c54f67ecf6a638','f4cb78a81f6045a0ab6e6a6595cd371a','12');----
INSERT INTO word VALUES ('6b50b5ce2df0471983d84387cd3bcf9e','denounce','[diˈnauns]','http://res.iciba.com/resource/amp3/oxford/0/ff/b5/ffb5ee6276f343fca52a9515c2b42897.mp3','vt. 谴责，痛斥；告发','','');----
INSERT INTO classwords VALUES ('81b9ccdd1d084db79319ca6bd72d5865','6b50b5ce2df0471983d84387cd3bcf9e','12');----
INSERT INTO word VALUES ('1eda32f8e5304267bdd4e1deccbf8e41','impose','[imˈpəuz]','http://res.iciba.com/resource/amp3/0/0/e6/3a/e63a60ca2d1051f3fcb9c59419b38c60.mp3','vt. 强加；使承受；使打扰','','');----
INSERT INTO classwords VALUES ('f35c0eee2eac4639b39f50050eebfdea','1eda32f8e5304267bdd4e1deccbf8e41','12');----
INSERT INTO word VALUES ('d4f32ec755f84c6b93a9715554315349','reign','[rein]','http://res.iciba.com/resource/amp3/oxford/0/87/fd/87fd6d645ee9c275fab31c5aed6fcec7.mp3','v. 占优势，盛行；统治，治理；主宰','','');----
INSERT INTO classwords VALUES ('f405a4fb0e21455382736a9cc62c8e36','d4f32ec755f84c6b93a9715554315349','12');----
INSERT INTO word VALUES ('578628d0706f49228775614ae62e3a02','electrician','[ilekˈtriʃən]','http://res.iciba.com/resource/amp3/oxford/0/88/b2/88b23153d87b74e86a8a362bba4adabe.mp3','n. 电工，电气技师','','');----
INSERT INTO classwords VALUES ('44e5432f62cc4e5482c8c81b337d8612','578628d0706f49228775614ae62e3a02','12');----
INSERT INTO word VALUES ('07b0d90332784d0181611fd1552cb474','traverse','[ˈtrævəs]','http://res.iciba.com/resource/amp3/oxford/0/ba/b3/bab3edd87d27d8fad089f0f5bd3a8534.mp3','vt. 横越，横穿，穿过','','');----
INSERT INTO classwords VALUES ('89f31e446d9e4ac08e76e49ed40232de','07b0d90332784d0181611fd1552cb474','12');----
INSERT INTO word VALUES ('123e976316d649e1942028791ded387b','row','[rəu]','http://res.iciba.com/resource/amp3/oxford/0/1b/5b/1b5b1a4a0677501aaa92a5eb666b557a.mp3','n. 严重分歧；争吵；吵闹','','');----
INSERT INTO classwords VALUES ('c0e6f8aa7fcc432e80fe1b0d4d4e6d59','123e976316d649e1942028791ded387b','12');----
INSERT INTO word VALUES ('5c2d86652a8045cfaa884f9cc99bfde0','acknowledge','[əkˈnɔlidʒ]','http://res.iciba.com/resource/amp3/oxford/0/40/f1/40f11b8dce2228348f379f34ba469974.mp3','vt. 承认；告知收到；公认；表示感谢','','');----
INSERT INTO classwords VALUES ('da8d793633c74549b7d152178519c934','5c2d86652a8045cfaa884f9cc99bfde0','12');----
INSERT INTO word VALUES ('bf5b699926db46faa9a7d4c971724471','cherish','[ˈtʃeriʃ]','http://res.iciba.com/resource/amp3/oxford/0/01/5d/015de71bf14bf7794d79fd0385452023.mp3','vt. 珍爱；怀有','','');----
INSERT INTO classwords VALUES ('9e85b792eec84d918c60b49907bc30aa','bf5b699926db46faa9a7d4c971724471','12');----
INSERT INTO word VALUES ('9a11215252d4490284645e7317cf4a8e','windmill','[ˈwɪndˌmɪl]','http://res.iciba.com/resource/amp3/oxford/0/71/e8/71e8ff477fee302d5253146b409b2fff.mp3','n. 风车','','');----
INSERT INTO classwords VALUES ('8ad5345f40524924a86f7f990deb3629','9a11215252d4490284645e7317cf4a8e','12');----
INSERT INTO word VALUES ('db263fe39c3744d286cd95c59bd84499','bachelor','[ˈbætʃələ]','http://res.iciba.com/resource/amp3/oxford/0/c3/fe/c3fee2668d6fb3d3b94c16dcafc17160.mp3','n. 单身汉；学士','','');----
INSERT INTO classwords VALUES ('abf0a9c35cc345b0b639711849a7f811','db263fe39c3744d286cd95c59bd84499','12');----
INSERT INTO word VALUES ('1e5b803a524048fc97888119f408d60c','hard','[hɑrd]','http://res.iciba.com/resource/amp3/0/0/d6/4a/d64a84456adc959f56de6af685d0dadd.mp3','adj. 坚硬的；困难的；努力的','','');----
INSERT INTO classwords VALUES ('53d6759d3d834014a676ccd12b60f27b','1e5b803a524048fc97888119f408d60c','12');----
INSERT INTO word VALUES ('8fc64029bf5f4bccb69dc383377cf25f','ingredient','[inˈɡri:djənt]','http://res.iciba.com/resource/amp3/oxford/0/33/90/3390a209219b1166ed720964f1ddb94d.mp3','n. 配料，成分；要素；因素','','');----
INSERT INTO classwords VALUES ('19aaeea67d2b4d26b4fe651a8462a420','8fc64029bf5f4bccb69dc383377cf25f','12');----
INSERT INTO word VALUES ('219e9373e35b4295b8fb30b48160948f','shatter','[ˈʃætə]','http://res.iciba.com/resource/amp3/oxford/0/75/ed/75edd8f0031d80db7d01cb851c47e54e.mp3','vt. 使粉碎，使破碎；使破灭；使受到极...','','');----
INSERT INTO classwords VALUES ('23ca0b66e38a4cf2b3554e24550650eb','219e9373e35b4295b8fb30b48160948f','12');----
INSERT INTO word VALUES ('016dfcf9105748bfab79cbb423387163','drama','[ˈdrɑ:mə]','http://res.iciba.com/resource/amp3/oxford/0/a4/f7/a4f7cfb288cf51a2023c0f6fcd3c15f7.mp3','n. 戏剧性事件；戏剧','','');----
INSERT INTO classwords VALUES ('0da8da6996c94d8fbe8e8defac2b852a','016dfcf9105748bfab79cbb423387163','12');----
INSERT INTO word VALUES ('a7c1d5c6791140e38b94325591f96915','framework','[ˈfreimwə:k]','http://res.iciba.com/resource/amp3/oxford/0/34/2b/342bd7e66b2355a893a82ee343a89c08.mp3','n. 体系，体制；框架，构架','','');----
INSERT INTO classwords VALUES ('afa308608d2e4a6e99607565feeb8b20','a7c1d5c6791140e38b94325591f96915','12');----
INSERT INTO word VALUES ('bcf5fffb377c4315a9bb4160dc4a30a0','paralyse','[ˈpærəlaiz]','http://res.iciba.com/resource/amp3/oxford/0/55/26/55268a8983b0fdd9116e94699ef08564.mp3','vt. 使麻痹，使瘫痪；使无法正常运转','','');----
INSERT INTO classwords VALUES ('28ef30d1708c4b5db6b0c1417fe4412b','bcf5fffb377c4315a9bb4160dc4a30a0','12');----
INSERT INTO word VALUES ('b81af6de1f90427187ba50be70014aac','summary','[ˈsʌməri]','http://res.iciba.com/resource/amp3/oxford/0/31/0a/310a5ed681c355b39560aae99cf14001.mp3','adj. 概括的；速决的','','');----
INSERT INTO classwords VALUES ('b8c38a9e67a9422cbc84cc7e8ba5572d','b81af6de1f90427187ba50be70014aac','12');----
INSERT INTO word VALUES ('8a7d443096624a9e8d2a5591887dc994','denial','[diˈnaiəl]','http://res.iciba.com/resource/amp3/oxford/0/93/bb/93bb7dcb86a7a95f23d171ce6a8c92fd.mp3','n. 否认；拒绝；拒绝接受','','');----
INSERT INTO classwords VALUES ('b4dd799743814a97a574cb7fad0499f2','8a7d443096624a9e8d2a5591887dc994','12');----
INSERT INTO word VALUES ('ce33a1ce12cb45e5a6b76f9c2a1f1197','accord','[əˈkɔ:d]','http://res.iciba.com/resource/amp3/0/0/17/ee/17eec3190b081a1c237f673f39d821a9.mp3','n. 一致，符合；协议','','');----
INSERT INTO classwords VALUES ('0397129f77524ff9aa83fd7e779c9417','ce33a1ce12cb45e5a6b76f9c2a1f1197','12');----
INSERT INTO word VALUES ('45d5db26b87d4d118c4fa9b5ad9d39a8','audience','[ˈɔ:djəns]','http://res.iciba.com/resource/amp3/oxford/0/0c/a8/0ca87bf1c996071ffc5099845a9fb179.mp3','n. 正式会见；听众；读者','','');----
INSERT INTO classwords VALUES ('27f56eb91bf14006b59fb61cf64bd30c','45d5db26b87d4d118c4fa9b5ad9d39a8','12');----
INSERT INTO word VALUES ('f91d03b0d4274002b71364af08cb7dfb','uniformly','[ju:nɪfɔ:mlɪ]','http://res.iciba.com/resource/amp3/0/0/b3/0e/b30eb0771c2ee2f1b32c0d1c6dc62739.mp3','adv. 相同地；一致地','','');----
INSERT INTO classwords VALUES ('43e923ffe8a64c9d86d54719a11c4fca','f91d03b0d4274002b71364af08cb7dfb','12');----
INSERT INTO word VALUES ('91da4a778c2f4db591e921bade721e5e','thoughtless','[ˈθɔ:tlɪs]','http://res.iciba.com/resource/amp3/oxford/0/ce/af/ceaf13ab004a7ef7719c5480d6e16875.mp3','adj. 粗心的；欠考虑的；自私的','','');----
INSERT INTO classwords VALUES ('5164356ccaae42bf8149c0178de30440','91da4a778c2f4db591e921bade721e5e','12');----
INSERT INTO word VALUES ('858fdfd6fc32411781d4444c241ac5d3','irrespective','[ˌɪrisˈpektiv]','http://res.iciba.com/resource/amp3/0/0/9e/d8/9ed893e8274bc2a1cb450bdbbb36173b.mp3','adj. 不考虑的，不顾的','','');----
INSERT INTO classwords VALUES ('c403d45b448447dea02c1a3386afcf1f','858fdfd6fc32411781d4444c241ac5d3','12');----
INSERT INTO word VALUES ('ccc68347ec654591b992b1f69921830f','glider','[ˈglaɪdə]','http://res.iciba.com/resource/amp3/oxford/0/22/d9/22d95c95178e7f2eb9374867475d5030.mp3','n. 滑翔机','','');----
INSERT INTO classwords VALUES ('243d491fda784fc488abe38ca63bc56e','ccc68347ec654591b992b1f69921830f','12');----
INSERT INTO word VALUES ('c54634db6dda4f35970d2aaf22e33431','tack','[tæk]','http://res.iciba.com/resource/amp3/oxford/0/c7/a0/c7a0a8fbff5207058dc3ee74e6e5f689.mp3','vt. 用大头钉固定；曲折航行；（用大针...','','');----
INSERT INTO classwords VALUES ('5a741a562f734361967f74d4587b2210','c54634db6dda4f35970d2aaf22e33431','12');----
INSERT INTO word VALUES ('6bed697b5c8a4b30ac45a6ba0dcd81d1','answer','[ˈɑ:nsə]','http://res.iciba.com/resource/amp3/oxford/0/3d/bd/3dbd39fd78f5d7acfcaa31d6153ad531.mp3','vi. 回答，答复；回信；接电话；解答；...','','');----
INSERT INTO classwords VALUES ('c01b9153176145718562a6e19ab1b193','6bed697b5c8a4b30ac45a6ba0dcd81d1','12');----
INSERT INTO word VALUES ('d4f73e7e0e2741fabd9971bb832b9c5c','linear','[ˈlɪniə(r)]','http://res.iciba.com/resource/amp3/oxford/0/1d/bf/1dbf8e8dbaba3083796a281482e3c477.mp3','adj. 线性的；长度的','','');----
INSERT INTO classwords VALUES ('db5cc246d7da4c5b8dfb24b210f01a4e','d4f73e7e0e2741fabd9971bb832b9c5c','12');----
INSERT INTO word VALUES ('805d97f4662d48f5a20acc5f97d9aded','propeller','[prəˈpelə]','http://res.iciba.com/resource/amp3/oxford/0/0e/cf/0ecf96b7e407d1f7e3f5691b8c583ec4.mp3','n. 螺旋桨，推进器','','');----
INSERT INTO classwords VALUES ('a87061802161417f84e1363d52de10a8','805d97f4662d48f5a20acc5f97d9aded','12');----
INSERT INTO word VALUES ('8402c95cc1834e6aaf004b1772703869','rattle','[ˈrætl]','http://res.iciba.com/resource/amp3/oxford/0/dc/d2/dcd2a5470e52da58980fcabc2222ef96.mp3','vt. （使）发出震颤声；发出格格声；使...','','');----
INSERT INTO classwords VALUES ('14f5f4ba230f47f5b31e7ba55c23812b','8402c95cc1834e6aaf004b1772703869','12');----
INSERT INTO word VALUES ('355667e06a7146d485a10e56bd58d600','dismay','[disˈmei]','http://res.iciba.com/resource/amp3/oxford/0/78/01/780189ec22bd7fae0671a70e1866a88c.mp3','n. 惊恐；焦虑；哀伤','','');----
INSERT INTO classwords VALUES ('33dd6d624318407c932be04c1a46766c','355667e06a7146d485a10e56bd58d600','12');----
INSERT INTO word VALUES ('0065cbccee7b4825a6cea62524e7f68f','surpass','[səˈpɑ:s]','http://res.iciba.com/resource/amp3/0/0/f1/3e/f13e9f71d7ecbc24ac9bbfa39812a751.mp3','vt. 超过；超出','','');----
INSERT INTO classwords VALUES ('c427386d62654ca8b4094f69cb61d011','0065cbccee7b4825a6cea62524e7f68f','12');----
INSERT INTO word VALUES ('71418262bd7641c4b6dbcea66e678c7c','grim','[ɡrim]','http://res.iciba.com/resource/amp3/oxford/0/e3/1d/e31dc53bd30dec4a14a38dd6bd192e6b.mp3','adj. 严峻的；阴森的；严肃的；糟糕的','','');----
INSERT INTO classwords VALUES ('0427a47bb1f84584a14647ba4d35d5de','71418262bd7641c4b6dbcea66e678c7c','12');----
INSERT INTO word VALUES ('6e844c39cc464ae488ba521efee4f7d2','antarctic','[ænˈtɑ:ktɪk]','http://res.iciba.com/resource/amp3/0/0/3a/43/3a434ab8c1defd95e0d238f4fc9a3c1d.mp3','n. 南极洲','','');----
INSERT INTO classwords VALUES ('b1cc29d57ff14acdbbecb7dd86491be4','6e844c39cc464ae488ba521efee4f7d2','12');----
INSERT INTO word VALUES ('881110e2d3be429a88c0bc7ee2456b74','end','[end]','http://res.iciba.com/resource/amp3/oxford/0/c4/84/c484af9bcc033ead398e6f7983b58a90.mp3','n. 目的；末端；结束；末尾','','');----
INSERT INTO classwords VALUES ('46db2e0e9907431c91bcd10816bed414','881110e2d3be429a88c0bc7ee2456b74','12');----
INSERT INTO word VALUES ('b62396380fee47598995cd2290547471','polar','[ˈpəulə]','http://res.iciba.com/resource/amp3/oxford/0/02/fd/02fd056bb71ce095e98580ac85a6a50f.mp3','adj. 极地的；完全相反的','','');----
INSERT INTO classwords VALUES ('3111e69320954beeabab95741196a7d6','b62396380fee47598995cd2290547471','12');----
INSERT INTO word VALUES ('03dfd7e1a6914cd6801055d84f120f7e','fair','[fɛə]','http://res.iciba.com/resource/amp3/0/0/f4/12/f4121a5aa2e22c742b9524033e8c9106.mp3','adj. 合理的；正确的；尚可的；浅色的...','','');----
INSERT INTO classwords VALUES ('2d01b78b9eba4b37aff71f7f9e8e2beb','03dfd7e1a6914cd6801055d84f120f7e','12');----
INSERT INTO word VALUES ('83c4621b8681474caa6e59c13325b273','skyscraper','[ˈskaiˌskreipə]','http://res.iciba.com/resource/amp3/oxford/0/4e/2a/4e2adcb846d7e5136fee54041339bc39.mp3','n. 摩天楼','','');----
INSERT INTO classwords VALUES ('eb949253934a42068428969b91a9b7aa','83c4621b8681474caa6e59c13325b273','12');----
INSERT INTO word VALUES ('48b2377f15fb46b3b149deb863e2a7e4','stew','[stju:]','http://res.iciba.com/resource/amp3/0/0/cd/c5/cdc556e84b4209ec4ecd7dad05282251.mp3','n. 炖煮的菜肴','','');----
INSERT INTO classwords VALUES ('04644f969d6341ebbfac1d00dabf043d','48b2377f15fb46b3b149deb863e2a7e4','12');----
INSERT INTO word VALUES ('b0d4a7e2a3994e4fa63d579009209ed2','sturdy','[ˈstə:di]','http://res.iciba.com/resource/amp3/0/0/aa/4c/aa4cfab07a8d6a6663e97ed0239706b9.mp3','adj. 坚定的；牢固的','','');----
INSERT INTO classwords VALUES ('7ea431bfcce4422ba10611ec3ebe034a','b0d4a7e2a3994e4fa63d579009209ed2','12');----
INSERT INTO word VALUES ('9c66ef1c92c342a99a3e1de9cd6021a1','kit','[kit]','http://res.iciba.com/resource/amp3/oxford/0/c1/8e/c18ec4a38bf1ce736c83e2db6331cf2a.mp3','n. 成套工具；全套衣服和装备；配套元件','','');----
INSERT INTO classwords VALUES ('6bbeb51638324c0598b1a5b1201a32ec','9c66ef1c92c342a99a3e1de9cd6021a1','12');----
INSERT INTO word VALUES ('38415a50f10b4d69b1879e1a4bacfee3','lever','[ˈli:və]','http://res.iciba.com/resource/amp3/1/0/ba/6e/ba6e7efe4ef9d89a520466f4fb894a0b.mp3','n. 把手；杠杆；手段，方法','','');----
INSERT INTO classwords VALUES ('44824bda6e674c66932c2e5de1753a41','38415a50f10b4d69b1879e1a4bacfee3','12');----
INSERT INTO word VALUES ('8e0c70266db44d54a0f4ddaf2fc439da','rally','[ˈræli]','http://res.iciba.com/resource/amp3/oxford/0/73/6e/736eff620e1147c854bbc6208adf1550.mp3','vi. 集合；团结起来；恢复','','');----
INSERT INTO classwords VALUES ('bb0fa8945f0f428e8536bca6278c9a8d','8e0c70266db44d54a0f4ddaf2fc439da','12');----
INSERT INTO word VALUES ('ef0ad89bdbac46708baeca6ef2f31318','spice','[spais]','http://res.iciba.com/resource/amp3/oxford/0/17/de/17de137deb58ef14bb8050b81b3d6b3f.mp3','n. 香料，调味品；香气；趣味','','');----
INSERT INTO classwords VALUES ('ebb72245ba1f4b1fa697ef4092dbfe58','ef0ad89bdbac46708baeca6ef2f31318','12');----
INSERT INTO word VALUES ('9ee994d966b84cddb109848ecb12dbb7','instantaneous','[ˌɪnstənˈteinjəs]','http://res.iciba.com/resource/amp3/oxford/0/b5/02/b502a2201ef3f3272ae828b7a72df195.mp3','adj. 瞬间的，即刻的','','');----
INSERT INTO classwords VALUES ('fbd3f847e12a4e9ea6163d4dfd9946fa','9ee994d966b84cddb109848ecb12dbb7','12');----
INSERT INTO word VALUES ('2ba920db92104cb49c52e0129b3264d9','perish','[ˈperiʃ]','http://res.iciba.com/resource/amp3/oxford/0/2b/87/2b87f0234d275c3cd72b594af26a02c0.mp3','vi. （人或动物）惨死；毁灭；老化','','');----
INSERT INTO classwords VALUES ('190a00f6658048cabea1ae00c0b844b7','2ba920db92104cb49c52e0129b3264d9','12');----
INSERT INTO word VALUES ('ec41b9c6b5204ff58e3620462f834c08','shorten','[ˈʃɔ:tn]','http://res.iciba.com/resource/amp3/0/0/31/1b/311bac622e1baaef25ec14c92a9944a3.mp3','vt. 缩短；缩写；变短','','');----
INSERT INTO classwords VALUES ('61a7bb3f617f4383a92ffa434fb1d52b','ec41b9c6b5204ff58e3620462f834c08','12');----
INSERT INTO word VALUES ('112708e22c5e42bca21941e3c6ff4918','burial','[ˈberiəl]','http://res.iciba.com/resource/amp3/oxford/0/ba/25/ba256ec7477f9da76d057390eacf1ce0.mp3','n. 埋葬；葬礼','','');----
INSERT INTO classwords VALUES ('d4e752dfd81841d0b6ed8d1513210e9f','112708e22c5e42bca21941e3c6ff4918','12');----
INSERT INTO word VALUES ('74bd478e6bed4b8e835af61b74c78962','tutor','[ˈtju:tə]','http://res.iciba.com/resource/amp3/oxford/0/c9/49/c9491d08336baab7e130de841bf0b116.mp3','vt. 教授，指导','','');----
INSERT INTO classwords VALUES ('0ade12f8b4f7436fbfa6e9a1ec2e0e04','74bd478e6bed4b8e835af61b74c78962','12');----
INSERT INTO word VALUES ('8cd83579362d49ff9be2d350399c33c9','nickname','[ˈnikneim]','http://res.iciba.com/resource/amp3/oxford/0/99/e0/99e052d6915492b8a7df22c52880811a.mp3','n. 绰号，诨号，外号','','');----
INSERT INTO classwords VALUES ('228528a6cca84b8bb27c81e63043e17c','8cd83579362d49ff9be2d350399c33c9','12');----
INSERT INTO word VALUES ('ca6bf1b31a3e41348c31795580ef9109','disappearance','[ˌdisəˈpiərəns]','http://res.iciba.com/resource/amp3/0/0/dc/7d/dc7d52b72965403261223f1d3bf515be.mp3','n. 消失；失踪；丢失；被盗','','');----
INSERT INTO classwords VALUES ('fdf18e70950649aea3c955cea5be8bfa','ca6bf1b31a3e41348c31795580ef9109','12');----
INSERT INTO word VALUES ('86cf4558461f456fa9590237d22d8b6c','recipe','[ˈresəpi]','http://res.iciba.com/resource/amp3/oxford/0/fd/e6/fde69c48ec48ac33106a478911f9ecd6.mp3','n. 食谱，烹饪配方；原因','','');----
INSERT INTO classwords VALUES ('7b366cb436e64abfb0f499f66104c3f2','86cf4558461f456fa9590237d22d8b6c','12');----
INSERT INTO word VALUES ('e37505bca81b48fd95d326bfe62542d3','vigour','[ˈvɪgə]','http://res.iciba.com/resource/amp3/oxford/0/dc/5d/dc5dcf3cb3484438590f32d7e2475fae.mp3','n. 活力，精力，元气','','');----
INSERT INTO classwords VALUES ('fb2ccb777a1343d19581ac5aa76661d2','e37505bca81b48fd95d326bfe62542d3','12');----
INSERT INTO word VALUES ('d18fa1d29af742d48c7cc911e5d64caa','faction','[ˈfækʃən]','http://res.iciba.com/resource/amp3/oxford/0/ac/2a/ac2ab305bbdfc6037489fc777ff5cac4.mp3','n. 派别，派系，小集团；内讧','','');----
INSERT INTO classwords VALUES ('154c89715ebc47cabe21a8eb956a4433','d18fa1d29af742d48c7cc911e5d64caa','12');----
INSERT INTO word VALUES ('3cd5e49d0a9847dba8de2d6c9e9054e9','bamboo','[bæmˈbu:]','http://res.iciba.com/resource/amp3/oxford/0/e8/10/e810781c2b2264f173b77048e0786736.mp3','n. 竹，竹子','','');----
INSERT INTO classwords VALUES ('394fcc247fde474391c7c321c16db9a6','3cd5e49d0a9847dba8de2d6c9e9054e9','12');----
INSERT INTO word VALUES ('28c32d7f0601449dbbd45a3a5408d951','oar','[ɔ:]','http://res.iciba.com/resource/amp3/oxford/0/f8/53/f85397c62075b60e64c624aedf07e9c2.mp3','vi. 划（行）','','');----
INSERT INTO classwords VALUES ('bc63eb380fa64f3faf1fa3c8ca90d3d4','28c32d7f0601449dbbd45a3a5408d951','12');----
INSERT INTO word VALUES ('090fc993a5104751837441a0e6165d6c','comparable','[ˈkɔmpərəbl]','http://res.iciba.com/resource/amp3/oxford/0/a6/20/a620232694728d9a4ca13be6dc31eff8.mp3','adj. 可比较的；类似的','','');----
INSERT INTO classwords VALUES ('165e3b63c15742b490f8e7c3bff27e62','090fc993a5104751837441a0e6165d6c','12');----
INSERT INTO word VALUES ('1887210682694cb3bb8aefa698b35471','projector','[prəˈdʒektə]','http://res.iciba.com/resource/amp3/oxford/0/6f/59/6f59d6a6d60795fe25aaea68894cf4be.mp3','n. 投影仪；放映机','','');----
INSERT INTO classwords VALUES ('af445573343741a2b0982a603c6a7005','1887210682694cb3bb8aefa698b35471','12');----
INSERT INTO word VALUES ('58bd4c8addac4b0396481d7a216b5a46','riot','[ˈraiət]','http://res.iciba.com/resource/amp3/oxford/0/df/a0/dfa049dcacc3a56d3248fa5c438d3cf0.mp3','vi. 发动暴乱；闹事','','');----
INSERT INTO classwords VALUES ('67e2ad7fdcdd45c682f05264cbb008b3','58bd4c8addac4b0396481d7a216b5a46','12');----
INSERT INTO word VALUES ('17db6b03ad244a548b3daecc5d72d013','even','[ˈi:vən]','http://res.iciba.com/resource/amp3/oxford/0/d7/2c/d72c984f2d0d4d790665138459fba88b.mp3','adj. 恒定的；平坦的；平均的；势均力...','','');----
INSERT INTO classwords VALUES ('420e0bd37fef4894824d0319e21c276f','17db6b03ad244a548b3daecc5d72d013','12');----
INSERT INTO word VALUES ('ca604c08e95d4f8a97c2851a5d9fcbb0','lounge','[laundʒ]','http://res.iciba.com/resource/amp3/oxford/0/2e/ac/2eac2e8264c66e71059a2a69b1e2592a.mp3','n. （旅馆等的）休息室；候机厅；起居室','','');----
INSERT INTO classwords VALUES ('808643cb038a4c1f8ddcfa6c33a87663','ca604c08e95d4f8a97c2851a5d9fcbb0','12');----
INSERT INTO word VALUES ('403fa28bf62c41dc8cb9acb681b4b982','directory','[diˈrektəri]','http://res.iciba.com/resource/amp3/oxford/0/fd/ee/fdee29dcc1c9e36620e464b45de44801.mp3','n. 通讯录；目录','','');----
INSERT INTO classwords VALUES ('fd20cd0aeed34b1b98ee8546e9fe5151','403fa28bf62c41dc8cb9acb681b4b982','12');----
INSERT INTO word VALUES ('0f28d2211f9448cea06e7490f9f8bee5','coke','[kəʊk]','http://res.iciba.com/resource/amp3/0/0/cb/2a/cb2a6b634f36e7f2f79d58956819a2d8.mp3','vt.&vi. 炼成焦炭','','');----
INSERT INTO classwords VALUES ('aceeb949c17e40ab8eba892fc4454f83','0f28d2211f9448cea06e7490f9f8bee5','12');----
INSERT INTO word VALUES ('0bed0c3e84e546f7a1ba77d33d2f78c2','counter','[ˈkauntə]','http://res.iciba.com/resource/amp3/oxford/0/e1/54/e154d0c2e5dc2998e7d3960dddf069ff.mp3','adv. 反方向地，对立地','','');----
INSERT INTO classwords VALUES ('b077522332524e069aa8aadc7c5c75f6','0bed0c3e84e546f7a1ba77d33d2f78c2','12');----
INSERT INTO word VALUES ('2711e32aafbc49c98d7cc860b9ebf732','exemplify','[ɪɡˈzɛmpləˌfaɪ]','http://res.iciba.com/resource/amp3/oxford/0/07/51/0751b0ee3bd8a109f2430701f3d581e1.mp3','vt. 作为…的例证；是…的典范','','');----
INSERT INTO classwords VALUES ('72f496e9c23741a5a8b815a81a36a6d7','2711e32aafbc49c98d7cc860b9ebf732','12');----
INSERT INTO word VALUES ('3758ddef4e2b45ce860b910c685bc059','cubic','[ˈkju:bɪk]','http://res.iciba.com/resource/amp3/oxford/0/31/13/3113f564c3c86b47ea02b3a7768e6645.mp3','adj. 立方体的；立方的','','');----
INSERT INTO classwords VALUES ('45b91d5fb7684b31a4f2610422496339','3758ddef4e2b45ce860b910c685bc059','12');----
INSERT INTO word VALUES ('52af0751e45f48f2bc2f571dc8df8542','parameter','[pəˈræmitə]','http://res.iciba.com/resource/amp3/oxford/0/fe/4e/fe4ebc60145c4a312ec5a101136f3382.mp3','n. 参数；界限','','');----
INSERT INTO classwords VALUES ('6e3d6c40b8914a4c80d07d451b373eb5','52af0751e45f48f2bc2f571dc8df8542','12');----
INSERT INTO word VALUES ('e71b2097f9e644c39f2c9f7f55cc444b','thigh','[θai]','http://res.iciba.com/resource/amp3/oxford/0/17/bc/17bc1c0dffa7f2099ff956ebad97cbe3.mp3','n. 股，大腿','','');----
INSERT INTO classwords VALUES ('126c257e1ff941ad9b5ade3532c76384','e71b2097f9e644c39f2c9f7f55cc444b','12');----
INSERT INTO word VALUES ('64cf7511dd644acc9b7a7c78e656a308','cavity','[ˈkæviti]','http://res.iciba.com/resource/amp3/oxford/0/78/66/78668288b1f9360fae452e2b6cfd7cad.mp3','n. 洞，孔；龋洞','','');----
INSERT INTO classwords VALUES ('b3efba7f51d841278f1dba632b043cfc','64cf7511dd644acc9b7a7c78e656a308','12');----
INSERT INTO word VALUES ('2bfa6311c5344e4b9021f1f119d53ab6','succession','[səkˈseʃən]','http://res.iciba.com/resource/amp3/oxford/0/cc/aa/ccaa56220f4b24eea9bd8708ae555798.mp3','n. 继承权；一连串','','');----
INSERT INTO classwords VALUES ('28c72a8cb276434794adc95967a29c97','2bfa6311c5344e4b9021f1f119d53ab6','12');----
INSERT INTO word VALUES ('a35c540c0cca45f5be0222a0e7a83a25','receiver','[riˈsi:və]','http://res.iciba.com/resource/amp3/oxford/0/df/2a/df2a87d290d1c31d005e7dc36fd349f8.mp3','n. 接受者；听筒','','');----
INSERT INTO classwords VALUES ('8b4d934c85ab494096d4f03077dddc6e','a35c540c0cca45f5be0222a0e7a83a25','12');----
INSERT INTO word VALUES ('a036c6d3855d4da8bc7cfe9ceffb2321','peak','[pi:k]','http://res.iciba.com/resource/amp3/oxford/0/11/ae/11ae691511d5fee066b85cca5a21e0dd.mp3','n. 顶峰；帽舌；山峰','','');----
INSERT INTO classwords VALUES ('bd0f7c7261364884ae6c3b390ad2a501','a036c6d3855d4da8bc7cfe9ceffb2321','12');----
INSERT INTO word VALUES ('5908ff47ac1e481193bf1f1490753e8d','frock','[frɔk]','http://res.iciba.com/resource/amp3/0/0/71/7b/717b1200c58b5fcc03a18d36115c68ac.mp3','n. 女裙，女装','','');----
INSERT INTO classwords VALUES ('3c891bd6e4b44596978b4ee782ca15c9','5908ff47ac1e481193bf1f1490753e8d','12');----
INSERT INTO word VALUES ('b812c3faec1f4365ad1200a2011f457e','criterion','[kraiˈtiəriən]','http://res.iciba.com/resource/amp3/oxford/0/ec/04/ec045a1da5a6664de472e9cb0041bb0d.mp3','n. 标准，准则','','');----
INSERT INTO classwords VALUES ('818b8d76035247a7a7b94fb3783c415f','b812c3faec1f4365ad1200a2011f457e','12');----
INSERT INTO word VALUES ('57fc46b143064e1fbd6b8cf32ce9d75c','should','[ʃud]','http://res.iciba.com/resource/amp3/oxford/0/3f/18/3f186e0648a803b7754b48486f59b5a9.mp3','v. 应该，应当','','');----
INSERT INTO classwords VALUES ('e11f481fdcd448d9910fd934f835bb08','57fc46b143064e1fbd6b8cf32ce9d75c','12');----
INSERT INTO word VALUES ('8b9d2393e2e44a4199cd7e8c21a88938','qualitative','[ˈkwɔlitətiv]','http://res.iciba.com/resource/amp3/oxford/0/66/ed/66edc582f8c58fa1ebe142390e77f96d.mp3','adj. 质量上的；品质的；性质的','','');----
INSERT INTO classwords VALUES ('8328652d213e4082b5b71afdf806a289','8b9d2393e2e44a4199cd7e8c21a88938','12');----
INSERT INTO word VALUES ('4e9e6b4d311e49a9bcf8e8e40a6ffc10','ascribe','[əsˈkraib]','http://res.iciba.com/resource/amp3/oxford/0/da/85/da85acab1739982f9dc47ce16ad33282.mp3','vt. 把…归因于；认为…具有','','');----
INSERT INTO classwords VALUES ('044fb698a1c54c5891fa2051daa51c03','4e9e6b4d311e49a9bcf8e8e40a6ffc10','12');----
INSERT INTO word VALUES ('a808caf1ee7141e1be2352b84e578a44','relay','[ˈriːleɪ]','http://res.iciba.com/resource/amp3/oxford/0/73/24/7324ee5076efeb0293c2adc29a11465e.mp3','vt. 转播，传送；传话；转述','','');----
INSERT INTO classwords VALUES ('292da0dfc8144e8d997dd8ae4787dd18','a808caf1ee7141e1be2352b84e578a44','12');----
INSERT INTO word VALUES ('077ef9db35ef46d69d651b808af7378d','firmness','[ˈfə:mnɪs]','http://res.iciba.com/resource/amp3/0/0/8f/09/8f09da8a15e5164837025532e0bb298f.mp3','n. 坚固；坚实；坚定','','');----
INSERT INTO classwords VALUES ('f48056e272394ebfbb15904c946a2b4e','077ef9db35ef46d69d651b808af7378d','12');----
INSERT INTO word VALUES ('f06ba3b0241848699a4efdd485f4e1ae','interconnect','[ˌɪntəkəˈnekt]','http://res.iciba.com/resource/amp3/oxford/0/a6/2d/a62d5c1382c151a68762d16283efc0f8.mp3','vt. 使互相联系；使互相联接','','');----
INSERT INTO classwords VALUES ('07846784339847e9ba9ef35b315958b2','f06ba3b0241848699a4efdd485f4e1ae','12');----
INSERT INTO word VALUES ('b3d1fdb6136b4f4e91ed1d0c3ffa04e6','maid','[meid]','http://res.iciba.com/resource/amp3/oxford/0/96/38/963820377fe98fe9d018135d253fc9da.mp3','n. 女佣；侍女','','');----
INSERT INTO classwords VALUES ('b7d9a07e7388474499393f7b09f90db2','b3d1fdb6136b4f4e91ed1d0c3ffa04e6','12');----
INSERT INTO word VALUES ('1b2e5f2d67cd4bdcaad9f54b6388e863','punch','[pʌntʃ]','http://res.iciba.com/resource/amp3/oxford/0/85/09/85093d9b8511ebdc47117d2349e67d60.mp3','n. 打孔机；穿孔器','','');----
INSERT INTO classwords VALUES ('ee144f90ed0945cdbfd2e4a1c36a7be0','1b2e5f2d67cd4bdcaad9f54b6388e863','12');----
INSERT INTO word VALUES ('900ea16e4f06419496c934e1fb557902','gust','[ɡʌst]','http://res.iciba.com/resource/amp3/oxford/0/23/9f/239fd444adbcd0bf7c8adf74b90c043d.mp3','n. 一阵狂风；（感情的）迸发','','');----
INSERT INTO classwords VALUES ('226de38a37ef4bddb1605e51b9a9d16d','900ea16e4f06419496c934e1fb557902','12');----
INSERT INTO word VALUES ('cbc8c9bde8b940bfbff4ccf0193b5bd4','scramble','[ˈskræmbl]','http://res.iciba.com/resource/amp3/oxford/0/05/38/0538f4145ddb74cf810ee20c6463e42f.mp3','vi. 爬，攀登；仓促行动；争夺，抢夺；...','','');----
INSERT INTO classwords VALUES ('322351d97e1d423094a3a87f4a68d0b2','cbc8c9bde8b940bfbff4ccf0193b5bd4','12');----
INSERT INTO word VALUES ('8dc6de705cd0402aa400f3e41577d753','pickle','[ˈpɪkəl]','http://res.iciba.com/resource/amp3/oxford/0/b5/a8/b5a8e35e84ec01f45a4651a094054bf0.mp3','n. 腌菜，泡菜；困境，窘境','','');----
INSERT INTO classwords VALUES ('682c9890294c4ce39ff7328b4b1bd4e1','8dc6de705cd0402aa400f3e41577d753','12');----
INSERT INTO word VALUES ('a0ee4ae7c63d47989e4a42bb65b3073d','inlet','[ˈinlet]','http://res.iciba.com/resource/amp3/oxford/0/2b/56/2b56d0279b0a63424ade44a51c97ea82.mp3','vt. 引进','','');----
INSERT INTO classwords VALUES ('17966670ff3245869b22c9a14d920109','a0ee4ae7c63d47989e4a42bb65b3073d','12');----
INSERT INTO word VALUES ('f5ae228b80cb4322ae7c1746d8152595','array','[əˈrei]','http://res.iciba.com/resource/amp3/oxford/0/cd/be/cdbe0c03338c6a344b511b777dd8fc16.mp3','n. 陈列，布置；一大批','','');----
INSERT INTO classwords VALUES ('76956f85c7e443708c9a990c04a6e2e9','f5ae228b80cb4322ae7c1746d8152595','12');----
INSERT INTO word VALUES ('d4837bfb613b4cb59dd5e68de40b0f7f','transverse','[trænsˈvɜ:s]','http://res.iciba.com/resource/amp3/oxford/0/03/b0/03b06de8749af63e7a2ba4e1c6644d24.mp3','n. 横轴','','');----
INSERT INTO classwords VALUES ('bc4ad2076e7e49339d70c678933388f2','d4837bfb613b4cb59dd5e68de40b0f7f','12');----
INSERT INTO word VALUES ('a4ded696a38e4ba2a9e187ab4de14a6c','superiority','[suːˌpɪəriˈɒrəti]','http://res.iciba.com/resource/amp3/oxford/0/a2/07/a207f826bb0754092a1631924b7ebd8e.mp3','n. 优越（性），优势','','');----
INSERT INTO classwords VALUES ('e22d7945ea854251bf844d72c991cac3','a4ded696a38e4ba2a9e187ab4de14a6c','12');----
INSERT INTO word VALUES ('8bcc4d93ebda428193a2105204f1e26f','romance','[rəuˈmæns]','http://res.iciba.com/resource/amp3/oxford/0/11/7b/117beca228b26079082d60f7e75c9ca6.mp3','n. 罗曼史；浪漫，爱意；传奇色彩','','');----
INSERT INTO classwords VALUES ('3d554b3f518743ce8b37c1b43c0d1dd5','8bcc4d93ebda428193a2105204f1e26f','12');----
INSERT INTO word VALUES ('afd0e3d0960a41eab519d27609341de6','paper','[ˈpeipə]','http://res.iciba.com/resource/amp3/oxford/0/57/1c/571c98596ba27970a5246b8a3c35901e.mp3','vt. 贴纸；用纸覆盖；掩饰','','');----
INSERT INTO classwords VALUES ('4847ef3bd95446b6b4fc79dff3ef91f1','afd0e3d0960a41eab519d27609341de6','12');----
INSERT INTO word VALUES ('37067b7d52834474b46d0a328616b0c5','replace','[riˈpleis]','http://res.iciba.com/resource/amp3/oxford/0/40/64/40649d9bab32ecb249f20d19afd6e1c7.mp3','vt. 替换；以…取代；把…放回（原处）','','');----
INSERT INTO classwords VALUES ('d928ad88550c4614bee8e7f3f67be8f2','37067b7d52834474b46d0a328616b0c5','12');----
INSERT INTO word VALUES ('14595861fb994b53b744d78d31cb4883','poke','[pəuk]','http://res.iciba.com/resource/amp3/0/0/ee/db/eedb72cf263463f7ec5bc4b15ce09141.mp3','vt. 戳，刺；把…插入','','');----
INSERT INTO classwords VALUES ('51ba6b1fb30146e1928e020eab8d8a29','14595861fb994b53b744d78d31cb4883','12');----
INSERT INTO word VALUES ('81b92942f1f54e9aa3a9bdbfd597ba93','jingle','[ˈdʒɪŋgəl]','http://res.iciba.com/resource/amp3/oxford/0/df/1c/df1c0ce0c027008221fc3b6fdd21a57c.mp3','vt.&vi. （使）叮当响','','');----
INSERT INTO classwords VALUES ('295ed0fa51674d8fa56142c26f8a3396','81b92942f1f54e9aa3a9bdbfd597ba93','12');----
INSERT INTO word VALUES ('ab63131ff8eb40028cbc6789eec95583','vision','[ˈviʒən]','http://res.iciba.com/resource/amp3/oxford/0/72/22/722230190bc283e83cbc0f5c56501ede.mp3','n. 视力；展望；想象；幻觉；视野','','');----
INSERT INTO classwords VALUES ('25d82db0133f4ba2bd4a1774855bdbe8','ab63131ff8eb40028cbc6789eec95583','12');----
INSERT INTO word VALUES ('0dca5ca718394f44906de0406c94d380','slit','[slit]','http://res.iciba.com/resource/amp3/oxford/0/a3/be/a3be71b33ede8253bd80a8550440d472.mp3','n. 狭长的切口；狭缝','','');----
INSERT INTO classwords VALUES ('a090506139e94747ab95d844df63d9b3','0dca5ca718394f44906de0406c94d380','12');----
INSERT INTO word VALUES ('d6d71ac0c08b46efa7214b2a3af37be9','basin','[ˈbeisn]','http://res.iciba.com/resource/amp3/oxford/0/de/95/de957b6e79cf321a904198f7273ee12f.mp3','n. 脸盆；盆地；流域','','');----
INSERT INTO classwords VALUES ('88eed4177d26481b9d93d65156487472','d6d71ac0c08b46efa7214b2a3af37be9','12');----
INSERT INTO word VALUES ('b10087993a1340ff979341b787dfd2ac','volunteer','[ˌvɔlənˈtiə]','http://res.iciba.com/resource/amp3/0/0/2d/56/2d56df9a08100634d51940309237855d.mp3','v. 自告奋勇；主动要求；主动提供（信息...','','');----
INSERT INTO classwords VALUES ('9a34c1e7f52e49d18d34919c44f115fb','b10087993a1340ff979341b787dfd2ac','12');----
INSERT INTO word VALUES ('dfb0232193f347d19ce9e7e1f9020ed2','anode','[ˈænˌəʊd]','http://res.iciba.com/resource/amp3/0/0/ad/52/ad528e37dda6de613846926c6eef957b.mp3','n. 阳极，正极','','');----
INSERT INTO classwords VALUES ('e3667301dd6f4c899399c1a92c2d8e7e','dfb0232193f347d19ce9e7e1f9020ed2','12');----
INSERT INTO word VALUES ('2b2f1de707a44ae794acec97e6572644','revive','[riˈvaiv]','http://res.iciba.com/resource/amp3/oxford/0/25/01/2501fcf3ba41e5d80600685d9d76b032.mp3','vt. 使复苏；使复兴；使苏醒','','');----
INSERT INTO classwords VALUES ('64110efd6c7d464fb62007d4c85842df','2b2f1de707a44ae794acec97e6572644','12');----
INSERT INTO word VALUES ('2f810ae3aacf467885dd34be02d85dc9','architect','[ˈɑ:kitekt]','http://res.iciba.com/resource/amp3/oxford/0/98/5d/985dc40e50aca6bf9b5db5e101d57006.mp3','n. 建筑师；规划者','','');----
INSERT INTO classwords VALUES ('6666216c2d364e1b9216bd4b3f44b8ad','2f810ae3aacf467885dd34be02d85dc9','12');----
INSERT INTO word VALUES ('72d8bd5310134ce38dae7194f4f49bb5','stiff','[stif]','http://res.iciba.com/resource/amp3/oxford/0/03/58/03581f934b98276b612a9641fa4b642b.mp3','adj. 生硬的；不灵活的；酸痛的','','');----
INSERT INTO classwords VALUES ('03c22d12a11a4ef58953b5ec6dd60e4a','72d8bd5310134ce38dae7194f4f49bb5','12');----
INSERT INTO word VALUES ('8226764608b14de480fde8ad1d7b9c0a','nun','[nʌn]','http://res.iciba.com/resource/amp3/oxford/0/1e/e2/1ee298b8d1e82fd4f24060644eb9dbd7.mp3','n. 修女，尼姑','','');----
INSERT INTO classwords VALUES ('263a3fb16ede4e968d2d1f9410af4d0d','8226764608b14de480fde8ad1d7b9c0a','12');----
INSERT INTO word VALUES ('4ba15e9e5c42400ab55b2055bbb6c35f','spectacle','[ˈspektəkl]','http://res.iciba.com/resource/amp3/oxford/0/3b/19/3b193a47bcf07465c31fad24ed90db50.mp3','n. 场面；景象','','');----
INSERT INTO classwords VALUES ('40dfbbefd4bc41b1bf405903ce39b4a5','4ba15e9e5c42400ab55b2055bbb6c35f','12');----
INSERT INTO word VALUES ('38079cac244247a9b0fb13f889cdacf6','clash','[klæʃ]','http://res.iciba.com/resource/amp3/oxford/0/a2/8d/a28daba071e7c49e9b87a3d34898e588.mp3','v. 争论；发生冲突；不相容；不协调','','');----
INSERT INTO classwords VALUES ('d38a0033c95e44f98918a96b348c2de4','38079cac244247a9b0fb13f889cdacf6','12');----
INSERT INTO word VALUES ('2b7ba1bd7fad4352869173e9c6d1223b','unlimited','[ʌnˈlɪmɪtɪd]','http://res.iciba.com/resource/amp3/oxford/0/94/cc/94cc40f1a8b84a6e4f24b3fb64f4b750.mp3','adj. 无限的','','');----
INSERT INTO classwords VALUES ('4561f5352b3141b0b921fc5e508e6504','2b7ba1bd7fad4352869173e9c6d1223b','12');----
INSERT INTO word VALUES ('c1e154dc344148cfbf95101f63f8cbe7','ashore','[əˈʃɔ:]','http://res.iciba.com/resource/amp3/oxford/0/77/2a/772a0f87cf8e179e8c372883a65daf10.mp3','adv. 在岸上，上岸','','');----
INSERT INTO classwords VALUES ('85e320a6ac0349df959017b4301cf010','c1e154dc344148cfbf95101f63f8cbe7','12');----
INSERT INTO word VALUES ('6279b1ea2481445e81aa8b11b823190e','concert','[ˈkɔnsət]','http://res.iciba.com/resource/amp3/0/0/09/09/0909553c7a647d10dbff1b00394c551d.mp3','n. 一致，和谐；音乐会','','');----
INSERT INTO classwords VALUES ('d42fa76f243d4741a3434714242f61fe','6279b1ea2481445e81aa8b11b823190e','12');----
INSERT INTO word VALUES ('c2bc5ae41e5644a6ad43208c950cd272','grant','[ɡrɑ:nt]','http://res.iciba.com/resource/amp3/0/0/64/fa/64fad28965d003cde964ea3016e257a3.mp3','n. 拨款；补助金','','');----
INSERT INTO classwords VALUES ('20a97c7f60434d53b7f7fb7d78ba215d','c2bc5ae41e5644a6ad43208c950cd272','12');----
INSERT INTO word VALUES ('40ca659a373145eb956f07c2e993acaa','circular','[ˈsə:kjulə]','http://res.iciba.com/resource/amp3/oxford/0/64/5d/645d5c32559488ed21830c7d4cad6627.mp3','adj. 圆形的；环行的','','');----
INSERT INTO classwords VALUES ('d4398d52159442ee99ac65f9e5eb8efb','40ca659a373145eb956f07c2e993acaa','12');----
INSERT INTO word VALUES ('2aa47bd68469409e98649cb47a0fefe4','majesty','[ˈmædʒisti]','http://res.iciba.com/resource/amp3/oxford/0/c3/8a/c38a7baddf861d995755aa4142b95e15.mp3','n. 庄严，雄伟；陛下','','');----
INSERT INTO classwords VALUES ('5e32ac7a888f4f80949b583a1076d4ce','2aa47bd68469409e98649cb47a0fefe4','12');----
INSERT INTO word VALUES ('68cd866c5abb460aa2cd9b86236d9667','scoff','[skɔf]','http://res.iciba.com/resource/amp3/0/0/de/67/de677d3611628a8f9f1b5970ac7d17ff.mp3','vi. 嘲笑，嘲弄；狼吞虎咽','','');----
INSERT INTO classwords VALUES ('0f7e46cb4b584f8ca3581bcf97478568','68cd866c5abb460aa2cd9b86236d9667','12');----
INSERT INTO word VALUES ('ed0eb96b88f74143aa792490c00a95e3','execution','[ˌeksiˈkju:ʃən]','http://res.iciba.com/resource/amp3/oxford/0/bc/88/bc88aab2f1ba82c36516cef8d89b7783.mp3','n. 实行，执行；执行死刑','','');----
INSERT INTO classwords VALUES ('c9f95fae068c4d57af0ee457272b4f25','ed0eb96b88f74143aa792490c00a95e3','12');----
INSERT INTO word VALUES ('2dbe9778c189439d895bfd327ef6412d','polymer','[ˈpɔləmə]','http://res.iciba.com/resource/amp3/oxford/0/32/65/32652d2d1ab7d02068aa0f5e3750e501.mp3','n. 聚合物，多聚体','','');----
INSERT INTO classwords VALUES ('4c3507893b114a728eb8374e179998dc','2dbe9778c189439d895bfd327ef6412d','12');----
INSERT INTO word VALUES ('9436c24e2b9b4c06a28d7c5e59d51625','courageous','[kəˈreɪdʒəs]','http://res.iciba.com/resource/amp3/oxford/0/91/ef/91ef1028d6c1533777047a5472d20d3c.mp3','adj. 勇敢的，无畏的','','');----
INSERT INTO classwords VALUES ('0773324615814bf0b2cff0ff77e83354','9436c24e2b9b4c06a28d7c5e59d51625','12');----
INSERT INTO word VALUES ('95ff6bb5b27d4585afde2748baa6c779','margin','[ˈmɑ:dʒin]','http://res.iciba.com/resource/amp3/0/0/d4/2f/d42f4851e770aa0f758b01388874f67b.mp3','n. 余地；差额；页边空白；边缘','','');----
INSERT INTO classwords VALUES ('5a982dcbd71a4c64aa9cf3cf1c63ed47','95ff6bb5b27d4585afde2748baa6c779','12');----
INSERT INTO word VALUES ('54e65b99efd149509908b3197057af40','deafen','[ˈdefən]','http://res.iciba.com/resource/amp3/oxford/0/06/36/0636b7020b7baf2de857d300afba2fdc.mp3','vt. 使聋；使听不见','','');----
INSERT INTO classwords VALUES ('3e30f1000ef147e78dc376d38e7b3185','54e65b99efd149509908b3197057af40','12');----
INSERT INTO word VALUES ('39e691f8b6bb4ab883711f45ce615a15','detain','[diˈtein]','http://res.iciba.com/resource/amp3/oxford/0/5b/7b/5b7bd2030d907cf9e1c76ac5a08fe9ee.mp3','vt. 耽搁；扣押，拘留','','');----
INSERT INTO classwords VALUES ('2a44c6379df3491b85fa19534f2a2d8b','39e691f8b6bb4ab883711f45ce615a15','12');----
INSERT INTO word VALUES ('c18502ff7e5347188f651c3cd8574f7b','surplus','[ˈsə:pləs]','http://res.iciba.com/resource/amp3/oxford/0/72/43/72435abe3c365ffab075800306e69a38.mp3','n. 过剩，剩余；（贸易）顺差；盈余','','');----
INSERT INTO classwords VALUES ('b65cdc2e6eb94390856d8baba7fc7623','c18502ff7e5347188f651c3cd8574f7b','12');----
INSERT INTO word VALUES ('7507999cef1b433fbc512151ee7fa1a6','compensation','[ˌkɔmpenˈseiʃən]','http://res.iciba.com/resource/amp3/oxford/0/39/9d/399d2443f71a78329ffb37b2ff65a753.mp3','n. 补偿；补偿金','','');----
INSERT INTO classwords VALUES ('f6f0d0c50a1f4c65aab61e26de7a0205','7507999cef1b433fbc512151ee7fa1a6','12');----
INSERT INTO word VALUES ('9f9445d6d56b4943a80aa0286660e810','freshen','[ˈfreʃən]','http://res.iciba.com/resource/amp3/oxford/0/8d/33/8d33cc6dd5b04e048ba5a48c85298007.mp3','vt. 使某物新鲜','','');----
INSERT INTO classwords VALUES ('321895d197cd491588b45e8792ad24d2','9f9445d6d56b4943a80aa0286660e810','12');----
INSERT INTO word VALUES ('275b6826277847ce8c4af455cf411d9c','courteous','[ˈkə:tjəs]','http://res.iciba.com/resource/amp3/oxford/0/66/ec/66ec287dbbfbf9b7dce4c7d7fb5e0eb7.mp3','adj. 有礼貌的，谦恭的','','');----
INSERT INTO classwords VALUES ('4c6f31bba9014e9d80d43b520f6e01b4','275b6826277847ce8c4af455cf411d9c','12');----
INSERT INTO word VALUES ('8435c5e923904f6984923b53156d03d7','universally','[ˌju:nɪˈvɜ:səlɪ]','http://res.iciba.com/resource/amp3/oxford/0/08/53/0853de9a5ad840a8310183d004e255fb.mp3','adv. 普遍地；人人；到处','','');----
INSERT INTO classwords VALUES ('45888bb76d704e05a94dcd9ce4a4f328','8435c5e923904f6984923b53156d03d7','12');----
INSERT INTO word VALUES ('c84b13f6ffda4f1ba0c0a73fe239145e','bishop','[ˈbiʃəp]','http://res.iciba.com/resource/amp3/oxford/0/bb/96/bb969bd943332561d8e71cc7e4941f2e.mp3','n. 主教；（国际象棋中的）象','','');----
INSERT INTO classwords VALUES ('eb1973a5e8694d149b275b8bbf0b738b','c84b13f6ffda4f1ba0c0a73fe239145e','12');----
INSERT INTO word VALUES ('0feaa74941394ad786282b7fac634e56','sharply','[ˈʃɑ:plɪ]','http://res.iciba.com/resource/amp3/0/0/32/98/32984f7d67e2f4b25176746c72c3dce5.mp3','adv. 严厉地；锋利地；急剧地','','');----
INSERT INTO classwords VALUES ('10007921d6f2454299186281ddd377a7','0feaa74941394ad786282b7fac634e56','12');----
INSERT INTO word VALUES ('c2ca3f25432845feb858a36355008383','initiative','[iˈniʃiətiv]','http://res.iciba.com/resource/amp3/oxford/0/03/56/0356fcffbaa76f6dd3011f576cc22a1b.mp3','n. 倡议；主动权；主动性；进取心','','');----
INSERT INTO classwords VALUES ('a1806a6b0d6f4aa5bdcca23fa4725101','c2ca3f25432845feb858a36355008383','12');----
INSERT INTO word VALUES ('d815b500d38c46e6bd88eb279bf64451','promptly','[prɔmptlɪ]','http://res.iciba.com/resource/amp3/oxford/0/85/f5/85f5b525eb293be3624012fcffb8f390.mp3','adv. 立即；马上；准时地','','');----
INSERT INTO classwords VALUES ('bb37249909e5454883ca9c26e4cfe954','d815b500d38c46e6bd88eb279bf64451','12');----
INSERT INTO word VALUES ('51bd230ccef44d21853e4d2c56f0b0da','magnify','[ˈmæɡnifai]','http://res.iciba.com/resource/amp3/oxford/0/47/da/47da6f9a50103e5358b425885b09b7df.mp3','vt. 放大，扩大；加强；夸大','','');----
INSERT INTO classwords VALUES ('55626f0dd8d34797a4dd82b08e9767ab','51bd230ccef44d21853e4d2c56f0b0da','12');----
INSERT INTO word VALUES ('d7ffa0b66c11450ba531e929abde01fa','flock','[flɒk]','http://res.iciba.com/resource/amp3/0/0/f5/f4/f5f43dd44a652bab4be8197039a120b6.mp3','vi. 群集；蜂拥','','');----
INSERT INTO classwords VALUES ('28ed61ab1a9f45cea0a1b4ed1f479275','d7ffa0b66c11450ba531e929abde01fa','12');----
INSERT INTO word VALUES ('c76d1f5b3ecc4a59ac28e22e748c7b3b','fireplace','[ˈfaiəpleis]','http://res.iciba.com/resource/amp3/oxford/0/4a/e3/4ae3c14978c3fbc07f274350093f1538.mp3','n. 壁炉','','');----
INSERT INTO classwords VALUES ('ba5f279bfee14fbbb4fd65008eef77b1','c76d1f5b3ecc4a59ac28e22e748c7b3b','12');----
INSERT INTO word VALUES ('f3c87fe2a3ef4114b8965e8d4be2a9a6','detective','[diˈtektiv]','http://res.iciba.com/resource/amp3/oxford/0/8d/c7/8dc79922a86851fbbabfcf446fa35d53.mp3','n. 侦探','','');----
INSERT INTO classwords VALUES ('fca9aebb6993432fa10abee41252c9f4','f3c87fe2a3ef4114b8965e8d4be2a9a6','12');----
INSERT INTO word VALUES ('26840ac4ff7a4dbc9380fa7eef194752','tackle','[ˈtækl]','http://res.iciba.com/resource/amp3/oxford/0/03/07/0307e5fc9210483b735b7b93b8fe2f02.mp3','n. 器具，器材；滑轮组','','');----
INSERT INTO classwords VALUES ('86e7f1817858407ab2ce5e6e00809316','26840ac4ff7a4dbc9380fa7eef194752','12');----
INSERT INTO word VALUES ('019a4b46425b4fedaa1a3460f506dad4','duplicate','[ˈdju:plikit]','http://res.iciba.com/resource/amp3/0/0/24/f1/24f1b0a79473250c195c7fb84e393392.mp3','n. 复制品 ˈdju:plikeit...','','');----
INSERT INTO classwords VALUES ('f180d55b53e9433fb3d0b62bf9ce8604','019a4b46425b4fedaa1a3460f506dad4','12');----
INSERT INTO word VALUES ('9b7aae4ca0b949d8b44dc0ff5b7325a7','defy','[diˈfai]','http://res.iciba.com/resource/amp3/oxford/0/bf/12/bf123db3444f78b2703b663ff3bfcc8d.mp3','vt. 挑战；反抗；不服从','','');----
INSERT INTO classwords VALUES ('f2b4613c97434424a395ae6ac6c69ddb','9b7aae4ca0b949d8b44dc0ff5b7325a7','12');----
INSERT INTO word VALUES ('534d5796b8524c6ba03177f224a18d34','enhance','[inˈhɑ:ns]','http://res.iciba.com/resource/amp3/oxford/0/9e/32/9e329df0e1b1cb3819780c0153976e80.mp3','vt. 提高，增加','','');----
INSERT INTO classwords VALUES ('8401c339fd5d407180a112442a76c261','534d5796b8524c6ba03177f224a18d34','12');----
INSERT INTO word VALUES ('7a14a031a2ad4be2b40e1d0117d89bc7','customary','[ˈkʌstəməri]','http://res.iciba.com/resource/amp3/oxford/0/eb/30/eb308ae847a8aca445d3b4c4727663fe.mp3','adj. 习惯的；习俗的；特有的，独特的','','');----
INSERT INTO classwords VALUES ('1eea18d6ce854cb59579c333cf35ab78','7a14a031a2ad4be2b40e1d0117d89bc7','12');----
INSERT INTO word VALUES ('04d555c9a0c44e96b9f99d3862de0c95','pendulum','[ˈpendjuləm]','http://res.iciba.com/resource/amp3/oxford/0/16/98/1698235f3416d2420382ba00be833956.mp3','n. 钟摆；（局势意见等的）摇摆不定','','');----
INSERT INTO classwords VALUES ('7107b823eec841bbb238bb75769d48d4','04d555c9a0c44e96b9f99d3862de0c95','12');----
INSERT INTO word VALUES ('b0b1b3ca48874e4a8119c4b72cdd2b1b','dizzy','[ˈdizi]','http://res.iciba.com/resource/amp3/oxford/0/97/f5/97f5f90f5c122e369ed9dc022a055c4c.mp3','adj. 头晕目眩的，眩晕的','','');----
INSERT INTO classwords VALUES ('788df7a3daf54f8b862ec6d937053d47','b0b1b3ca48874e4a8119c4b72cdd2b1b','12');----
INSERT INTO word VALUES ('a1fbbe9f0aa84a7c9e9c88fda1cc9470','tramp','[træmp]','http://res.iciba.com/resource/amp3/oxford/0/75/ae/75ae64ad299c4fcdabd761bed9216f25.mp3','vi. 拖着沉重的步子走；步行','','');----
INSERT INTO classwords VALUES ('8c06d26b7f2f4058a5ad4d2e7b7f217d','a1fbbe9f0aa84a7c9e9c88fda1cc9470','12');----
INSERT INTO word VALUES ('a38548c47dbd403ca4fc8a43f620e3cb','solidarity','[ˌsɔliˈdæriti]','http://res.iciba.com/resource/amp3/oxford/0/cf/ee/cfee79c34b706feac8386c7e9aca9021.mp3','n. 团结','','');----
INSERT INTO classwords VALUES ('7cd09ab2e2c246a6af52993292ea9193','a38548c47dbd403ca4fc8a43f620e3cb','12');----
INSERT INTO word VALUES ('e1d8890f004146de889b68c767ebd605','statistics','[stəˈtistiks]','http://res.iciba.com/resource/amp3/0/0/a9/12/a912a94d79b5124d876951f96ebb256f.mp3','n. 统计，统计数字','','');----
INSERT INTO classwords VALUES ('736285699049465aa295fb6f92f8a710','e1d8890f004146de889b68c767ebd605','12');----
INSERT INTO word VALUES ('1e1fbf69606a49e59ef7f9d7583578ee','impurity','[ɪmˈpjʊərɪti:]','http://res.iciba.com/resource/amp3/oxford/0/32/8f/328f8f7c45f3d59526059241f448f3d1.mp3','n. 不纯；杂质；不道德','','');----
INSERT INTO classwords VALUES ('6454e75014434af8b57bdffc25398c30','1e1fbf69606a49e59ef7f9d7583578ee','12');----
INSERT INTO word VALUES ('a633aa762d64499691f04450f32b57a1','mosque','[mɔsk]','http://res.iciba.com/resource/amp3/0/0/0c/34/0c34bceae1380ff3e7d342acc03762e3.mp3','n. 清真寺','','');----
INSERT INTO classwords VALUES ('3a24e0e437f0431db9c0ee36a3388ad5','a633aa762d64499691f04450f32b57a1','12');----
INSERT INTO word VALUES ('3c977f5fb19e4bc6946fa80f9fe2fced','axial','[ˈæksi:əl]','http://res.iciba.com/resource/amp3/oxford/0/09/ae/09aefe8d8d16c3ad3cff0326a5d890b9.mp3','adj. 轴的；轴向的；成轴的','','');----
INSERT INTO classwords VALUES ('447ff0d3a6884b368f70ab6e15100031','3c977f5fb19e4bc6946fa80f9fe2fced','12');----
INSERT INTO word VALUES ('45df4786df97410199e666db1235f6bd','outcome','[ˈautkʌm]','http://res.iciba.com/resource/amp3/oxford/0/96/e9/96e96c9a7c46c7c4e35c7bbee14d6365.mp3','n. 后果；结果','','');----
INSERT INTO classwords VALUES ('5fbb31ef028a42c489a206b96eaab475','45df4786df97410199e666db1235f6bd','12');----
INSERT INTO word VALUES ('9a11a3eeeb5a49758f4b43edf6cbe4ed','reckon','[ˈrekən]','http://res.iciba.com/resource/amp3/oxford/0/8c/27/8c270ca3371978f0eb21aaf808a9c9f4.mp3','vt. 认为','','');----
INSERT INTO classwords VALUES ('34f25d1c58a643a8a18b3839124732c8','9a11a3eeeb5a49758f4b43edf6cbe4ed','12');----
INSERT INTO word VALUES ('d201d8ffd39a40eeb3552e9234076acd','bait','[beit]','http://res.iciba.com/resource/amp3/oxford/0/6a/06/6a0625fd31594e31cc6f7c0d115ae404.mp3','n. 饵，诱饵；诱惑物','','');----
INSERT INTO classwords VALUES ('1b54497a11ea4c93ac49942b3d1d6da2','d201d8ffd39a40eeb3552e9234076acd','12');----
INSERT INTO word VALUES ('15e74d3cb5f54b71af6d099b56f5d6d8','carry','[ˈkæri]','http://res.iciba.com/resource/amp3/oxford/0/b5/de/b5dee43f539882745ee0b7b18bed58e6.mp3','vt. 刊登；使（提案、动议）通过；（罪...','','');----
INSERT INTO classwords VALUES ('88c3ad74108c46b8aa894eff31c73c9e','15e74d3cb5f54b71af6d099b56f5d6d8','12');----
INSERT INTO word VALUES ('8d8a1e3d466744539dc92fd1e489fb9b','deformation','[ˌdi:fɔ:ˈmeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/51/0d/510d0e214cf40d5fa48a09c01123a2f3.mp3','n. 损坏；变形；畸形','','');----
INSERT INTO classwords VALUES ('1428a5d3ed9f4a44a38374acb5a52d3f','8d8a1e3d466744539dc92fd1e489fb9b','12');----
INSERT INTO word VALUES ('c933717c9f6e43be888993b4e6ed9bb2','body','[ˈbɔdi]','http://res.iciba.com/resource/amp3/0/0/84/1a/841a2d689ad86bd1611447453c22c6fc.mp3','n. 身体；躯体；尸体；团体','','');----
INSERT INTO classwords VALUES ('0f1f22bc90864eb3a1d7d2d515b9dc3b','c933717c9f6e43be888993b4e6ed9bb2','12');----
INSERT INTO word VALUES ('e8bf1749f5d646c9b2a5ac01ee89fcde','flee','[fli:]','http://res.iciba.com/resource/amp3/oxford/0/5e/18/5e18f96a909a78376e12b86a8c89098c.mp3','vt. 逃避','','');----
INSERT INTO classwords VALUES ('525ecc391fc54e7d8c040062caba961b','e8bf1749f5d646c9b2a5ac01ee89fcde','12');----
INSERT INTO word VALUES ('4a3ecb5ceccf442eab7fd4295558a300','context','[ˈkɔntekst]','http://res.iciba.com/resource/amp3/oxford/0/41/92/41922d26073b89b5a9aa12aab05e884b.mp3','n. 上下文；背景','','');----
INSERT INTO classwords VALUES ('1823a5da8f824b7f98d2e4e6b2b30b99','4a3ecb5ceccf442eab7fd4295558a300','12');----
INSERT INTO word VALUES ('d6cc278d080941ec957687a9393d3cd1','transition','[trænˈziʃən]','http://res.iciba.com/resource/amp3/oxford/0/0d/ef/0defbac0474684c8d5094c6d0fc74dd3.mp3','n. 转变，变迁，过渡','','');----
INSERT INTO classwords VALUES ('082a8e4251f6405da8dfc79e59208c18','d6cc278d080941ec957687a9393d3cd1','12');----
INSERT INTO word VALUES ('52b75bfd1d6f43cf9d3e3e032d50893f','energize','[ˈenəˌdʒaɪz]','http://res.iciba.com/resource/amp3/oxford/0/3f/26/3f2621a0b258c1502d2a506d2d4b8a8c.mp3','vt. 使充满活力，使精力充沛','','');----
INSERT INTO classwords VALUES ('4ab2a7cf1c5c4afb823c854a9d6f04c0','52b75bfd1d6f43cf9d3e3e032d50893f','12');----
INSERT INTO word VALUES ('6a5a95d4a0bd4af08b242fb0f26a28cf','clamp','[klæmp]','http://res.iciba.com/resource/amp3/oxford/0/fb/87/fb876459587704cb0ba68c93bfb0ba52.mp3','vt. 夹住，夹紧；将…固定；紧紧抓住','','');----
INSERT INTO classwords VALUES ('5a3f696d5b21476693d20962086e9997','6a5a95d4a0bd4af08b242fb0f26a28cf','12');----
INSERT INTO word VALUES ('31bad67d2060429eb018c5ef0a1e8977','mild','[maild]','http://res.iciba.com/resource/amp3/oxford/0/3a/81/3a814d81b69cac75ff3111faef47f75a.mp3','adj. 温和的；（天气）温暖的；（味道...','','');----
INSERT INTO classwords VALUES ('9eb2a5f1bdb84fde96f54ede01038f5e','31bad67d2060429eb018c5ef0a1e8977','12');----
INSERT INTO word VALUES ('086e597022bc4864a9dde713e310a66e','piston','[ˈpistən]','http://res.iciba.com/resource/amp3/oxford/0/15/83/15830f0fd129bb3f820c503ea73955d2.mp3','n. 活塞','','');----
INSERT INTO classwords VALUES ('0639ed0c315147afaa21d330b8b1f722','086e597022bc4864a9dde713e310a66e','12');----
INSERT INTO word VALUES ('b0f9e9dbb3a948568768700e666d38ef','quiver','[ˈkwivə]','http://res.iciba.com/resource/amp3/oxford/0/5d/31/5d310baeb63b826d6faac16e2d833898.mp3','vi. 颤动；颤抖','','');----
INSERT INTO classwords VALUES ('6902e0770eb54772840b995f2923f9a2','b0f9e9dbb3a948568768700e666d38ef','12');----
INSERT INTO word VALUES ('a0ed3c179cd24aecac56e848c7b15094','improper','[ɪmˈprɔpə]','http://res.iciba.com/resource/amp3/oxford/0/3b/87/3b87e1a6d73fb90ebfea0027e6317215.mp3','adj. 不正当的；不合适的；不得体的','','');----
INSERT INTO classwords VALUES ('0a6e13fbb6ff44299a8a27c220d51735','a0ed3c179cd24aecac56e848c7b15094','12');----
INSERT INTO word VALUES ('867d3d966bf447aebd3cc6b7cc4a3c57','simple','[ˈsimpl]','http://res.iciba.com/resource/amp3/oxford/0/c5/22/c522a279b6e63507f49996e0bad1122c.mp3','adj. 简明的；朴素的；容易的；易解决...','','');----
INSERT INTO classwords VALUES ('3242833201964a0fbc8eb81052e3162d','867d3d966bf447aebd3cc6b7cc4a3c57','12');----
INSERT INTO word VALUES ('358dc86e66cb4aca89397c0218d1e612','guitar','[ɡiˈtɑ:]','http://res.iciba.com/resource/amp3/oxford/0/31/7d/317dd52e1d20803ebffb1167ecf29cfc.mp3','n. 吉他；六弦琴','','');----
INSERT INTO classwords VALUES ('26ea21bb51a54f8582b736ce70c50146','358dc86e66cb4aca89397c0218d1e612','12');----
INSERT INTO word VALUES ('56554f4760cb4e1caa08fa5a7dcf4786','shaft','[ʃɑ:ft]','http://res.iciba.com/resource/amp3/0/0/b9/5f/b95ff886d828874541332c35d7f536e2.mp3','n. 通风井；传动轴；柄，杆','','');----
INSERT INTO classwords VALUES ('85e354059e4e4275b6d4745c8ee30e47','56554f4760cb4e1caa08fa5a7dcf4786','12');----
INSERT INTO word VALUES ('a3c8bb0869b942779ba710213796c647','breakfast','[ˈbrekfəst]','http://res.iciba.com/resource/amp3/oxford/0/0b/25/0b255d53ffea1aa5bc7b885fed27a5a2.mp3','vi. 吃早餐','','');----
INSERT INTO classwords VALUES ('a114f61ff5cb4ef2a78af8fe562d9cd2','a3c8bb0869b942779ba710213796c647','12');----
INSERT INTO word VALUES ('4cb7e7bf89a041b6acca3e3ce1401db1','curly','[ˈkɜ:li:]','http://res.iciba.com/resource/amp3/0/0/d8/00/d8000efdcdd3ee172793aa6e73bcb8b4.mp3','adj. （头发）卷曲的','','');----
INSERT INTO classwords VALUES ('5745dcb6835b4cc2808cd7ffffd7c8fb','4cb7e7bf89a041b6acca3e3ce1401db1','12');----
INSERT INTO word VALUES ('4b1eca9487fd4bf790dcac4693a41fd5','inasmuch','[ˌɪnəzˈmʌtʃ]','http://res.iciba.com/resource/amp3/0/0/14/3b/143b6293eff31a8174f3f7f1c64f7052.mp3','adv. 因为，由于','','');----
INSERT INTO classwords VALUES ('8ac9d138ee2945a28450a483279fbdfd','4b1eca9487fd4bf790dcac4693a41fd5','12');----
INSERT INTO word VALUES ('ef6490e7dd074ce2981459cf9abbdb0a','roam','[rəum]','http://res.iciba.com/resource/amp3/0/0/04/b6/04b67196dc27fa8a2ea2cd80a1e83d1b.mp3','vt. 漫步；漫游；游荡','','');----
INSERT INTO classwords VALUES ('3972229e0e53465c9158676594927a6f','ef6490e7dd074ce2981459cf9abbdb0a','12');----
INSERT INTO word VALUES ('45617ac82dab44c1bfcdb8aa6213f076','precede','[ˌpriˈsi:d]','http://res.iciba.com/resource/amp3/oxford/0/d7/b6/d7b68016a9e923c9279331677c21a4c9.mp3','vi. 发生在…之前','','');----
INSERT INTO classwords VALUES ('2c9f4679037e4e99b8e3995806af5dea','45617ac82dab44c1bfcdb8aa6213f076','12');----
INSERT INTO word VALUES ('f37ff5e406be4be1af54f8f95315b39c','plastic','[ˈplɑ:stik]','http://res.iciba.com/resource/amp3/oxford/0/08/93/089329eeb5f2692b66e9e084e59cd757.mp3','adj. 不自然的；塑性的','','');----
INSERT INTO classwords VALUES ('278dadcb97184677952923695a475859','f37ff5e406be4be1af54f8f95315b39c','12');----
INSERT INTO word VALUES ('b0c00ad4bcc44d948974d60e3ac41741','formulate','[ˈfɔ:mjuleit]','http://res.iciba.com/resource/amp3/oxford/0/57/6a/576abae0e7f54a355199649defea976a.mp3','vt. 用公式表示；系统阐述；规划','','');----
INSERT INTO classwords VALUES ('a75779a179074c5a9bff0f197d1099ce','b0c00ad4bcc44d948974d60e3ac41741','12');----
INSERT INTO word VALUES ('64cf0909becf44c097ddb20abf07e9d7','crab','[kræb]','http://res.iciba.com/resource/amp3/oxford/0/8a/52/8a5219dddb2474233539ee8f14330a3c.mp3','vi. 捕蟹','','');----
INSERT INTO classwords VALUES ('24b534ae7c2049fa87e4a6e02a84d765','64cf0909becf44c097ddb20abf07e9d7','12');----
INSERT INTO word VALUES ('c14019c322c64809883f8aaf248d9296','ultimate','[ˈʌltimit]','http://res.iciba.com/resource/amp3/oxford/0/9c/49/9c491d9a2b15a836cc6a5a9fcf8137e2.mp3','adj. 最后的；最根本的；至高的','','');----
INSERT INTO classwords VALUES ('20fc5890749f4859a481ca0a6028c8ae','c14019c322c64809883f8aaf248d9296','12');----
INSERT INTO word VALUES ('1646ffd6eb9042e88ea61819ebb32478','induction','[ɪnˈdʌkʃən]','http://res.iciba.com/resource/amp3/oxford/0/60/cb/60cbf635eea088a518a326dbc75abf21.mp3','n. 就职；归纳；电磁感应','','');----
INSERT INTO classwords VALUES ('6787dbb9cf324b4f8a2682531a10c80b','1646ffd6eb9042e88ea61819ebb32478','12');----
INSERT INTO word VALUES ('bf19a1f2cbdf4dd69322e9d47a743a5c','sensation','[senˈseiʃən]','http://res.iciba.com/resource/amp3/oxford/0/7e/ba/7eba0ecc1e9461bbb0fad08a643c1817.mp3','n. 感觉，知觉；轰动','','');----
INSERT INTO classwords VALUES ('16bfdd38b23c4358bbbb8ec2391ccb81','bf19a1f2cbdf4dd69322e9d47a743a5c','12');----
INSERT INTO word VALUES ('3b9cff994d024c2eaed91e971d38e29b','bug','[bʌɡ]','http://res.iciba.com/resource/amp3/oxford/0/73/e0/73e001d735ddeebededb08cfed60cc42.mp3','n. 虫子；臭虫；小病；漏洞；窃听器','','');----
INSERT INTO classwords VALUES ('8ae3dcd0fdd24c2484eb5583de4be064','3b9cff994d024c2eaed91e971d38e29b','12');----
INSERT INTO word VALUES ('4803b158b39f4e98b0100cde34bb12fb','enchant','[inˈtʃɑ:nt]','http://res.iciba.com/resource/amp3/oxford/0/ec/bf/ecbfa2e5b6b4309fd4dc607f0a23f05c.mp3','vt. 使陶醉；使入迷；使着魔','','');----
INSERT INTO classwords VALUES ('e6f4a5c99bb64d9398c29685ba62c99f','4803b158b39f4e98b0100cde34bb12fb','12');----
INSERT INTO word VALUES ('9d55d55f2eab41bb8deeb90999250675','pop','[pɔp]','http://res.iciba.com/resource/amp3/0/0/b2/1a/b21afc54fb48d153c19101658f4a2a48.mp3','n. 流行音乐；汽水；爸爸','','');----
INSERT INTO classwords VALUES ('cefacc493e0046cf9b86f5ee24981dec','9d55d55f2eab41bb8deeb90999250675','12');----
INSERT INTO word VALUES ('0da115417bbc4cf383ebaa53e430b036','scheme','[ski:m]','http://res.iciba.com/resource/amp3/oxford/0/a9/b8/a9b86adf372e1b3d4ca7ee4166581d83.mp3','vi. 密谋，秘密策划','','');----
INSERT INTO classwords VALUES ('a7d74bf27e574b28b17826c3343acd4b','0da115417bbc4cf383ebaa53e430b036','12');----
INSERT INTO word VALUES ('3388ffd66a08451cb93d142971354582','foul','[faul]','http://res.iciba.com/resource/amp3/oxford/0/6d/fd/6dfdb9b835d0c520090fc981bdfd2620.mp3','adj. 肮脏的；恶臭的；（言语）粗俗的...','','');----
INSERT INTO classwords VALUES ('8955e8370b7940f68533277d98bdfe61','3388ffd66a08451cb93d142971354582','12');----
INSERT INTO word VALUES ('e70df0a4fd864a3b98f920924eb8853e','subscription','[səbˈskrɪpʃən]','http://res.iciba.com/resource/amp3/oxford/0/03/1f/031ff6b3bf39c01f8907013942e2736c.mp3','n. 会员费；订阅费','','');----
INSERT INTO classwords VALUES ('f68d4caf00dd40589ef1d621a40a6b90','e70df0a4fd864a3b98f920924eb8853e','12');----
INSERT INTO word VALUES ('a5aaf2f8023f4e2b841187b3d4968c6e','net','[net]','http://res.iciba.com/resource/amp3/oxford/0/48/3e/483e0c94a7f1356528a5032f50e10808.mp3','vt. 用网捕；进（球）','','');----
INSERT INTO classwords VALUES ('9e0d02b2947d4368a61f0f98430e8c1f','a5aaf2f8023f4e2b841187b3d4968c6e','12');----
INSERT INTO word VALUES ('b6b96987843042ac9314dfaf2bc7b1fe','storm','[stɔ:m]','http://res.iciba.com/resource/amp3/0/0/84/9c/849c829d658baaeff512d766b0db3cce.mp3','vt. 猛攻；袭击；怒吼','','');----
INSERT INTO classwords VALUES ('58d7170a48674fa8ad4f7a9de49327ee','b6b96987843042ac9314dfaf2bc7b1fe','12');----
INSERT INTO word VALUES ('51c960abd50f4a4091ee55bc8627e98f','charge','[tʃɑ:dʒ]','http://res.iciba.com/resource/amp3/0/0/41/a2/41a2e03f8686640344badf516a008503.mp3','vt. 索价；指控；指责；给…充电','','');----
INSERT INTO classwords VALUES ('1ce1731afa12404da599e11660af871f','51c960abd50f4a4091ee55bc8627e98f','12');----
INSERT INTO word VALUES ('a01682d4d5964898a288e7d1086e5121','quest','[kwest]','http://res.iciba.com/resource/amp3/oxford/0/13/f3/13f3bb9d9d9c7720fa3fb5d528f81dc6.mp3','n. 追求；探索','','');----
INSERT INTO classwords VALUES ('4813f22b3022468685a36a20df23e69e','a01682d4d5964898a288e7d1086e5121','12');----
INSERT INTO word VALUES ('3964271fe56248299aaacef409380ff3','stammer','[ˈstæmə]','http://res.iciba.com/resource/amp3/oxford/0/3c/43/3c439bf3d2c57ed0d3c41a5bbe097153.mp3','n. 口吃，结巴','','');----
INSERT INTO classwords VALUES ('d6a74742b501417fafd2fdc314338b29','3964271fe56248299aaacef409380ff3','12');----
INSERT INTO word VALUES ('c6b8514bbd9c4be28cf1ad4aee9d3519','dissatisfacti...','[dɪsˌsætɪsˈfækʃən]','http://res.iciba.com/resource/amp3/oxford/0/5e/fe/5efee5bffe67d9d19c77e6aa9f5c0008.mp3','n. 不满，不悦','','');----
INSERT INTO classwords VALUES ('67392b90eae14f29baa64b82304a46d7','c6b8514bbd9c4be28cf1ad4aee9d3519','12');----
INSERT INTO word VALUES ('6ed8879f36e9437c89775c39b23c3546','plead','[pli:d]','http://res.iciba.com/resource/amp3/oxford/0/7c/af/7caf3d4cdf8c2e118234c0642a0708fd.mp3','vi. 恳求','','');----
INSERT INTO classwords VALUES ('370ec3adb8d84857b78f25ca7bcc603a','6ed8879f36e9437c89775c39b23c3546','12');----
INSERT INTO word VALUES ('33b125c0d1f84e3c9d2190c94dde9405','dine','[dain]','http://res.iciba.com/resource/amp3/oxford/0/f6/ec/f6ece4016f99fee0406ef4e09ae90be3.mp3','vt. 设宴款待，请客','','');----
INSERT INTO classwords VALUES ('738c37a5341c4963af0e058c4a944e17','33b125c0d1f84e3c9d2190c94dde9405','12');----
INSERT INTO word VALUES ('c2ae96e3219d417d8a06ea0be2d27f00','prism','[ˈprɪzəm]','http://res.iciba.com/resource/amp3/oxford/0/24/63/2463ed39de9c02e297b0777037614636.mp3','n. 棱柱（体）；棱镜','','');----
INSERT INTO classwords VALUES ('450129412ade4dc7bee2fbff53f8951b','c2ae96e3219d417d8a06ea0be2d27f00','12');----
INSERT INTO word VALUES ('641b808bbe8b486cb8d69a206c5da074','timely','[ˈtaimli]','http://res.iciba.com/resource/amp3/oxford/0/13/c2/13c29bd1f0bdcb89a01e48f12307e3c9.mp3','adj. 及时的；适时的','','');----
INSERT INTO classwords VALUES ('d156ae56f56d4481b1682f4476227429','641b808bbe8b486cb8d69a206c5da074','12');----
INSERT INTO word VALUES ('0717eb8fb64a457ea006846b0a4c4d66','circus','[ˈsə:kəs]','http://res.iciba.com/resource/amp3/0/0/c5/19/c5191509f4f6afc6f1a111663950e52d.mp3','n. 马戏团；环形广场','','');----
INSERT INTO classwords VALUES ('2a9184598aeb48ceb3d2759ae1af1c34','0717eb8fb64a457ea006846b0a4c4d66','12');----
INSERT INTO word VALUES ('6682e3f60af3410a9fc1f27bcbb4ba93','proficient','[prəˈfɪʃənt]','http://res.iciba.com/resource/amp3/oxford/0/90/d6/90d6d80990a812a9b5f664b3f9c6d8ea.mp3','adj. 熟练的，精通的','','');----
INSERT INTO classwords VALUES ('e863749c9f824ff7946d7bc79393a061','6682e3f60af3410a9fc1f27bcbb4ba93','12');----
INSERT INTO word VALUES ('9336945e055c446481d61d8a86516e6c','dry','[drai]','http://res.iciba.com/resource/amp3/oxford/0/0b/fb/0bfbdff87f35ff5644d4235148fdda9a.mp3','adj. 干燥的；（皮肤或头发）发干的；...','','');----
INSERT INTO classwords VALUES ('328df36f0b634aacaf7318def900dc97','9336945e055c446481d61d8a86516e6c','12');----
INSERT INTO word VALUES ('9b9cfffe02a94aa6877884f70d167c08','hemisphere','[ˈhemiˌsfiə]','http://res.iciba.com/resource/amp3/oxford/0/c9/d8/c9d8115a6979f0b32f120f35addfe7ec.mp3','n. 半球；（大脑的）半球','','');----
INSERT INTO classwords VALUES ('9e7f75db816c43e1b6656b4c9f2c05fe','9b9cfffe02a94aa6877884f70d167c08','12');----
INSERT INTO word VALUES ('76b5368b53724e108e27ef155d28c207','skeleton','[ˈskelitn]','http://res.iciba.com/resource/amp3/oxford/0/3e/64/3e646b17219ed354c039d560d0d63fb8.mp3','n. 骨骼；轮廓；框架；梗概','','');----
INSERT INTO classwords VALUES ('da36247ddee94d0294a67f4400b3bcd3','76b5368b53724e108e27ef155d28c207','12');----
INSERT INTO word VALUES ('4dc8dd2e14324e11b71a97d49a84c6ec','conqueror','[ˈkɔŋkɵrə]','http://res.iciba.com/resource/amp3/oxford/0/cb/1e/cb1e0f4763cf57b5173f2f17a8077fb0.mp3','n. 征服者；（比赛的）胜利者','','');----
INSERT INTO classwords VALUES ('a3341e5fe6304b84a247ca6291104a67','4dc8dd2e14324e11b71a97d49a84c6ec','12');----
INSERT INTO word VALUES ('74d93c91c12b4af1abaf29aaa8ce8550','rule','[ru:l]','http://res.iciba.com/resource/amp3/oxford/0/60/4a/604aa09675b3de6db2ce0fef02d391cb.mp3','n. 规则；习惯；统治','','');----
INSERT INTO classwords VALUES ('1b5585c0037b4360a8457e5403f4f196','74d93c91c12b4af1abaf29aaa8ce8550','12');----
INSERT INTO word VALUES ('0072afcf6d274acfb64db8138c10229a','headlong','[ˈhedˈlɔ:ŋ]','http://res.iciba.com/resource/amp3/oxford/0/c1/c1/c1c1f7c0799e0d21281069f1a939403d.mp3','adv. 快速地；头朝下地；轻率地','','');----
INSERT INTO classwords VALUES ('99070e265f714ce2a1a7439b37752fb8','0072afcf6d274acfb64db8138c10229a','12');----
INSERT INTO word VALUES ('48ea9e4723694f648ae574493fc168db','wrestle','[ˈresl]','http://res.iciba.com/resource/amp3/oxford/0/42/e1/42e177db80912e03f7440cbf34854796.mp3','v. 摔跤；用力移动；试图解决','','');----
INSERT INTO classwords VALUES ('8ee7b2e431c6496aab5ad96a82abb2a1','48ea9e4723694f648ae574493fc168db','12');----
INSERT INTO word VALUES ('2a476de6b9cd4cb8b0b2c301890added','sardine','[sɑ:ˈdi:n]','http://res.iciba.com/resource/amp3/oxford/0/4d/ce/4dcec4c44874f94793dd30a41534a52f.mp3','n. 沙丁鱼','','');----
INSERT INTO classwords VALUES ('619f72b7d0b148d9a5c8f8e6baf8af2f','2a476de6b9cd4cb8b0b2c301890added','12');----
INSERT INTO word VALUES ('2a98b96578a74271ab94167656aefdfc','fore','[fɔː(r)]','http://res.iciba.com/resource/amp3/oxford/0/35/8c/358c8dddeb01e5741cf23c9781d8609e.mp3','adj. 前部的，前端的','','');----
INSERT INTO classwords VALUES ('ebeb5f7731464526b76d1fa534bfe640','2a98b96578a74271ab94167656aefdfc','12');----
INSERT INTO word VALUES ('feaaaaa1b276409980952e3b88bffd76','astonishment','[əˈstɔnɪʃmənt]','http://res.iciba.com/resource/amp3/oxford/0/6e/38/6e38cdb2c359808fe74739655852a635.mp3','n. 惊奇，惊讶','','');----
INSERT INTO classwords VALUES ('37fd36a4998a4d78ab5f88a9fd413bf0','feaaaaa1b276409980952e3b88bffd76','12');----
INSERT INTO word VALUES ('3e9d61027dab45bebca86c35bdbc4bcd','oblige','[əˈblaidʒ]','http://res.iciba.com/resource/amp3/oxford/0/02/70/027046bb2630c3a0590d463c8656c1a5.mp3','vt. 使感激；施恩惠于；强迫，迫使','','');----
INSERT INTO classwords VALUES ('d0ebdf69a3e74a54a439ad1c9ab1fd89','3e9d61027dab45bebca86c35bdbc4bcd','12');----
INSERT INTO word VALUES ('326f0fa22dc7448c9abde0c0aa21852e','snobbish','[ˈsnɔbɪʃ]','http://res.iciba.com/resource/amp3/oxford/0/ea/76/ea763193a0a78a3da941a8300eb59945.mp3','adj. 势利的，过分自傲的','','');----
INSERT INTO classwords VALUES ('d23b36745dcb4125a22c8385e8863ca4','326f0fa22dc7448c9abde0c0aa21852e','12');----
INSERT INTO word VALUES ('2bc76d09f47347b3ad3caf6710fd0cec','prohibition','[ˌprəʊəˈbɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/3b/05/3b0547b5192062c17b3622137384e728.mp3','n. 禁令，禁律','','');----
INSERT INTO classwords VALUES ('c554edf9d167435db15de2b2d8debb38','2bc76d09f47347b3ad3caf6710fd0cec','12');----
INSERT INTO word VALUES ('3c803df0483a483582fee9bd96ec71ec','opium','[ˈəʊpi:əm]','http://res.iciba.com/resource/amp3/oxford/0/10/32/1032c4ed004336b16f6ab7e4ac3ea081.mp3','n. 鸦片','','');----
INSERT INTO classwords VALUES ('4e6fdf1bc00e4453bd1652e6cb9e41aa','3c803df0483a483582fee9bd96ec71ec','12');----
INSERT INTO word VALUES ('0e233ddd544f4204ba88ecb06e8c3342','impart','[imˈpɑ:t]','http://res.iciba.com/resource/amp3/0/0/4b/23/4b234a4d0cf9437a228ebb0fff9e3920.mp3','vt. 给予；传递；告知','','');----
INSERT INTO classwords VALUES ('2ebb7eb8e5a74f11a89953f269baeaec','0e233ddd544f4204ba88ecb06e8c3342','12');----
INSERT INTO word VALUES ('ca40103dc2dd4b169c8b4eabb7ece9b0','calculus','[ˈkælkjələs]','http://res.iciba.com/resource/amp3/oxford/0/77/30/7730c53abe5142f3c0cc68f133ea084c.mp3','n. 微积分；结石','','');----
INSERT INTO classwords VALUES ('4c0d874a60bf42cfb803daf1188197d0','ca40103dc2dd4b169c8b4eabb7ece9b0','12');----
INSERT INTO word VALUES ('fb3bcb3c1c3c496292e2917e22ecff9d','dismiss','[disˈmis]','http://res.iciba.com/resource/amp3/oxford/0/51/8b/518b9f8fd931787a2a96ba84b7928886.mp3','vt. 不理会；（从头脑中）去除；解雇；...','','');----
INSERT INTO classwords VALUES ('1dd8213ce2c94b88b4ba61021108f1b9','fb3bcb3c1c3c496292e2917e22ecff9d','12');----
INSERT INTO word VALUES ('55a3598bbca3456086f05c417ef5fb1d','ice','[ais]','http://res.iciba.com/resource/amp3/oxford/0/6e/52/6e52a044c0a682527483f23f76aaf493.mp3','n. 冰块；雪糕','','');----
INSERT INTO classwords VALUES ('023f7f40d74542568af8d579d657ae56','55a3598bbca3456086f05c417ef5fb1d','12');----
INSERT INTO word VALUES ('95fea3b591da471da753c79b23176fdc','morality','[məˈræliti]','http://res.iciba.com/resource/amp3/oxford/0/ec/ef/ecefbce4cf8a90737b51cd3209b2dd01.mp3','n. 道德；道德规范','','');----
INSERT INTO classwords VALUES ('c718343833034b00adff1afe082a3a26','95fea3b591da471da753c79b23176fdc','12');----
INSERT INTO word VALUES ('e335e307a4e24c439e285909c367d64e','episode','[ˈepisəud]','http://res.iciba.com/resource/amp3/oxford/0/18/30/18303a404c10f65eb5b6e03017a60141.mp3','n. 插曲；（广播剧或电视剧的）一集；患...','','');----
INSERT INTO classwords VALUES ('452e71ce347c47d3bcd0f13d4968cd39','e335e307a4e24c439e285909c367d64e','12');----
INSERT INTO word VALUES ('9bb80be082c14b6f8c6453b9b1030a1f','bulletin','[ˈbulitin]','http://res.iciba.com/resource/amp3/oxford/0/8b/31/8b31fe13869dc20076df3f08cca2d9a1.mp3','n. 布告，公告，公报；简明新闻','','');----
INSERT INTO classwords VALUES ('71ffc2473a65414e9657727b93fe87c8','9bb80be082c14b6f8c6453b9b1030a1f','12');----
INSERT INTO word VALUES ('f4d0293e6baf499f935360bcc4d0dc7f','insert','[inˈsə:t]','http://res.iciba.com/resource/amp3/0/0/e0/df/e0df5f3dfd2650ae5be9993434e2b2c0.mp3','vt. 插入；嵌入；（在文章中）添加','','');----
INSERT INTO classwords VALUES ('170325aa31bf46d9bcf345799144709e','f4d0293e6baf499f935360bcc4d0dc7f','12');----
INSERT INTO word VALUES ('91c20a070ed14e16a3a54495589e9f87','deliberately','[dɪˈlɪbərɪtlɪ]','http://res.iciba.com/resource/amp3/oxford/0/38/7c/387cebc8656a177c07f60a12b5cf0327.mp3','adv. 审慎地；故意地，蓄意地','','');----
INSERT INTO classwords VALUES ('93a7f7d9a819406781381670a0effeaf','91c20a070ed14e16a3a54495589e9f87','12');----
INSERT INTO word VALUES ('2a84ff7d1fef4aa0b680a633490ca73d','multitude','[ˈmʌltitju:d]','http://res.iciba.com/resource/amp3/oxford/0/51/c7/51c766f2b4b5a7b044e622438ba2a182.mp3','n. 人群；大量，许多；大众','','');----
INSERT INTO classwords VALUES ('af9c225e5914439588757d26590aa455','2a84ff7d1fef4aa0b680a633490ca73d','12');----
INSERT INTO word VALUES ('9574398c43c140858f1a72774da1aadb','interpret','[inˈtə:prit]','http://res.iciba.com/resource/amp3/oxford/0/38/15/3815350c225173b9b37210c4a0f2475d.mp3','vi. 口译','','');----
INSERT INTO classwords VALUES ('e11a84c2e30f43fb84b569f1667c2421','9574398c43c140858f1a72774da1aadb','12');----
INSERT INTO word VALUES ('405c368fe1be4c0bb1a9620ccfd5a696','participant','[pɑ:ˈtisipənt]','http://res.iciba.com/resource/amp3/oxford/0/34/c1/34c172f42bd5d9a315ef11895bf4b445.mp3','adj. 参加的','','');----
INSERT INTO classwords VALUES ('6d98f6c38a4944a29b18957905987842','405c368fe1be4c0bb1a9620ccfd5a696','12');----
INSERT INTO word VALUES ('8223b380491f4ab695d80409c34a57fe','inclusive','[inˈklu:siv]','http://res.iciba.com/resource/amp3/oxford/0/b5/1e/b51e2810a04e8c74b9a3a76a14fc24ce.mp3','adj. 包括一切费用在内的；包括的；包...','','');----
INSERT INTO classwords VALUES ('57773299979048bf9469d8a7edc1103a','8223b380491f4ab695d80409c34a57fe','12');----
INSERT INTO word VALUES ('a0b9586806d24fe6b0690b27ea5f2f7a','oyster','[ˈɔistə]','http://res.iciba.com/resource/amp3/oxford/0/f0/12/f0124c65ee853d7336156ad9dae92bcf.mp3','n. 牡蛎；蚝','','');----
INSERT INTO classwords VALUES ('647622f17f4848508c37f4a551e8f6c3','a0b9586806d24fe6b0690b27ea5f2f7a','12');----
INSERT INTO word VALUES ('5bd7bc28de9240a995ba70b5e96926d9','hitherto','[ˌhiðəˈtu:]','http://res.iciba.com/resource/amp3/0/0/f8/1b/f81b826dc69b6d0b745f258d8a3cd0d7.mp3','adv. 迄今，到目前为止','','');----
INSERT INTO classwords VALUES ('32ce180767324a5db051b4dac6378703','5bd7bc28de9240a995ba70b5e96926d9','12');----
INSERT INTO word VALUES ('99283718aab74786ae561edac48ef54c','mingle','[ˈmiŋɡl]','http://res.iciba.com/resource/amp3/oxford/0/3c/6b/3c6bbb1642ff45b5faa2dd4b88e552b0.mp3','vi. 混合；应酬','','');----
INSERT INTO classwords VALUES ('e998e6ce8a2e425b828cdeeb32baa226','99283718aab74786ae561edac48ef54c','12');----
INSERT INTO word VALUES ('0b86989b0541461eb0a893f1223ce987','catalyst','[ˈkætlɪst]','http://res.iciba.com/resource/amp3/oxford/0/3e/09/3e094e7a056f4135303b0aa182e761bc.mp3','n. 催化剂，触媒；诱因','','');----
INSERT INTO classwords VALUES ('fdbf47a557de4bce8382c93e851c8252','0b86989b0541461eb0a893f1223ce987','12');----
INSERT INTO word VALUES ('29b8330edd514fdb88d2139296697c6b','experimentati...','[ɪkˌsperəmenˈteɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/e2/25/e225aaa0dbae292538c5bcebb914da4e.mp3','n. 实验，试验；实验法','','');----
INSERT INTO classwords VALUES ('31805dba963e4611b97888c6de926bb5','29b8330edd514fdb88d2139296697c6b','12');----
INSERT INTO word VALUES ('3ac2af54ffc54d3f97ebf0ffc05a82ae','beforehand','[biˈfɔ:hænd]','http://res.iciba.com/resource/amp3/oxford/0/55/7f/557f754cd7a42eaae9043fc66163e83d.mp3','adv. 预先；提前','','');----
INSERT INTO classwords VALUES ('dfb04f66fe4348f7bedcb8915313210e','3ac2af54ffc54d3f97ebf0ffc05a82ae','12');----
INSERT INTO word VALUES ('41cadcf67dd24167901c7dcf8fdae9ff','commonwealth','[ˈkɔmənwelθ]','http://res.iciba.com/resource/amp3/oxford/0/0c/a1/0ca197db098a2280fefdd3b5cfc1f732.mp3','n. 共和国；联邦；团体，协会','','');----
INSERT INTO classwords VALUES ('908d640c1f304802917621c7634e3f38','41cadcf67dd24167901c7dcf8fdae9ff','12');----
INSERT INTO word VALUES ('8d9b9af07e10410ca81c314cf4044b53','length','[leŋθ]','http://res.iciba.com/resource/amp3/oxford/0/0c/29/0c29b9cc659c5bb4fac88c7db05df291.mp3','n. 长度；篇幅；时间的长短；一段，一节...','','');----
INSERT INTO classwords VALUES ('41721fd950df4204afccf829338d97c2','8d9b9af07e10410ca81c314cf4044b53','12');----
INSERT INTO word VALUES ('a88276636c9544adb39387cd297d1e10','collaborate','[kəˈlæbəˌreɪt]','http://res.iciba.com/resource/amp3/oxford/0/bf/26/bf26f2f90da2f2897a53bb593993f806.mp3','vi. 协作，合作；通敌','','');----
INSERT INTO classwords VALUES ('71fb43435120492da5fdf00771406915','a88276636c9544adb39387cd297d1e10','12');----
INSERT INTO word VALUES ('45a005d14b7747a4926c520533453f4a','satellite','[ˈsætəlait]','http://res.iciba.com/resource/amp3/oxford/0/95/60/956004f5a6afe37735a435779f479dc5.mp3','n. 人造卫星；卫星；卫星国','','');----
INSERT INTO classwords VALUES ('f08f5fe8a5754cd18bee2e7e76404765','45a005d14b7747a4926c520533453f4a','12');----
INSERT INTO word VALUES ('f057f025a9bf40e793bbc6f361330e85','bushel','[ˈbʊʃəl]','http://res.iciba.com/resource/amp3/oxford/0/f3/8d/f38d6ef80c1720ef4e6773a3526f1b0d.mp3','n. 蒲式耳（容量单位）；大量','','');----
INSERT INTO classwords VALUES ('00cbfa543e7c4706bb8b98a1e1809272','f057f025a9bf40e793bbc6f361330e85','12');----
INSERT INTO word VALUES ('c2374a21bf7649ecbce4ef408e27ef8f','fighter','[ˈfaɪtə]','http://res.iciba.com/resource/amp3/oxford/0/86/ba/86ba97b415f5d6bc7c26b59e71e33425.mp3','n. 奋斗者；战斗机；战士；打架者','','');----
INSERT INTO classwords VALUES ('187e56635e504dc7b4174eba47d80f7c','c2374a21bf7649ecbce4ef408e27ef8f','12');----
INSERT INTO word VALUES ('c2cd69524d10478283cae4035a08971f','inversely','','http://res.iciba.com/resource/amp3/1/0/27/c0/27c0720e125476d5662465ab56cdcd01.mp3','adv. 相反地','','');----
INSERT INTO classwords VALUES ('3b785bcc52c74049b9d583acaa07aebf','c2cd69524d10478283cae4035a08971f','12');----
INSERT INTO word VALUES ('e94d6cf2ba3f4b638e3ffe84b2b34593','shrimp','[ʃrimp]','http://res.iciba.com/resource/amp3/oxford/0/b9/4b/b94b08b71d31d9d79a4646257c0fd418.mp3','n. 小虾，虾','','');----
INSERT INTO classwords VALUES ('f68dc6363d4f4bf2b4259bf4e8b55638','e94d6cf2ba3f4b638e3ffe84b2b34593','12');----
INSERT INTO word VALUES ('238ee7debb464cd3bec0e66d3173d3af','clockwise','[ˈklɔkwaiz]','http://res.iciba.com/resource/amp3/oxford/0/07/6c/076cafbede152c7ce604f40b7eddde1c.mp3','adj. 顺时针方向的','','');----
INSERT INTO classwords VALUES ('4c761e00a0054ed49593fd2887bb287a','238ee7debb464cd3bec0e66d3173d3af','12');----
INSERT INTO word VALUES ('61b977d6fc604c3f954e5967f7a6c428','tribute','[ˈtribju:t]','http://res.iciba.com/resource/amp3/oxford/0/9d/87/9d8766d51e88ecc73a5c16979128bbd3.mp3','n. 献礼；致敬；体现','','');----
INSERT INTO classwords VALUES ('585302dcbeaf4414ae8659db9b1117b9','61b977d6fc604c3f954e5967f7a6c428','12');----
INSERT INTO word VALUES ('33a8f19a60d74035a22a9425d3bd87ab','lessen','[ˈlesən]','http://res.iciba.com/resource/amp3/oxford/0/da/c3/dac332480d9b021abd87d37744cffa20.mp3','vi. 变少，减少','','');----
INSERT INTO classwords VALUES ('6b238a791de94833b9f82919ecf4906b','33a8f19a60d74035a22a9425d3bd87ab','12');----
INSERT INTO word VALUES ('20911b1a0ff84d04bbce0c67caa5aa07','elbow','[ˈelbəu]','http://res.iciba.com/resource/amp3/oxford/0/9f/66/9f661b8a37353af0c4ed6fac85b891a9.mp3','vt. 用肘挤；挤掉；跻身','','');----
INSERT INTO classwords VALUES ('a396ab4dc5d840ba94649ac2eb7f17c0','20911b1a0ff84d04bbce0c67caa5aa07','12');----
INSERT INTO word VALUES ('98959f15f0ae41668a9e01a1b848557e','henceforth','[ˈhensˈfɔ:θ]','http://res.iciba.com/resource/amp3/oxford/0/3c/b5/3cb5f1e549b83d54eb773f8eec6fad2a.mp3','adv. 今后，从今以后','','');----
INSERT INTO classwords VALUES ('5ccba884796b4bc2bc15b3edb54024cc','98959f15f0ae41668a9e01a1b848557e','12');----
INSERT INTO word VALUES ('8f8223e2842243e18076ccddc9bfa3b0','millionaire','[ˌmiljəˈnɛə]','http://res.iciba.com/resource/amp3/oxford/0/f9/4a/f94a6c96d42c5e318accb6ab49046e10.mp3','n. 百分富翁；大财主','','');----
INSERT INTO classwords VALUES ('2c15f4f60f584d67b4d179177f08ddd6','8f8223e2842243e18076ccddc9bfa3b0','12');----
INSERT INTO word VALUES ('9850c6fd34a4435cb1d18f8c250a0fb9','extinguish','[iksˈtiŋɡwiʃ]','http://res.iciba.com/resource/amp3/oxford/0/89/fe/89fe844899c7c75a32293067f568e221.mp3','vt. 熄灭，扑灭；消除','','');----
INSERT INTO classwords VALUES ('7d1d45223ba941669f6b6e0016843bf6','9850c6fd34a4435cb1d18f8c250a0fb9','12');----
INSERT INTO word VALUES ('0d7d202ef39546f299c36b8fde40f0ea','polarity','[pəʊˈlærɪti:]','http://res.iciba.com/resource/amp3/oxford/0/87/d6/87d64d0483b903f1779f50d91d119985.mp3','n. 极性；截然对立','','');----
INSERT INTO classwords VALUES ('707e39a216a34a6781604dc4e44ce0f2','0d7d202ef39546f299c36b8fde40f0ea','12');----
INSERT INTO word VALUES ('52a12c82bee8494b8e9315c0a29b9124','representatio...','[ˌreprɪzenˈteɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/91/cc/91ccfe9c4655d00d7f79f899fe7c20eb.mp3','n. 描写，描绘；代表','','');----
INSERT INTO classwords VALUES ('a77e3b6110e44ef797862ebd90c1a5d4','52a12c82bee8494b8e9315c0a29b9124','12');----
INSERT INTO word VALUES ('bb69e63a5bab46d2bdffc754358c622c','atom','[ˈætəm]','http://res.iciba.com/resource/amp3/oxford/0/bc/77/bc777bd3ed41e286d2fbf7e58cee3775.mp3','n. 微粒；原子','','');----
INSERT INTO classwords VALUES ('5f4d327aaef748449667d174d371c4d2','bb69e63a5bab46d2bdffc754358c622c','12');----
INSERT INTO word VALUES ('9c1e70ef09404a03bfc6b963f733dce7','disgrace','[disˈɡreis]','http://res.iciba.com/resource/amp3/oxford/0/95/5e/955ef00b3ff5d180f4efc1799a620424.mp3','n. 丢脸；耻辱；不光彩；丢脸的人（或事...','','');----
INSERT INTO classwords VALUES ('2443ea7460e9442d983d51ecf2cb8697','9c1e70ef09404a03bfc6b963f733dce7','12');----
INSERT INTO word VALUES ('712e7519de414623a49db0044f61f943','wither','[ˈwiðə]','http://res.iciba.com/resource/amp3/oxford/0/f7/2f/f72f1e9744f12a36505583179bc595fb.mp3','vt. 使衰弱','','');----
INSERT INTO classwords VALUES ('80f66d878f2441d0ad2235ed8e045846','712e7519de414623a49db0044f61f943','12');----
INSERT INTO word VALUES ('4b9bb81f5b67488d93f5872df8a30a8c','moderately','[ˈmɔdərətlɪ]','http://res.iciba.com/resource/amp3/oxford/0/91/a4/91a4917d51e5f15c41b9a8d0ff5e30e5.mp3','adv. 适度地；普通地','','');----
INSERT INTO classwords VALUES ('e2d72b25d4ab42538189bd8ef772904a','4b9bb81f5b67488d93f5872df8a30a8c','12');----
INSERT INTO word VALUES ('cc6a5943657242f49b0e9e95376820a5','cite','[sait]','http://res.iciba.com/resource/amp3/oxford/0/3f/eb/3feb8c1f8763d0f8bc287683338a36e5.mp3','vt. 引用；引证；传讯','','');----
INSERT INTO classwords VALUES ('af6e3f42a48946efb59872f83d0b3a82','cc6a5943657242f49b0e9e95376820a5','12');----
INSERT INTO word VALUES ('060f3bd05236421aa9a0f6f0fc2b009f','constitution','[ˌkɔnstiˈtju:ʃən]','http://res.iciba.com/resource/amp3/1/0/44/8b/448b62646e4daf34e38cfced0eaa1a0f.mp3','n. 体格，体质；宪法','','');----
INSERT INTO classwords VALUES ('3eeef02b9f8d499ab3ffe97fcc12a8b6','060f3bd05236421aa9a0f6f0fc2b009f','12');----
INSERT INTO word VALUES ('2301141bfce64a60b48b0ae08c51266e','cautious','[ˈkɔ:ʃəs]','http://res.iciba.com/resource/amp3/oxford/0/fb/64/fb64da7a6223f716ad0937bce46d57c1.mp3','adj. 小心的，谨慎的','','');----
INSERT INTO classwords VALUES ('c763b90a077c4df691d31ed0205493c9','2301141bfce64a60b48b0ae08c51266e','12');----
INSERT INTO word VALUES ('68848e41e4bf4f0395f10509051d70c2','conception','[kənˈsepʃən]','http://res.iciba.com/resource/amp3/oxford/0/ee/e5/eee5a13426ad2a966c1d3d2fcefd1b8f.mp3','n. 概念，观念；构想，设想；受孕','','');----
INSERT INTO classwords VALUES ('cbc33796af6144d18b1191a4eac89d9b','68848e41e4bf4f0395f10509051d70c2','12');----
INSERT INTO word VALUES ('c6a54591556f45d2855c51d99fe735ff','lipstick','[ˈlipstik]','http://res.iciba.com/resource/amp3/oxford/0/ed/c5/edc5279d1e3f3312b6095e915414b951.mp3','n. 唇膏，口红','','');----
INSERT INTO classwords VALUES ('0b8675afd8754b02bc8efa6dcf5ffbc8','c6a54591556f45d2855c51d99fe735ff','12');----
INSERT INTO word VALUES ('8e4302254ea84f74998f4c76d9e80986','harsh','[hɑ:ʃ]','http://res.iciba.com/resource/amp3/0/0/d4/e3/d4e3730e8cba214f85cddae5f9331d74.mp3','adj. 粗糙的；严厉的；刺耳的，难听的...','','');----
INSERT INTO classwords VALUES ('60133eaced694e7fac3cc4d135bfb0d0','8e4302254ea84f74998f4c76d9e80986','12');----
INSERT INTO word VALUES ('5232229ef9364e8d9ef2dfb21342f81b','incense','','http://res-tts.iciba.com/9/c/e/9ce99053013be668130ba839f54ebca6.mp3','v. 使愤怒，激怒','','');----
INSERT INTO classwords VALUES ('55c98f50c7fb480a8fc51069d566746c','5232229ef9364e8d9ef2dfb21342f81b','12');----
INSERT INTO word VALUES ('4aa4b6019c4f40329d93e59c7a9721c6','diverge','[dɪˈvɜ:dʒ]','http://res.iciba.com/resource/amp3/oxford/0/76/7d/767d72b2b5d545bc345b5e5208052fe5.mp3','vi. 偏离，背离；存在分歧；分开，叉开','','');----
INSERT INTO classwords VALUES ('bff5dfe786bd40688ac8c6b74ef902a1','4aa4b6019c4f40329d93e59c7a9721c6','12');----
INSERT INTO word VALUES ('08f46f8f75f548a0975974fb49dfe530','entry','[ˈentri]','http://res.iciba.com/resource/amp3/oxford/0/10/b5/10b5ae8879aa453170f24b0358cdd2dd.mp3','n. 进入权；参加；参赛人数；参赛；入口','','');----
INSERT INTO classwords VALUES ('48ba92e45ced4316975f329a9c034e37','08f46f8f75f548a0975974fb49dfe530','12');----
INSERT INTO word VALUES ('76d061892c5a4c07b4e2e07de681cfb2','vow','[vaʊ]','http://res.iciba.com/resource/amp3/oxford/0/de/02/de02d81872d76489b8041062374fea84.mp3','n. 誓言；誓约','','');----
INSERT INTO classwords VALUES ('2e09b6a7999944e189b8202eaecedefd','76d061892c5a4c07b4e2e07de681cfb2','12');----
INSERT INTO word VALUES ('567ab494159a4f94b562145a0d77e986','grease','[ɡri:s]','http://res.iciba.com/resource/amp3/oxford/0/ca/7f/ca7f4b01962bdc3b574a7e94c95bc04e.mp3','n. 动物油脂；（皮肤分泌的）油脂；润滑...','','');----
INSERT INTO classwords VALUES ('4c92a99983854380a62596095e58ee8a','567ab494159a4f94b562145a0d77e986','12');----
INSERT INTO word VALUES ('8b47eae0516648b895eaf7cc7dc75e53','tuna','[ˈtu:nə]','http://res.iciba.com/resource/amp3/0/0/2b/f9/2bf93a8a979420ff77b32fab0751cad2.mp3','n. 金枪鱼','','');----
INSERT INTO classwords VALUES ('c0340ffad2da43538e5ee67ea45f2963','8b47eae0516648b895eaf7cc7dc75e53','12');----
INSERT INTO word VALUES ('14b7f09b3217470f813af716a0ee2d47','microprocesso...','[ˈmaɪkrəʊˌprɔsesə]','http://res.iciba.com/resource/amp3/oxford/0/41/2a/412a5ba5ac398b9bf081402cf5321ccd.mp3','n. 微处理器','','');----
INSERT INTO classwords VALUES ('c8004ae06c7d453c8346603602b65fb2','14b7f09b3217470f813af716a0ee2d47','12');----
INSERT INTO word VALUES ('f14ce611332b4d1d9d6996503f668d88','combustion','[kəmˈbʌstʃən]','http://res.iciba.com/resource/amp3/oxford/0/5a/c2/5ac2c88ce9a803fe222682cb2f1136ee.mp3','n. 燃烧，烧毁','','');----
INSERT INTO classwords VALUES ('fc83e6e118df4d9aa295b7c9da4aebc9','f14ce611332b4d1d9d6996503f668d88','12');----
INSERT INTO word VALUES ('12ebe83c0e8d49b689083b97dec447ae','degradation','[ˌdegrəˈdeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/6b/b3/6bb3bb025655ed273e60aa180b8d48d6.mp3','n. 降级；退化；堕落；衰退','','');----
INSERT INTO classwords VALUES ('1afb5585e8a54749b4fa3b8e885661ec','12ebe83c0e8d49b689083b97dec447ae','12');----
INSERT INTO word VALUES ('86bea73042ac4349a9828bf7e9b9de17','indignation','[ˌɪndiɡˈneiʃən]','http://res.iciba.com/resource/amp3/oxford/0/71/d6/71d6c727fa9f576eda6d5848dd3bfffa.mp3','n. 愤怒，愤慨，义愤','','');----
INSERT INTO classwords VALUES ('572492d7f292463fb750a6d67c06af1f','86bea73042ac4349a9828bf7e9b9de17','12');----
INSERT INTO word VALUES ('b36776af604e4bd29d6e1f5cba8388d6','hull','[hʌl]','http://res.iciba.com/resource/amp3/oxford/0/fe/9e/fe9ea8ea7e929b71781fe9ab183373c7.mp3','n. 船体；花萼','','');----
INSERT INTO classwords VALUES ('bff47da934cc45dcab74316515193b59','b36776af604e4bd29d6e1f5cba8388d6','12');----
INSERT INTO word VALUES ('9189358d2bcb4126b35f6c4daa8150c8','fascinate','[ˈfæsineit]','http://res.iciba.com/resource/amp3/oxford/0/60/a7/60a76d241b0e03b17e3fd6686a9e29ea.mp3','vi. 入迷','','');----
INSERT INTO classwords VALUES ('8780ebad8bb44fc8a2cef4444ae39c6b','9189358d2bcb4126b35f6c4daa8150c8','12');----
INSERT INTO word VALUES ('0866f6739ce44c789934deaee5d7bd5f','shutter','[ˈʃʌtə]','http://res.iciba.com/resource/amp3/oxford/0/02/ec/02ecc8856350aac5c862d4491d5d90c1.mp3','n. 百叶窗；（相机）快门','','');----
INSERT INTO classwords VALUES ('4d9498c9ba684687826f642b0c1b4c3e','0866f6739ce44c789934deaee5d7bd5f','12');----
INSERT INTO word VALUES ('a25aeca410cd4bf986524ec2bb2817e6','ample','[ˈæmpl]','http://res.iciba.com/resource/amp3/oxford/0/78/25/782567e957567dff662078a45c699f97.mp3','adj. 充裕的；丰富的；宽敞的','','');----
INSERT INTO classwords VALUES ('25f9223ed8ac4dd7a101e5a4d9a7c9d4','a25aeca410cd4bf986524ec2bb2817e6','12');----
INSERT INTO word VALUES ('02b27eebc0cf44eea1b85cfadcdcec18','similarity','[ˌsɪməˈlærɪti:]','http://res.iciba.com/resource/amp3/oxford/0/20/6b/206b687ccd48715175e9c41153b9bc05.mp3','n. 类似，相似；相似点','','');----
INSERT INTO classwords VALUES ('7af1278995b54adfa81cfdf0a5a5de58','02b27eebc0cf44eea1b85cfadcdcec18','12');----
INSERT INTO word VALUES ('d7086bf27d3948dd9854215a4683172a','largely','[ˈlɑ:dʒli]','http://res.iciba.com/resource/amp3/0/0/b7/46/b7465ad9caf96c65273dfaa4bfb691e4.mp3','adv. 大致上；主要地','','');----
INSERT INTO classwords VALUES ('bd51e995b3fe49dab0f695e12728b0ba','d7086bf27d3948dd9854215a4683172a','12');----
INSERT INTO word VALUES ('fe794103449f4cec9133b01ed12005a5','distract','[disˈtrækt]','http://res.iciba.com/resource/amp3/oxford/0/8a/64/8a64b8188502bcc3a7b341ce92c1a80b.mp3','vt. 分散（心思）；使分心','','');----
INSERT INTO classwords VALUES ('1b858197836d4d3c9bb38cf22baea2a6','fe794103449f4cec9133b01ed12005a5','12');----
INSERT INTO word VALUES ('56c77de81fd34c599cccc9a5164a0384','stubborn','[ˈstʌbən]','http://res.iciba.com/resource/amp3/oxford/0/5d/cd/5dcddf102dd571587990a4354dfa8c0c.mp3','adj. 顽固的，固执的','','');----
INSERT INTO classwords VALUES ('c454c9cd930d4dbb877f4b9d9d5662c8','56c77de81fd34c599cccc9a5164a0384','12');----
INSERT INTO word VALUES ('61441ccd15b24c419ce01c9c9c774fec','exclamation','[ˌekskləˈmeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/b8/eb/b8ebe0369135b2ead60b4a205f477273.mp3','n. 呼喊，惊叫；感叹；感叹语；感叹词','','');----
INSERT INTO classwords VALUES ('17c158aca4e546f49cecf7bbea392b2b','61441ccd15b24c419ce01c9c9c774fec','12');----
INSERT INTO word VALUES ('d0dc5de649d04b17b09fe9d1068580a6','virtual','[ˈvə:tjuəl]','http://res.iciba.com/resource/amp3/oxford/0/31/4e/314e639555fe0f158539c7e04e7ddad6.mp3','adj. 实际上的；几乎的；虚拟的','','');----
INSERT INTO classwords VALUES ('1667c9675e064bf59cebd618df80535a','d0dc5de649d04b17b09fe9d1068580a6','12');----
INSERT INTO word VALUES ('eda56b7c7f444b8bb39326ee5561767e','censor','[ˈsensə]','http://res.iciba.com/resource/amp3/oxford/0/c4/1e/c41e31815723cc941c4eabe305c98019.mp3','vt. 审查，检查','','');----
INSERT INTO classwords VALUES ('9742aeceb75643f7a83f715952f9f346','eda56b7c7f444b8bb39326ee5561767e','12');----
INSERT INTO word VALUES ('3e4db04cbccf46819b0b9330118be651','pants','','http://res.iciba.com/resource/amp3/oxford/0/7d/ae/7dae6605c9a1288fe466067009bc1c28.mp3','n. 裤子；短裤','','');----
INSERT INTO classwords VALUES ('21662c02bcf34bb785876c6be2dbb683','3e4db04cbccf46819b0b9330118be651','12');----
INSERT INTO word VALUES ('61fb5b505bd749e8ae60162c5da1ee06','extraordinari...','[ɪksˈtrɔ:dnrɪlɪ]','http://res.iciba.com/resource/amp3/0/0/49/aa/49aa727e9b8f51e0773520816004caef.mp3','adv. 非常，格外地','','');----
INSERT INTO classwords VALUES ('279b6341b4e24f04a6d55ba058cad1dc','61fb5b505bd749e8ae60162c5da1ee06','12');----
INSERT INTO word VALUES ('4a284e0a8c4a465fa16345de5079addb','fort','[fɔ:t]','http://res.iciba.com/resource/amp3/0/0/f2/6c/f26cfe5b0596bb5077db7f7c0e19d9e5.mp3','n. 要塞，堡垒','','');----
INSERT INTO classwords VALUES ('63b27bbeb65a4f599963ace11e97562d','4a284e0a8c4a465fa16345de5079addb','12');----
INSERT INTO word VALUES ('7c0935627b694c5d938b464ff82b21a3','distortion','[dɪˈstɔ:ʃən]','http://res.iciba.com/resource/amp3/0/0/db/19/db19f13fc4785697b53043bdfd4823ab.mp3','n. 曲解，歪曲；畸变；变形','','');----
INSERT INTO classwords VALUES ('4fae81c5fc5d4e20bf4bd2a1e78e9fbf','7c0935627b694c5d938b464ff82b21a3','12');----
INSERT INTO word VALUES ('f41e06181aed42d4a6d3175b346dbd68','impartial','[ɪmˈpɑ:ʃəl]','http://res.iciba.com/resource/amp3/0/0/c5/26/c526681b295049215e5f1c2066639f4a.mp3','adj. 公正的，无偏见的','','');----
INSERT INTO classwords VALUES ('bcf6fba4cc5a48759eda4ed2c4fa4245','f41e06181aed42d4a6d3175b346dbd68','12');----
INSERT INTO word VALUES ('96e7c7d29c8240639685e6d8dc293fb3','ivory','[ˈaivəri]','http://res.iciba.com/resource/amp3/oxford/0/21/28/212820c525bd02ed3a941e4b3a342607.mp3','n. 象牙；乳白色；象牙制品','','');----
INSERT INTO classwords VALUES ('b14b0717b0ed45768cd101bfdc6002a0','96e7c7d29c8240639685e6d8dc293fb3','12');----
INSERT INTO word VALUES ('a35acf60409643ddaac2717e6f25ce1b','shove','[ʃʌv]','http://res.iciba.com/resource/amp3/oxford/0/1c/3b/1c3b2fc506b2c14d393cdad6cf8e46fa.mp3','vi. 推','','');----
INSERT INTO classwords VALUES ('c8cc5c5ee19a4b8a9697c5db29cd3a13','a35acf60409643ddaac2717e6f25ce1b','12');----
INSERT INTO word VALUES ('116c245e265c4beb9928e3722f99d22a','kindle','[ˈkɪndl]','http://res.iciba.com/resource/amp3/oxford/0/50/7e/507ed447ce27b604e30086ed350b50f0.mp3','vi. 着火；发亮，放光','','');----
INSERT INTO classwords VALUES ('ea5e52f9b62a4726800a8b605670be0c','116c245e265c4beb9928e3722f99d22a','12');----
INSERT INTO word VALUES ('dc987b91476449cdb421a7ec7b4ab53a','tone','[təun]','http://res.iciba.com/resource/amp3/0/0/f3/03/f303f9a15cddbe8ee0296511a8b04b30.mp3','n. 音调；语气；气氛；色调','','');----
INSERT INTO classwords VALUES ('4b622676f5904410a44cbc7a5f084ef5','dc987b91476449cdb421a7ec7b4ab53a','12');----
INSERT INTO word VALUES ('ee6333700a9d42d4b20f392e0304085c','tanker','[ˈtæŋkə]','http://res.iciba.com/resource/amp3/oxford/0/f6/0a/f60a86e2a118a4a162851f4b368ede0f.mp3','n. 油轮；大卡车','','');----
INSERT INTO classwords VALUES ('f03d5e39c9aa499f9504317acf0b9ee0','ee6333700a9d42d4b20f392e0304085c','12');----
INSERT INTO word VALUES ('afed33687cbd444db966221d86059483','captive','[ˈkæptiv]','http://res.iciba.com/resource/amp3/oxford/0/d4/4b/d44b998df028de6429884ddaa6dc963a.mp3','adj. 被俘的；被监禁的','','');----
INSERT INTO classwords VALUES ('b8870793b8aa438ebd41d441c8e5d6ed','afed33687cbd444db966221d86059483','12');----
INSERT INTO word VALUES ('3b6d426228684cfab459d3d698d01bce','suicide','[ˈsjuisaid]','http://res.iciba.com/resource/amp3/oxford/0/10/88/1088b2f73525c83792a14b2d28d41e07.mp3','n. 自杀','','');----
INSERT INTO classwords VALUES ('b255bd7c422242a48adc9ffe33228d29','3b6d426228684cfab459d3d698d01bce','12');----
INSERT INTO word VALUES ('25b0a4187d89459a9e5724afa04daa19','grab','[ɡræb]','http://res.iciba.com/resource/amp3/oxford/0/76/de/76def6cdf3a74bc8a2abd7fbd2e8277f.mp3','vt. 攫取，抓住；引起…的注意','','');----
INSERT INTO classwords VALUES ('95e2da1296dc4a35977f47d561a1155c','25b0a4187d89459a9e5724afa04daa19','12');----
INSERT INTO word VALUES ('f8f419163d8448c4ac68e82a82e3706f','watt','[wɔt]','http://res.iciba.com/resource/amp3/0/0/2b/85/2b851f2a77cdb4f12cb200406971c1f7.mp3','n. 瓦（特）','','');----
INSERT INTO classwords VALUES ('a88a248127274f78ad7a6db19421a3b1','f8f419163d8448c4ac68e82a82e3706f','12');----
INSERT INTO word VALUES ('3910994f7f624d59a5665229fe8ade8e','report','[riˈpɔ:t]','http://res.iciba.com/resource/amp3/0/0/e9/8d/e98d2f001da5678b39482efbdf5770dc.mp3','n. 报道；成绩单；爆炸声','','');----
INSERT INTO classwords VALUES ('da22576cff4b4a0e89deca20da628ab0','3910994f7f624d59a5665229fe8ade8e','12');----
INSERT INTO word VALUES ('532792cd598f49a7bd8020ef2259d1ea','infer','[inˈfə:]','http://res.iciba.com/resource/amp3/oxford/0/87/05/870562598ba8c456d4ab1ad46bb65c09.mp3','vt. 推断，推定；暗示','','');----
INSERT INTO classwords VALUES ('e0aaed49cf4344cfb1fcdb61eaa9ed3c','532792cd598f49a7bd8020ef2259d1ea','12');----
INSERT INTO word VALUES ('6286b1bba12844f7b43468455289c748','peculiarity','[pɪˌkju:li:ˈærɪti:]','http://res.iciba.com/resource/amp3/oxford/0/cd/fe/cdfe112d91313d4685043c7d3d41b70b.mp3','n. 特性，独特性；怪癖','','');----
INSERT INTO classwords VALUES ('56e5393e80f64e4aa0ea75dd40a07d0c','6286b1bba12844f7b43468455289c748','12');----
INSERT INTO word VALUES ('3d59064915ec424ea7f0fa5a4cea0949','displace','[disˈpleis]','http://res.iciba.com/resource/amp3/oxford/0/2d/64/2d643cb7924028c45706d179712e0a3a.mp3','vt. 代替，取代，置换；迫使…离开家园','','');----
INSERT INTO classwords VALUES ('108a6e21265241e8a24bc935a15f95e6','3d59064915ec424ea7f0fa5a4cea0949','12');----
INSERT INTO word VALUES ('4f14e725a91945ab88657c10c7f2e1fb','offence','[əˈfens]','http://res.iciba.com/resource/amp3/oxford/0/5d/94/5d947aa781ac86bebe3a7ead9bc03a38.mp3','n. 犯罪；冒犯；进攻队','','');----
INSERT INTO classwords VALUES ('bdcc39eb7894498e9e4fe8630e18bc2f','4f14e725a91945ab88657c10c7f2e1fb','12');----
INSERT INTO word VALUES ('4052938087cc423bbc0636fcb4724ba7','desolate','[ˈdesəlit]','http://res.iciba.com/resource/amp3/oxford/0/e4/73/e473c00908475e6c7311fb6b3f3c94df.mp3','adj. 荒芜的；孤独的','','');----
INSERT INTO classwords VALUES ('330107802e9a421781fc702fdab18d6a','4052938087cc423bbc0636fcb4724ba7','12');----
INSERT INTO word VALUES ('b6b6001fd8b04c2db55c44d55d55a393','invoice','[ˈɪnˌvɔɪs]','http://res.iciba.com/resource/amp3/oxford/0/2d/5c/2d5c8498a1eabec83e419f9163c1724b.mp3','n. 发票；发货清单','','');----
INSERT INTO classwords VALUES ('ef13b0b274ac4906bcae0d938588c6c0','b6b6001fd8b04c2db55c44d55d55a393','12');----
INSERT INTO word VALUES ('2fde153594464fbc8add86b51be11eea','trot','[trɔt]','http://res.iciba.com/resource/amp3/0/0/49/4d/494dac0564bc55cc149bfa4af23d171f.mp3','vi. （马）小跑；快步走','','');----
INSERT INTO classwords VALUES ('f6b993071d8b49638441d75c762de713','2fde153594464fbc8add86b51be11eea','12');----
INSERT INTO word VALUES ('9f72b8b8ee2f4306a7b4c32d4eb808f8','enroll','[inˈrəul]','http://res.iciba.com/resource/amp3/0/0/6c/ef/6cef57d0d2cac5a6891b62934f2fee7b.mp3','vi. 入伍','','');----
INSERT INTO classwords VALUES ('0445ab8c572e4131a0f597acb8a742da','9f72b8b8ee2f4306a7b4c32d4eb808f8','12');----
INSERT INTO word VALUES ('2a56841fb303410cac3c6b3b5d8991bb','diplomatic','[ˌdipləˈmætik]','http://res.iciba.com/resource/amp3/oxford/0/11/2f/112ff5d8cf651f0c47d62b825f209a9d.mp3','adj. 外交的；讲究策略的；婉转的','','');----
INSERT INTO classwords VALUES ('7053853f52b640a6b53606affed531c3','2a56841fb303410cac3c6b3b5d8991bb','12');----
INSERT INTO word VALUES ('caebc025ec71496487f3b80a9d8b9b87','civilian','[siˈviljən]','http://res.iciba.com/resource/amp3/oxford/0/b7/61/b76170a72cbc66e20a558f4ccc94b48e.mp3','adj. 平民的；民用的','','');----
INSERT INTO classwords VALUES ('858c9917ea984bf0abe5974d236f163e','caebc025ec71496487f3b80a9d8b9b87','12');----
INSERT INTO word VALUES ('a90675b314494df3b56d669dea94c666','geometrical','[dʒɪəˈmetrɪkəl]','http://res.iciba.com/resource/amp3/0/0/b0/8d/b08d6889e1c7de09f15962c0658577e9.mp3','adj. 几何学的；几何图案的；成几何级...','','');----
INSERT INTO classwords VALUES ('7e6017fec300403c99585d4bebd02394','a90675b314494df3b56d669dea94c666','12');----
INSERT INTO word VALUES ('d2eb779ebfca41ef83f22b0a2a3a1b01','primitive','[ˈprimitiv]','http://res.iciba.com/resource/amp3/oxford/0/14/5e/145e254763bb7a81688db1e2d35dc372.mp3','adj. 远古的；未开化的；原始的；简陋...','','');----
INSERT INTO classwords VALUES ('63dd23dfe17c43588b8ecd8fa36adf70','d2eb779ebfca41ef83f22b0a2a3a1b01','12');----
INSERT INTO word VALUES ('19fd477fa04e4c4ea7e6039acceee211','waggon','[ˈwæɡən]','http://res.iciba.com/resource/amp3/1/0/2e/45/2e45a99d30e0835cf0f2371430f92a9b.mp3','n. 敞蓬车厢','','');----
INSERT INTO classwords VALUES ('19a43f087cee4ad485eda814c4e3b537','19fd477fa04e4c4ea7e6039acceee211','12');----
INSERT INTO word VALUES ('ab565e1fb9f0408995d9b54bddcbeb66','scout','[skaut]','http://res.iciba.com/resource/amp3/oxford/0/a5/fc/a5fcdb4a7b2f59b62f8c69b2d95aa2b8.mp3','vt. 搜索，寻找','','');----
INSERT INTO classwords VALUES ('4518fb7908874254bc5bc1dfd861085f','ab565e1fb9f0408995d9b54bddcbeb66','12');----
INSERT INTO word VALUES ('fd8c8690b8c6462ca2c29d34a43a9e97','workshop','[ˈwə:kʃɔp]','http://res.iciba.com/resource/amp3/0/0/33/f2/33f2ee11f1130c5c6e11061cc91d9b9a.mp3','n. 研讨会；研习班；车间','','');----
INSERT INTO classwords VALUES ('41b75f60fc8e4dd49f4a2ec09642557d','fd8c8690b8c6462ca2c29d34a43a9e97','12');----
INSERT INTO word VALUES ('980e63b89442487c862c6f885a6f130f','malice','[ˈmælis]','http://res.iciba.com/resource/amp3/oxford/0/69/e5/69e51df0ad23d92dae807ea0ebc06da3.mp3','n. 恶意；怨恨','','');----
INSERT INTO classwords VALUES ('729ff5697b6f4863882956e588555748','980e63b89442487c862c6f885a6f130f','12');----
INSERT INTO word VALUES ('d31efb56b51845b9a768773ad469ffb7','coffin','[ˈkɔ:fɪn]','http://res.iciba.com/resource/amp3/0/0/7e/ac/7eac63f9261b7240e96b43ceb575d249.mp3','n. 棺材，灵柩','','');----
INSERT INTO classwords VALUES ('d730ae59ed394fae91335e6257a3da80','d31efb56b51845b9a768773ad469ffb7','12');----
INSERT INTO word VALUES ('e1e290959a444e1783848c16681fa6b7','segment','[ˈseɡmənt]','http://res.iciba.com/resource/amp3/oxford/0/6e/35/6e35b68e9d59a13122b06f065e11b335.mp3','n. 部分；片段','','');----
INSERT INTO classwords VALUES ('c86edfd03a48486eb6aafd2a29f1d8e2','e1e290959a444e1783848c16681fa6b7','12');----
INSERT INTO word VALUES ('3fd069e24bc1424381cea3f8e37c1c4b','dentist','[ˈdentist]','http://res.iciba.com/resource/amp3/oxford/0/b0/e9/b0e972cf13d19b2c3dbfa50edbc4d86a.mp3','n. 牙科医生','','');----
INSERT INTO classwords VALUES ('3d2434f2cf7d419098890d2d0914f7cd','3fd069e24bc1424381cea3f8e37c1c4b','12');----
INSERT INTO word VALUES ('b270380487e74560af514761c969ee85','hiss','[his]','http://res.iciba.com/resource/amp3/oxford/0/36/c3/36c356654756e914de6f0ecc82bb262c.mp3','v. 发嘶嘶声；发出嘘声','','');----
INSERT INTO classwords VALUES ('451d6509c7fc4e499a2ac6a03de25b34','b270380487e74560af514761c969ee85','12');----
INSERT INTO word VALUES ('8b6226cebf6e4254bf86b1c1386b61c2','platform','[ˈplætfɔ:m]','http://res.iciba.com/resource/amp3/oxford/0/5f/2c/5f2c8e1c99d5815a7ead9d7c0cc94058.mp3','n. 纲领；讲台；平台；站台','','');----
INSERT INTO classwords VALUES ('fb292040e1544ad69f86a93ba25d4762','8b6226cebf6e4254bf86b1c1386b61c2','12');----
INSERT INTO word VALUES ('27b8351d55644241b0eee8ad6eabf864','stalk','[stɔ:k]','http://res.iciba.com/resource/amp3/oxford/0/c0/eb/c0eb8bff62f1a07fd43b5c4ad7c4a55d.mp3','v. 悄悄跟踪；高视阔步','','');----
INSERT INTO classwords VALUES ('fd43a4869c3148a38fded933e6f80223','27b8351d55644241b0eee8ad6eabf864','12');----
INSERT INTO word VALUES ('699c6041e4e5423b901ebffdefe145bf','rap','[ræp]','http://res.iciba.com/resource/amp3/oxford/0/60/92/609264fc5dc98a8ff4dc5be0f6abaa55.mp3','vt.&vi. 说唱；急拍；责备；闲聊','','');----
INSERT INTO classwords VALUES ('6d435350b8a64315ab1848935fd7e40a','699c6041e4e5423b901ebffdefe145bf','12');----
INSERT INTO word VALUES ('165b2fd2fb7d42daa6252f7b63706320','gramophone','[ˈgræməˌfəʊn]','http://res.iciba.com/resource/amp3/oxford/0/ec/cb/eccbafd57f8620039bdf64dd8d17340d.mp3','n. 留声机','','');----
INSERT INTO classwords VALUES ('2cdffeda73704a53bd017b3db4a4b353','165b2fd2fb7d42daa6252f7b63706320','12');----
INSERT INTO word VALUES ('3fb1601eea7947cda5a5911bd7e096c9','pier','[piə]','http://res.iciba.com/resource/amp3/0/0/c7/2e/c72e2158c941635b8ab6c33abcadf6da.mp3','n. 码头','','');----
INSERT INTO classwords VALUES ('895035aa8cb4442c972e668b74812d99','3fb1601eea7947cda5a5911bd7e096c9','12');----
INSERT INTO word VALUES ('4c98d4f2cc8849cbaf43faf1399f4c49','sullen','[ˈsʌlən]','http://res.iciba.com/resource/amp3/oxford/0/c4/f7/c4f770ed3573665ddc25c5b11a57573c.mp3','adj. 面有愠色的，闷闷不乐的，郁郁寡...','','');----
INSERT INTO classwords VALUES ('9271df095b43474ba4aeec5ab2aba0f6','4c98d4f2cc8849cbaf43faf1399f4c49','12');----
INSERT INTO word VALUES ('bb84f4a889e949b68473fc5311766fdf','hypothesis','[haiˈpɔθisis]','http://res.iciba.com/resource/amp3/oxford/0/14/75/14750e193d2557767e94b9326842462a.mp3','n. 假设，假说','','');----
INSERT INTO classwords VALUES ('bb3a81789ef644eba1af3326c93d5ec9','bb84f4a889e949b68473fc5311766fdf','12');----
INSERT INTO word VALUES ('28cc35ed20d84f638db3f6465d83c652','cruelty','[ˈkru:əlti:]','http://res.iciba.com/resource/amp3/oxford/0/a5/c7/a5c7ca4ac8f11fe8982afb5ad6eb38fc.mp3','n. 残酷；残忍；残暴','','');----
INSERT INTO classwords VALUES ('110317bcdc1a4716a9e907a9a82a9017','28cc35ed20d84f638db3f6465d83c652','12');----
INSERT INTO word VALUES ('a51c457f41dc49bd9e346e2113d20ba8','moss','[mɔs]','http://res.iciba.com/resource/amp3/0/0/06/a3/06a311b9097555ff46e11ef76b194f6e.mp3','n. 苔藓，青苔','','');----
INSERT INTO classwords VALUES ('6e95fb819f5e4ac3a4ffd1c1c72d45c2','a51c457f41dc49bd9e346e2113d20ba8','12');----
INSERT INTO word VALUES ('22981ef0d5d240c5b1b8bd01d6ef9c91','waitress','[ˈweɪtrɪs]','http://res.iciba.com/resource/amp3/oxford/0/e9/3e/e93e84da353f5cc74131e5345fd50f43.mp3','n. 女侍者，女服务员','','');----
INSERT INTO classwords VALUES ('35138078685d4e968e0bdc2935743172','22981ef0d5d240c5b1b8bd01d6ef9c91','12');----
INSERT INTO word VALUES ('d4351b8968714c90815fecac3d15461c','neighbouring','[ˈneɪbərɪŋ]','http://res.iciba.com/resource/amp3/oxford/0/37/42/3742919e90b01bd3aa6f1a602e0bbca3.mp3','adj. 邻近的；接壤的','','');----
INSERT INTO classwords VALUES ('2843cb3f5bed442ea5757eee3c3a3e8e','d4351b8968714c90815fecac3d15461c','12');----
INSERT INTO word VALUES ('abb4a55982054071a21b48b577e8e124','cancel','[ˈkænsəl]','http://res.iciba.com/resource/amp3/oxford/0/0b/c1/0bc1ee7669e305c5d807c01a35b750e1.mp3','vt. 取消；废除；注销（邮票或支票）','','');----
INSERT INTO classwords VALUES ('6c65c680c4af47f0bcc4180efc1d9440','abb4a55982054071a21b48b577e8e124','12');----
INSERT INTO word VALUES ('02e0743d0ca548ef93cac81a32fd5477','municipal','[mjuˈnisipəl]','http://res.iciba.com/resource/amp3/oxford/0/55/91/5591ccc0d34a28bdd4e805404baf98d8.mp3','adj. 市的，市政的','','');----
INSERT INTO classwords VALUES ('b7a5555e377f4d949a01cf676432c14a','02e0743d0ca548ef93cac81a32fd5477','12');----
INSERT INTO word VALUES ('c5e2ceb2eefd4a2f8bfed7399ee030d0','gracious','[ˈɡreiʃəs]','http://res.iciba.com/resource/amp3/oxford/0/50/12/5012e2102563ad64c97badde8aa19bbb.mp3','adj. 和蔼的；彬彬有礼的；舒适的','','');----
INSERT INTO classwords VALUES ('b92e6a0ccf704adc88adfc98e4d61689','c5e2ceb2eefd4a2f8bfed7399ee030d0','12');----
INSERT INTO word VALUES ('cfc9cea827d346b696bbe5250c83f50a','religion','[riˈlidʒən]','http://res.iciba.com/resource/amp3/oxford/0/d9/10/d910f51e16c2769261acb4dfd95561bd.mp3','n. 宗教，教派；宗教活动','','');----
INSERT INTO classwords VALUES ('e52f24d146824396a6b609913ca26e3f','cfc9cea827d346b696bbe5250c83f50a','12');----
INSERT INTO word VALUES ('3a02f3f4ba7342ada9813e5797265c12','pyjamas','[pəˈdʒɑ:məz]','http://res.iciba.com/resource/amp3/oxford/0/84/45/84455bcf407b20fdb799c621d4ceb0b0.mp3','n. 睡衣裤','','');----
INSERT INTO classwords VALUES ('b7f2ecd63d3f4274b656d481e11e87c1','3a02f3f4ba7342ada9813e5797265c12','12');----
INSERT INTO word VALUES ('2773a616e5ce4d5982f65bcfb92c6f26','retail','[ˈri:teil]','http://res.iciba.com/resource/amp3/oxford/0/d1/8b/d18bd5a5869cbb7a4e31bcdc8584526b.mp3','adj. 零售的','','');----
INSERT INTO classwords VALUES ('d27cfb7f480349d7acd30fcce87eb19e','2773a616e5ce4d5982f65bcfb92c6f26','12');----
INSERT INTO word VALUES ('7bbc8bbe609040cc96b3cb50366878c7','electrode','[ɪˈlekˌtrəʊd]','http://res.iciba.com/resource/amp3/oxford/0/23/4a/234ad32ec8a32d804849f1d9991c5b3e.mp3','n. 电极','','');----
INSERT INTO classwords VALUES ('56bfcd5620504e26b081b213621a22e0','7bbc8bbe609040cc96b3cb50366878c7','12');----
INSERT INTO word VALUES ('b2f55aded73b4604a80169eaaf0bf53c','spill','[spil]','http://res.iciba.com/resource/amp3/oxford/0/a2/94/a294554ae6a1279f11f56623ca808b41.mp3','n. 溢出量；溢出物','','');----
INSERT INTO classwords VALUES ('906011a2c2434d679f1232ddb6ccae83','b2f55aded73b4604a80169eaaf0bf53c','12');----
INSERT INTO word VALUES ('629636beed89434b8e7ec37f6fb4cea7','sham','[ʃæm]','http://res.iciba.com/resource/amp3/oxford/0/94/7a/947afc97b48707e4ee4f0ce5200ec74e.mp3','vt. 假装','','');----
INSERT INTO classwords VALUES ('52360e444667448b844edddc1e803e33','629636beed89434b8e7ec37f6fb4cea7','12');----
INSERT INTO word VALUES ('5d259452df514540993d169f6466934b','flight','[flait]','http://res.iciba.com/resource/amp3/oxford/0/d9/52/d9522970b4fff2eb0213a8f7619a7751.mp3','n. 航行；航班；鸟群；逃避，躲开；一段...','','');----
INSERT INTO classwords VALUES ('d860cbb4c1b14bfdbe0b9fbf3cebeab5','5d259452df514540993d169f6466934b','12');----
INSERT INTO word VALUES ('d6f7e6a1cf7d43839f36d1d0bdac6e4c','whale','[hweil]','http://res.iciba.com/resource/amp3/oxford/0/38/4e/384ecf59a7da2deb191705a2992a6255.mp3','n. 鲸，鲸鱼','','');----
INSERT INTO classwords VALUES ('9ce2c66780384e23b40ee184f3f99e9a','d6f7e6a1cf7d43839f36d1d0bdac6e4c','12');----
INSERT INTO word VALUES ('a30e8473d0774db39397c8f4e7345d7d','innumerable','[iˈnju:mərəbl]','http://res.iciba.com/resource/amp3/oxford/0/b0/6d/b06d4cad9fefcdb2fe3123b96308f967.mp3','adj. 无数的，数不清的','','');----
INSERT INTO classwords VALUES ('8b1fbade45de455c9d6c17d765dd5923','a30e8473d0774db39397c8f4e7345d7d','12');----
INSERT INTO word VALUES ('aa6792997ade4cd0ae9bba5bb0f4ad19','client','[ˈklaiənt]','http://res.iciba.com/resource/amp3/oxford/0/fa/7c/fa7cb70c6015ac7f83ea3730a9e7d2b7.mp3','n. 顾客；诉讼委托人','','');----
INSERT INTO classwords VALUES ('bd97532c62e44a62a25d57656946e392','aa6792997ade4cd0ae9bba5bb0f4ad19','12');----
INSERT INTO word VALUES ('4379d68300e2469a8846cf8b7023747a','cutter','[ˈkʌtə]','http://res.iciba.com/resource/amp3/oxford/0/9f/e9/9fe9da83b0235087a36fcd8a03edab6c.mp3','n. 切割工具；切割工；小艇','','');----
INSERT INTO classwords VALUES ('d944166d3593453687a39eb632009405','4379d68300e2469a8846cf8b7023747a','12');----
INSERT INTO word VALUES ('3d3fa3d86ba04d36a829b5960e3f469c','immerse','[iˈmə:s]','http://res.iciba.com/resource/amp3/0/0/a0/40/a040a91cefdd01d2a660723a8e7739de.mp3','vt. 沉浸；使深陷；使浸没（于液体中）','','');----
INSERT INTO classwords VALUES ('1991a69cfcce43c98eeda8f7e574f1f3','3d3fa3d86ba04d36a829b5960e3f469c','12');----
INSERT INTO word VALUES ('86ebd59897904538a2177df31a362c26','infinity','[ɪnˈfɪnɪti:]','http://res.iciba.com/resource/amp3/oxford/0/aa/28/aa28cce2358d284263df7348e0d4d8a2.mp3','n. 无限远的距离；无穷大','','');----
INSERT INTO classwords VALUES ('cb6afb61500a4117a94b4614d9bacd63','86ebd59897904538a2177df31a362c26','12');----
INSERT INTO word VALUES ('9ce1e2d6e5a94149afb7aa97f8409e6a','shipment','[ˈʃipmənt]','http://res.iciba.com/resource/amp3/oxford/0/3e/6d/3e6d45d4718442a86f5cf800f1d08cf1.mp3','n. 运输；装载的货物','','');----
INSERT INTO classwords VALUES ('0bef28fa4075499aac7b6c5d8e4ca009','9ce1e2d6e5a94149afb7aa97f8409e6a','12');----
INSERT INTO word VALUES ('22fb84e726ce4e1187c6c812ca143573','limb','[lim]','http://res.iciba.com/resource/amp3/oxford/0/b8/65/b8655d4cd6bdeefd7a0f220c3368203c.mp3','n. 肢，臂；树枝','','');----
INSERT INTO classwords VALUES ('6ef3578cb31747078364ebf859978c91','22fb84e726ce4e1187c6c812ca143573','12');----
INSERT INTO word VALUES ('553e3f4be11b423281d63f131c297263','dealer','[ˈdi:lə]','http://res.iciba.com/resource/amp3/oxford/0/49/82/49827d60e3a17b48c82c54ba83b6f158.mp3','n. 商人；交易商；毒品贩子','','');----
INSERT INTO classwords VALUES ('389f35c57cda476c9bc57f5484ad6f8b','553e3f4be11b423281d63f131c297263','12');----
INSERT INTO word VALUES ('345f9d86d35d4a268a5bbda120c66d1a','embrace','[imˈbreis]','http://res.iciba.com/resource/amp3/0/0/5e/58/5e58e27883fa86c163e7929fe27365ec.mp3','vt. 包括；拥抱；欣然接受','','');----
INSERT INTO classwords VALUES ('f9d875cb38bf48d4a1de185a9fb18deb','345f9d86d35d4a268a5bbda120c66d1a','12');----
INSERT INTO word VALUES ('b65f07052d974171971f43de2f037027','lattice','[ˈlætɪs]','http://res.iciba.com/resource/amp3/oxford/0/52/2c/522c1bbf6e93183095be15e008f842d9.mp3','n. 格子木架','','');----
INSERT INTO classwords VALUES ('92c37e3057314c169e5fe56fb5576d00','b65f07052d974171971f43de2f037027','12');----
INSERT INTO word VALUES ('0d14a32372d84d1499eaa5fbacd469ca','formulation','[ˌfɔ:mjʊˈleɪʃən]','http://res.iciba.com/resource/amp3/0/0/b2/76/b2760d16bb1c5ea50442166106f87b4f.mp3','n. 配方；构想；表达方法','','');----
INSERT INTO classwords VALUES ('72eb507908fb4d52be40155e1250a3de','0d14a32372d84d1499eaa5fbacd469ca','12');----
INSERT INTO word VALUES ('ecec94b5321145ce8bb00644ea27d0e7','fringe','[frindʒ]','http://res.iciba.com/resource/amp3/oxford/0/da/02/da023a800e7aade77c1aea4e2cd14ab9.mp3','n. 穗，流苏；边缘；刘海','','');----
INSERT INTO classwords VALUES ('6dae5f18d92b4728bf557558201228bd','ecec94b5321145ce8bb00644ea27d0e7','12');----
INSERT INTO word VALUES ('41d28241e2ed469fad1ecd825693c5d2','toss','[tɔs]','http://res.iciba.com/resource/amp3/0/0/cb/34/cb347a164c3367954803be2f0cadf7bb.mp3','vt.&vi. 扔，抛；掷（硬币以决定）...','','');----
INSERT INTO classwords VALUES ('989bf5aad7474d89927f6566b241fac4','41d28241e2ed469fad1ecd825693c5d2','12');----
INSERT INTO word VALUES ('5d39c75da2624ba98bab0efe24db7a4f','troop','[tru:p]','http://res.iciba.com/resource/amp3/oxford/0/0a/88/0a881dc9d3e19067e2587f7292efd462.mp3','n. 一群；部队；骑兵队','','');----
INSERT INTO classwords VALUES ('0c07e5c8f0114c64be5959ea0fe86fdd','5d39c75da2624ba98bab0efe24db7a4f','12');----
INSERT INTO word VALUES ('b69bec520834441297e63afbebc60959','veil','[veil]','http://res.iciba.com/resource/amp3/oxford/0/b9/da/b9dabb9177eaca59c0032fec3b50aa4d.mp3','n. 面纱；遮盖物；（薄雾等）幕障','','');----
INSERT INTO classwords VALUES ('e450989bb64e4092b5ff2dd5aad23471','b69bec520834441297e63afbebc60959','12');----
INSERT INTO word VALUES ('9939ce2206e64603ada7375c0b60c94f','hoarse','[hɔ:s]','http://res.iciba.com/resource/amp3/0/0/67/9f/679f38050e590f4080523e23c27ea881.mp3','adj. （声音）嘶哑的','','');----
INSERT INTO classwords VALUES ('7cad49f79568443eb95ead7abe34178e','9939ce2206e64603ada7375c0b60c94f','12');----
INSERT INTO word VALUES ('5ff2de9c520a420594ea7bbbc5183d57','revolve','[riˈvɔlv]','http://res.iciba.com/resource/amp3/0/0/35/d2/35d2fd9bd583c7dc3a1e4cf8ed21824c.mp3','vt.&vi. （使）旋转；围绕','','');----
INSERT INTO classwords VALUES ('bb35c73996ce4bcf96594bca9e29230d','5ff2de9c520a420594ea7bbbc5183d57','12');----
INSERT INTO word VALUES ('deebb5913bb942e4a566a14c22c3fe64','lobby','[ˈlɔbi]','http://res.iciba.com/resource/amp3/0/0/d8/67/d8671d1cb097a3bd26b2344ee25a0562.mp3','n. 门厅，大厅；游说团体','','');----
INSERT INTO classwords VALUES ('3f92aed9c5484f4d86253b5c5c7ff251','deebb5913bb942e4a566a14c22c3fe64','12');----
INSERT INTO word VALUES ('dcdd01ed9a34406f9db806ec6dbf4e8b','marshal','[ˈmɑ:ʃəl]','http://res.iciba.com/resource/amp3/0/0/03/fb/03fba462c523f51ae0aae965889c1098.mp3','n. 元帅；典礼官','','');----
INSERT INTO classwords VALUES ('50032d03ac8145b28f1add3624429d69','dcdd01ed9a34406f9db806ec6dbf4e8b','12');----
INSERT INTO word VALUES ('bd1679f2c3b745558ec418b8cf9385bf','printer','[ˈprɪntə]','http://res.iciba.com/resource/amp3/oxford/0/14/24/14244c67fe4dcad83cac3f7536a9e584.mp3','n. 打印机；印刷工人；印刷厂','','');----
INSERT INTO classwords VALUES ('d02a37b6c5ab4616bc6d3cbdedb019a8','bd1679f2c3b745558ec418b8cf9385bf','12');----
INSERT INTO word VALUES ('bf6e4407c359426caa112ab381fa7221','dazzle','[ˈdæzl]','http://res.iciba.com/resource/amp3/oxford/0/79/48/7948b2ad8bee6aa4cd66c07f675ac8c6.mp3','vt.&vi. 使目眩；使惊叹','','');----
INSERT INTO classwords VALUES ('7a38dc3464694641abfaf286ec3acdde','bf6e4407c359426caa112ab381fa7221','12');----
INSERT INTO word VALUES ('18c1e9b47c32423799202c82d21ea860','twist','[twist]','http://res.iciba.com/resource/amp3/oxford/0/f2/ec/f2ec50d94d65afb2ad5b3845954acc97.mp3','v. 扭，捻；使扭曲；扭动；扭伤','','');----
INSERT INTO classwords VALUES ('f6d6c209c1ac4678b49d9ff76ecebfed','18c1e9b47c32423799202c82d21ea860','12');----
INSERT INTO word VALUES ('0d64e9bacf4e46f8b7ab91abd4836ec0','amateur','[ˈæmətə]','http://res.iciba.com/resource/amp3/oxford/0/94/b2/94b2e2659c448984cd78183606d27a2f.mp3','n. 业余爱好者','','');----
INSERT INTO classwords VALUES ('d22d2795ad414a21904b5c571f999feb','0d64e9bacf4e46f8b7ab91abd4836ec0','12');----
INSERT INTO word VALUES ('d1a12cbcd4d243e8b026c674f07e2428','gutter','[ˈɡʌtə]','http://res.iciba.com/resource/amp3/oxford/0/39/9d/399d27983760c0ea4609848c38fe58d0.mp3','n. 排水沟；（屋檐的）雨水槽','','');----
INSERT INTO classwords VALUES ('84a57e5b5a2847b4b0799a86e8d9c94d','d1a12cbcd4d243e8b026c674f07e2428','12');----
INSERT INTO word VALUES ('bd3351c13f034eeb9e4f8db098675945','spiral','[ˈspaiərəl]','http://res.iciba.com/resource/amp3/oxford/0/6d/5c/6d5cab357dcbae067d10273ac6c15ef3.mp3','v. 使成螺旋形；（数量、水平）急遽增长...','','');----
INSERT INTO classwords VALUES ('28aa07eb490243e18d95e27343ed08c5','bd3351c13f034eeb9e4f8db098675945','12');----
INSERT INTO word VALUES ('c536dbffaae040b28625a13883315ee6','walnut','[ˈwɔ:lnət]','http://res.iciba.com/resource/amp3/oxford/0/80/41/804106384655fa2dd57204b264c35812.mp3','n. 胡桃，胡桃树；胡桃木','','');----
INSERT INTO classwords VALUES ('99a08dc83b12409d8f670fac27dc198f','c536dbffaae040b28625a13883315ee6','12');----
INSERT INTO word VALUES ('0a74422f59ac47a2b6e7dd6d04ef2330','presumably','[prɪˈzjuːməbli]','http://res.iciba.com/resource/amp3/oxford/0/5d/99/5d99de266aa103767dd15b5c50b1d537.mp3','adv. 据推测；大概；很可能','','');----
INSERT INTO classwords VALUES ('df9d4abb86ad468088e58d96b4684afa','0a74422f59ac47a2b6e7dd6d04ef2330','12');----
INSERT INTO word VALUES ('af444200a9164e5e990e05cf34dd8fc0','fabricate','[ˈfæbrikeit]','http://res.iciba.com/resource/amp3/oxford/0/c9/32/c9327968ebec13c4bc2578ee712ff470.mp3','vt. 制作，制造；捏造','','');----
INSERT INTO classwords VALUES ('d3ad4287d71d42aab61e4231839fc96e','af444200a9164e5e990e05cf34dd8fc0','12');----
INSERT INTO word VALUES ('c7ab92c7e30b4fc28a883e899c77703c','absurd','[əbˈsə:d]','http://res.iciba.com/resource/amp3/0/0/65/99/65997b466ba894a5f6d08718370ebb33.mp3','adj. 不合理的，荒唐的','','');----
INSERT INTO classwords VALUES ('a97d35df7de64cf39c5c6e8c7cd02e79','c7ab92c7e30b4fc28a883e899c77703c','12');----
INSERT INTO word VALUES ('f06a8c60002246a6a34bed57c49ca9e6','crooked','[ˈkrukid]','http://res.iciba.com/resource/amp3/oxford/0/08/58/08589a836cedb53937d775ef0a7e4d50.mp3','adj. 弯曲的；扭曲的；（笑）不自然的...','','');----
INSERT INTO classwords VALUES ('2bf3a0ed4d47411b9088898bc0a45a16','f06a8c60002246a6a34bed57c49ca9e6','12');----
INSERT INTO word VALUES ('9f75c4ec1cc04523a5a23598c0e37c15','swell','[swel]','http://res.iciba.com/resource/amp3/oxford/0/a6/7f/a67f5e7d9e639babf78608910f197080.mp3','vi.&vt. 使膨胀；肿胀；增加','','');----
INSERT INTO classwords VALUES ('7618897f7249439bb1365957d658fe8c','9f75c4ec1cc04523a5a23598c0e37c15','12');----
INSERT INTO word VALUES ('1d815f59427a4361af6e4a9816adf325','perfect','[ˈpə:fikt]','http://res.iciba.com/resource/amp3/0/0/82/6a/826ad6b0338304c40b42644b5144f80a.mp3','vt. 使完美；完善','','');----
INSERT INTO classwords VALUES ('84c503ca1f0f42f6bff91e2b1911deba','1d815f59427a4361af6e4a9816adf325','12');----
INSERT INTO word VALUES ('3dc5825294014ed980f3afec742ca28c','shell','[ʃel]','http://res.iciba.com/resource/amp3/oxford/0/49/c2/49c2c2832fa8069db19ced821238d884.mp3','n. 炮弹；（蛋、坚果等的）壳；贝壳','','');----
INSERT INTO classwords VALUES ('2675baf60ece46eb8e40cd36d428abb5','3dc5825294014ed980f3afec742ca28c','12');----
INSERT INTO word VALUES ('ca8a191613c24fa0aa66f7a92269fa4e','hop','[hɔp]','http://res.iciba.com/resource/amp3/0/0/5f/67/5f67b2845b51a17a7751f0d7fd460e70.mp3','vi. 齐足跳行；（人）单足跳跃；跳上（...','','');----
INSERT INTO classwords VALUES ('47598b10fa864a2297cdc177b7655cc6','ca8a191613c24fa0aa66f7a92269fa4e','12');----
INSERT INTO word VALUES ('25d24a5245174758ba935362e39a5e34','proceeding','[prəˈsi:diŋ]','http://res.iciba.com/resource/amp3/oxford/0/6f/12/6f12f62320b547691284694156aa1b8b.mp3','n. 诉讼；活动；会议记录','','');----
INSERT INTO classwords VALUES ('651e953419fb4559af241f31379f3130','25d24a5245174758ba935362e39a5e34','12');----
INSERT INTO word VALUES ('3f285b5f6a584bfc850bff8da443e2b5','peel','[pi:l]','http://res.iciba.com/resource/amp3/oxford/0/e1/f7/e1f7213d432894bbf193507f89ebeea9.mp3','n. 果皮，蔬菜皮','','');----
INSERT INTO classwords VALUES ('1642a471e8bc41e181e1ba6840e96591','3f285b5f6a584bfc850bff8da443e2b5','12');----
INSERT INTO word VALUES ('41aabc77f89e47dfa68c85e5c0ae9f83','harmonious','[hɑ:ˈməʊni:əs]','http://res.iciba.com/resource/amp3/oxford/0/7d/32/7d322c8cc523fd02a667c08b57133a24.mp3','adj. 融洽的；和谐的，协调的；悦耳的','','');----
INSERT INTO classwords VALUES ('a307b0175acd48609862cec04fd48e97','41aabc77f89e47dfa68c85e5c0ae9f83','12');----
INSERT INTO word VALUES ('35cf5e8030b4495cadc04c06c51dc8a8','blast','[blɑ:st]','http://res.iciba.com/resource/amp3/0/0/9e/1b/9e1b93b20faf4a4798c106c0db299473.mp3','n. 爆炸；一阵（强风）','','');----
INSERT INTO classwords VALUES ('33ab054992564d3e9ea68177c882463b','35cf5e8030b4495cadc04c06c51dc8a8','12');----
INSERT INTO word VALUES ('703307b0f74b4b8e804a6e6599f0003e','fragile','[ˈfrædʒail]','http://res.iciba.com/resource/amp3/oxford/0/b5/ec/b5ec1505904b270e89dd65d44eacfd3d.mp3','adj. 脆弱的；易碎的；（外表）精致的...','','');----
INSERT INTO classwords VALUES ('5dbd7c44e8534a8aaec5d4a113a35a68','703307b0f74b4b8e804a6e6599f0003e','12');----
INSERT INTO word VALUES ('5790134cf37447b9b5fc7cd23ef1dd63','motive','[ˈməutiv]','http://res.iciba.com/resource/amp3/oxford/0/57/a0/57a05d91642a327d0b2771ed09cd8e55.mp3','n. 动机，缘由','','');----
INSERT INTO classwords VALUES ('3358ebbb31a14947a25631fcedeac38e','5790134cf37447b9b5fc7cd23ef1dd63','12');----
INSERT INTO word VALUES ('c5e78e48cfdd4a959f2cb528617c1a03','glossary','[ˈglɔ:səri:]','http://res.iciba.com/resource/amp3/oxford/0/e9/eb/e9ebecb98f725a94dcad17d2f1925eb9.mp3','n. 词汇表；术语汇编','','');----
INSERT INTO classwords VALUES ('566a17acc4744bfe8159af252b6daee2','c5e78e48cfdd4a959f2cb528617c1a03','12');----
INSERT INTO word VALUES ('1458775e4ad44e478f414e06477fbc66','perimeter','[pəˈrɪmɪtə]','http://res.iciba.com/resource/amp3/oxford/0/3b/82/3b82f2c1eac23701fad94dd7a23afe22.mp3','n. 周边，边界；周长','','');----
INSERT INTO classwords VALUES ('8df3ea6c003a4bca8005b237baf2a9a7','1458775e4ad44e478f414e06477fbc66','12');----
INSERT INTO word VALUES ('b961de978ef34976a381ea3be8cdab88','scrub','[skrʌb]','http://res.iciba.com/resource/amp3/oxford/0/96/fa/96fa6eb2f23e071e4ed9960cf8462377.mp3','vt. 擦洗；擦掉','','');----
INSERT INTO classwords VALUES ('460167b525b147efa3e37f6a36109094','b961de978ef34976a381ea3be8cdab88','12');----
INSERT INTO word VALUES ('6793bb2f4f744e74aada2b831bf6335b','conservative','[kənˈsə:vətiv]','http://res.iciba.com/resource/amp3/oxford/0/f7/66/f7662e8bed76ad7d12458a631154d758.mp3','adj. 保守的，因循守旧的；保守党的','','');----
INSERT INTO classwords VALUES ('31c8961d11ee491f8bb0637a6bc4382a','6793bb2f4f744e74aada2b831bf6335b','12');----
INSERT INTO word VALUES ('036420d041894836bde1e3be59c1c2db','oxidize','[ˈɔksɪˌdaɪz]','http://res.iciba.com/resource/amp3/oxford/0/66/00/660067ab5190630cb4e21ff47db472f9.mp3','vt. 使氧化；使生锈','','');----
INSERT INTO classwords VALUES ('67e14a164f214866a9f64bd9a38a1cfe','036420d041894836bde1e3be59c1c2db','12');----
INSERT INTO word VALUES ('051f24b12fc243bfb73a3d423af918b4','tow','[təu]','http://res.iciba.com/resource/amp3/0/0/ba/1f/ba1fa7e7999dd72ff18d0e6d5d6e6c93.mp3','vt. 拖，拉，牵引','','');----
INSERT INTO classwords VALUES ('e4b86497ae564b06b525107e6120e339','051f24b12fc243bfb73a3d423af918b4','12');----
INSERT INTO word VALUES ('9dc199fa1dc5447eb63946f67eaa36c1','metallurgy','[ˈmetlˌɜ:dʒi:]','http://res.iciba.com/resource/amp3/0/0/fd/71/fd719672948f60491a24214346b41e27.mp3','n. 冶金学，冶金术','','');----
INSERT INTO classwords VALUES ('69ebfb8e4e774d3b8c4edd2910d6d692','9dc199fa1dc5447eb63946f67eaa36c1','12');----
INSERT INTO word VALUES ('e056d565e41144649d797e411a585680','appreciable','[əˈpri:ʃəbəl]','http://res.iciba.com/resource/amp3/oxford/0/23/e0/23e03193fde290c9dfdc9266781e284d.mp3','adj. 可觉察的；相当大的；明显的','','');----
INSERT INTO classwords VALUES ('1e18ef186a0f442788b11abe9f511fbc','e056d565e41144649d797e411a585680','12');----
INSERT INTO word VALUES ('5f730ab6bb5940ef8adbdf0496f4f065','longing','[ˈlɔ:ŋɪŋ]','http://res.iciba.com/resource/amp3/oxford/0/90/47/904722670204e65f193febfc9b434ce7.mp3','adj. 渴望的','','');----
INSERT INTO classwords VALUES ('3d3f2b1e7a4e466993422661b468a485','5f730ab6bb5940ef8adbdf0496f4f065','12');----
INSERT INTO word VALUES ('9a765f3ce74243d8942a04983796b5d5','optimum','[ˈɔptiməm]','http://res.iciba.com/resource/amp3/oxford/0/36/e2/36e25fa08d668b547d48b3286808189f.mp3','adj. 最适宜的；最优的','','');----
INSERT INTO classwords VALUES ('8b05551ef2ce4d3c920e612a8c13d293','9a765f3ce74243d8942a04983796b5d5','12');----
INSERT INTO word VALUES ('d6fcf939bdbf4055ba9cbf6c9a32cc13','whereby','[hwɛəˈbai]','http://res.iciba.com/resource/amp3/oxford/0/14/f5/14f57f8a17adfb5178ab87c6cfed1b10.mp3','adv. 靠那个；借以','','');----
INSERT INTO classwords VALUES ('dbd84e3a5cf34bc8bb8a173c0acc09ab','d6fcf939bdbf4055ba9cbf6c9a32cc13','12');----
INSERT INTO word VALUES ('f99ce4b06d414978a673039e11f3dbba','coherent','[kəuˈhiərənt]','http://res.iciba.com/resource/amp3/oxford/0/32/e6/32e698d59fdce82cc6563417d135b59b.mp3','adj. 一致的，连贯的；有条理的','','');----
INSERT INTO classwords VALUES ('fadddbd446704e02952a6576bcdcff64','f99ce4b06d414978a673039e11f3dbba','12');----
INSERT INTO word VALUES ('39d176d53449464d8575248836720496','propagate','[ˈprɔpəɡeit]','http://res.iciba.com/resource/amp3/oxford/0/90/cb/90cb7d2b09a12907530868c710f92f2b.mp3','vt. 繁殖；传播，普及','','');----
INSERT INTO classwords VALUES ('7e9d7bc9cd18459c9ac5a5815e3f2a52','39d176d53449464d8575248836720496','12');----
INSERT INTO word VALUES ('227e9f16dbef4e9fa5dcef1bcaf66960','refreshment','[riˈfreʃmənt]','http://res.iciba.com/resource/amp3/oxford/0/86/a6/86a60acd909b7471ca0d23ebf52da1d3.mp3','n. （精力的）恢复；茶点；食物','','');----
INSERT INTO classwords VALUES ('4f61302b914249f298303e9690c4334c','227e9f16dbef4e9fa5dcef1bcaf66960','12');----
INSERT INTO word VALUES ('af38cb0c75e34eef8919438cbb057fcd','hydraulic','[haɪˈdrɔ:lɪk]','http://res.iciba.com/resource/amp3/oxford/0/57/70/5770f17407e3270ff124301d1a783c64.mp3','adj. 水力的，液压的','','');----
INSERT INTO classwords VALUES ('b554897a8b8a431ead4ef8483a8533a4','af38cb0c75e34eef8919438cbb057fcd','12');----
INSERT INTO word VALUES ('64782786343f49a3bc08bc2a4d6644ab','expect','[iksˈpekt]','http://res.iciba.com/resource/amp3/oxford/0/cb/a3/cba38a86b22b69ccc320c72513b94428.mp3','vt. 预期；期待；要求；指望','','');----
INSERT INTO classwords VALUES ('04d503a085194ffcac9ea127e725a509','64782786343f49a3bc08bc2a4d6644ab','12');----
INSERT INTO word VALUES ('585708f03a2646ffb4bc725c7734eee3','migrate','[maiˈɡreit]','http://res.iciba.com/resource/amp3/1/0/f1/83/f183fde1c1f409b21fc8463052ca49e5.mp3','vi. 迁移，移居；迁徙','','');----
INSERT INTO classwords VALUES ('d52bd7b6090f40fc8016a53a4ad3d28d','585708f03a2646ffb4bc725c7734eee3','12');----
INSERT INTO word VALUES ('80f4e54503694ef3b598d5992e436c04','perpetual','[pəˈpetʃuəl]','http://res.iciba.com/resource/amp3/oxford/0/72/2a/722a1bb287755c56ab2ed4d1bc4818e1.mp3','adj. 永久的；连续不断的','','');----
INSERT INTO classwords VALUES ('1d211725a99845f1ac0489585d82d6c3','80f4e54503694ef3b598d5992e436c04','12');----
INSERT INTO word VALUES ('e7671a08cc454837962bfb54286f3ac6','emigrate','[ˈemiɡreit]','http://res.iciba.com/resource/amp3/oxford/0/f6/15/f6158153d5c6b9ae0eab200028e92c3c.mp3','vi. 移居国外','','');----
INSERT INTO classwords VALUES ('ce55f79402ce4515bd3e76c4e342faf2','e7671a08cc454837962bfb54286f3ac6','12');----
INSERT INTO word VALUES ('bece45de7c6146b490fe77e6b8d2a72d','quarterly','[ˈkwɔ:təli]','http://res.iciba.com/resource/amp3/0/0/4a/ee/4aeebd4aa1cedd190731299c3810a5db.mp3','adv. 季度地','','');----
INSERT INTO classwords VALUES ('85bb6e8dc8124adeb1658b27ae4eb517','bece45de7c6146b490fe77e6b8d2a72d','12');----
INSERT INTO word VALUES ('6d6de1d13a524fec86024c4a3be7812a','monster','[ˈmɔnstə]','http://res.iciba.com/resource/amp3/oxford/0/12/0d/120dedf10423e103061acd4c8472cb3e.mp3','n. 怪物；庞然大物；恶人','','');----
INSERT INTO classwords VALUES ('5824be00b58848e2a71807f3760b5aab','6d6de1d13a524fec86024c4a3be7812a','12');----
INSERT INTO word VALUES ('74fda9aaaf3241e98b6a4d412541ccfe','hip','[hip]','http://res.iciba.com/resource/amp3/oxford/0/ac/da/acdaddcf9acc6f299497e7918b66f52f.mp3','n. 臀部，髋；屋脊','','');----
INSERT INTO classwords VALUES ('a629586a3e35481bb3a7b637e5e2505d','74fda9aaaf3241e98b6a4d412541ccfe','12');----
INSERT INTO word VALUES ('e804a9bde06345aa91041ea87d39d296','satisfactoril...','[ˌsætɪsˈfæktərɪlɪ]','http://res.iciba.com/resource/amp3/0/0/86/52/8652979694284b99c1baa2d05b62d747.mp3','adv. 令人满意地','','');----
INSERT INTO classwords VALUES ('2d8e3f601ca645e5bfb3b9e253755cab','e804a9bde06345aa91041ea87d39d296','12');----
INSERT INTO word VALUES ('73d6b329cfce4202807195bfccca3e4c','fitting','[ˈfitiŋ]','http://res.iciba.com/resource/amp3/oxford/0/5b/15/5b150d86cb390cbf94d506fe29b25e23.mp3','n. 试穿，试衣；配件','','');----
INSERT INTO classwords VALUES ('58e46cafcdf241fb8d3930668420e3bc','73d6b329cfce4202807195bfccca3e4c','12');----
INSERT INTO word VALUES ('473b7396b124460696df345bffe4521b','crash','[kræʃ]','http://res.iciba.com/resource/amp3/oxford/0/12/38/12386bb601e5b50f18f977940896eed4.mp3','v. 碰撞；撞毁；撞击','','');----
INSERT INTO classwords VALUES ('2509645ea4754ca6af5ac031c1002a01','473b7396b124460696df345bffe4521b','12');----
INSERT INTO word VALUES ('9f8bcd1581c645d59619f7e3a73a3d8d','nickel','[ˈnikəl]','http://res.iciba.com/resource/amp3/oxford/0/a1/f5/a1f57f0e63bdf72f46e67631d52e9f26.mp3','n. 镍；五分镍币','','');----
INSERT INTO classwords VALUES ('4856a69870ae4de885147f1ac598818a','9f8bcd1581c645d59619f7e3a73a3d8d','12');----
INSERT INTO word VALUES ('6d346c37523a4744829dfbf2e9185ce8','discern','[diˈsə:n]','http://res.iciba.com/resource/amp3/oxford/0/01/c9/01c9f0b17bdc4f9181278b9ddbfd3ebc.mp3','vt. 看出；辨别；觉察出','','');----
INSERT INTO classwords VALUES ('327abd3c582149b498cc29ccb16f3a9f','6d346c37523a4744829dfbf2e9185ce8','12');----
INSERT INTO word VALUES ('b41d50d86e034b75b0f4b96cc7625cad','utilization','[ˌju:tɪlaɪˈzeɪʃɵn]','http://res.iciba.com/resource/amp3/0/0/69/6f/696f8e44fcc63316bd70b581c1601abd.mp3','n. 利用，效用','','');----
INSERT INTO classwords VALUES ('9c4a8022ee4547f78db1b0d5dc48585e','b41d50d86e034b75b0f4b96cc7625cad','12');----
INSERT INTO word VALUES ('e658eac58f71480099f8fa717260ead7','grumble','[ˈɡrʌmbl]','http://res.iciba.com/resource/amp3/oxford/0/84/3e/843e48fbeae50a1bdcd60b2eb0f6deb6.mp3','vi. 抱怨；发牢骚；隆隆作响','','');----
INSERT INTO classwords VALUES ('2225e36f57cb4404b7bb2e074a0d4446','e658eac58f71480099f8fa717260ead7','12');----
INSERT INTO word VALUES ('834c2cd86a204296b4342f952a6efc63','barely','[ˈbɛəli]','http://res.iciba.com/resource/amp3/0/0/22/c1/22c1febc0ae5b70d1b992009b7ff05d2.mp3','adv. 仅仅，勉强；刚刚','','');----
INSERT INTO classwords VALUES ('78ba13375b9b4d08a4dc30e705a7b770','834c2cd86a204296b4342f952a6efc63','12');----
INSERT INTO word VALUES ('03277e127fe5436aa9a88c0eac1c6b0b','tighten','[ˈtaɪtn]','http://res.iciba.com/resource/amp3/oxford/0/0a/41/0a411504f19e7a184701863d3d44336c.mp3','vt.&vi. 抓紧；使绷紧；（对…）严...','','');----
INSERT INTO classwords VALUES ('193b69cb632d4267bd512fb062f9ba93','03277e127fe5436aa9a88c0eac1c6b0b','12');----
INSERT INTO word VALUES ('b8b221d0e959440d9926fbdb9635e0bc','box','[bɔks]','http://res.iciba.com/resource/amp3/0/0/34/be/34be958a921e43d813a2075297d8e862.mp3','n. 专席；包厢；电视机','','');----
INSERT INTO classwords VALUES ('8eff55662cf8443f8606a72917581fc4','b8b221d0e959440d9926fbdb9635e0bc','12');----
INSERT INTO word VALUES ('326d1a0042194ffbacbe1062f5a24591','magnet','[ˈmæɡnit]','http://res.iciba.com/resource/amp3/oxford/0/2b/30/2b30b282deb06adf37e9b46c86b450c3.mp3','n. 有吸引力的人（或物）；磁铁','','');----
INSERT INTO classwords VALUES ('987856ee7f90481ca0328beced596cc0','326d1a0042194ffbacbe1062f5a24591','12');----
INSERT INTO word VALUES ('ff44d4962b2e45cebd40e756c350aabd','extravagant','[iksˈtræviɡənt]','http://res.iciba.com/resource/amp3/oxford/0/4d/c3/4dc3a548ed9d2c92cf73c7417362efc4.mp3','adj. 奢侈的；过度的；离谱的','','');----
INSERT INTO classwords VALUES ('e2a17a345855463caee4b39edd04c96c','ff44d4962b2e45cebd40e756c350aabd','12');----
INSERT INTO word VALUES ('5fca42ca85f54982ba60eb2d528b5464','astronomy','[əsˈtrɔnəmi]','http://res.iciba.com/resource/amp3/oxford/0/a1/6b/a16b3838ed23bc5c11c449a2e8c9f327.mp3','n. 天文学','','');----
INSERT INTO classwords VALUES ('cdac509fa24c435dab09d02999659558','5fca42ca85f54982ba60eb2d528b5464','12');----
INSERT INTO word VALUES ('1dca4d31e481459b9b3488666885d3c0','decline','[diˈklain]','http://res.iciba.com/resource/amp3/oxford/0/d2/43/d24360bc78d0476decb41644beb49176.mp3','vt. 下降；谢绝；衰退','','');----
INSERT INTO classwords VALUES ('c6af19a96a8e4a10a470a749d935337e','1dca4d31e481459b9b3488666885d3c0','12');----
INSERT INTO word VALUES ('022a20cae77b44f1b33b2fb7952d2dd9','loosely','[ˈlu:slɪ]','http://res.iciba.com/resource/amp3/oxford/0/c5/2e/c52e09653161556d9210905efd2a8824.mp3','adv. 松弛地，松散地；轻率地','','');----
INSERT INTO classwords VALUES ('2db96539a92e481fa88407dcb2514c0b','022a20cae77b44f1b33b2fb7952d2dd9','12');----
INSERT INTO word VALUES ('339125b0c8e04da5a0add4c0ea602a96','circulation','[ˌsə:kjuˈleiʃən]','http://res.iciba.com/resource/amp3/oxford/0/c6/44/c6443cb32e07f0bcfd2e14638c4f2c67.mp3','n. 血液循环；发行量','','');----
INSERT INTO classwords VALUES ('f1953f8717474f3288f54306df387f0b','339125b0c8e04da5a0add4c0ea602a96','12');----
INSERT INTO word VALUES ('2a3ed17fa0ed4020bd389e7109067e77','adhere','[ədˈhiə]','http://res.iciba.com/resource/amp3/0/0/e2/32/e2325955c56e3af895605a187bfcc3ba.mp3','vi. 粘附；遵守；坚持','','');----
INSERT INTO classwords VALUES ('21bcb61092ed4fa9b5c9cc85c29d5d26','2a3ed17fa0ed4020bd389e7109067e77','12');----
INSERT INTO word VALUES ('b2c11de38921475a810aa21fc861aeaf','module','[ˈmɔdju:l]','http://res.iciba.com/resource/amp3/0/0/22/88/22884db148f0ffb0d830ba431102b0b5.mp3','n. 单元；模块；组件','','');----
INSERT INTO classwords VALUES ('c2a9799bed744119835f8fe8fcef8494','b2c11de38921475a810aa21fc861aeaf','12');----
INSERT INTO word VALUES ('d96d8463ad4744858a2241304fef8bb8','splash','[splæʃ]','http://res.iciba.com/resource/amp3/oxford/0/73/b3/73b356d4c0dd0fda1ad71addd3647d01.mp3','n. 溅泼声','','');----
INSERT INTO classwords VALUES ('473952cc26e94033843831f555aff9b7','d96d8463ad4744858a2241304fef8bb8','12');----
INSERT INTO word VALUES ('56d488abf54d4c7ab33ef7aba25cbfda','illusion','[iˈlju:ʒən]','http://res.iciba.com/resource/amp3/oxford/0/a7/1b/a71b99c601a75c2c5318224ae26f785c.mp3','n. 幻想；错觉；假象','','');----
INSERT INTO classwords VALUES ('c519945394bb4eaea17cbe812898724f','56d488abf54d4c7ab33ef7aba25cbfda','12');----
INSERT INTO word VALUES ('cb30adf37f8241e690beb82548b71f03','formidable','[ˈfɔ:midəbl]','http://res.iciba.com/resource/amp3/oxford/0/27/8f/278f420c23e33a19633d666b86c07a6f.mp3','adj. 可怕的；难对付的；令人惊叹的；...','','');----
INSERT INTO classwords VALUES ('5b6ea5b046144642ba46a7e590d2a114','cb30adf37f8241e690beb82548b71f03','12');----
INSERT INTO word VALUES ('87e5210f98e949ceb0974239f1898da2','constraint','[kənˈstreint]','http://res.iciba.com/resource/amp3/oxford/0/a7/7d/a77d89131780b796d909095e272dfa72.mp3','n. 限制，束缚；约束；克制','','');----
INSERT INTO classwords VALUES ('b71f4cd971d847c38e23a1fa1be007cc','87e5210f98e949ceb0974239f1898da2','12');----
INSERT INTO word VALUES ('1adcef6b056c45cfb513fe8fbd53fbb0','assurance','[əˈʃuərəns]','http://res.iciba.com/resource/amp3/oxford/0/fe/27/fe27cd8d4aedeea0aac84473500f0705.mp3','n. 保证；信心；保险','','');----
INSERT INTO classwords VALUES ('cd390b36bfb04345ae4431af765b1d8d','1adcef6b056c45cfb513fe8fbd53fbb0','12');----
INSERT INTO word VALUES ('cc76d43fa57b4809856bba2fa9889051','trolley','[ˈtrɔli]','http://res.iciba.com/resource/amp3/0/0/c4/83/c483e1c93617f88a758a51d48f66de58.mp3','n. 手推车；小推车；担架车；有轨电车','','');----
INSERT INTO classwords VALUES ('b4296104072749bd90f48f68d5a1d5d5','cc76d43fa57b4809856bba2fa9889051','12');----
INSERT INTO word VALUES ('558337c9b5c54534a50695b06b68cd07','infectious','[inˈfekʃəs]','http://res.iciba.com/resource/amp3/oxford/0/fc/ca/fcca01e7b18a86ebbbd9a86cfb83c87b.mp3','adj. 传染的；有感染力的','','');----
INSERT INTO classwords VALUES ('457cb0a77afe4c5ba032e046069d86ec','558337c9b5c54534a50695b06b68cd07','12');----
INSERT INTO word VALUES ('3bff0051b992403499c82be56d973696','fury','[ˈfjuəri]','http://res.iciba.com/resource/amp3/0/0/3f/df/3fdf5f4083319262fc510e0b2ac97dd3.mp3','n. 狂怒，暴怒','','');----
INSERT INTO classwords VALUES ('1d83e0012f5e4db4b037a4a1ffff039e','3bff0051b992403499c82be56d973696','12');----
INSERT INTO word VALUES ('03412f3e2417432983da9c6d2c08d805','elapse','[iˈlæps]','http://res.iciba.com/resource/amp3/oxford/0/df/aa/dfaab21f9001e1dbd1262e90f8c306fb.mp3','vi. （时间）过去，消逝','','');----
INSERT INTO classwords VALUES ('7aef736333264b35bdcf4c222143b50b','03412f3e2417432983da9c6d2c08d805','12');----
INSERT INTO word VALUES ('7632744dbf4f430da53397fb92be77f9','competitor','[kəmˈpetɪtə]','http://res.iciba.com/resource/amp3/oxford/0/86/90/869068947d442720751142444abb23bc.mp3','n. 竞争者，对手；参赛者','','');----
INSERT INTO classwords VALUES ('8ed6f6a2166446acb6d6e47ce2ed448b','7632744dbf4f430da53397fb92be77f9','12');----
INSERT INTO word VALUES ('55eacd3592494cf09febda17f67dda8b','sniff','[snif]','http://res.iciba.com/resource/amp3/oxford/0/a5/58/a558fbffd4b3981d5d31d85bcd472bc7.mp3','vt. 嗅；抽鼻子；轻蔑地说','','');----
INSERT INTO classwords VALUES ('c4f402727ff94b93a3c358d07b593289','55eacd3592494cf09febda17f67dda8b','12');----
INSERT INTO word VALUES ('306333ce7c994faca4250954ef2a93f4','identificatio...','[aiˌdentifiˈkeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/2b/eb/2beb8a443331a80a3acff864ad8d6bfb.mp3','n. 识别，鉴定；身份证','','');----
INSERT INTO classwords VALUES ('720a377c42744f7a88d95752b650d957','306333ce7c994faca4250954ef2a93f4','12');----
INSERT INTO word VALUES ('a2bc88d490844038ad65c132f291330b','mansion','[ˈmænʃən]','http://res.iciba.com/resource/amp3/oxford/0/84/36/8436c511ba8469a6177f462ab9a8fe53.mp3','n. 大厦，大楼；宅邸','','');----
INSERT INTO classwords VALUES ('c9c335df656d4551ad3088d45e55c188','a2bc88d490844038ad65c132f291330b','12');----
INSERT INTO word VALUES ('f6d05379f059443e8b256e595927e47f','hide','[haid]','http://res.iciba.com/resource/amp3/oxford/0/d2/9a/d29ad2793920ef8a65f417b93a871843.mp3','v. 隐藏；躲藏；隐瞒；遮盖','','');----
INSERT INTO classwords VALUES ('62f6da8a67df44e5b9bc2d443dca1b0a','f6d05379f059443e8b256e595927e47f','12');----
INSERT INTO word VALUES ('6e197aab672d4e67a73b30afdce9c676','caution','[ˈkɔ:ʃən]','http://res.iciba.com/resource/amp3/oxford/0/11/81/11815bc0be32808dd021dbd8ee11eaf3.mp3','vt. 警告；告诫','','');----
INSERT INTO classwords VALUES ('1b093b1fcea24375ae45f3832f8f9d9b','6e197aab672d4e67a73b30afdce9c676','12');----
INSERT INTO word VALUES ('42c163c02795426b9f070e5696adbda1','theft','[θeft]','http://res.iciba.com/resource/amp3/oxford/0/8d/75/8d75f579900a280a7d556bb0ac2fff91.mp3','n. 盗窃罪，偷窃','','');----
INSERT INTO classwords VALUES ('560dce3c58144ba7ba773cfe8b3f46ff','42c163c02795426b9f070e5696adbda1','12');----
INSERT INTO word VALUES ('02b1163229644651952a428e9c56fd1c','exile','[ˈeksail]','http://res.iciba.com/resource/amp3/oxford/0/5a/5a/5a5a4fba7c8b8c56cc58dada40f1ff65.mp3','n. 被流放者；流放','','');----
INSERT INTO classwords VALUES ('d84b50be8f5f4df28308d63815e62889','02b1163229644651952a428e9c56fd1c','12');----
INSERT INTO word VALUES ('2ca7fa73c9e44bf88c76eefe11167930','footpath','[ˈfʊtˌpæθ]','http://res.iciba.com/resource/amp3/oxford/0/ec/c1/ecc1d592b1bcfee4ac1797f7a81a3d2a.mp3','n. 小路；人行道','','');----
INSERT INTO classwords VALUES ('43f149e1dd164e87ada9462bdca6763f','2ca7fa73c9e44bf88c76eefe11167930','12');----
INSERT INTO word VALUES ('cc36c2599c064319b3bf81e3ca7b39af','consequent','[ˈkɔnsikwənt]','http://res.iciba.com/resource/amp3/oxford/0/53/98/53989fec02c41f976da0706bd1a24ed1.mp3','adj. 作为结果的；随之发生的','','');----
INSERT INTO classwords VALUES ('100c5332792c4e4ab615e3922ac2c02a','cc36c2599c064319b3bf81e3ca7b39af','12');----
INSERT INTO word VALUES ('b3b088d2a5a846c9b47e9780337bf746','mischief','[ˈmistʃif]','http://res.iciba.com/resource/amp3/oxford/0/93/c6/93c646833ee6ecf36719f419dea6fca8.mp3','n. 调皮，淘气，恶作剧；惹麻烦之事','','');----
INSERT INTO classwords VALUES ('9fa24e01bebb49d393fad83b612737d4','b3b088d2a5a846c9b47e9780337bf746','12');----
INSERT INTO word VALUES ('b1d320a2efc640668074458e038c3ea6','shadowy','[ˈʃædəʊi:]','http://res.iciba.com/resource/amp3/oxford/0/a9/78/a9781d4a90902881f8b3fc69a69a53cc.mp3','adj. 昏暗的；幽暗的；模糊的','','');----
INSERT INTO classwords VALUES ('09f7136a09b141008363553faeca8b5d','b1d320a2efc640668074458e038c3ea6','12');----
INSERT INTO word VALUES ('bcbc9d2019f14c0390906512a518d165','hardy','[ˈhɑ:di]','http://res.iciba.com/resource/amp3/0/0/0c/da/0cdadc9ab9e91d4a482958962f56a566.mp3','adj. 强壮的；耐寒的','','');----
INSERT INTO classwords VALUES ('56f27e001eea4808be44dc4a7ee42408','bcbc9d2019f14c0390906512a518d165','12');----
INSERT INTO word VALUES ('7ac5abdbdc134bec9c22ed0f6a1168a2','clutch','[klʌtʃ]','http://res.iciba.com/resource/amp3/oxford/0/ea/04/ea04f95a425b588a9b6e3607e09cc4d4.mp3','n. 控制，掌握；离合器','','');----
INSERT INTO classwords VALUES ('8e1a4c7055ce47cb9a1ebc78bd6efe90','7ac5abdbdc134bec9c22ed0f6a1168a2','12');----
INSERT INTO word VALUES ('5931d2912cf44994b68974b39ca0f429','blouse','[blauz]','http://res.iciba.com/resource/amp3/0/0/2b/bb/2bbbc09c29efa9bebd8718aa6f9d7bae.mp3','n. 女衬衫；短上衣','','');----
INSERT INTO classwords VALUES ('db0c8265638740d681cd70ddcdd5dc92','5931d2912cf44994b68974b39ca0f429','12');----
INSERT INTO word VALUES ('3eeb6e00d268420398b355060fb5d5c6','objective','[əbˈdʒektiv]','http://res.iciba.com/resource/amp3/oxford/0/18/08/1808dc4d43f2ce6d3ae69ac674c69b55.mp3','adj. 客观的','','');----
INSERT INTO classwords VALUES ('facb91331b1143e384e59860e85ef916','3eeb6e00d268420398b355060fb5d5c6','12');----
INSERT INTO word VALUES ('7f4e68efd898452881f4173c69279c5c','longitude','[ˈlɔndʒitju:d]','http://res.iciba.com/resource/amp3/0/0/ba/56/ba569b80f7bb7762f073f1be57cc36aa.mp3','n. 经度','','');----
INSERT INTO classwords VALUES ('48070c833c10439aacba4c3a996933e8','7f4e68efd898452881f4173c69279c5c','12');----
INSERT INTO word VALUES ('2be0a585478144cba0f0e439bedcc390','dispatch','[disˈpætʃ]','http://res.iciba.com/resource/amp3/oxford/0/a0/3d/a03da39eee2fc19019e740d4f0becf60.mp3','n. 急件；迅速，急速；新闻报道','','');----
INSERT INTO classwords VALUES ('0d97c26d452c4ad9a773bbbb48d1059e','2be0a585478144cba0f0e439bedcc390','12');----
INSERT INTO word VALUES ('0aecc36b92514f42b13b35e455ab55af','dessert','[diˈzə:t]','http://res.iciba.com/resource/amp3/0/0/ea/bb/eabbf14ccc6150d9122050d27bc43c7c.mp3','n. 甜点','','');----
INSERT INTO classwords VALUES ('0cfc3c0e242b45758666fbdba0531f57','0aecc36b92514f42b13b35e455ab55af','12');----
INSERT INTO word VALUES ('da497dc1ae29450aa7e005b1f6368309','void','[vɔid]','http://res.iciba.com/resource/amp3/oxford/0/ce/e6/cee67074e260d805b82a631c131ef6d2.mp3','adj. 没有的；无效的','','');----
INSERT INTO classwords VALUES ('51e01920889341b4bec244d14ef20ff3','da497dc1ae29450aa7e005b1f6368309','12');----
INSERT INTO word VALUES ('0587e80948ed45adbe432f46a2cdd5af','calibration','[ˌkæləˈbreɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/e5/c4/e5c41b2d84a91fc7ee7cb88c619fa4ba.mp3','n. 校准；刻度','','');----
INSERT INTO classwords VALUES ('8b15d66d2e914eb48c6139dcd113ba6a','0587e80948ed45adbe432f46a2cdd5af','12');----
INSERT INTO word VALUES ('7707054c8b4f4636851c46efc2355051','program','[ˈprəuɡræm]','http://res.iciba.com/resource/amp3/oxford/0/4f/c1/4fc10cff5d15bce21e337eb25fceb95c.mp3','v. 为（计算机）编制程序','','');----
INSERT INTO classwords VALUES ('7d04b9e460744c1ab9d355efd06f015c','7707054c8b4f4636851c46efc2355051','12');----
INSERT INTO word VALUES ('6905c29087234c1c8cadb8a621c87a67','subscribe','[səbˈskraib]','http://res.iciba.com/resource/amp3/oxford/0/59/60/5960986597e546104a87c9feaa581101.mp3','vi. 订购，订阅；定期捐款','','');----
INSERT INTO classwords VALUES ('07d4edfa5ddd425e93a9396379b81ad6','6905c29087234c1c8cadb8a621c87a67','12');----
INSERT INTO word VALUES ('834d432e9f7e4330a0970e2165299e92','realization','[ˌri:əlɪˈzeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/9f/15/9f153e6185aba49d2a964915d2f48711.mp3','n. 实现；认识，领会','','');----
INSERT INTO classwords VALUES ('582781606adb49c2b4e4fee7be64286f','834d432e9f7e4330a0970e2165299e92','12');----
INSERT INTO word VALUES ('dd185233082841fbbf180166cd58be51','purify','[ˈpjuərifai]','http://res.iciba.com/resource/amp3/oxford/0/41/9d/419dc40681afe589458e5937e5b39ec6.mp3','vt. 使纯净，净化','','');----
INSERT INTO classwords VALUES ('0e51d99a9bf04f9ea4415979229ae000','dd185233082841fbbf180166cd58be51','12');----
INSERT INTO word VALUES ('f78e283a05f148b1aca03eaeff481a0b','strive','[straiv]','http://res.iciba.com/resource/amp3/oxford/0/0a/39/0a39bd5e0b0af23abb95ea835a575a51.mp3','vi. 努力，奋斗，力求','','');----
INSERT INTO classwords VALUES ('30fc0839b8c4410ba744d519c578f43d','f78e283a05f148b1aca03eaeff481a0b','12');----
INSERT INTO word VALUES ('878711d3b72d4dcaba0ff83c2aa0133b','systematicall...','[ˌsɪstəˈmætɪkəlɪ]','http://res.iciba.com/resource/amp3/0/0/bc/99/bc998d43fb8669a692b8888ea4108719.mp3','adv. 系统地；有条不紊地','','');----
INSERT INTO classwords VALUES ('eb336853657c478283266e9807c0d1b9','878711d3b72d4dcaba0ff83c2aa0133b','12');----
INSERT INTO word VALUES ('7fd3eea269f543d5b116fd30f3bbcdc8','inaccessible','[ˌɪnækˈsesəbəl]','http://res.iciba.com/resource/amp3/oxford/0/40/3d/403d0d3f0097018bdca1275579127c85.mp3','adj. 达不到的；见不到的；难懂的','','');----
INSERT INTO classwords VALUES ('3a89f30601874bf6b7b78c4f0cee5b1f','7fd3eea269f543d5b116fd30f3bbcdc8','12');----
INSERT INTO word VALUES ('ae267c4cf858447abdedc008bf89c28d','superb','[ˌsju:ˈpə:b]','http://res.iciba.com/resource/amp3/0/0/89/50/8950bea5530975cd2719033f50085b42.mp3','adj. 极佳的；超凡的','','');----
INSERT INTO classwords VALUES ('fde637c5f2844eb39fbd0216f6388e1e','ae267c4cf858447abdedc008bf89c28d','12');----
INSERT INTO word VALUES ('7bf6079625704a29b90af6b84eea14a6','postal','[ˈpəʊstəl]','http://res.iciba.com/resource/amp3/0/0/26/15/2615184d0d14f10ef400be857b158a1a.mp3','adj. 邮政的；邮寄的','','');----
INSERT INTO classwords VALUES ('56fbcd051b5140aa9e532fef2c5fa3a0','7bf6079625704a29b90af6b84eea14a6','12');----
INSERT INTO word VALUES ('664978fb5bb44527803b9b073c4ab115','line','[lain]','http://res.iciba.com/resource/amp3/oxford/0/f3/3d/f33d2f12b98a27bdd6e53cd929f33176.mp3','vt. 给…安衬里；沿…排列成行','','');----
INSERT INTO classwords VALUES ('e52466b4b32c4524bc83c6fe836cae12','664978fb5bb44527803b9b073c4ab115','12');----
INSERT INTO word VALUES ('0e35750610ce4b82b07d6b6a587e0ea7','leaflet','[ˈli:flit]','http://res.iciba.com/resource/amp3/oxford/0/9e/8e/9e8e80790268a27a3085ec0984197042.mp3','n. 传单，小册子','','');----
INSERT INTO classwords VALUES ('9ff644a6caae487aaf905fd804d219ae','0e35750610ce4b82b07d6b6a587e0ea7','12');----
INSERT INTO word VALUES ('b0b399ad456849a78faea54705e892f8','flush','[flʌʃ]','http://res.iciba.com/resource/amp3/oxford/0/f0/5f/f05fe906eec63e47c314371471f7b069.mp3','v. 脸红；冲刷','','');----
INSERT INTO classwords VALUES ('1ac67c5da9b44df987bef5c8a7984dea','b0b399ad456849a78faea54705e892f8','12');----
INSERT INTO word VALUES ('1dd9599d68374aa0bfa71abefe8caf7c','linger','[ˈliŋɡə]','http://res.iciba.com/resource/amp3/oxford/0/19/99/1999c9a2b0ac840bfd17e8043162ea31.mp3','vi. 逗留，徘徊；继续存留','','');----
INSERT INTO classwords VALUES ('c4de9233a7db4cb28a33e6d7c6a0ef63','1dd9599d68374aa0bfa71abefe8caf7c','12');----
INSERT INTO word VALUES ('0ec57db3a16e4a89a1ee5126b7290e5b','fuse','[fju:z]','http://res.iciba.com/resource/amp3/oxford/0/7d/50/7d504404efb36f870b1aa145f4fecf28.mp3','n. 保险丝；导火线','','');----
INSERT INTO classwords VALUES ('9c7e165f8f524fa6b07d42b1836a5a8c','0ec57db3a16e4a89a1ee5126b7290e5b','12');----
INSERT INTO word VALUES ('99bc432b07894704a704654e8b0fd63d','glorify','[ˈglɔ:rəˌfaɪ]','http://res.iciba.com/resource/amp3/oxford/0/0b/da/0bda84b418529f2c47be07fa9f345c0c.mp3','vt. 赞美；颂扬；美化','','');----
INSERT INTO classwords VALUES ('7064304a858c4be4aa173904f12c1a8d','99bc432b07894704a704654e8b0fd63d','12');----
INSERT INTO word VALUES ('859a5e2d9ebb4c25a63841b1fa09f2a3','trivial','[ˈtriviəl]','http://res.iciba.com/resource/amp3/oxford/0/b0/1a/b01a0e42f7be96558f9dd1c4aaea0c42.mp3','adj. 琐碎的；微不足道的','','');----
INSERT INTO classwords VALUES ('ee1df55af39b46ff9cfb56fb34875e7a','859a5e2d9ebb4c25a63841b1fa09f2a3','12');----
INSERT INTO word VALUES ('f02f08477b2d477d94d5ef3ee3050eb2','observation','[ˌɔbzə:ˈveiʃən]','http://res.iciba.com/resource/amp3/oxford/0/89/c1/89c174e936ae9367403831187aeed7d3.mp3','n. 观察；观察所得；评论；观察力','','');----
INSERT INTO classwords VALUES ('614b80a87f6142feb2102ad49ee24760','f02f08477b2d477d94d5ef3ee3050eb2','12');----
INSERT INTO word VALUES ('32edcde349c243f6bf12a22eb3abfd9a','plunder','[ˈplʌndə]','http://res.iciba.com/resource/amp3/oxford/0/16/6d/166d77c1e36bf1867b32e8123f80e6f4.mp3','v. 掠夺，劫掠','','');----
INSERT INTO classwords VALUES ('16258e10c583447db953b888b7e70a9c','32edcde349c243f6bf12a22eb3abfd9a','12');----
INSERT INTO word VALUES ('09c9452f487c4879911be46088658a72','pore','[pɔ:]','http://res.iciba.com/resource/amp3/oxford/0/d6/29/d629e56f12bd094e9dd2a19959dbcb7d.mp3','n. 毛孔；气孔','','');----
INSERT INTO classwords VALUES ('3211c0bc754f4494b0ada82fb8a3962c','09c9452f487c4879911be46088658a72','12');----
INSERT INTO word VALUES ('9fe771fc08464f1d92bf0d5c972106d0','bump','[bʌmp]','http://res.iciba.com/resource/amp3/oxford/0/e0/06/e006457d28e9a7c9406c63fc6718becb.mp3','n. 肿块；碰撞','','');----
INSERT INTO classwords VALUES ('418019cff3b847c0b4beb301ab636ed1','9fe771fc08464f1d92bf0d5c972106d0','12');----
INSERT INTO word VALUES ('c0a5a0d539664f45b5b2b974a030c607','peacock','[ˈpi:ˌkɔk]','http://res.iciba.com/resource/amp3/oxford/0/e6/91/e6914eb7c1fb8456ccef8df71b6bbf43.mp3','n. 孔雀；骄傲自大的人','','');----
INSERT INTO classwords VALUES ('ceecc039b36641beb7a3e9e17f8bf354','c0a5a0d539664f45b5b2b974a030c607','12');----
INSERT INTO word VALUES ('03060466eb5044d6ae1529cb29f4649c','unemployment','[ˌʌnimˈplɔimənt]','http://res.iciba.com/resource/amp3/oxford/0/ce/61/ce615b65fb84d72a27bf29b9e7cdb1fa.mp3','n. 失业；失业人数，失业率','','');----
INSERT INTO classwords VALUES ('3eef1e95d4e1436292a0ffec6766314c','03060466eb5044d6ae1529cb29f4649c','12');----
INSERT INTO word VALUES ('bd5aa210f3074dd79fe3ae7a2127bcac','synthesis','[ˈsinθisis]','http://res.iciba.com/resource/amp3/oxford/0/55/16/551628c3de4ec0b2ebf7dfde7e2f60fd.mp3','n. 合成；综合，综合物','','');----
INSERT INTO classwords VALUES ('b5b6545a45cb465dbce56a5346541c99','bd5aa210f3074dd79fe3ae7a2127bcac','12');----
INSERT INTO word VALUES ('b90ff44ab2574bc5b42f7295c088ce2c','scarlet','[ˈskɑ:lɪt]','http://res.iciba.com/resource/amp3/0/0/54/06/54067a5b738923497a9354fd57c8421e.mp3','adj. 鲜红的，深红的；羞红的','','');----
INSERT INTO classwords VALUES ('a50c9ac52a474964a801f6d9b04c9648','b90ff44ab2574bc5b42f7295c088ce2c','12');----
INSERT INTO word VALUES ('a4709b6fbf60472f92dfeb92c5c7be27','novelty','[ˈnɔvəlti]','http://res.iciba.com/resource/amp3/oxford/0/c6/e0/c6e0c4387a0af5bb73b92083266b6cfd.mp3','n. 新颖；新奇的事物；小玩意','','');----
INSERT INTO classwords VALUES ('86e219f8d0854b81832ea6ef46256833','a4709b6fbf60472f92dfeb92c5c7be27','12');----
INSERT INTO word VALUES ('3fea717cfb9b4aa8b3825033edb7e1e6','tabulate','[ˈtæbjəˌleɪt]','http://res.iciba.com/resource/amp3/oxford/0/36/a9/36a959abe8ffd12127e1bbd05b3e7902.mp3','vt. 把…制成表','','');----
INSERT INTO classwords VALUES ('ac614eda7a004d15867fd79475417852','3fea717cfb9b4aa8b3825033edb7e1e6','12');----
INSERT INTO word VALUES ('41ee0fbb48c24e19b6e4836d2955ed8a','slumber','[ˈslʌmbə]','http://res.iciba.com/resource/amp3/oxford/0/7f/64/7f64ac10e10953f88930043618646f6d.mp3','n. 睡眠','','');----
INSERT INTO classwords VALUES ('55cd4304e3b54098801bba1ae1a31721','41ee0fbb48c24e19b6e4836d2955ed8a','12');----
INSERT INTO word VALUES ('4268fb6cea3f404eaf54b769fdf96b91','verge','[və:dʒ]','http://res.iciba.com/resource/amp3/0/0/af/e7/afe76348b19a69a5b4beb8641095dd16.mp3','n. 边缘，边界，界限','','');----
INSERT INTO classwords VALUES ('7e34314431f141bfbe28ec3286c4db32','4268fb6cea3f404eaf54b769fdf96b91','12');----
INSERT INTO word VALUES ('89bbf7660bfe44f19d69b0450a04a660','comply','[kəmˈplai]','http://res.iciba.com/resource/amp3/oxford/0/69/20/6920d400e6f77134af2b8bd1a9e7c0ee.mp3','vi. 服从；遵守','','');----
INSERT INTO classwords VALUES ('d67b451ef35348448e16ea45baf0da86','89bbf7660bfe44f19d69b0450a04a660','12');----
INSERT INTO word VALUES ('6792c6daa95f4e4ba995c23c5531780e','solar','[ˈsəulə]','http://res.iciba.com/resource/amp3/oxford/0/c6/6e/c66ef8e0ba12ce6624bc615e7b21926d.mp3','adj. 太阳的','','');----
INSERT INTO classwords VALUES ('7a8b8c47780747089b98fd4c45d21d84','6792c6daa95f4e4ba995c23c5531780e','12');----
INSERT INTO word VALUES ('f160fa4964584a8c81ca776928974835','value','[ˈvælju]','http://res.iciba.com/resource/amp3/oxford/0/6f/94/6f94f15e1f0187484aef05c820ede906.mp3','vt. 珍视，重视；给…估价','','');----
INSERT INTO classwords VALUES ('e9d17dad067b4e5da7bd537230e823b6','f160fa4964584a8c81ca776928974835','12');----
INSERT INTO word VALUES ('ec40fd8d6e07450ebd972bfe80ac4c60','ambiguous','[æmˈbiɡjuəs]','http://res.iciba.com/resource/amp3/oxford/0/22/04/22044ed857571a70a2ed25c3db9dddb0.mp3','adj. 模棱两可的，含糊不清的','','');----
INSERT INTO classwords VALUES ('54619567ef334e1db2cad90464016027','ec40fd8d6e07450ebd972bfe80ac4c60','12');----
INSERT INTO word VALUES ('ff8662af0f3c4b288f1b7406f44e9f65','hush','[hʌʃ]','http://res.iciba.com/resource/amp3/oxford/0/2a/ec/2aec0806c4edf553339037be4965ef0d.mp3','v. 使安静下来','','');----
INSERT INTO classwords VALUES ('816e799be70c4c1585ff796622184e98','ff8662af0f3c4b288f1b7406f44e9f65','12');----
INSERT INTO word VALUES ('655ade76895c4f2ba0bfa424031e36a6','rip','[rip]','http://res.iciba.com/resource/amp3/oxford/0/83/cf/83cffeec518b68bfebd8efe1b5eddb1f.mp3','vi. 撕开，扯开；撕去；穿透','','');----
INSERT INTO classwords VALUES ('339242016c7c489aa2f2813fd04f4e26','655ade76895c4f2ba0bfa424031e36a6','12');----
INSERT INTO word VALUES ('ec9542a8f385468fb18bfd27201354da','sensor','[ˈsensə]','http://res.iciba.com/resource/amp3/oxford/0/30/7f/307f5330ebec7317d79495c9c97672fc.mp3','n. 传感器，灵敏元件','','');----
INSERT INTO classwords VALUES ('1423347d8bf04d19a74e85c14ad83304','ec9542a8f385468fb18bfd27201354da','12');----
INSERT INTO word VALUES ('a56b0cbee18749339736d78bd74ebcd0','halve','[hæv]','http://res.iciba.com/resource/amp3/0/0/dc/17/dc175a44808b61dbb9208c3fa3c9ffb3.mp3','vt. 把…减半；平摊；将…对半分','','');----
INSERT INTO classwords VALUES ('31bbaa5167db43a0a9d5315c0a3675e9','a56b0cbee18749339736d78bd74ebcd0','12');----
INSERT INTO word VALUES ('56f106b145e74c5e80fe7e8bebeb99b5','triangular','[traɪˈæŋgjələ]','http://res.iciba.com/resource/amp3/oxford/0/8d/01/8d01ff0e61acb5063261718aa630d1bc.mp3','adj. 三角的；三人间的','','');----
INSERT INTO classwords VALUES ('8a960916c0664931a97178fd32264d92','56f106b145e74c5e80fe7e8bebeb99b5','12');----
INSERT INTO word VALUES ('4e469b3ccc424650b693f566195d6b82','porcelain','[ˈpɔ:slin]','http://res.iciba.com/resource/amp3/oxford/0/db/2e/db2ea055a97daaa6c29638fe82e6dfb4.mp3','adj. 瓷制的；精美的','','');----
INSERT INTO classwords VALUES ('5e6b94522f35450091ccca09629fedbc','4e469b3ccc424650b693f566195d6b82','12');----
INSERT INTO word VALUES ('3a20795e62784d3ebcca8d053b0849d0','equivalent','[iˈkwivələnt]','http://res.iciba.com/resource/amp3/oxford/0/8f/b1/8fb1f1a3cf0c9f834b6eaced557bccdd.mp3','adj. 相等的，相当的','','');----
INSERT INTO classwords VALUES ('f9a2de9698f5494cb823c852e89e805a','3a20795e62784d3ebcca8d053b0849d0','12');----
INSERT INTO word VALUES ('1ef33a21f55148bd976ac476db8fa8bf','frightful','[ˈfraɪtfəl]','http://res.iciba.com/resource/amp3/oxford/0/19/72/19720e2c5f8b1ac3a6bdcb3a6066b51f.mp3','adj. 可怕的；讨厌的；非常的','','');----
INSERT INTO classwords VALUES ('d2a7ec342dc84ffaa7968ec31bf17bcd','1ef33a21f55148bd976ac476db8fa8bf','12');----
INSERT INTO word VALUES ('2d17ca0b068b4ccd9c6ede7eb47fa9a1','Buddhism','[ˈbudizəm]','http://res.iciba.com/resource/amp3/oxford/0/4e/8a/4e8a0d0b0c95933377df469ee1f3993d.mp3','n. 佛教','','');----
INSERT INTO classwords VALUES ('e4b39790b4f848a786eb9822ca921afe','2d17ca0b068b4ccd9c6ede7eb47fa9a1','12');----
INSERT INTO word VALUES ('9f93b73bf18b4ce3b5d9ff9c377d3d3e','garlic','[ˈɡɑ:lik]','http://res.iciba.com/resource/amp3/0/0/cc/f6/ccf6184efe5e38da61ef2e9a30d1c1ea.mp3','n. 蒜，大蒜','','');----
INSERT INTO classwords VALUES ('488621e7cb10462cae5c61dd5005f496','9f93b73bf18b4ce3b5d9ff9c377d3d3e','12');----
INSERT INTO word VALUES ('555c454a3f6b49a399f3ec031e5097ff','alert','[əˈlə:t]','http://res.iciba.com/resource/amp3/0/0/7e/d2/7ed21143076d0cca420653d4345baa2f.mp3','adj. 警惕的；机敏的','','');----
INSERT INTO classwords VALUES ('f189dbe6164c41ae95ff96f95d12a903','555c454a3f6b49a399f3ec031e5097ff','12');----
INSERT INTO word VALUES ('d510281ee8fa46a9b3aa78056898fbea','compression','[kəmˈpreʃən]','http://res.iciba.com/resource/amp3/0/0/07/f5/07f5d2d550d5961d1dd0984fe666a2f6.mp3','n. 压缩，压紧','','');----
INSERT INTO classwords VALUES ('15bb2e2820424ee5b7f1cff476a87100','d510281ee8fa46a9b3aa78056898fbea','12');----
INSERT INTO word VALUES ('d849056aac2f460f850fec85e36be1c3','urge','[ə:dʒ]','http://res.iciba.com/resource/amp3/0/0/3b/63/3b6377359fa75e487f3ac0bc647685bc.mp3','vt. 催促；敦促；力劝；强烈要求','','');----
INSERT INTO classwords VALUES ('2353d341364f4140b607b25da5b17cc6','d849056aac2f460f850fec85e36be1c3','12');----
INSERT INTO word VALUES ('573315c431cc454582f743e142cc47aa','strength','[streŋθ]','http://res.iciba.com/resource/amp3/oxford/0/08/86/08866f402fa65f5baeeb5d7e5c13af1d.mp3','n. 体力；强度；信心，勇气；实力','','');----
INSERT INTO classwords VALUES ('04e7892299294b52bc31e4e0977e65f9','573315c431cc454582f743e142cc47aa','12');----
INSERT INTO word VALUES ('3a3f40026b2140cda39fd7c85ba0abe2','homely','[ˈhəʊmli:]','http://res.iciba.com/resource/amp3/0/0/ba/45/ba45be928a39f5ac48b1a992028f3450.mp3','adj. 热情亲切的；家常的；相貌平平的','','');----
INSERT INTO classwords VALUES ('ba10005342824ce8b8bd75eb63d87e76','3a3f40026b2140cda39fd7c85ba0abe2','12');----
INSERT INTO word VALUES ('fdba4017e266461f9df34eb43d1694d9','hatch','[hætʃ]','http://res.iciba.com/resource/amp3/oxford/0/c0/f2/c0f2b746ae78391321e8190bdb7a637c.mp3','vt.&vi. 孵出；孵化；筹划','','');----
INSERT INTO classwords VALUES ('643bbfa5b70c4f849ae4ec1c49c28fc6','fdba4017e266461f9df34eb43d1694d9','12');----
INSERT INTO word VALUES ('cd7a77e7a7a941dcbef4908650d06f22','engagement','[inˈɡeidʒmənt]','http://res.iciba.com/resource/amp3/oxford/0/a0/7f/a07f52990611ca95becf751d39b5a921.mp3','n. 婚约；约会；战斗','','');----
INSERT INTO classwords VALUES ('4774c0b1bc704fdaab5eaa4e4c5f91e9','cd7a77e7a7a941dcbef4908650d06f22','12');----
INSERT INTO word VALUES ('cb4ce71fcb814a64ac3496519d551993','arc','[ɑ:k]','http://res.iciba.com/resource/amp3/0/0/90/9b/909ba4ad2bda46b10aac3c5b7f01abd5.mp3','n. 弧形；弧线','','');----
INSERT INTO classwords VALUES ('2fd04786d93d45efab160b329e315129','cb4ce71fcb814a64ac3496519d551993','12');----
INSERT INTO word VALUES ('e1a7e28b79594464beec04fc07ec77be','smuggle','[ˈsmʌɡl]','http://res.iciba.com/resource/amp3/oxford/0/79/c6/79c6f3227651bb15e23b2cd3d82a96bf.mp3','vi. 走私','','');----
INSERT INTO classwords VALUES ('a3c1530b2fe44257bfe371885ffa6114','e1a7e28b79594464beec04fc07ec77be','12');----
INSERT INTO word VALUES ('3d75337c37854437887656f9488a4610','provoke','[prəˈvəuk]','http://res.iciba.com/resource/amp3/oxford/0/4d/4c/4d4ce4f0f1fa3845b12abfd95ac32357.mp3','vt. 挑衅；激起；引起','','');----
INSERT INTO classwords VALUES ('76e18ddfcc344f36b28b2068cbd5f4dd','3d75337c37854437887656f9488a4610','12');----
INSERT INTO word VALUES ('c73e5732d24a4a7c879b8a36861983a3','trader','[ˈtreɪdə]','http://res.iciba.com/resource/amp3/oxford/0/de/45/de45c857393acc72fb7adc65c20bf5a5.mp3','n. 商人；交易者','','');----
INSERT INTO classwords VALUES ('a75e884555114a2db9c7ef36429b754e','c73e5732d24a4a7c879b8a36861983a3','12');----
INSERT INTO word VALUES ('b8e161df51164a8abbbc16db2ce1738d','heighten','[ˈhaitən]','http://res.iciba.com/resource/amp3/oxford/0/82/e5/82e51ed09ee7106c8493e0c1f1d9171f.mp3','vt. 使加深；增强','','');----
INSERT INTO classwords VALUES ('1dd84ddd64b74ec9bbb395ec1b67d043','b8e161df51164a8abbbc16db2ce1738d','12');----
INSERT INTO word VALUES ('03f8bb01d4754ebaa036174c4ed486fe','decidedly','[dɪˈsaɪdɪdlɪ]','http://res.iciba.com/resource/amp3/oxford/0/bd/5b/bd5bbc65b7dc3dac73a8d83966fe0574.mp3','adv. 坚决地；确实无疑地；显然','','');----
INSERT INTO classwords VALUES ('be83e79c753e4163956e9032e075ea16','03f8bb01d4754ebaa036174c4ed486fe','12');----
INSERT INTO word VALUES ('981e8e22cead4a808c03d35e9e354ffd','baseball','[ˈbeisbɔ:l]','http://res.iciba.com/resource/amp3/oxford/0/16/31/1631f22395365d1a2759b6abaaeccc1d.mp3','n. 棒球；棒球运动','','');----
INSERT INTO classwords VALUES ('e4aa575b8b44496b92e4d0d52a639c89','981e8e22cead4a808c03d35e9e354ffd','12');----
INSERT INTO word VALUES ('9aa70d476fb8410b8fb26a77f82918d1','scratch','[skrætʃ]','http://res.iciba.com/resource/amp3/oxford/0/30/da/30da055c5d96f02831f302a53dc54151.mp3','n. 划痕；擦痕','','');----
INSERT INTO classwords VALUES ('1e68d51ec4664dc9abe842e22331bc4b','9aa70d476fb8410b8fb26a77f82918d1','12');----
INSERT INTO word VALUES ('73f38d426cc048a39f429802b280d04b','plea','[pli:]','http://res.iciba.com/resource/amp3/oxford/0/bd/73/bd73182960516c2da81b4d4ddb52f14c.mp3','n. 答辩，抗辩；请求，恳求；借口','','');----
INSERT INTO classwords VALUES ('0035b571a3b5491dbc70ca422263328c','73f38d426cc048a39f429802b280d04b','12');----
INSERT INTO word VALUES ('b0dec0ad9c0647c8b5c18462e5983adb','abide','[əˈbaid]','http://res.iciba.com/resource/amp3/oxford/0/0b/29/0b295e589f619de0cec9e15d0bd99a1e.mp3','vi. 逗留，居住','','');----
INSERT INTO classwords VALUES ('868ce47f889e4d0da3bd1351bcf2215c','b0dec0ad9c0647c8b5c18462e5983adb','12');----
INSERT INTO word VALUES ('9d477b44fbe349c59d2fb52926b2ed92','ass','[æs]','http://res.iciba.com/resource/amp3/oxford/0/71/c4/71c40d3b2f3c1485876c49a86d73dd68.mp3','n. 驴；傻瓜，蠢笨的人；屁股','','');----
INSERT INTO classwords VALUES ('c2f8320ed2924193b76b25f21d8b6cb3','9d477b44fbe349c59d2fb52926b2ed92','12');----
INSERT INTO word VALUES ('c3026e0243784bbe99373e5dbee84e02','fly','[flai]','http://res.iciba.com/resource/amp3/oxford/0/25/3b/253bd7586a6ee5404feee7723a1eba76.mp3','v. 飞行；驾驶（飞机）；空运；升（旗）...','','');----
INSERT INTO classwords VALUES ('9697d6ec0d954aba84ddd702661682fc','c3026e0243784bbe99373e5dbee84e02','12');----
INSERT INTO word VALUES ('393934dbb6724773acd3c1d254c2f161','beware','[biˈwɛə]','http://res.iciba.com/resource/amp3/oxford/0/af/f2/aff2625810c7182c1789b5fd882590cf.mp3','v. 提防；当心','','');----
INSERT INTO classwords VALUES ('27d1768c6d1d45ad8c277c69075820cd','393934dbb6724773acd3c1d254c2f161','12');----
INSERT INTO word VALUES ('a2117c12d4dd48c09c3f12ccfe04eea9','solidify','[səˈlɪdəˌfaɪ]','http://res.iciba.com/resource/amp3/oxford/0/61/54/615452f2d9dd89980259f871be5db477.mp3','vt. 使固化；使凝固','','');----
INSERT INTO classwords VALUES ('59d40457ca094009932def503851eb2d','a2117c12d4dd48c09c3f12ccfe04eea9','12');----
INSERT INTO word VALUES ('a457ab2944794e278bf50418b603dde8','salmon','[ˈsæmən]','http://res.iciba.com/resource/amp3/oxford/0/a6/84/a68407245e0fe4c69250cf9a238460e5.mp3','n. 鲑鱼，大马哈鱼','','');----
INSERT INTO classwords VALUES ('7246a96afc8a49cfabf856a06fb67b5f','a457ab2944794e278bf50418b603dde8','12');----
INSERT INTO word VALUES ('96452f5329854573a624727e9267ea2c','symptom','[ˈsimptəm]','http://res.iciba.com/resource/amp3/oxford/0/e0/c8/e0c85151a9c1b7c1b152c66136205053.mp3','n. 症状；征兆','','');----
INSERT INTO classwords VALUES ('8ab09c36ba7847739d4b3b0cacc74dc8','96452f5329854573a624727e9267ea2c','12');----
INSERT INTO word VALUES ('e6604220fe184cc9b823f30d610f6e31','hound','[haund]','http://res.iciba.com/resource/amp3/oxford/0/2b/59/2b59dfa5b6f8edbf9d1d03ec2382e92d.mp3','v. 烦扰；纠缠','','');----
INSERT INTO classwords VALUES ('f3192bc0cc094ea6afeb094b0ffe0d8f','e6604220fe184cc9b823f30d610f6e31','12');----
INSERT INTO word VALUES ('b1602d9b31214536a9c7c69c7ee92eba','tug','[tʌɡ]','http://res.iciba.com/resource/amp3/oxford/0/ef/84/ef8439356f805a66d6f90737a78ca6ed.mp3','n. 猛拉；拖船','','');----
INSERT INTO classwords VALUES ('0eab9b7466db44518086946d97af33f6','b1602d9b31214536a9c7c69c7ee92eba','12');----
INSERT INTO word VALUES ('c1cfadc54220437e984a5a797b102458','shortcut','[ˈʃɔ:tˌkʌt]','http://res.iciba.com/resource/amp3/0/0/c0/95/c0954f37465ac52acf4a22c5e1c5bf87.mp3','n. 近路，捷径','','');----
INSERT INTO classwords VALUES ('970f81b6fa9f4ef8ba1c472b3ae64c89','c1cfadc54220437e984a5a797b102458','12');----
INSERT INTO word VALUES ('3a14df6bf5ac4c2baea5302d8f8eb351','recreation','[ˌrekriˈeiʃn]','http://res.iciba.com/resource/amp3/oxford/0/06/de/06dea85c93def4aea426000355996d23.mp3','n. 娱乐；休闲','','');----
INSERT INTO classwords VALUES ('d1158757f5ca44b1adbd22fdd17f1f75','3a14df6bf5ac4c2baea5302d8f8eb351','12');----
INSERT INTO word VALUES ('e3ef82c7d2c149e3a4e709a1ae109e57','sermon','[ˈsə:mən]','http://res.iciba.com/resource/amp3/0/0/8a/cf/8acffd93ab51ac730611a8ec8113cbcd.mp3','n. 布道，讲道；一大通教训','','');----
INSERT INTO classwords VALUES ('f85d9d044935435d9cb63fbd60e895c6','e3ef82c7d2c149e3a4e709a1ae109e57','12');----
INSERT INTO word VALUES ('b656398f319748c49824664856c7ae0e','main','[mein]','http://res.iciba.com/resource/amp3/oxford/0/67/a7/67a73652a7dde66a3bc1deefc97a0107.mp3','n. 总管道；电力线，电源','','');----
INSERT INTO classwords VALUES ('052909f0acee4b9697d3d8a295434241','b656398f319748c49824664856c7ae0e','12');----
INSERT INTO word VALUES ('053449816ce242f9bed70275b74bd5a6','orchestra','[ˈɔ:kistrə]','http://res.iciba.com/resource/amp3/oxford/0/ba/f4/baf4d4b03913273548c9c4259082b659.mp3','n. 管弦乐队','','');----
INSERT INTO classwords VALUES ('b090eb7c9524424c95d87abfa7954bbf','053449816ce242f9bed70275b74bd5a6','12');----
INSERT INTO word VALUES ('57fc60fbdd6a490ebc0e2adccf1392d1','banker','[ˈbæŋkə]','http://res.iciba.com/resource/amp3/oxford/0/d9/65/d965f9d8a0c54a3627c805a530a9e865.mp3','n. 银行家；庄家','','');----
INSERT INTO classwords VALUES ('df9ab56f0fde450c87feb7e0e039654c','57fc60fbdd6a490ebc0e2adccf1392d1','12');----
INSERT INTO word VALUES ('ef2701ed344c4a1b96279d4ad3286989','therein','[ðeərˈɪn]','http://res.iciba.com/resource/amp3/oxford/0/d6/31/d631dab8795e7390cf09aca8bd2e4767.mp3','adv. 在那里；在其中','','');----
INSERT INTO classwords VALUES ('14dca52a913144d9aba29bb8864eb9f7','ef2701ed344c4a1b96279d4ad3286989','12');----
INSERT INTO word VALUES ('42c7d1f59b17434d9aa8778a06e8a695','fearless','[ˈfɪəlɪs]','http://res.iciba.com/resource/amp3/0/0/4f/34/4f3448839842418bb5c539e3281ced8a.mp3','adj. 无畏的，大胆的','','');----
INSERT INTO classwords VALUES ('5aaab552605a4bb8a5b25a8ac928bc7e','42c7d1f59b17434d9aa8778a06e8a695','12');----
INSERT INTO word VALUES ('14e720dc7f5d40ee9d66a9029de59dad','threshold','[ˈθreʃhəuld]','http://res.iciba.com/resource/amp3/oxford/0/ee/29/ee29e6072017d6b810a48083d53c7a98.mp3','n. 门槛；界限，起始点','','');----
INSERT INTO classwords VALUES ('be78343bb64e465486b97502f84f4815','14e720dc7f5d40ee9d66a9029de59dad','12');----
INSERT INTO word VALUES ('89d3e79bf4034bbe8eac1d334b7a31cf','custom','[ˈkʌstəm]','http://res.iciba.com/resource/amp3/oxford/0/e5/09/e509b9bf5c6d349f782a798736ac182e.mp3','n. 海关；习惯；风俗；光顾','','');----
INSERT INTO classwords VALUES ('11235807d2494458a848674f51391f2d','89d3e79bf4034bbe8eac1d334b7a31cf','12');----
INSERT INTO word VALUES ('2471e517fc4d43b39c2819ae798704bc','freight','[freit]','http://res.iciba.com/resource/amp3/oxford/0/02/4a/024adc3e4fbaef54c7e06181073b770e.mp3','n. 运费；货运；货物','','');----
INSERT INTO classwords VALUES ('133becf1fab741879f5b1332df3566a2','2471e517fc4d43b39c2819ae798704bc','12');----
INSERT INTO word VALUES ('7620e06b1a5d45d98ffadba6f39d6ccd','apt','[æpt]','http://res.iciba.com/resource/amp3/oxford/0/01/d4/01d41e35a101e8cda940c23da8836c7a.mp3','adj. 恰当的；聪明的；易于…的','','');----
INSERT INTO classwords VALUES ('161046f94d004bfa9534871c0db83816','7620e06b1a5d45d98ffadba6f39d6ccd','12');----
INSERT INTO word VALUES ('f790c00bc1c24141aea26a34113e1df0','shorthand','[ˈʃɔ:thænd]','http://res.iciba.com/resource/amp3/oxford/0/5e/f2/5ef240c729b0226a2b35e40c73caf750.mp3','n. 速记，速记法','','');----
INSERT INTO classwords VALUES ('573ebf94e4b24d8d8a116e14fa8d8981','f790c00bc1c24141aea26a34113e1df0','12');----
INSERT INTO word VALUES ('6978bf8a7af74027aaff74ef79e5c474','latitude','[ˈlætitju:d]','http://res.iciba.com/resource/amp3/oxford/0/9f/7e/9f7e097b57c729a2aacc2b9396075f79.mp3','n. 纬度；选择的自由；回旋余地','','');----
INSERT INTO classwords VALUES ('c7e13a7bc4a44ff186da818ae84ea8a8','6978bf8a7af74027aaff74ef79e5c474','12');----
INSERT INTO word VALUES ('9147b7ed0d8e4eb984349720ae282d9e','legislation','[ˌledʒisˈleiʃən]','http://res.iciba.com/resource/amp3/oxford/0/9d/53/9d53784b7038b4627e0c8b5fd0996caf.mp3','n. 立法；法规','','');----
INSERT INTO classwords VALUES ('11274fba353b4446b45fd450cec54790','9147b7ed0d8e4eb984349720ae282d9e','12');----
INSERT INTO word VALUES ('1aaf0e86e6bc43f6808fe2049fd271b6','obligation','[ˌɔbliˈɡeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/15/d7/15d715fe2b5442cb980cd45f5b123961.mp3','n. 义务，责任','','');----
INSERT INTO classwords VALUES ('79bd8f620f60437ebc21f90c1dcf7eaf','1aaf0e86e6bc43f6808fe2049fd271b6','12');----
INSERT INTO word VALUES ('6845b3a55eef4af1990b827bf5562ce3','excursion','[iksˈkə:ʃən]','http://res.iciba.com/resource/amp3/0/0/5b/a8/5ba8df5f883b7f64df2d40eb4a37d763.mp3','n. 远足；短途旅行；尝试','','');----
INSERT INTO classwords VALUES ('1970db8f1ba94f518bd2e23c765bf9bf','6845b3a55eef4af1990b827bf5562ce3','12');----
INSERT INTO word VALUES ('9f612ae1fb6f4bf79c03bf018b409271','pledge','[pledʒ]','http://res.iciba.com/resource/amp3/oxford/0/88/2f/882f21c19c32b5155047522f63c09456.mp3','vt. 许诺；使发誓；用…抵押','','');----
INSERT INTO classwords VALUES ('20cf22c970004e23a58373fc7d6000a3','9f612ae1fb6f4bf79c03bf018b409271','12');----
INSERT INTO word VALUES ('fbb7e826be5f4f90adedf018441066c0','flask','[flɑ:sk]','http://res.iciba.com/resource/amp3/0/0/31/9c/319c3206a7f10c17c3b9116d4a957646.mp3','n. 瓶子；烧瓶；长颈瓶','','');----
INSERT INTO classwords VALUES ('fc445bdfd65047bab526802700cf7b83','fbb7e826be5f4f90adedf018441066c0','12');----
INSERT INTO word VALUES ('0102abf2839c45cc843a0732d0863564','harbour','[ˈhɑ:bə]','http://res.iciba.com/resource/amp3/oxford/0/d5/60/d5607d9e5df18e272de73faf9da023d0.mp3','vt. 隐匿，窝藏；怀有','','');----
INSERT INTO classwords VALUES ('feb8559a05c4445eb9d900e99a636319','0102abf2839c45cc843a0732d0863564','12');----
INSERT INTO word VALUES ('4e3ceb1e94954a9eb7e8c70d94640d61','nourish','[ˈnʌriʃ]','http://res.iciba.com/resource/amp3/0/0/9a/ab/9aab79d0b439689f327ac8f6dee4a658.mp3','vt. 给…提供营养；养育','','');----
INSERT INTO classwords VALUES ('56a9e1af9bff485d938b6a227186c957','4e3ceb1e94954a9eb7e8c70d94640d61','12');----
INSERT INTO word VALUES ('31341d2b7f9d42e7a62eb60434518777','wind','[wind]','http://res.iciba.com/resource/amp3/oxford/0/c2/45/c245630e53453fd83e4c22ae7d3aab1c.mp3','n. 风；趋势','','');----
INSERT INTO classwords VALUES ('68f0db2f676f4667a9e563c97265ef00','31341d2b7f9d42e7a62eb60434518777','12');----
INSERT INTO word VALUES ('ac7d20864df546488db594b673732749','tropical','[ˈtrɔpikəl]','http://res.iciba.com/resource/amp3/oxford/0/f6/d6/f6d6688773b8b13262737eb612cf154f.mp3','adj. 热带的；湿热的','','');----
INSERT INTO classwords VALUES ('c1b648dba642488f8f61f8d7698aa38e','ac7d20864df546488db594b673732749','12');----
INSERT INTO word VALUES ('0b08b36a2cbc4fd4be76e3f60bfcb664','offensive','[əˈfensiv]','http://res.iciba.com/resource/amp3/oxford/0/1c/28/1c288e83b7ef27f52da02802a4a39255.mp3','adj. 冒犯的；进攻的','','');----
INSERT INTO classwords VALUES ('e6dd7db676f042b78ce6f22f2f60f1df','0b08b36a2cbc4fd4be76e3f60bfcb664','12');----
INSERT INTO word VALUES ('2ed0dcb8a9f44867a88d88f66203afc2','barometer','[bəˈrɔmitə]','http://res.iciba.com/resource/amp3/oxford/0/ad/46/ad460696cdb97e520a896aa387856732.mp3','n. 气压计；睛雨表','','');----
INSERT INTO classwords VALUES ('8d91775a6d9b47aca0bd81edb966ca53','2ed0dcb8a9f44867a88d88f66203afc2','12');----
INSERT INTO word VALUES ('d710aaa5e31b43b38106b0631a39cce5','entertainment','[ˌentəˈteinmənt]','http://res.iciba.com/resource/amp3/oxford/0/b0/a7/b0a7bf02454ace9ba98d8f8755a5cd0c.mp3','n. 招待；娱乐节目','','');----
INSERT INTO classwords VALUES ('cfbabda882604cbb859b22bab2629e7a','d710aaa5e31b43b38106b0631a39cce5','12');----
INSERT INTO word VALUES ('5a2fdd16e7d6498fa9077c8c7ef13092','microscopic','[ˌmaɪkrəˈskɔpɪk]','http://res.iciba.com/resource/amp3/oxford/0/24/e0/24e0ef8e0bc5b6276889f4f2a06ef3e2.mp3','adj. 显微镜的；微小的；一丝不苟的','','');----
INSERT INTO classwords VALUES ('6265bcfd589a4e60b12f6923b30de126','5a2fdd16e7d6498fa9077c8c7ef13092','12');----
INSERT INTO word VALUES ('624fb5937e80412bacbe99bbb8683e01','literally','[ˈlitərəli]','http://res.iciba.com/resource/amp3/oxford/0/41/f9/41f9ef5f596b572c60ae3c0a596db529.mp3','adv. 照字面地；逐字地；直译地；确实...','','');----
INSERT INTO classwords VALUES ('f123b8ce7d504583bdc934a94a43fa73','624fb5937e80412bacbe99bbb8683e01','12');----
INSERT INTO word VALUES ('881e096461da4d5e936e51eeaa410603','composer','[kəmˈpəʊzə]','http://res.iciba.com/resource/amp3/oxford/0/c3/25/c3255c1861084d976d35ab40450eeeb2.mp3','n. 作曲家；调停人','','');----
INSERT INTO classwords VALUES ('8b09c52b472c4c738dab4f7b3fbc3f53','881e096461da4d5e936e51eeaa410603','12');----
INSERT INTO word VALUES ('35c4eb2c80324d1492ba04482d2cbe95','instructor','[ɪnˈstrʌktə]','http://res.iciba.com/resource/amp3/oxford/0/3b/a8/3ba8ab6127786b42c51018774443a35a.mp3','n. 指导者，教师','','');----
INSERT INTO classwords VALUES ('42e6e90578d1424d9fff1c1008ddbaab','35c4eb2c80324d1492ba04482d2cbe95','12');----
INSERT INTO word VALUES ('245637c5c0fb4cc0bbac7ba928acc5d3','orientation','[ˌɔ:rienˈteiʃən]','http://res.iciba.com/resource/amp3/oxford/0/15/50/1550676b7f41d53282b3901f61ea69da.mp3','n. 取向；定位；方向；任职培训；朝向','','');----
INSERT INTO classwords VALUES ('110a10e9065840ab8cf1e7d0358777a7','245637c5c0fb4cc0bbac7ba928acc5d3','12');----
INSERT INTO word VALUES ('97c5813f9cac4feaa8ab97dba1fd4b88','availability','[əˌveɪləˈbɪlɪtɪ]','http://res.iciba.com/resource/amp3/0/0/f2/44/f24431ce9f1b8885678b1ed611c4c214.mp3','n. 有效；有用；有益；可得到的人（或物...','','');----
INSERT INTO classwords VALUES ('aba1b8c6e0c2438283b6d526fab3be49','97c5813f9cac4feaa8ab97dba1fd4b88','12');----
INSERT INTO word VALUES ('d86d1660cfbb4bb2b949dd1cdd1e4e24','shuttle','[ˈʃʌtl]','http://res.iciba.com/resource/amp3/oxford/0/0d/d2/0dd2e9ac647c5b436775c67010fc1c45.mp3','n. （织机的）梭；往来于两地之间的航班','','');----
INSERT INTO classwords VALUES ('d9528f674f504c49812a116829f6a97d','d86d1660cfbb4bb2b949dd1cdd1e4e24','12');----
INSERT INTO word VALUES ('4a783f70962a4cb181332ac3a39ae788','mercury','','http://res.iciba.com/resource/amp3/oxford/0/df/77/df77229d9c20c2ed2e166001f7ced706.mp3','n. 汞，水银','','');----
INSERT INTO classwords VALUES ('a328da794ec948cbbefe81730ef0bbf7','4a783f70962a4cb181332ac3a39ae788','12');----
INSERT INTO word VALUES ('7642b1183f5a4288b3c7b1956aad4178','blind','[blaind]','http://res.iciba.com/resource/amp3/oxford/0/83/42/8342bfe5f1a2d69b92def974c238fbdc.mp3','adj. 盲的，瞎的；看不到的；盲目的','','');----
INSERT INTO classwords VALUES ('0ad29161a1b0495b87c38457b846ade1','7642b1183f5a4288b3c7b1956aad4178','12');----
INSERT INTO word VALUES ('f1c0faae87824ae680f36644d35e0f1f','imitation','[ˌɪmiˈteiʃən]','http://res.iciba.com/resource/amp3/oxford/0/95/0f/950f573416704e1602d8f72745e71c04.mp3','n. 仿制品；模仿','','');----
INSERT INTO classwords VALUES ('7366bd153690476fa5ad1de21043433e','f1c0faae87824ae680f36644d35e0f1f','12');----
INSERT INTO word VALUES ('036cfb06ef024c628b5c382b4d96dd81','bore','[bɔ:]','http://res.iciba.com/resource/amp3/oxford/0/11/2d/112ded3a88c0ced677d94fb86d8d4d6a.mp3','n. 讨厌的人；麻烦事','','');----
INSERT INTO classwords VALUES ('40ef92c66b774d57ae211239119999ed','036cfb06ef024c628b5c382b4d96dd81','12');----
INSERT INTO word VALUES ('f2a9777919ea40ebaadec7d226c8cfa7','nose','[nəuz]','http://res.iciba.com/resource/amp3/0/0/41/d1/41d1de28e96dc1cde568d3b068fa17bb.mp3','n. 鼻子；车头；嗅觉','','');----
INSERT INTO classwords VALUES ('e7c0106a483c41b884791a0cd786f19b','f2a9777919ea40ebaadec7d226c8cfa7','12');----
INSERT INTO word VALUES ('b9c4f4d516e14848bccc18a79f270979','by-product','[ˈbaiprɔdʌkt]','http://res.iciba.com/resource/amp3/0/0/ed/81/ed81d2c1d705861968d8963ac974ba36.mp3','n. 副产品；附带产生的结果','','');----
INSERT INTO classwords VALUES ('503b2af0f0d54da4b5011f0b6c41ce9b','b9c4f4d516e14848bccc18a79f270979','12');----
INSERT INTO word VALUES ('d75fd8eaf60c494e942abe30a7ec2992','entitle','[inˈtaitl]','http://res.iciba.com/resource/amp3/oxford/0/a3/21/a321e3db29220547d7d502a46ae2dc32.mp3','vt. 给予…权利；给予…资格；给…命名','','');----
INSERT INTO classwords VALUES ('556b3b9b24274e7d86e2097d56b63dfa','d75fd8eaf60c494e942abe30a7ec2992','12');----
INSERT INTO word VALUES ('d32565abaaa74f51852ff89a043a46e1','advertise','[ˈædvətaiz]','http://res.iciba.com/resource/amp3/oxford/0/19/7c/197cee85e257cecc335f16c7da90a1c9.mp3','vi. 登广告','','');----
INSERT INTO classwords VALUES ('f0e69b9fdd024fcfae3a458f635f9b3e','d32565abaaa74f51852ff89a043a46e1','12');----
INSERT INTO word VALUES ('be1f5f58c9fe4aa98f32b8f68bb7faf2','personnel','[ˌpə:səˈnel]','http://res.iciba.com/resource/amp3/oxford/0/a8/13/a8138bd3e5e0e093f0fa0808735ae152.mp3','n. 人事部门；人员','','');----
INSERT INTO classwords VALUES ('091b979000654322a5b06678bd3a0aa8','be1f5f58c9fe4aa98f32b8f68bb7faf2','12');----
INSERT INTO word VALUES ('74b33e0fccac4d548d97059839732005','intervene','[ˌɪntəˈvi:n]','http://res.iciba.com/resource/amp3/oxford/0/74/95/7495a6760ee5812c3b587ef3fcf918ae.mp3','vi. 干涉，干预；插话；阻挠','','');----
INSERT INTO classwords VALUES ('deee480489e64e208eaefe9a852d3415','74b33e0fccac4d548d97059839732005','12');----
INSERT INTO word VALUES ('27b3bcf24617467e8820541146db2c2e','endurance','[inˈdjuərəns]','http://res.iciba.com/resource/amp3/oxford/0/29/c7/29c715528c91a6c79a4def723354de1b.mp3','n. 耐力；忍耐力','','');----
INSERT INTO classwords VALUES ('46227f1c3e9c4a94a5ba03a84ee01759','27b3bcf24617467e8820541146db2c2e','12');----
INSERT INTO word VALUES ('e69a61ddc11848ccac923c6a47ac6c43','craft','[krɑ:ft]','http://res.iciba.com/resource/amp3/0/0/23/ca/23ca2c6b139fb6ff9654c1b197a4db3a.mp3','n. 航天器；手艺，工艺','','');----
INSERT INTO classwords VALUES ('a6d4aa2cc2de467e9541fc528e13fab7','e69a61ddc11848ccac923c6a47ac6c43','12');----
INSERT INTO word VALUES ('b44d718a7ce74d34a37129529e37f9ff','spokesman','[ˈspəuksmən]','http://res.iciba.com/resource/amp3/oxford/0/58/5d/585ded97142211f9ed2c894508ef88ac.mp3','n. 发言人','','');----
INSERT INTO classwords VALUES ('64b8026f6dfc455fb3fc894a1e4f0ab9','b44d718a7ce74d34a37129529e37f9ff','12');----
INSERT INTO word VALUES ('5473b4b24d4744b1ae392d079bafa621','cloudy','[ˈklaudi]','http://res.iciba.com/resource/amp3/oxford/0/70/49/704982e14c7a66c0fdd88d23531263c2.mp3','adj. 混浊的；模糊不清的；多云的','','');----
INSERT INTO classwords VALUES ('f04e6fcc0ea84fa78e18cf222630df14','5473b4b24d4744b1ae392d079bafa621','12');----
INSERT INTO word VALUES ('d80e8b95b25941cea46a913bfda132ff','spacious','[ˈspeiʃəs]','http://res.iciba.com/resource/amp3/oxford/0/ee/6d/ee6d177bfb8c3058b90fab374491153a.mp3','adj. 广阔的，宽敞的','','');----
INSERT INTO classwords VALUES ('f871f3abf6fb4b0a8802248ca0f023bb','d80e8b95b25941cea46a913bfda132ff','12');----
INSERT INTO word VALUES ('d0d49cb699ff4bf48f71098687055033','seemingly','[ˈsiːmɪŋli]','http://res.iciba.com/resource/amp3/oxford/0/7c/44/7c44c62e41bfd23d19e7b0ac7098cfb7.mp3','adv. 看来似乎，表面上看','','');----
INSERT INTO classwords VALUES ('4a393f1ad9204ccdad5fe8fa65cac566','d0d49cb699ff4bf48f71098687055033','12');----
INSERT INTO word VALUES ('10ee6835bcd04240bb22720387f59f26','consciousness','[ˈkɔnʃəsnɪs]','http://res.iciba.com/resource/amp3/oxford/0/20/37/2037b8dc70175b5c1252610f00667ec5.mp3','n. 意识；观念；知觉','','');----
INSERT INTO classwords VALUES ('fd24b268462146929bad3a3a54f2cf72','10ee6835bcd04240bb22720387f59f26','12');----
INSERT INTO word VALUES ('d14c42d32c7f406aa154579ee26b4fef','ally','[ˈælaɪ]','http://res.iciba.com/resource/amp3/oxford/0/f7/aa/f7aa0afbf49b04cdf6fbba3656e9e3ef.mp3','n. 同盟国，同盟者；盟友','','');----
INSERT INTO classwords VALUES ('ea471362250948e68006c2a85e38862c','d14c42d32c7f406aa154579ee26b4fef','12');----
INSERT INTO word VALUES ('21419b6604b94beba8c1c0cd259d86d3','instability','[ˌɪnstəˈbɪlɪti:]','http://res.iciba.com/resource/amp3/oxford/0/2b/1d/2b1d848c5b55e7ab846b8d9a726d3072.mp3','n. 不稳定性，不稳固性','','');----
INSERT INTO classwords VALUES ('0e7f678225de48cfb382f5094bff98db','21419b6604b94beba8c1c0cd259d86d3','12');----
INSERT INTO word VALUES ('7f660d6d6a1c4988ab8e3105fbf5d266','closet','[ˈklɔzit]','http://res.iciba.com/resource/amp3/0/0/84/0c/840c6b391852a581b48bc613c90ddbd4.mp3','n. 小储藏间；壁橱','','');----
INSERT INTO classwords VALUES ('91d8799a96034a2e966405cf0c9a6cc9','7f660d6d6a1c4988ab8e3105fbf5d266','12');----
INSERT INTO word VALUES ('e74a91c5f72441b69294526bd7f6f649','vector','[ˈvektə]','http://res.iciba.com/resource/amp3/oxford/0/b5/52/b552d87c82c8445251bee9fd9adb27ba.mp3','n. 矢量；带菌生物','','');----
INSERT INTO classwords VALUES ('5d6050515977436288b0ed50ebe5b4f3','e74a91c5f72441b69294526bd7f6f649','12');----
INSERT INTO word VALUES ('5d33d43b4a8b446a8069b01d85cef991','abstract','[ˈæbstrækt]','http://res.iciba.com/resource/amp3/oxford/0/03/90/0390b0bb4e556f329ca196fa967e12b2.mp3','n. 摘要；抽象派艺术作品','','');----
INSERT INTO classwords VALUES ('599fc9d63127401b896a8ee840f700db','5d33d43b4a8b446a8069b01d85cef991','12');----
INSERT INTO word VALUES ('59ccc768114549e99fd74a12d479fbba','bridge','[bridʒ]','http://res.iciba.com/resource/amp3/oxford/0/5d/94/5d94a8d9bdca5a8b675192b0846e00b1.mp3','vt. 架桥于；弥合（分歧）','','');----
INSERT INTO classwords VALUES ('2553073560684903ba0d28298e550407','59ccc768114549e99fd74a12d479fbba','12');----
INSERT INTO word VALUES ('af4db388714143fa8c5fb88cb037aa02','fuss','[fʌs]','http://res.iciba.com/resource/amp3/oxford/0/36/c5/36c501e46678eca4978dbe9005c52951.mp3','vi. 大惊小怪；瞎忙活','','');----
INSERT INTO classwords VALUES ('93ed8564ac594c0b908fa08e6cebae02','af4db388714143fa8c5fb88cb037aa02','12');----
INSERT INTO word VALUES ('5121937b9602449ea2891c22a29a3790','velvet','[ˈvelvit]','http://res.iciba.com/resource/amp3/oxford/0/25/28/2528a461a01f033f3d2539a1312144ed.mp3','n. 丝绒，天鹅绒','','');----
INSERT INTO classwords VALUES ('3eeb39f7503e45c49d4023d31240cf0d','5121937b9602449ea2891c22a29a3790','12');----
INSERT INTO word VALUES ('090f366524d440e09f3304ba7e2eca16','strait','[streit]','http://res.iciba.com/resource/amp3/oxford/0/c4/a9/c4a9fb9e801669a2035f15328eee70bc.mp3','n. 海峡；困境','','');----
INSERT INTO classwords VALUES ('7e7a25a95dee48a0b066f6e355efd795','090f366524d440e09f3304ba7e2eca16','12');----
INSERT INTO word VALUES ('b79cb266d3ea4703bc6ca1555d72a67e','evenly','[ˈi:vənlɪ]','http://res.iciba.com/resource/amp3/oxford/0/67/fc/67fcb8d8a1e837e4cb939e751bc08f9c.mp3','adv. 平坦地；均匀地；均衡地；平等的','','');----
INSERT INTO classwords VALUES ('7544ce9fc0ab44609cdcf862bbb5504c','b79cb266d3ea4703bc6ca1555d72a67e','12');----
INSERT INTO word VALUES ('6869aca6ea3c49e581f979e597397b43','humidity','[hju:ˈmiditi]','http://res.iciba.com/resource/amp3/oxford/0/04/98/0498336ff0e7256d8dc85c8821c07ca8.mp3','n. 潮湿；湿度','','');----
INSERT INTO classwords VALUES ('6ccf1fbdd8b24ea38a71dbb21be3b303','6869aca6ea3c49e581f979e597397b43','12');----
INSERT INTO word VALUES ('1ecd93902cfd4bda9370690d458e4852','dioxide','[daɪˈɔksaɪd]','http://res.iciba.com/resource/amp3/oxford/0/bc/ef/bcef84b5c29db9877077ae670880477e.mp3','n. 二氧化物','','');----
INSERT INTO classwords VALUES ('22d305e4beb84f8a82a23fd70f6e0fa6','1ecd93902cfd4bda9370690d458e4852','12');----
INSERT INTO word VALUES ('65bcd03116874eb9b28a509750150312','elevation','[ˌeləˈveɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/45/87/45870bac74e2778a3cb0b5d5b5a1cc0b.mp3','n. 高地，高处；海拔；立面','','');----
INSERT INTO classwords VALUES ('300c4da9222142af9a53a5a54727dfaf','65bcd03116874eb9b28a509750150312','12');----
INSERT INTO word VALUES ('b07c1d5db11d472b990b24640859cc1b','excessively','[ɪkˈsesɪvlɪ]','http://res.iciba.com/resource/amp3/0/0/d2/5b/d25b6cafe2c8802dfd9dc266b76ec6d0.mp3','adv. 过分地，极度地','','');----
INSERT INTO classwords VALUES ('3bea695a27a84a82b800ed693a685fbb','b07c1d5db11d472b990b24640859cc1b','12');----
INSERT INTO word VALUES ('376051a8594b4f3a8abf49e920528bb4','severe','[siˈviə]','http://res.iciba.com/resource/amp3/oxford/0/a1/a6/a1a648e2b34deef760e2703affd798ae.mp3','adj. 严重的；简朴的；严厉的','','');----
INSERT INTO classwords VALUES ('37f72f4378be4e69981e69f8a7d8a3d7','376051a8594b4f3a8abf49e920528bb4','12');----
INSERT INTO word VALUES ('2cc146a8d94042c3975819fffee668a3','reciprocal','[riˈsiprəkəl]','http://res.iciba.com/resource/amp3/oxford/0/c1/f4/c1f42ec56cea7740cb2f666a147c68d7.mp3','adj. 相互的；互利的','','');----
INSERT INTO classwords VALUES ('e4a5d5e65f6643068cae6818add4ab30','2cc146a8d94042c3975819fffee668a3','12');----
INSERT INTO word VALUES ('1159354a1b5e408ca44bd87dc563fb1a','whoever','[hu:ˈevə]','http://res.iciba.com/resource/amp3/oxford/0/b9/cc/b9cc4a6d16f738091e7e77c624710534.mp3','conj. 无论是谁','','');----
INSERT INTO classwords VALUES ('c3287fb7b8f54e2984f9d7c1ce24116c','1159354a1b5e408ca44bd87dc563fb1a','12');----
INSERT INTO word VALUES ('446debfe9f064f85893b9f89d8636e1c','excel','[ikˈsel]','http://res.iciba.com/resource/amp3/oxford/0/1c/4f/1c4fd74a18fd1f10c8d0b94cf1b2049d.mp3','vi. 胜过','','');----
INSERT INTO classwords VALUES ('8204203e87414cbe8dd1e9b4f91c02bd','446debfe9f064f85893b9f89d8636e1c','12');----
INSERT INTO word VALUES ('f3a4f329f4fd45d5a8a77ffddd9d951c','questionnaire','[ˌkwestiəˈnɛə]','http://res.iciba.com/resource/amp3/oxford/0/59/40/594091942957570674004f432323b2a3.mp3','n. 调查表；调查问卷','','');----
INSERT INTO classwords VALUES ('87c537a1416d4747a772946d9d7d3137','f3a4f329f4fd45d5a8a77ffddd9d951c','12');----
INSERT INTO word VALUES ('ddda486837eb4e788f85bd70a0e0df35','commonsense','[ˈkɔmənˈsens]','http://res.iciba.com/resource/amp3/0/0/e7/e1/e7e1bd3d9f3c32cb3c0ac5e759e46af2.mp3','adj. 常识的','','');----
INSERT INTO classwords VALUES ('78c985a8e6fe4abfa188d84d7ba300a7','ddda486837eb4e788f85bd70a0e0df35','12');----
INSERT INTO word VALUES ('183c2dd777d44580a10a09751dc47a4b','smash','[smæʃ]','http://res.iciba.com/resource/amp3/oxford/0/66/31/6631d7918ae170acac42fe208aa73d47.mp3','vt. 打碎，摔烂；冲破；使撞击；粉碎','','');----
INSERT INTO classwords VALUES ('a9d90eebeb004d86ad13564f7a4f4bbe','183c2dd777d44580a10a09751dc47a4b','12');----
INSERT INTO word VALUES ('7a4de731c3fa43849b3c3b7f99ba9968','hurt','[hə:t]','http://res.iciba.com/resource/amp3/0/0/c0/bb/c0bb722d28c628d3066cc2264dcc7c87.mp3','v. 损害；使受伤；使伤心','','');----
INSERT INTO classwords VALUES ('f2e3183f14c04549bbfce18b241ebb0d','7a4de731c3fa43849b3c3b7f99ba9968','12');----
INSERT INTO word VALUES ('4152f1b5b23b4da4bf42b218220dc798','barley','[ˈbɑ:li]','http://res.iciba.com/resource/amp3/0/0/02/fa/02facb072e3fb74a221b36db58b4493c.mp3','n. 大麦','','');----
INSERT INTO classwords VALUES ('f95a14ac129c4a088fd4fbdf8fe0f9a7','4152f1b5b23b4da4bf42b218220dc798','12');----
INSERT INTO word VALUES ('7fc9b2f72c8d4723a35346d32b537abc','stall','[stɔ:l]','http://res.iciba.com/resource/amp3/oxford/0/4d/0e/4d0e9c40af5450bd67e8085d2a7f0ff5.mp3','v. 使暂停；拖延；把…拖住','','');----
INSERT INTO classwords VALUES ('866409bbdcde4a109ad9ab28670963e8','7fc9b2f72c8d4723a35346d32b537abc','12');----
INSERT INTO word VALUES ('d94c2d8890d6489d87f87263f3afa643','situation','[ˌsitjuˈeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/4f/6c/4f6cb94f5fc5814d9b3ef690654a5ee8.mp3','n. 位置；形势，局面','','');----
INSERT INTO classwords VALUES ('5fc6945bb8c2456ebd1828e1ff53a603','d94c2d8890d6489d87f87263f3afa643','12');----
INSERT INTO word VALUES ('6e6a1ff5e8024c0c9e38b5ca87456779','inherent','[inˈhiərənt]','http://res.iciba.com/resource/amp3/oxford/0/20/7e/207edb555400e6ef572a1ea0509737d9.mp3','adj. 固有的，生来就有的','','');----
INSERT INTO classwords VALUES ('cbe10fe77a4c4772aa5938785709e6b8','6e6a1ff5e8024c0c9e38b5ca87456779','12');----
INSERT INTO word VALUES ('fe6f23548deb41b8bc2f947f525129e1','headquarters','[ˈhedˈkwɔ:təz]','http://res.iciba.com/resource/amp3/0/0/3c/89/3c8925c7fb2d563070c4c7aa96954e92.mp3','n. 总部，总公司','','');----
INSERT INTO classwords VALUES ('2cd131c2a96b466ca339ba5cb14e8a6a','fe6f23548deb41b8bc2f947f525129e1','12');----
INSERT INTO word VALUES ('833eacda84ec4ee4a49d4a130b2ddc50','gesture','[ˈdʒestʃə]','http://res.iciba.com/resource/amp3/oxford/0/af/49/af49267b4c085a514162c5bceedda67f.mp3','vi. 打手势；用手势表示','','');----
INSERT INTO classwords VALUES ('a9aca6fa511b4fa6a7e69e83658200ae','833eacda84ec4ee4a49d4a130b2ddc50','12');----
INSERT INTO word VALUES ('e8593fece38e48bbb85ed32cc04f04fd','youngster','[ˈjʌŋstə]','http://res.iciba.com/resource/amp3/oxford/0/c1/f6/c1f635239a561a421fbe2de45f8f6c89.mp3','n. 儿童，少年，年轻人','','');----
INSERT INTO classwords VALUES ('d13e88c96790436a9d3ccf4bbbc91820','e8593fece38e48bbb85ed32cc04f04fd','12');----
INSERT INTO word VALUES ('22e86b54b1e742948db5ae698f4d89b0','cartoon','[kɑ:ˈtu:n]','http://res.iciba.com/resource/amp3/oxford/0/3f/c5/3fc522559d761f6f5d1c3e2ae94590a6.mp3','n. 漫画；动画片','','');----
INSERT INTO classwords VALUES ('187a1509c64a4406bafe9fc0503d9b5a','22e86b54b1e742948db5ae698f4d89b0','12');----
INSERT INTO word VALUES ('aea8612286744fda9547dc8f91a0d5ed','puppy','[ˈpʌpi]','http://res.iciba.com/resource/amp3/oxford/0/1b/fd/1bfd8d4d8f0988468d0b271ddf80869f.mp3','n. 小狗，幼犬','','');----
INSERT INTO classwords VALUES ('74b490fd57fa4622aa8b06cd1a3e09b5','aea8612286744fda9547dc8f91a0d5ed','12');----
INSERT INTO word VALUES ('70dbee26d80e40c9b1515f534df70b49','alien','[ˈeiljən]','http://res.iciba.com/resource/amp3/oxford/0/d5/6f/d56fd732f0d15de62776ae888ecc544a.mp3','n. 外国人；外星人','','');----
INSERT INTO classwords VALUES ('a936af1428cd4ec185b87450dd314f84','70dbee26d80e40c9b1515f534df70b49','12');----
INSERT INTO word VALUES ('539d8d57bd4d45cbbe9657098d58eae9','flank','[flæŋk]','http://res.iciba.com/resource/amp3/oxford/0/c9/dc/c9dccc5c5ad8168ec6b6d0370e5009bd.mp3','n. 侧翼；侧面，一侧','','');----
INSERT INTO classwords VALUES ('1cce893a9cbf4e71b4bae9f3494081a7','539d8d57bd4d45cbbe9657098d58eae9','12');----
INSERT INTO word VALUES ('7ba6c3ce9d314a19b9e1e5b9b45d7b07','mitten','[ˈmɪtn]','http://res.iciba.com/resource/amp3/oxford/0/a4/29/a42948c0eca088b4547ebc8f3e04fb8a.mp3','n. 连指手套；露指手套','','');----
INSERT INTO classwords VALUES ('b479ff907d70491caabcc5c8b1658bd4','7ba6c3ce9d314a19b9e1e5b9b45d7b07','12');----
INSERT INTO word VALUES ('e64615e4ef4f49c58d6e01ff003115be','fertile','[ˈfə:tail]','http://res.iciba.com/resource/amp3/1/0/55/68/556812cf6709ad44c1a3b3023f597042.mp3','adj. 肥沃的；富有创意的；能生育的','','');----
INSERT INTO classwords VALUES ('c13241e31ebc4cc2baf87e896a78138c','e64615e4ef4f49c58d6e01ff003115be','12');----
INSERT INTO word VALUES ('423f5d0180bc4b5db295c8ddbf9e214b','transaction','[trænˈzækʃən]','http://res.iciba.com/resource/amp3/oxford/0/3b/95/3b95542baa3ade61a0a2e1cf15a65dbe.mp3','n. 处理；交易；事务','','');----
INSERT INTO classwords VALUES ('c5db889e1edc41ca9e46f38074b6736b','423f5d0180bc4b5db295c8ddbf9e214b','12');----
INSERT INTO word VALUES ('fe09b367e94e4a90888805735a8e2f2f','blacksmith','[ˈblæksmi:θ]','http://res.iciba.com/resource/amp3/oxford/0/f6/46/f646c1fd56eb221a82476077591e5d61.mp3','n. 铁匠','','');----
INSERT INTO classwords VALUES ('13f92aae943b41a18e8ec630b1bb91af','fe09b367e94e4a90888805735a8e2f2f','12');----
INSERT INTO word VALUES ('400ddd946f8e4ecda0af276945aa9f0c','ramble','[ˈræmbəl]','http://res.iciba.com/resource/amp3/oxford/0/ee/fb/eefb04088986d30d7938104a0d82c5c2.mp3','vi. 闲逛，漫步；漫谈','','');----
INSERT INTO classwords VALUES ('3f220284fc1e452790296609611093fc','400ddd946f8e4ecda0af276945aa9f0c','12');----
INSERT INTO word VALUES ('4e49980c107c4c4c80e05d8bb7565a77','clearing','[ˈklɪərɪŋ]','http://res.iciba.com/resource/amp3/0/0/58/32/5832a4d83b80b2dcaa3fb9db62774b6c.mp3','n. （林间）空地','','');----
INSERT INTO classwords VALUES ('55173216ebc54f4ea5e29b87e45b14ff','4e49980c107c4c4c80e05d8bb7565a77','12');----
INSERT INTO word VALUES ('072d560893704d7b8fa116fbd7b569fc','muscular','[ˈmʌskjulə]','http://res.iciba.com/resource/amp3/oxford/0/8d/22/8d226222375ce77014741e019db217ac.mp3','adj. 肌肉的；强壮的','','');----
INSERT INTO classwords VALUES ('ea2c4920f1534c7bbaea5c90ee5413ac','072d560893704d7b8fa116fbd7b569fc','12');----
INSERT INTO word VALUES ('e0cefcfd93354fca9afb3d72b0089cac','attendance','[əˈtendəns]','http://res.iciba.com/resource/amp3/oxford/0/29/c4/29c4dfa7267a1195ab744fdf1bcfb935.mp3','n. 出席，参加；出席的人数；出席率','','');----
INSERT INTO classwords VALUES ('e334a876cec9436894bf30f9506d17f8','e0cefcfd93354fca9afb3d72b0089cac','12');----
INSERT INTO word VALUES ('e42dd49979da425fadee27c81b694d0f','devotion','[diˈvəuʃən]','http://res.iciba.com/resource/amp3/oxford/0/c4/21/c42185624d8ceada1620aa0e57ca72ae.mp3','n. 献身，奉献；深爱；（对宗教的）虔诚','','');----
INSERT INTO classwords VALUES ('0438119c8c3c4041b168744652038124','e42dd49979da425fadee27c81b694d0f','12');----
INSERT INTO word VALUES ('d664cee34ef74c64b11cb479d249ce6c','squash','[skwɔʃ]','http://res.iciba.com/resource/amp3/0/0/bf/f2/bff23476a33b6bfe3b0353826940edd3.mp3','n. 鲜果汁；拥挤；壁球','','');----
INSERT INTO classwords VALUES ('85e7233985c24cc485d1baab39634f4e','d664cee34ef74c64b11cb479d249ce6c','12');----
INSERT INTO word VALUES ('eaf373d368524819a708cd1c780a3109','triumphant','[traɪˈʌmfənt]','http://res.iciba.com/resource/amp3/oxford/0/0d/d1/0dd1d661227276399134346ee5cf2c63.mp3','adj. 欢欣鼓舞的，狂喜的','','');----
INSERT INTO classwords VALUES ('d20e60b6d16d445db06c8772e5154dba','eaf373d368524819a708cd1c780a3109','12');----
INSERT INTO word VALUES ('24a710c0eaf0466a992b876c3ae8cdee','wedge','[wedʒ]','http://res.iciba.com/resource/amp3/oxford/0/e3/7f/e37f08bd085c083d6fcd523910b3063f.mp3','vt. 把…楔住；将…挤入','','');----
INSERT INTO classwords VALUES ('bb7f772de614462aa58040bc14d25fae','24a710c0eaf0466a992b876c3ae8cdee','12');----
INSERT INTO word VALUES ('dadd7d71c86f4f2384dbb57a91824023','sociology','[ˌsəusiˈɔlədʒi]','http://res.iciba.com/resource/amp3/oxford/0/85/36/8536313d1b128c8baf97a5ae8021b8bc.mp3','n. 社会学','','');----
INSERT INTO classwords VALUES ('7bdead9810a94037aebbb8220978722d','dadd7d71c86f4f2384dbb57a91824023','12');----
INSERT INTO word VALUES ('7b9c8790611b410185f9e4a67d8f2a92','fell','[fel]','http://res.iciba.com/resource/amp3/oxford/0/ae/6d/ae6d64214950b51ce4fad4eec9354ca7.mp3','vt. 砍倒（树等），砍伐；打倒','','');----
INSERT INTO classwords VALUES ('b25e0acc34c44649afa13efbc0ecc2f6','7b9c8790611b410185f9e4a67d8f2a92','12');----
INSERT INTO word VALUES ('f3959bb98b144de38bc6bbc48b7a8cdd','cane','[kein]','http://res.iciba.com/resource/amp3/oxford/0/52/9d/529d2cd2745fdd1927b51891047cc8f2.mp3','n. （植物的）茎；竹杖；甘蔗；拐杖','','');----
INSERT INTO classwords VALUES ('a5416aa245a443fd888e1f68f834cbc7','f3959bb98b144de38bc6bbc48b7a8cdd','12');----
INSERT INTO word VALUES ('c08ebac181c649cbafb7e41a66e6388f','attendant','[əˈtendənt]','http://res.iciba.com/resource/amp3/oxford/0/7d/1f/7d1fcf6791fc9cce25cf9a7c099b063e.mp3','n. 侍者；服务员','','');----
INSERT INTO classwords VALUES ('1f9a2778aa4c45d3bfb115b08278aea5','c08ebac181c649cbafb7e41a66e6388f','12');----
INSERT INTO word VALUES ('83a73693a2f44c2cb4fc2018b53b09c7','vital','[ˈvaitəl]','http://res.iciba.com/resource/amp3/oxford/0/85/c1/85c1a488679266f19b00f13e681c36e5.mp3','adj. 至关重要的；充满活力的','','');----
INSERT INTO classwords VALUES ('90629fdcbc6f49158ccc4587634cec33','83a73693a2f44c2cb4fc2018b53b09c7','12');----
INSERT INTO word VALUES ('f2ee6ca3f57f4a22bfb1f568b72f5eac','lighter','[ˈlaɪtə]','http://res.iciba.com/resource/amp3/oxford/0/c3/1e/c31e7d567df7e82df04179e687de8172.mp3','n. 打火机，点火器','','');----
INSERT INTO classwords VALUES ('4fc76473ea9d426b882d114a267f7d06','f2ee6ca3f57f4a22bfb1f568b72f5eac','12');----
INSERT INTO word VALUES ('f0a61d4ed0de44e3934510bd338ab739','divine','[diˈvain]','http://res.iciba.com/resource/amp3/oxford/0/e2/cb/e2cb16a5364634d19148e719448cb08a.mp3','adj. 神的；神圣的；绝妙的','','');----
INSERT INTO classwords VALUES ('1fd475a9de2a48d1a890b6658f7b6426','f0a61d4ed0de44e3934510bd338ab739','12');----
INSERT INTO word VALUES ('2c5c416be062440b80c1d5cc37a4a41b','broaden','[ˈbrɔ:dn]','http://res.iciba.com/resource/amp3/oxford/0/6b/44/6b44d898aeaf04e9d62496414b4e204e.mp3','vt.&vi. 变宽；扩大','','');----
INSERT INTO classwords VALUES ('ae5a0c7623e646e28d77caa7451ad40c','2c5c416be062440b80c1d5cc37a4a41b','12');----
INSERT INTO word VALUES ('d7f1fbafd21a494895a4c661d8d396c8','provision','[prəˈviʒən]','http://res.iciba.com/resource/amp3/oxford/0/42/09/42094960b7bb1fb94853a53d9bc7dd4e.mp3','n. 规定；供应；预备；赡养','','');----
INSERT INTO classwords VALUES ('643c02b2ccbe472e8b76124b9bb56b0a','d7f1fbafd21a494895a4c661d8d396c8','12');----
INSERT INTO word VALUES ('6bdb1a75364b462cae0693dfb8c34e7c','extract','[iksˈtrækt]','http://res.iciba.com/resource/amp3/0/0/3e/40/3e40063e25753005ccb971c164035b1a.mp3','vt. 取出；提取；提炼；摘录 ˈek...','','');----
INSERT INTO classwords VALUES ('053471a42ef94e7b84c97a26643b5778','6bdb1a75364b462cae0693dfb8c34e7c','12');----
INSERT INTO word VALUES ('596d2773092540c7a384b09d0861aaf0','peer','[piə]','http://res.iciba.com/resource/amp3/0/0/f8/fe/f8fe68b4c4cba197efa9c8bbd45f144e.mp3','vi. 凝视；盯着看','','');----
INSERT INTO classwords VALUES ('a3d0b8724dbc415498dd48870e75a5f8','596d2773092540c7a384b09d0861aaf0','12');----
INSERT INTO word VALUES ('c5c7103ad4254b6d8d25876d3ad58453','roundabout','[ˈraundəbaut]','http://res.iciba.com/resource/amp3/oxford/0/70/df/70dfa8183bff89d64776e3cbc42e27bb.mp3','adj. 迂回的；转弯抹角的','','');----
INSERT INTO classwords VALUES ('961fd3d6ffd44d10966fe28e661ff59a','c5c7103ad4254b6d8d25876d3ad58453','12');----
INSERT INTO word VALUES ('27ed07b4a4ab4bb98b81859385eb6e11','assumption','[əˈsʌmpʃən]','http://res.iciba.com/resource/amp3/oxford/0/ae/f1/aef1d70c2ca770a6ff8ce06622e6d720.mp3','n. 假定，假设；承担','','');----
INSERT INTO classwords VALUES ('5ee4bbb64f154a8f8571b7c1e0f38a88','27ed07b4a4ab4bb98b81859385eb6e11','12');----
INSERT INTO word VALUES ('d8c1ce65cc2541d4a3e4cc4599f9e5cf','stationery','[ˈsteiʃənəri]','http://res.iciba.com/resource/amp3/oxford/0/76/43/764312cbc53891190bf723bb9ef2ce75.mp3','n. 文具；信笺','','');----
INSERT INTO classwords VALUES ('a59610e88d4241a3b2ac7f52bff9050c','d8c1ce65cc2541d4a3e4cc4599f9e5cf','12');----
INSERT INTO word VALUES ('40486fe17d7b48ffb8551bd554a6c2b9','tactics','[ˈtæktɪks]','http://res.iciba.com/resource/amp3/0/0/7c/8d/7c8dc0690262b6586c97fef5fec7f9e6.mp3','n. 策略，手段；战术','','');----
INSERT INTO classwords VALUES ('3cc7d44ccf724f2eb71c21ccbb28626b','40486fe17d7b48ffb8551bd554a6c2b9','12');----
INSERT INTO word VALUES ('11ce18b1306740c1b059ea3508d9554d','crisp','[krisp]','http://res.iciba.com/resource/amp3/oxford/0/a0/6a/a06aed1b1d18b4e2cb94620596640d82.mp3','adj. 脆的；凉爽的；洁净的','','');----
INSERT INTO classwords VALUES ('d7750a829ede4d6d900b15c88789b671','11ce18b1306740c1b059ea3508d9554d','12');----
INSERT INTO word VALUES ('5c0aa92a78104557a837358534bd39c6','luncheon','[ˈlʌntʃən]','http://res.iciba.com/resource/amp3/oxford/0/76/a1/76a1bdc8e3f7da3b656751b2f8e4ac9a.mp3','n. 午宴；午餐，午饭','','');----
INSERT INTO classwords VALUES ('27937db1a7954a83a064e202368179f3','5c0aa92a78104557a837358534bd39c6','12');----
INSERT INTO word VALUES ('70c2809519b64f93ba633b75f6f21d04','desert','[ˈdezət]','http://res.iciba.com/resource/amp3/0/0/3f/d6/3fd6b6210e33bb046e69f256a138e28d.mp3','vt. 舍弃；遗弃；放弃；擅离（职守）','','');----
INSERT INTO classwords VALUES ('6219fdca3fbb421fa2464e715dcdc352','70c2809519b64f93ba633b75f6f21d04','12');----
INSERT INTO word VALUES ('036071278b2f40d4ad505faa4fa1b718','cater','[ˈkeitə]','http://res.iciba.com/resource/amp3/oxford/0/41/c1/41c139e8a5b9dabad5d503c927aec673.mp3','vi. 为…提供服务；考虑到；为…提供饮...','','');----
INSERT INTO classwords VALUES ('2a8f1057d0ba4a6a8525c32209806978','036071278b2f40d4ad505faa4fa1b718','12');----
INSERT INTO word VALUES ('efaea41fb8e744b884ed133d78fd6502','prophet','[ˈprɔfit]','http://res.iciba.com/resource/amp3/oxford/0/76/97/7697b7071bbea8ca118c748c14020399.mp3','n. 预言家；先知','','');----
INSERT INTO classwords VALUES ('4ba46cc956db4c0999a5ff2068c7aa9c','efaea41fb8e744b884ed133d78fd6502','12');----
INSERT INTO word VALUES ('37b2705fd84347adab91ae4414aeb68b','stem','[stem]','http://res.iciba.com/resource/amp3/oxford/0/5a/f6/5af638559738cfc1a1b34e559d78098e.mp3','v. 起源于；阻止','','');----
INSERT INTO classwords VALUES ('2796abd77dbc4e77a288f631ffcfbcd5','37b2705fd84347adab91ae4414aeb68b','12');----
INSERT INTO word VALUES ('514993bfbd75437a8c9f08e94db61396','hindrance','[ˈhɪndrəns]','http://res.iciba.com/resource/amp3/oxford/0/43/3b/433ba689b1654c42c72f0b4a4224947b.mp3','n. 障碍，妨碍；障碍物','','');----
INSERT INTO classwords VALUES ('a66aa9cd40f04df09c1bb38e6518e5b3','514993bfbd75437a8c9f08e94db61396','12');----
INSERT INTO word VALUES ('757b8218e65241429f0c0335f9748a88','sorrowful','[ˈsɔrəʊfəl]','http://res.iciba.com/resource/amp3/oxford/0/21/fd/21fd294666d1a462cd710e23524508d9.mp3','adj. 悲哀的；悲伤的；忧愁的','','');----
INSERT INTO classwords VALUES ('67726806dc6d47cfb97abb94c8660992','757b8218e65241429f0c0335f9748a88','12');----
INSERT INTO word VALUES ('6bd222d377dd4acabd22600707b55fce','discriminatio...','[dɪˌskrimiˈneiʃən]','http://res.iciba.com/resource/amp3/oxford/0/71/33/7133a348d10ee7bde728a04dc09909ce.mp3','n. 辨别；识别力；歧视','','');----
INSERT INTO classwords VALUES ('bebfa05f67ec48ba91773cb0d0f55659','6bd222d377dd4acabd22600707b55fce','12');----
INSERT INTO word VALUES ('09a0d482730f42ea8a0a57b377c61e83','bandage','[ˈbændidʒ]','http://res.iciba.com/resource/amp3/oxford/0/81/8f/818fa3f45ced2ff728c898b3815da260.mp3','n. 绷带','','');----
INSERT INTO classwords VALUES ('49193123873f4f908d5caf4af9e6499d','09a0d482730f42ea8a0a57b377c61e83','12');----
INSERT INTO word VALUES ('ab1f20c0c85349f4878f52c4a31b2a3c','idiot','[ˈidiət]','http://res.iciba.com/resource/amp3/oxford/0/c6/72/c672c74a1258b3c9561c5d19bad1023a.mp3','n. 白痴；傻子；弱智者','','');----
INSERT INTO classwords VALUES ('ee37c0bf412943ef93f6d263d7a0eea3','ab1f20c0c85349f4878f52c4a31b2a3c','12');----
INSERT INTO word VALUES ('821dc813053b4825aff9b3944c3273d9','unpaid','[ʌnˈpeɪd]','http://res.iciba.com/resource/amp3/oxford/0/0a/f9/0af9d661b819b19a4cb7d2422c65feb7.mp3','adj. 未付的；不支薪水的','','');----
INSERT INTO classwords VALUES ('823ec6b2ae3a4324b55847de3befc472','821dc813053b4825aff9b3944c3273d9','12');----
INSERT INTO word VALUES ('f52d2e8644e645858e8b216225b97460','depression','[diˈpreʃən]','http://res.iciba.com/resource/amp3/oxford/0/a1/70/a1707676c4a36871b0473b8c5b924515.mp3','n. 消沉；萧条；凹陷','','');----
INSERT INTO classwords VALUES ('2240c2c5b3634597bf0869be3e9f8703','f52d2e8644e645858e8b216225b97460','12');----
INSERT INTO word VALUES ('c79062a0f9cd4c12a0a3e57042bacb1d','humanity','[hju:ˈmæniti]','http://res.iciba.com/resource/amp3/oxford/0/ef/22/ef2215bac567643d961d2e220debc2f0.mp3','n. 人类；人性；人道；人文学科','','');----
INSERT INTO classwords VALUES ('b408ccdcb30b48f9b68f6bd3f51e9350','c79062a0f9cd4c12a0a3e57042bacb1d','12');----
INSERT INTO word VALUES ('45448448e4024577bf6bba4f61a245c6','reveal','[riˈvi:l]','http://res.iciba.com/resource/amp3/oxford/0/0b/61/0b6151d7ad4fb87c8e19d9c1167b14c5.mp3','vt. 揭露；使显露；显示','','');----
INSERT INTO classwords VALUES ('5dc7d8264093413bafa928075985e2ff','45448448e4024577bf6bba4f61a245c6','12');----
INSERT INTO word VALUES ('089d35c5d2f342f88364746c5d80a5e6','hit','[hit]','http://res.iciba.com/resource/amp3/oxford/0/72/3c/723cc0ca97b83460fb042871bf3573a3.mp3','n. 轰动一时的人（或事）；点击','','');----
INSERT INTO classwords VALUES ('cbb84165954d4fa49567dc6e17ffffc0','089d35c5d2f342f88364746c5d80a5e6','12');----
INSERT INTO word VALUES ('3677637088fc4b96bf7d68cc39604a88','forthcoming','[fɔ:θˈkʌmiŋ]','http://res.iciba.com/resource/amp3/oxford/0/69/8f/698f5ead8a5291e19ae0ee1de5eda89c.mp3','adj. 即将到来的；现成的','','');----
INSERT INTO classwords VALUES ('8249e5338d914c17879805876bbf157a','3677637088fc4b96bf7d68cc39604a88','12');----
INSERT INTO word VALUES ('27a5ff4f3d8b4dccb5295cf38cc006ba','shark','[ʃɑ:k]','http://res.iciba.com/resource/amp3/0/0/da/67/da6776e7ec7eaa7a6f3df5c6b149127e.mp3','n. 鲨鱼；诈骗者','','');----
INSERT INTO classwords VALUES ('0721a3153d12420591473bc0499ff197','27a5ff4f3d8b4dccb5295cf38cc006ba','12');----
INSERT INTO word VALUES ('2c5c420e1c874869a77bed790ac1f27c','prick','[prik]','http://res.iciba.com/resource/amp3/oxford/0/9e/85/9e855ef39fc60530ab16a51e000a28b0.mp3','n. 刺痛','','');----
INSERT INTO classwords VALUES ('4eaf445b1d30444482f78d4f4d8ebbc3','2c5c420e1c874869a77bed790ac1f27c','12');----
INSERT INTO word VALUES ('80fa45d360a8422aad43f503238b0def','garage','[ˈɡærɑ:ʒ]','http://res.iciba.com/resource/amp3/0/0/38/24/3824795e4e1fbf0f72f1cf99ee90d861.mp3','n. 汽车修理站；车库','','');----
INSERT INTO classwords VALUES ('8c60258a2b9a4c979b1347c8e6c13183','80fa45d360a8422aad43f503238b0def','12');----
INSERT INTO word VALUES ('5476eadc4b2340a0b6c7c81a29f38633','facilitate','[fəˈsiliteit]','http://res.iciba.com/resource/amp3/oxford/0/ba/c4/bac4cc76b6057b8fbc10c0d48e776e73.mp3','vt. 促进；使便利','','');----
INSERT INTO classwords VALUES ('38eba242279f43988b78f3b48ad456f3','5476eadc4b2340a0b6c7c81a29f38633','12');----
INSERT INTO word VALUES ('e1187b015cb04026895230648288a95a','repeal','[riˈpi:l]','http://res.iciba.com/resource/amp3/oxford/0/76/1b/761b31e702b58e6078ccb92639d30825.mp3','n. 撤销','','');----
INSERT INTO classwords VALUES ('e89368039d57412eab61638bf1ee5a84','e1187b015cb04026895230648288a95a','12');----
INSERT INTO word VALUES ('8e26735c44e8497e85abd7a8e4798d83','grasshopper','[ˈgræsˌhɔpə]','http://res.iciba.com/resource/amp3/oxford/0/fd/f2/fdf2605084af41a0121a22c6ad0ebf16.mp3','n. 蚱蜢，蝗虫','','');----
INSERT INTO classwords VALUES ('ecdc251f77ab4f1e82d5a66ddf47d350','8e26735c44e8497e85abd7a8e4798d83','12');----
INSERT INTO word VALUES ('df814d1d42aa4db99b1b1dd48764143e','head','[hed]','http://res.iciba.com/resource/amp3/oxford/0/68/d9/68d9ee9b0a4b15cbcd3a08ba3d21b4ab.mp3','vi. 出发；向…方向移动','','');----
INSERT INTO classwords VALUES ('b0141bbd11024800a85ede9bd4d76e81','df814d1d42aa4db99b1b1dd48764143e','12');----
INSERT INTO word VALUES ('b0e87195b1fb4f859a5bd2abf3f6bee7','forward','[ˈfɔ:wəd]','http://res.iciba.com/resource/amp3/0/0/96/5d/965dbaac085fc891bfbbd4f9d145bbc8.mp3','vt. 促进，推进；转交','','');----
INSERT INTO classwords VALUES ('27d84694b6a7442eb269bac346d2ddff','b0e87195b1fb4f859a5bd2abf3f6bee7','12');----
INSERT INTO word VALUES ('5b4b013b927c49b6a71d8e7817b60405','monopoly','[məˈnɔpəli]','http://res.iciba.com/resource/amp3/oxford/0/ce/03/ce03dca64cd3a7512532ba1b5755c4f0.mp3','n. 垄断；专卖者；独有','','');----
INSERT INTO classwords VALUES ('f8d7dce15bfa449994d4c3481fb70c9e','5b4b013b927c49b6a71d8e7817b60405','12');----
INSERT INTO word VALUES ('0028444200b94bccb276e494358bc78a','alas','[əˈlæs]','http://res.iciba.com/resource/amp3/oxford/0/af/f6/aff6e06abfefd9578cf099344dbab1eb.mp3','int. 唉，哎呀（表示悲伤、怜悯等）','','');----
INSERT INTO classwords VALUES ('fc7be40a96c1485d902ffa65fd54147f','0028444200b94bccb276e494358bc78a','12');----
INSERT INTO word VALUES ('a18636f52298463f9eb6c77e593784ac','safeguard','[ˈseifɡɑ:d]','http://res.iciba.com/resource/amp3/oxford/0/d2/d2/d2d2756730cfea614836b4343bb6296b.mp3','n. 保护措施；保护，保卫','','');----
INSERT INTO classwords VALUES ('cbbee62f81b94b88ae16ad8abcdc313c','a18636f52298463f9eb6c77e593784ac','12');----
INSERT INTO word VALUES ('e8bf604bf744487ea3e81b241da8d95d','irritate','[ˈiriteit]','http://res.iciba.com/resource/amp3/oxford/0/ce/15/ce154ba140b955e71dba1d33e3d94723.mp3','vt. 激怒；使恼怒；刺激；使发痒','','');----
INSERT INTO classwords VALUES ('d439486800a24a05b0bb8c6875730f6c','e8bf604bf744487ea3e81b241da8d95d','12');----
INSERT INTO word VALUES ('ee5a028677b44244bbcd26aa8334373e','elemental','[ˌeləˈmentl]','http://res.iciba.com/resource/amp3/oxford/0/a0/fa/a0fa8f17e4a473673b218fdf22c145b6.mp3','adj. 基本的；自然力的','','');----
INSERT INTO classwords VALUES ('862fb9796abd498a802c24b7208d1eec','ee5a028677b44244bbcd26aa8334373e','12');----
INSERT INTO word VALUES ('aa5522386c664e6995981a568a4c2f37','deviation','[ˌdi:vi:ˈeɪʃən]','http://res.iciba.com/resource/amp3/oxford/0/b0/64/b0646df369ec63ec36ae34cf39f75f84.mp3','n. 背离，偏离；离经叛道；偏差','','');----
INSERT INTO classwords VALUES ('dea8b0bff468452c8c55e28ac0cdcfd4','aa5522386c664e6995981a568a4c2f37','12');----
INSERT INTO word VALUES ('6bb1040b71854dcbbb15a0a54e8b6055','bleach','[bli:tʃ]','http://res.iciba.com/resource/amp3/oxford/0/60/be/60bee3257c518ad167dd7577f81288f0.mp3','n. 漂白剂','','');----
INSERT INTO classwords VALUES ('af659578ad7f449e9994ad17e833d50c','6bb1040b71854dcbbb15a0a54e8b6055','12');----
INSERT INTO word VALUES ('d70dba756f604585bf107d7cbf6f5d77','reserve','[riˈzə:v]','http://res.iciba.com/resource/amp3/0/0/9c/3b/9c3b62949032a7361e2f0642fcb118d6.mp3','n. 储备；替补队员；保护区；寡言，矜持','','');----
INSERT INTO classwords VALUES ('14643ea6170f461b87d81f18239f5179','d70dba756f604585bf107d7cbf6f5d77','12');----
INSERT INTO word VALUES ('3d0f2b93e4dd43c583da709b04965d92','chatter','[ˈtʃætə]','http://res.iciba.com/resource/amp3/oxford/0/a9/6e/a96ef6e6fbea8a3f48e346c7a578b1d2.mp3','vi. 喋喋不休，唠叨；（牙齿）打战；发...','','');----
INSERT INTO classwords VALUES ('46067461d5694b6b945bf65d07ae12ef','3d0f2b93e4dd43c583da709b04965d92','12');----
INSERT INTO word VALUES ('68cf4eaec7164d09944044f083d0b5c6','interact','[ˌɪntərˈækt]','http://res.iciba.com/resource/amp3/oxford/0/aa/43/aa432ee497b7914de1a112d390e2cf69.mp3','vi. 相互作用；相互影响','','');----
INSERT INTO classwords VALUES ('0f06624e8e334d419e51303df7355de6','68cf4eaec7164d09944044f083d0b5c6','12');----
INSERT INTO word VALUES ('c8993175ec8e4340af57d13443285bcb','sophisticated','[səˈfistikeitid]','http://res.iciba.com/resource/amp3/oxford/0/32/27/322743a2c4dae78d7c1e22cd3834c70b.mp3','adj. 见过世面的；高级的；精明老练的','','');----
INSERT INTO classwords VALUES ('72ad3a2f59294d8996531935c4becf7c','c8993175ec8e4340af57d13443285bcb','12');----
INSERT INTO word VALUES ('e7724d64e8ac4dc8a0e41e567b115111','sideways','[ˈsaidweiz]','http://res.iciba.com/resource/amp3/oxford/0/0a/b3/0ab34410ad2bc3e75763de0db5b1ce52.mp3','adv. 斜向一边地；（调动工作）平级地','','');----
INSERT INTO classwords VALUES ('01132af2e0eb43a38a7c605dec637cca','e7724d64e8ac4dc8a0e41e567b115111','12');----
INSERT INTO word VALUES ('78b1432b6e2e4aac9288b8483851d4fd','number','[ˈnʌmbə]','http://res.iciba.com/resource/amp3/oxford/0/ad/57/ad570b7d85d3445cac88c0eb6cca4511.mp3','vt. 共计；把…编号','','');----
INSERT INTO classwords VALUES ('973e78108e294fab97b49cbcfc46a6dd','78b1432b6e2e4aac9288b8483851d4fd','12');----
INSERT INTO word VALUES ('46e9068c06084ca893e024894142d3bc','stone','[stəun]','http://res.iciba.com/resource/amp3/0/0/0a/84/0a840ef45467fb3932dbf2c2896c5cbf.mp3','n. 石头；小石子；石碑；结石','','');----
INSERT INTO classwords VALUES ('b070b570d1914ff0a1aed78b2b539f98','46e9068c06084ca893e024894142d3bc','12');----
INSERT INTO word VALUES ('03cdf99a2e194f1a98f1ed545090f2b9','appendix','[əˈpendiks]','http://res.iciba.com/resource/amp3/oxford/0/05/b0/05b0236cc3370519de745a9098c36cd8.mp3','n. 附录，附属物；阑尾','','');----
INSERT INTO classwords VALUES ('4d5aab9a42c24c1b83d46470a943a2f4','03cdf99a2e194f1a98f1ed545090f2b9','12');----
INSERT INTO word VALUES ('9a3535e351d146cb9fd9397e8b0327b1','underline','[ˌʌndəˈlain]','http://res.iciba.com/resource/amp3/oxford/0/6f/06/6f062537e3f70be303630d70a8c979bb.mp3','vt. 强调；凸显；在…下画线','','');----
INSERT INTO classwords VALUES ('467483938c0c4957b96624f76b4cdaa5','9a3535e351d146cb9fd9397e8b0327b1','12');----
INSERT INTO word VALUES ('7504355f8216407e87b4c528068600f7','complication','[ˌkɔmpliˈkeiʃən]','http://res.iciba.com/resource/amp3/oxford/0/6d/6c/6d6c9c12f3f1fa3096d7ea8bb9aa2661.mp3','n. 困难，难题；并发症','','');----
INSERT INTO classwords VALUES ('ce0017fb175e4bf48407b9bcc2008b36','7504355f8216407e87b4c528068600f7','12');----
INSERT INTO word VALUES ('34911a09c1d14dc7ab62db19a8eee496','hostess','[ˈhəʊstɪs]','http://res.iciba.com/resource/amp3/0/0/c2/b2/c2b2f076c396328a28f6c0bd5f6756af.mp3','n. 女主人；（夜总会的）舞女','','');----
INSERT INTO classwords VALUES ('6307996212fe42bbbeeee45bb0f3d540','34911a09c1d14dc7ab62db19a8eee496','12');----
INSERT INTO word VALUES ('c0e1120613d84cdeb96e9e6b2130f3f8','hoe','[həu]','http://res.iciba.com/resource/amp3/0/0/30/40/30403192841bf90f1d801faedb1509aa.mp3','vt.&vi. 锄地；锄草','','');----
INSERT INTO classwords VALUES ('70829d6e5eaf4a9fb68fc9ada13c0de1','c0e1120613d84cdeb96e9e6b2130f3f8','12');----
INSERT INTO word VALUES ('fa61e296aa624fb8b320b16587ef4df1','steady','[ˈstedi]','http://res.iciba.com/resource/amp3/oxford/0/36/55/3655241c4a9561e14a0b9e390db3cef5.mp3','adj. 坚定的；稳步的；沉着的','','');----
INSERT INTO classwords VALUES ('c8267edd542a46d286f9655164932036','fa61e296aa624fb8b320b16587ef4df1','12');----
INSERT INTO word VALUES ('efa9ecd813064c9fa4ba7bfd5f853daf','vengeance','[ˈvendʒəns]','http://res.iciba.com/resource/amp3/oxford/0/59/4e/594ecfb1adada4a1a889abb480625053.mp3','n. 报复，报仇，复仇','','');----
INSERT INTO classwords VALUES ('539bdf81f369491eaeb03245e75651f5','efa9ecd813064c9fa4ba7bfd5f853daf','12');----
INSERT INTO word VALUES ('725fa4fa845042e0913e5f87b48be987','spherical','[ˈsfɪərɪkəl]','http://res.iciba.com/resource/amp3/oxford/0/18/65/1865ce80ccdf9805cd84b59b63cd51ba.mp3','adj. 球形的，球面的','','');----
INSERT INTO classwords VALUES ('b739a8f8c6824e7e941bf33cfc2ac4c2','725fa4fa845042e0913e5f87b48be987','12');----
INSERT INTO word VALUES ('b42be1f5bbc0428a86aaea01545e7d1a','growl','[ɡraul]','http://res.iciba.com/resource/amp3/oxford/0/71/d4/71d48104be70ff9657a80b965e2291f0.mp3','vi. （狗等）嗥叫；咆哮；隆隆作响','','');----
INSERT INTO classwords VALUES ('fcb8c066e1db4300a2fd91c5b772dba9','b42be1f5bbc0428a86aaea01545e7d1a','12');----
INSERT INTO word VALUES ('6c747c2ca8c0415ba2523b1b16d8bda8','overlook','[ˌəuvəˈluk]','http://res.iciba.com/resource/amp3/0/0/10/ce/10ce6750b68ac56d8fbaecca86b528b5.mp3','vt. 眺望；忽视；宽容','','');----
INSERT INTO classwords VALUES ('c26647beb46244ef8907b8ac98f2d3f9','6c747c2ca8c0415ba2523b1b16d8bda8','12');----
INSERT INTO word VALUES ('2636c3ba92f24eb6b641f5919557718a','immortal','[iˈmɔ:tl]','http://res.iciba.com/resource/amp3/0/0/cd/cd/cdcd267dd9829fbb9070142d231d16b0.mp3','adj. 不朽的；流芳百世的；不死的','','');----
INSERT INTO classwords VALUES ('717470e6bb2c4da991b88ca437853074','2636c3ba92f24eb6b641f5919557718a','12');----
INSERT INTO word VALUES ('2b56aa1459964f4d93e8036dda403242','landscape','[ˈlændskeip]','http://res.iciba.com/resource/amp3/oxford/0/44/0f/440f190955c73622e8dc5f19092955a2.mp3','n. 风景，景色；情形，形势','','');----
INSERT INTO classwords VALUES ('ee6bc217ee444d7894e251457bd857bb','2b56aa1459964f4d93e8036dda403242','12');----
INSERT INTO word VALUES ('e0440349f8994c2bbe615a90a2de61b9','winding','[ˈwaɪndɪŋ]','http://res.iciba.com/resource/amp3/oxford/0/be/0b/be0b58d229e42fc1381440e60b79dd7a.mp3','adj. 蜿蜒的，弯曲的','','');----
INSERT INTO classwords VALUES ('5263d1a2e512488ab46c9a2adc7a35c8','e0440349f8994c2bbe615a90a2de61b9','12');----
INSERT INTO word VALUES ('c2c54f9e96f14a0181635c3d31bb3a1e','consequence','[ˈkɔnsikwəns]','http://res.iciba.com/resource/amp3/0/0/da/9c/da9c3748877e7cc063dea8073b33986d.mp3','n. 结果，后果；影响','','');----
INSERT INTO classwords VALUES ('8b661068ff1143a1906e76c4616999e8','c2c54f9e96f14a0181635c3d31bb3a1e','12');----
INSERT INTO word VALUES ('a241f77502194a3dacbe4b2908e0a6bd','valuable','[ˈvæljuəbl]','http://res.iciba.com/resource/amp3/oxford/0/2f/50/2f50557706cc7d0fe060101022774401.mp3','adj. 有价值的；有用的；贵重的','','');----
INSERT INTO classwords VALUES ('9e135a0b34064426b267a782cc9def7a','a241f77502194a3dacbe4b2908e0a6bd','12');----
INSERT INTO word VALUES ('2ebfe9da1e5548b296bcffd0232a46bf','reed','[riːd]','http://res.iciba.com/resource/amp3/oxford/0/8c/6c/8c6c9aba7a3ef6656de28e3f8142ffc3.mp3','n. 芦苇；[乐]簧片','','');----
INSERT INTO classwords VALUES ('f3518428df9646808b8caf54ba942859','2ebfe9da1e5548b296bcffd0232a46bf','12');----
INSERT INTO word VALUES ('a4ecdbdc91f54e7c8bfa9f3f65c1daef','thresh','[θreʃ]','http://res.iciba.com/resource/amp3/oxford/0/9e/db/9edbb27f126272be9536eec12648e688.mp3','vt. 打谷，给…脱粒；推敲','','');----
INSERT INTO classwords VALUES ('4f91b7bbc84245f8a950d57cdf53c49f','a4ecdbdc91f54e7c8bfa9f3f65c1daef','12');----
INSERT INTO word VALUES ('6dba5431bc40463eabb1325f9a5cc823','badge','[bædʒ]','http://res.iciba.com/resource/amp3/oxford/0/16/fa/16fa58859d052990fe2a5836e38834ea.mp3','n. 徽章；标志','','');----
INSERT INTO classwords VALUES ('34f78ff943644f9e95f2175f650c4392','6dba5431bc40463eabb1325f9a5cc823','12');----
INSERT INTO word VALUES ('880c1865dbd541c9bedef47bfe43d8ed','whereas','[hwɛərˈæz]','http://res.iciba.com/resource/amp3/oxford/0/ec/48/ec48469f7960286d795e0dc31bb57bd5.mp3','conj. 但是，然而','','');----
INSERT INTO classwords VALUES ('20a57182e14d4cb8bcf78d7e7ca386d9','880c1865dbd541c9bedef47bfe43d8ed','12');----
INSERT INTO word VALUES ('00cf272c1ae1487d85ed62ebf81e1784','kidnap','[ˈkidnæp]','http://res.iciba.com/resource/amp3/oxford/0/77/ed/77ed58acbef8ffdf7124a0ec2b8524c7.mp3','vt. 绑架；劫持','','');----
INSERT INTO classwords VALUES ('37704898478c4dfdba29aa5045e6ba54','00cf272c1ae1487d85ed62ebf81e1784','12');----
INSERT INTO word VALUES ('9fb6d5c28c1b47adae84476593e66157','discourse','[ˈdiskɔ:s]','http://res.iciba.com/resource/amp3/oxford/0/41/5c/415cd407ab52b1361dfc1d335f9e53af.mp3','n. 演讲，论述；语篇','','');----
INSERT INTO classwords VALUES ('5ee79942207443a58c760e02e5b7d099','9fb6d5c28c1b47adae84476593e66157','12');----
INSERT INTO word VALUES ('ead1359968dc45fbb643906351180c79','eject','[iˈdʒekt]','http://res.iciba.com/resource/amp3/oxford/0/4c/64/4c64f6c6f4cee86d326b6ccfe39d5795.mp3','vt. 驱逐；喷射','','');----
INSERT INTO classwords VALUES ('81358b33efe942eeaf1efae9f66d6466','ead1359968dc45fbb643906351180c79','12');----
INSERT INTO word VALUES ('358bbe62b8eb42d9ad5e3346a946e6de','controversy','[ˈkɔntrəvə:si]','http://res.iciba.com/resource/amp3/0/0/99/77/9977222e570c3ba22779cf9011b26dd5.mp3','n. 争论，辩论，争议','','');----
INSERT INTO classwords VALUES ('7474db0b475e4eaaa4c45bce53f53246','358bbe62b8eb42d9ad5e3346a946e6de','12');----
INSERT INTO class VALUES ('12','大学六级必备词汇','2087');
