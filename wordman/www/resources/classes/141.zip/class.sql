CREATE TABLE IF NOT EXISTS `word_141` (  `id` char(32) NOT NULL,  `word` varchar(55) NOT NULL,  `classId` char(32) NOT NULL,  `phon` varchar(255) NOT NULL,  `pron` varchar(255) NOT NULL,  `para` varchar(512) NOT NULL,  `build` varchar(512) NOT NULL,  `example` varchar(1024) NOT NULL)--B3WmSQL--
INSERT INTO word_141 VALUES ('9129bd094ed44cbcb61d8dbb07142450','let out','141','[let aut]','http://res.iciba.com/resource/amp3/0/0/af/4b/af4bf7de5a0e47c710664d07e9d0ba22.mp3','放掉, 泄露','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a588ec0731fa48d68df13675f7a2db7c','put away','141','[put əˈwei]','http://res.iciba.com/resource/amp3/0/0/f6/ae/f6aebbee4163169a82fd337d49ba149e.mp3','储存','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('625f865e300b4c828c1e8c06f5ddac07','go on doing.....','141','[put əˈwei]','','继续干某事，不停地干某事','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('703c059371a14ab2ac0be6c9b6174373','by and by','141','[bai ænd bai]','http://res.iciba.com/resource/amp3/0/0/b2/39/b239eb281c171927761398cfdea950dc.mp3','不久以后，逐渐地','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('452f9a3c59c8481b9744f2e259fae7ac','set down','141','[set daun]','http://res.iciba.com/resource/amp3/0/0/fd/1b/fd1bfbbfb8b86174eb0efb7630b362fc.mp3','放下','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('73e4abd267f4434aa98d3bb3bbc0285e','write down','141','[rait daun]','http://res.iciba.com/resource/amp3/1/0/6d/7b/6d7bde8ccf1a2876a85e6d0db303a1ea.mp3','写下，记下','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('898f8ee95ed847ef9fe13a227ef31ee1','earn one''s li...','141','[ə:n wʌnz ˈliviŋ]','http://res.iciba.com/resource/amp3/0/0/f6/6d/f66d7ddb97986031aedf69cb5f372435.mp3','谋生','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6594d0988c874354aa83bcd5a6334c59','go in for','141','[ɡəu in fɔ:]','http://res.iciba.com/resource/amp3/0/0/dd/bc/ddbc2b6f300ea55fedefe363850687e8.mp3','参加，喜欢','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ebc0f21af0344e32b4a72685029c26f7','depend on (up...','141','[ɡəu in fɔ:]','','依靠，相信，信赖','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('daaeed7f154c4c7dbd2254905b03ca6e','send out','141','[send aut]','http://res.iciba.com/resource/amp3/0/0/e9/d0/e9d07bd968483d687722ad328570d08e.mp3','发出，派遣','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fd5acdce1c3e4137910513667b5d5d77','in a hurry','141','[in ə ˈhʌri]','http://res.iciba.com/resource/amp3/0/0/44/75/44751e53cf7ae2150b00b65fe3eb0e53.mp3','匆忙，很快地','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('932b5684d4ec4369a2ca7ced58f3d376','in a word','141','[in ə wə:d]','http://res.iciba.com/resource/amp3/0/0/1a/5a/1a5ae76a4eedd87f85669c2950ebbfb9.mp3','简言之，总之','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('56c86686efe9467896258c5394b2b093','get along wit...','141','[ɡet əˈlɔŋ wið]','http://res.iciba.com/resource/amp3/0/0/d3/28/d328cf7a311e10c31fdbe1dd52e8b5d6.mp3','与……相处','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('145fdfc081a34b2f9e923f8b3cca4e59','lead to','141','[li:d tu:]','http://res.iciba.com/resource/amp3/0/0/c1/9a/c19a08e132073ccc42091dc309da8631.mp3','导致，导向','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6a1bc888079346ada35a5aa5296e9d68','so far as','141','[səʊ fɑ: æz]','http://res.iciba.com/resource/amp3/0/0/8c/a4/8ca41b11fe464a0c930f12416a9af961.mp3','（表示程度，范围）就……，尽……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('418626f4f6b9465ab86902c2b88c4c70','in need of','141','[in ni:d ɔv]','http://res.iciba.com/resource/amp3/0/0/e8/18/e818baf4ba9e825fea07d3a666cb5ea9.mp3','需要，缺少','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('96690c8bc95840cfb499805a6359d28c','on foot','141','[ɔn fut]','http://res.iciba.com/resource/amp3/0/0/f1/8b/f18b10e99f79e4336552ef0789bf6803.mp3','走路，步行','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('cf1a0f6a388f46e7a6459ff9834ad387','come about','141','[kʌm əˈbaut]','http://res.iciba.com/resource/amp3/0/0/ec/9b/ec9b2350dc9e6184af175d996f68aa23.mp3','发生，产生','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('12486ff2c75b47a4a13c6d2d8840c90c','get together','141','[ɡet təˈɡeðə]','http://res.iciba.com/resource/amp3/0/0/b9/e1/b9e14d45cf990c9d2c27e14ae7961810.mp3','聚会，联欢','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fea74bbf2fd94154a76476fb0f48e5dd','check out','141','[tʃek aut]','http://res.iciba.com/resource/amp3/0/0/8b/81/8b81d9aa118c0c3f760799dcbc9b81c1.mp3','查明; 结账','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a6712c5a0e05415e91d1c035a60ce78f','send for','141','[send fɔ:]','http://res.iciba.com/resource/amp3/0/0/89/ca/89cab114aff61e28530067c8c876103a.mp3','派人去叫（请）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('024334a0d6714c89bf51c66c35db5b15','spend...on','141','','http://res-tts.iciba.com/8/1/4/814ff9557adbebd02186ecab27e08b51.mp3','在……花钱','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ef81e0a1d5bb4bc1940361fc098aa7ca','get off','141','[ɡet ɔf]','http://res.iciba.com/resource/amp3/0/0/25/c3/25c3ada1387b1c6b2c855a0facf5ef3a.mp3','脱下（衣服等）；下车','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ad0620854c704b7d9924d3ab751a7046','make up of','141','[meik ʌp ɔv]','http://res.iciba.com/resource/amp3/0/0/9b/bd/9bbda06a23ed1b22a9b597d1b95edf40.mp3','由……组成，构成','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4da95c1534e444dc8d1fd3506cf088f5','hold on','141','[həuld ɔn]','http://res.iciba.com/resource/amp3/0/0/45/c1/45c194a91bfef734109bb8ecaffa5561.mp3','等一等（别挂电话）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('0507edd9138d48cb889a3894fb94d77e','in the end','141','[in ðə end]','http://res.iciba.com/resource/amp3/0/0/a6/a3/a6a3b11134c4bc7538bb79454ce5ea31.mp3','最后，终于','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8fbce016a10d4a4e996410613b11f6eb','stand for','141','[stænd fɔ:]','http://res.iciba.com/resource/amp3/0/0/c2/91/c291452d4077260e22b5996663975ae4.mp3','代表，象征','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('58e00769c8694f04a615128894be1200','dozens of','141','','http://res-tts.iciba.com/1/d/5/1d5c6dd343acbf5b5989a74bc68d1346.mp3','几十','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3c8f5bb275bf4379896f7153c5ace1ae','or else','141','[ɔ: els]','http://res.iciba.com/resource/amp3/0/0/f2/80/f28035166a9889f3c27b266611c0358c.mp3','否则，要不然','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9ac0dff308dd4212a2114b19b75490ab','come across','141','[kʌm əˈkrɔs]','http://res.iciba.com/resource/amp3/0/0/6d/af/6daf350034e01ceff031200e2fc32f2c.mp3','(偶然)遇见(或发现）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('7463d602b06f4487b3de623daa988122','feel like doi...','141','[fi:l laik ˈdu:ɪŋ]','http://res-tts.iciba.com/9/8/3/9832edcd0d97315c02e18c05e1ab598b.mp3','想要…, 感觉要…','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d93a6df61402469c9f5e2aa86b993568','be strict wit...','141','[bi: strikt wið]','http://res-tts.iciba.com/3/a/d/3ade0973b5d44523a62ff0cb6526e132.mp3','对……严格要求','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('83967d1acee64ef0bcb0fcb9f56defcc','cut off','141','[kʌt ɔf]','http://res.iciba.com/resource/amp3/1/0/cc/64/cc64e77e65d232d2741f5e62efa3faee.mp3','切断','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8cc886ffc9f84f9ba57b52f12f736086','in peace','141','[in pi:s]','http://res.iciba.com/resource/amp3/0/0/18/cf/18cf642f9eea7ec484e9a6853e3e1938.mp3','安静，宁静','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('62da8b36a59b4a6cb55cbae0835a7517','make a face','141','[meik ə feis]','http://res.iciba.com/resource/amp3/0/0/f9/08/f908e0e91862b1b4fcd68129ee94b5fd.mp3','做鬼脸，做苦脸','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c4d54d7db430408c88b94022649ea99f','think about','141','[θiŋk əˈbaut]','http://res-tts.iciba.com/3/e/e/3eecef3ee37002c553a48e7e9974b75d.mp3','考虑（是否去做）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b16fa2b0cf824c928771940389f55598','arrive at (in...','141','[θiŋk əˈbaut]','','到达某地','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a6eff99b0d0040208e01a2865468dbac','go on','141','[ɡəu ɔn]','http://res.iciba.com/resource/amp3/0/0/4f/e6/4fe62855e964d07c63617d5ac8c5b88a.mp3','继续','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1d6a0254f2564c2bb9ea811084f4db70','on (the, an) ...','141','[ɡəu ɔn]','','平均，按平均数计算','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c5639a52b1b1438d8b26430039fc78e1','give back','141','[ɡiv bæk]','http://res.iciba.com/resource/amp3/0/0/d5/38/d538fbd83e4531b493c4a268cafdc97e.mp3','归还；送回','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('41035bb921a2450bb3f1c65c399d8553','laugh at','141','[lɑ:f æt]','http://res.iciba.com/resource/amp3/0/0/1a/ec/1aecc42e226fb222c0f74ab686311d04.mp3','嘲笑','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('161f8bd6b26c42c39b8dcb36aab8c221','all kinds of','141','','http://res.iciba.com/resource/amp3/0/0/71/8c/718c0bf22971db0f7bbce83c4de05fbd.mp3','各种各样的','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('710e5cd7111e4513a765724da09f369c','look for','141','[luk fɔ:]','http://res.iciba.com/resource/amp3/0/0/80/95/8095d87fe84e9c5288bccd590976964e.mp3','寻找','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a97b982103e94e2cbb1f3d5b6ebc4f8e','go out','141','[ɡəu aut]','http://res.iciba.com/resource/amp3/0/0/f0/eb/f0ebc176acb87aaf3b7165173a057106.mp3','出去, 熄灭','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4db818c638aa407fba197886571f2de0','pay for','141','[pei fɔ:]','http://res.iciba.com/resource/amp3/0/0/d5/22/d52299dfff4ae51adc2f883011389cc0.mp3','付款','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e8ce45789e7940319f86692c01c4b4e0','so far','141','[səʊ fɑ:]','http://res.iciba.com/resource/amp3/0/0/49/6b/496b1a892afca979499eeb40a2f24c44.mp3','到目前为止','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('2f1ceb18dbea4928835b3341e9b7de25','help oneself ...','141','[help wʌnˈself tu:]','http://res.iciba.com/resource/amp3/0/0/31/50/3150c7faf8441558e5951429f2aa8522.mp3','请随便吃点','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('2f6060d879fd4eb28e5766b50e2a8a63','get up','141','[ɡet ʌp]','http://res.iciba.com/resource/amp3/0/0/c6/ec/c6ec1bb206e0f89e1798208abe061ae6.mp3','起床','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('be3141a9b54445748d75a1fbe9c79a6b','a great deal','141','[ə ɡreit di:l]','http://res-tts.iciba.com/7/b/5/7b5c6cf6aff9277d15c01c64d0d8a6ba.mp3','大量，许多','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('efd474570d1143ee85df7126a83e5079','no longer','141','','http://res.iciba.com/resource/amp3/0/0/29/2d/292dede7b52cc12cd7a666823620001a.mp3','不再','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3fe31aa22d10483ab7dda911d2afc700','keep doing st...','141','','','继续做某事','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('f647f668e9134d1aa25b9e67a9fcd0ea','put up with','141','[put ʌp wið]','http://res.iciba.com/resource/amp3/0/0/04/17/0417fdbdca7b77e693428fe35265711f.mp3','忍受','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d19f3e9bb11f4b4f96b7f9603ebf5040','on show','141','[ɔn ʃəu]','http://res.iciba.com/resource/amp3/0/0/33/be/33be8345a32226b7ffde4460c5d82c9b.mp3','展出，在上演（放映）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('dd7042d740a345f28661855921e6fa26','turn on','141','[tə:n ɔn]','http://res.iciba.com/resource/amp3/1/0/b1/97/b197375d9ebab835d23fd69d05cf3eb6.mp3','打开（水、电视、收音机、灯、煤气等）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('40fa020261674696b617b984bd6da676','on duty','141','[ɔn ˈdju:ti]','http://res.iciba.com/resource/amp3/0/0/bc/66/bc66bd161e10618607e147174d03e72f.mp3','值日，值班','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1db0d7db1be44b59a337dade6cecf278','hundreds of','141','','http://res-tts.iciba.com/4/b/d/4bde493da4b8ed0d05b9499392f62e4e.mp3','几百，成百上千','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('bb23ef003c444a22bd2d79f4f7a8a4de','right now','141','[rait nau]','http://res.iciba.com/resource/amp3/0/0/4b/c3/4bc3954b03f53c00f11a5d99e7263bd6.mp3','立即，马上','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d5347f933d7b4af891dcbd133cd24e24','work out','141','[wə:k aut]','http://res.iciba.com/resource/amp3/1/0/64/45/6445838221dd01d60743ccb8da88407e.mp3','算出，解决','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('cad9fe9cab7d48389b081a3dad6ea37f','in danger','141','[in ˈdeindʒə]','http://res.iciba.com/resource/amp3/0/0/00/21/002125b1a358b3ce4972376722d4e800.mp3','处在危险状态','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('63408d84181d4be8a49f68919fcc2749','go for a walk...','141','[ɡəu fɔ: ə wɔ:k]','http://res.iciba.com/resource/amp3/0/0/f8/f4/f8f47e27973f90f1f3068903a4e58b58.mp3','散步','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d5a799f6d3674323937bb38bc49744d9','sentence...to...','141','[ɡəu fɔ: ə wɔ:k]','','判处死刑','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('866d0af1963b41fe8f1626cc3914c1a2','save one''s li...','141','[ɡəu fɔ: ə wɔ:k]','','挽救某人生命','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('68470bf16630434c87ef005745502e1f','run away','141','[rʌn əˈwei]','http://res.iciba.com/resource/amp3/0/0/c9/7d/c97da3c65a68a1c8068f311b3752b3d1.mp3','逃跑, 失控','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('dbdd0d7bed2446f784d08245cd47c6fc','figure out','141','[ˈfiɡə aut]','http://res.iciba.com/resource/amp3/0/0/2d/76/2d7672dee811764e19ae620bd33e3d07.mp3','理解，想明白','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e0354ac59c8448f485e6b6b1b2759b8f','a little','141','[ə ˈlitl]','http://res-tts.iciba.com/2/2/5/225ca0b4604f639c163e0aa77dfd8b58.mp3','一点，少许','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('35e9010812254444a50921e99de48451','stop doing st...','141','','http://res-tts.iciba.com/a/f/d/afd12a2e57b73e35a4e2bfc3d44bc61d.mp3','停止做某事','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('423cd7c8071a4f7c8efbb8d78cf65864','go through','141','[ɡəu θru:]','http://res.iciba.com/resource/amp3/0/0/45/60/456032ca6aaecf560ef92adf5acc6ee2.mp3','浏览; 翻阅，通过','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('503b02219f7a462abf10d93c8ee08dd0','refer to','141','[riˈfə: tu:]','http://res.iciba.com/resource/amp3/0/0/d6/87/d6876c7aadc3629552b3db734c615db5.mp3','提到，涉及，有关','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1bb6fde300b642719926e1030803c978','make friends ...','141','','http://res.iciba.com/resource/amp3/0/0/93/f4/93f49508669d93663eccada08bd27e54.mp3','与……交朋友','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('0b398591346e4a3bbf44d6c5a7a32d81','connect to','141','[kəˈnekt tu:]','http://res-tts.iciba.com/0/7/4/074481cdbfb1b31384a05eff275e00bf.mp3','连接，相连','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5b2361a210d74cf8b82357c835ac1200','in time','141','[in taim]','http://res.iciba.com/resource/amp3/0/0/6d/6d/6d6d79c57c8e833a6b82a9bff8f7f736.mp3','及时，来得及','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('f373a1157784498287f0d7071c69d0a0','not only ... ...','141','','http://res.iciba.com/resource/amp3/0/0/b9/a8/b9a82c1c7c7e6b72a7e5c035406b5447.mp3','不仅…而且…','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('234b9f1a55b648b28b2a3f0177604fdd','bring in','141','[briŋ in]','http://res.iciba.com/resource/amp3/0/0/1c/f4/1cf447e6230970ae01f9fa844f4f69d9.mp3','引来，引进，吸收','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1d1a26e66b994b98b2e080a90ad2dcde','set out','141','[set aut]','http://res.iciba.com/resource/amp3/0/0/47/97/479742c1eb280b2bce596b8dc7eb9b13.mp3','出发; 开始','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('28d79a1468d841d287dbf355f82e9183','take up','141','[teik ʌp]','http://res.iciba.com/resource/amp3/0/0/90/70/90709b4878b07a9b6e669e3b53bbb1b2.mp3','占去，占据（时间、地位等）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('7971f50b15a24d64a954cfb82b15a0fa','ring up','141','[riŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/34/55/3455986d98f74c6e54d1b0c32db456cb.mp3','打电话给','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('824d4ab386194c5585fcfd632cd6b41a','after class','141','[ˈɑ:ftə klɑ:s]','http://res-tts.iciba.com/5/3/1/531cad3e444c6974610074d112e5bce9.mp3','课后','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('21c0255c6b304e7689ca40f25d38740f','take off','141','[teik ɔf]','http://res.iciba.com/resource/amp3/0/0/e5/4f/e54f0f6c95f9f9bd43ea0e266b0ef4ca.mp3','脱下，起飞','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('bfe951e9ce384342a44ce337b06fee24','day and night...','141','[dei ænd nait]','http://res-tts.iciba.com/f/1/b/f1bd884ad5b81c4c3238e0025054aa30.mp3','日日夜夜','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c01ff267c5244c98ba97da6d5a895173','fall asleep','141','[fɔ:l əˈsli:p]','http://res.iciba.com/resource/amp3/0/0/b3/8a/b38a2bc60138c2c7c9b6f4a240863d74.mp3','入睡','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d7b19cb1443242a5abd2bba01032d4da','after all','141','[ˈɑ:ftə ɔ:l]','http://res.iciba.com/resource/amp3/0/0/d9/bf/d9bf78346b9f609a594e5b7510e2dd0d.mp3','毕竟，终究','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1806762a90f34f4bbeec13813b1a72c3','hand in','141','[hænd in]','http://res.iciba.com/resource/amp3/0/0/04/bc/04bc3505649bdc0ce315aa8ac68ef86e.mp3','上交; 交纳','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('76e1ccb45ffc4365beac2424767b1642','hold one''s br...','141','','http://res.iciba.com/resource/amp3/0/0/0f/3d/0f3d1d3597485f323812a82fec67eabb.mp3','不出气,屏住呼吸','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('99bad25b6ab44897b6f68ec8a8f3adc1','get in','141','[ɡet in]','http://res.iciba.com/resource/amp3/0/0/ad/b2/adb2733c99aee6038538aba3b9672f6a.mp3','进入, 收获，达到','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('354cade9919e496a951783ba6642c941','fill in','141','[fil in]','http://res.iciba.com/resource/amp3/0/0/da/27/da2770eb7910e1dfae779adb454a45b2.mp3','填充','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('635e42a6cade49d59cf4518d7aec4b49','deal with','141','[di:l wið]','http://res.iciba.com/resource/amp3/1/0/1c/b4/1cb49697bf438bc903ff9704e950a633.mp3','处理，对付','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('887f8fb346d54542b302ce40aeea3df9','get on','141','[ɡet ɔn]','http://res.iciba.com/resource/amp3/0/0/fc/94/fc94b89254559d145986b854c7b2e2cb.mp3','上车；过活','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ba5bdcc88da0431d93777cd76db716d8','divide up','141','[diˈvaid ʌp]','http://res.iciba.com/resource/amp3/1/0/b2/7d/b27daf51715232c40113c69bfeee2247.mp3','分配','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6838aa22f9f94908b4f18ac29dbb8bf3','get down to','141','[ɡet daun tu:]','http://res.iciba.com/resource/amp3/0/0/d7/c3/d7c333a895962fe5b174e3e6038bf9b7.mp3','开始认真（做某事）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c6ded5db3ab943f0853118705c5dc889','carry off','141','[ˈkæri ɔf]','http://res.iciba.com/resource/amp3/0/0/ac/2c/ac2c398aabfd21a7b3754aefe665b8c4.mp3','携走，夺走','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('548698aeb4e242fb8ec89c1f9375e36c','pass by','141','[pɑ:s bai]','http://res.iciba.com/resource/amp3/0/0/02/21/02212fae7818e725863de3f14eaa94b6.mp3','经过','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d8cbb50aaa50499aa9e66309317f478f','have fun with...','141','','http://res-tts.iciba.com/a/7/f/a7fae4ff97dc602dc037af360c9fffcd.mp3','玩得高兴','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3d27c964a50b43f7b19f010b19ffe610','agree with sb...','141','','http://res-tts.iciba.com/5/4/c/54c2ca250447a763d8411b918bbfd949.mp3','同意某人的看法，与某人看法一致','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('0a0bc720092f4d0c9c21f90fcc561220','build up','141','[bild ʌp]','http://res.iciba.com/resource/amp3/0/0/50/e0/50e05d5cf0e374c7b7369326b957d16b.mp3','逐步建立','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ba42f4e754604883918c207c33b64816','break off','141','[breik ɔf]','http://res.iciba.com/resource/amp3/0/0/4e/21/4e21fe61899be58cb5cf1957b99a6bae.mp3','打断; 折断','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('7fa2b2cc59fa498aa0807ea0898bb42d','bring up','141','[briŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/58/77/5877f75c7f78669372e2159ddd6e85b5.mp3','教育，培养','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ef4bba11a7474813bbe3326e4200bd79','in order','141','[in ˈɔ:də]','http://res.iciba.com/resource/amp3/0/0/c6/55/c65530c55229fab2e3af0bc9fb1ed124.mp3','按顺序','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('667a8dfd85c44f189a0d851a2293f522','in other word...','141','','http://res.iciba.com/resource/amp3/0/0/78/0f/780f7b0f52d613efc5678a6a616eb4c7.mp3','换句话说','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('25f66346ff924fc6b9bca4d8948fbc0c','turn down','141','[tə:n daun]','http://res.iciba.com/resource/amp3/1/0/87/89/8789270b7a02a169d0a065e3ca03fdf8.mp3','关小，调低','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3b9458d7d52240feb1f16dbfbb460826','look down upo...','141','[luk daun əˈpɔn]','http://res.iciba.com/resource/amp3/0/0/97/5f/975f4d5381cf08d20f0eff8e9fcfb5b2.mp3','看不起，轻视','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3d264c91261a454da318c28b1c2df2bd','ought to','141','[ˈɔ:t tə]','http://res.iciba.com/resource/amp3/oxford/0/97/bb/97bb0d22013a0cd9bee66e42cf2de9dd.mp3','应该','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fffa67b638254e779659b800c9b1dcb1','stop to do st...','141','[ˈɔ:t tə]','','停下来做某事','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('96c89fe1d48a47a4ac525fa1a8e09b67','be proud of','141','[bi: praud ɔv]','http://res.iciba.com/resource/amp3/0/0/1e/90/1e90c729ad3c5fbf9b86fd69266ddde3.mp3','骄傲，自豪','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('53b54f0466724d71a84cf94a5b3b2744','come back','141','[kʌm bæk]','http://res.iciba.com/resource/amp3/0/0/1f/ce/1fce5629baaeaade48f614c18f10626b.mp3','回来，想起来','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ffac45f250f244979ea2c03a3198a177','have a good t...','141','[hæv ə ɡud taim]','http://res.iciba.com/resource/amp3/0/0/60/bc/60bc0718d1c81013812de7ea467ad975.mp3','玩得高兴，过得愉快','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e421c7b8ca814174b0d4d832e4225f7c','as if','141','[æz if]','http://res.iciba.com/resource/amp3/0/0/ad/32/ad3203e31be3977b9108254cdb7a07aa.mp3','好像，仿佛','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('465b2e689aca46d6a26f50b5373b916e','all in all','141','[ɔ:l in ɔ:l]','http://res.iciba.com/resource/amp3/0/0/55/53/5553f74713ecef912082b1189fbade16.mp3','总的来说，总计','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('86afcdd752e64d9d879097a3acf090ef','come on','141','[kʌm ɔn]','http://res.iciba.com/resource/amp3/0/0/b1/9b/b19b704a47b51ae9d8c3ef7101eb9a7e.mp3','来吧，赶快','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4f53baf651ce45fbb68048d66c1a719d','hurry up','141','[ˈhʌri ʌp]','http://res.iciba.com/resource/amp3/0/0/0f/45/0f45cf405da2bb03814883f28cfd4c8c.mp3','赶快，快点','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('369361c713984564b40cdf079ce1e8c8','go fishing','141','[ɡəu ˈfɪʃɪŋ]','http://res.iciba.com/resource/amp3/0/0/3b/43/3b4342f88a82a18e04c9ebbb27b7b6c7.mp3','（去）钓鱼','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('01155beda8de49f78a934af9f3806e4c','again and aga...','141','[əˈɡen ænd əˈɡen]','http://res.iciba.com/resource/amp3/0/0/51/52/5152ac16a2540d8a72fdb1e65107fbaa.mp3','反复地，再三地','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a6c02b5ff4ca40fb8a6bd27af447fd03','try out','141','[trai aut]','http://res.iciba.com/resource/amp3/1/0/f6/07/f607f2a5c3a82ce4f8dab4ae574486af.mp3','试验','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ef86a5ed973a4c6e957e077a41f31f40','talk about','141','[tɔ:k əˈbaut]','http://res.iciba.com/resource/amp3/0/0/b0/f9/b0f91942e580a96767c0ccca31c6de46.mp3','谈论，议论','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5639f5e95c4b4e768fd263da52c41f76','write to','141','[rait tu:]','http://res-tts.iciba.com/e/9/e/e9eb435a0792f6fed24b43cdd5662acf.mp3','写信给…','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('23e9db7d1b0b4bb28aea42749a2d3c69','come from','141','[kʌm frɔm]','http://res.iciba.com/resource/amp3/0/0/4c/89/4c89cd90affd70a24513f11161dc4167.mp3','出生（于），来自','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6cd91b93b8d745a69e0ebd3d8b52a4ff','come in','141','[kʌm in]','http://res.iciba.com/resource/amp3/0/0/e1/99/e199114d6fbbcb354e308561f3723f8e.mp3','进入，进来','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8dc8d4c69fbb4826abcd8790f2e42d03','in all','141','[in ɔ:l]','http://res.iciba.com/resource/amp3/0/0/66/90/6690b31d1f2a51d6e7f6c63dff94261f.mp3','总之','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6a3af85db9764a01b48cbfeaaf8d27fa','once more','141','[wʌns mɔ:]','http://res.iciba.com/resource/amp3/0/0/97/f8/97f880f250c33c3af41aa38d48f5a4ae.mp3','再一次','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('74969188f95844718f27d3b11a38b298','each other','141','[i:tʃ ˈʌðə(r]','http://res-tts.iciba.com/3/e/e/3eef9039b69cd989f551655ea2103dad.mp3','相互','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1f3e4f2cf2564bd891a038b114c7dfe1','send up','141','[send ʌp]','http://res.iciba.com/resource/amp3/0/0/2d/cf/2dcfaf5e68c86024cfbad070a58bf657.mp3','发出, 射出','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3bdfbe4737244887bd131791cba5196b','see...off','141','[send ʌp]','','为某人送行','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ecf6bdee66a641bca089fa355f6b7979','die out','141','[dai aut]','http://res.iciba.com/resource/amp3/1/0/db/b7/dbb7f99f26a1c5fc87097cb058531055.mp3','消失，灭亡','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('66d43448478641329110a3b8dddc594c','give up','141','[ɡiv ʌp]','http://res.iciba.com/resource/amp3/0/0/07/8d/078da1f9958e5856d6cdf0741d98c421.mp3','放?','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fb4f8a2317ff4236a82746f5472585c5','in fact','141','[in fækt]','http://res.iciba.com/resource/amp3/0/0/a6/de/a6deccdb95cbd779293edd17d3fe47ae.mp3','事实上，实际上','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c3c5d159cf7b47dba79e4b98ce8f3c4c','even if','141','[ˈi:vən if]','http://res-tts.iciba.com/d/f/9/df99d2ca8ccbc29caa6628f08dea0ce8.mp3','即使，尽管','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('cf13359837b34ff59be410a56851c0ba','take it easy','141','[teik it ˈi:zi]','http://res.iciba.com/resource/amp3/0/0/10/7e/107e07983e9f50df860abced64637438.mp3','别着急，别紧张','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ddcade711f8f488195b2e7054ef0e4d2','in debt','141','[in det]','http://res.iciba.com/resource/amp3/0/0/aa/5f/aa5f7c7715ffd6aeed32dd70634af2cb.mp3','欠债','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8169396c9510497ea94939be84d8c0e0','put on a perf...','141','[in det]','','演出','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('acb3136df4994bb299407b9bae4915b8','come up','141','[kʌm ʌp]','http://res.iciba.com/resource/amp3/0/0/a8/6a/a86a0d634f7bf63a521e986d3bab64f7.mp3','上来，上升，抬头','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fe4a430c595b4dcfb755fc8ce355a5ad','grow up','141','[ɡrəu ʌp]','http://res.iciba.com/resource/amp3/0/0/7a/c3/7ac361505e596dfc8932b526466ff882.mp3','长大成人，成长','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('51d31ee66efa455fa77f6d8796a122b0','get down','141','[ɡet daun]','http://res.iciba.com/resource/amp3/0/0/9d/9a/9d9a627954fbd2915b2c132c775af471.mp3','降下','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1f51d5c0297e40d5a4ea726dc92886a9','now and then','141','[nau ænd ðen]','http://res.iciba.com/resource/amp3/0/0/af/b3/afb348c8eae5841560b39a27bc1dafbe.mp3','不时，偶尔','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('280342635c024724a6f3a8a5e6911c7c','one after ano...','141','[wʌn ˈɑ:ftə əˈnʌðər]','http://res.iciba.com/resource/amp3/0/0/de/b6/deb6c001798c6b3f8a570a6fac6c8fcf.mp3','一个接一个','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e599ff456bb84f6981ded66a0d787d9e','hand out','141','[hænd aut]','http://res.iciba.com/resource/amp3/0/0/e8/fb/e8fb10760d6610fa2024e8d38e32a789.mp3','分发','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d92820eb495344768ccac5e01e319202','persuade sb. ...','141','[hænd aut]','','说服','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6079185d85ae4f9784b95af35544d81a','turn over','141','[tə:n ˈəuvə]','http://res.iciba.com/resource/amp3/1/0/08/63/0863e371d7ef2a18ebff815835f1d57a.mp3','翻动，犁翻（土地）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('acbcc9c3da5d4ec4a48f285ff975dff9','from... to','141','[tə:n ˈəuvə]','','从……到……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a722b41274c14d11a39cd48826310a01','try on','141','[trai ɔn]','http://res.iciba.com/resource/amp3/1/0/3c/6a/3c6ae4c14bdf6ec8fcaf8e9ccf83741d.mp3','试穿，试试看','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('69e7f11aaace445abd9ad110e2d33b00','keep back','141','[ki:p bæk]','http://res.iciba.com/resource/amp3/0/0/04/5f/045f55136e98eeb2347633494319e834.mp3','留下','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('aba0b2a317ea401c8de34e07af9419f4','rather than','141','','http://res.iciba.com/resource/amp3/0/0/13/3d/133d5a7c747b955dcb621ab1de6dadab.mp3','而不，非','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1878513ec73b44dd8cbedb22f58654e8','both...and','141','','http://res-tts.iciba.com/6/5/7/6575a8f2a8455b328a36fba21d798ea7.mp3','两个都，既…又…','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5bac2a7c6c764e91830a854e38aa2651','call in','141','[kɔ:l in]','http://res.iciba.com/resource/amp3/0/0/bf/d5/bfd58bacc1791ffdb1e8ce2fe7278a9b.mp3','召来，召集','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('bc78278e1bdb4442ad1bfda6554ee212','in front of','141','[in frʌnt ɔv]','http://res.iciba.com/resource/amp3/0/0/29/17/2917f8743e8dd4d36ae50a74526d28de.mp3','在……前面','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('42b07001ab574177a1fb45722682670e','take away','141','[teik əˈwei]','http://res.iciba.com/resource/amp3/0/0/6f/63/6f6367d451aa380d8842523467d11a41.mp3','拿走','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b5f6ffdbf5d24b3184ed04232b651b3c','as usual','141','[æz ˈju:ʒuəl]','http://res.iciba.com/resource/amp3/0/0/65/3e/653ee6d5b0670423d7e06481e52ac751.mp3','通常，平常地','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d04ac10a4216481f98b2367231e1a7ee','open up','141','[ˈəupən ʌp]','http://res.iciba.com/resource/amp3/0/0/0b/59/0b5932c3721f47c6feefcf767b06b64e.mp3','开启；开创; 开辟','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('db2177f1360a4a4cb4014f4d73757efd','out of order','141','[aut ɔv ˈɔ:də]','http://res.iciba.com/resource/amp3/0/0/17/35/17356f966aa42919007009984bb87132.mp3','运转不正常，出毛病','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fc02316129584afabd2b11918fbaadaa','a number of','141','[ə ˈnʌmbə ɔv]','http://res-tts.iciba.com/5/f/9/5f95a07c8848241cfe5076ac69477212.mp3','一些，许多','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('0f1259a34ae6466f91f64a8b34979b6f','the day after...','141','','http://res.iciba.com/resource/amp3/0/0/70/8c/708cceace22e3cde6e69a9304a6b79c4.mp3','后天','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d8c710fa462e466ca7e7af374a01dc6a','make up one''s...','141','','http://res.iciba.com/resource/amp3/0/0/ce/46/ce46d880a6977b195d5adb40dc2dfbc5.mp3','下决心','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('261e9e153b14475ca26df5f2e096a8a2','the more...th...','141','','http://res-tts.iciba.com/6/f/3/6f36811f428e54535b679f4377cc313a.mp3','越…就越…','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('009c4acb00af45d59691f080192190bb','from time to ...','141','[frɔm taim tu: taim]','http://res.iciba.com/resource/amp3/0/0/c2/ad/c2ad5f6f255616748a0310496d576e8b.mp3','不时，偶尔','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('df61360f09fb4434ae05bf9810a1935c','just now','141','[dʒʌst nau]','http://res.iciba.com/resource/amp3/0/0/26/54/2654992d78afbd40bad349302a6f2b6a.mp3','现在，刚才','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('867cc2d35b5f4ed296854fa00fa377a9','millions of','141','','http://res-tts.iciba.com/6/d/f/6dfe0e2013068722b91822a1a474efb1.mp3','成百万上千万，数以百万计','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a1763959aacf4ab699c2402159239803','for example','141','[fɔ: iɡˈzɑ:mpl]','http://res.iciba.com/resource/amp3/0/0/02/3d/023dbce5e060641d09218027704ca4b3.mp3','例如','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('0fb76a77c3554f8c941b1cb100df4712','wait for','141','[weit fɔ:]','http://res-tts.iciba.com/e/3/5/e35031efc5cf102eb14d71f301faa475.mp3','等候，等待','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c881e4e9c55f41b586f60dbf516067af','thousands of','141','','http://res-tts.iciba.com/1/f/7/1f741dd5c3c6458071193f208c895e6d.mp3','成千上万，几千','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('29262d0e77b34d9aacf27407a922049c','worry about','141','[ˈwʌri əˈbaut]','http://res-tts.iciba.com/5/f/e/5fe5dd576111fd6e5e18c3d10bcef64c.mp3','担心，烦恼','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1fbbec4b8ff64701a7c77335d226577b','a great many','141','[ə ɡreit ˈmeni]','http://res-tts.iciba.com/1/5/c/15cfccb6d4ed6c872ce70d6329de4cd5.mp3','大量，许多','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fe84e6e0cab14fdbb4ead492060b2b17','wrap up','141','[ræp ʌp]','http://res.iciba.com/resource/amp3/1/0/e5/94/e594ba35385531b78c8252893dd915d9.mp3','包好, 伪装','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('043fb44134f347368a68a4a1bd27c334','take out','141','[teik aut]','http://res.iciba.com/resource/amp3/0/0/6d/60/6d60b5b90711ac3669744f550314d52d.mp3','取出','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4346266ac1ae4eb7b4546c0833e03c48','according to','141','','http://res-tts.iciba.com/4/4/0/440a3bbc91716125aef7de35fc6e49ae.mp3','根据，按照','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('03ed0f8b7e5f4ce4b6ec4234cf6c422e','by day','141','[bai dei]','http://res.iciba.com/resource/amp3/0/0/d7/10/d7106bda7e75a8ab4dfd96fcb56fb2b6.mp3','日间，在白天','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b524d172cdf74db8831157a9d48ecbd8','let in','141','[let in]','http://res.iciba.com/resource/amp3/0/0/00/a6/00a6ff3dfbd23c1d8c3bafc3aa38e11a.mp3','让……进来，放进','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('534ba5cf76554f188827a0b6f94638b8','the other day...','141','[ðə ˈʌðə(r dei]','http://res.iciba.com/resource/amp3/0/0/64/e9/64e9f2bda171874aee42b8e8fe57659d.mp3','前几天，某日','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('92f8eb5ca6c14653b0343547994b0711','join up','141','[dʒɔin ʌp]','http://res.iciba.com/resource/amp3/0/0/14/2b/142bd51fd91e810c5bc5b2e242a084be.mp3','联合起来，联结起来','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('569c8ccfacdf4fe780b30eaa801b7ad2','compare with','141','[kəmˈpɛə wið]','http://res.iciba.com/resource/amp3/0/0/0e/06/0e062bf7d1366cf048b96b419614a399.mp3','与……相比','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('668b95dfb1b14ef5b2dcf3e7d0f37714','go ahead','141','[ɡəu əˈhed]','http://res.iciba.com/resource/amp3/0/0/86/7b/867b716ecfc8971b436fbf52f1961a2e.mp3','走在前面，领先；干吧，干下去','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('89e4ac2a79a145f0b6257fa5171ef63e','in surprise','141','[in səˈpraiz]','http://res.iciba.com/resource/amp3/0/0/7d/5c/7d5c332b18f2d6baca2fa1d090874d97.mp3','吃惊，惊讶','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('06a947cf80e044ecae4697a2ac497842','too...to','141','','http://res-tts.iciba.com/6/4/a/64a2e60ba8cfabb347b75b38644c7540.mp3','太……以至于不……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('26401faebf524846a3c0965988e2a306','care for','141','[kɛə fɔ:]','http://res.iciba.com/resource/amp3/0/0/11/96/11961689f25c32f0dfffb0aa75e3247a.mp3','喜欢；照顾（病人）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('cf84aa96df184b919bf26002694d79c7','put up','141','[put ʌp]','http://res.iciba.com/resource/amp3/0/0/23/cd/23cd8397e107fc963fb05fefd703a92b.mp3','挂起，举起, 贴（广告等）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ca6b3ea79c604dd7a83e871aab55d561','hold out','141','[həuld aut]','http://res.iciba.com/resource/amp3/0/0/93/4f/934ff94692ff719304400953146259bb.mp3','伸出；坚持，维持','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ee34d8d62ec14cd1b1af32e60a1e9141','do one''s best...','141','','http://res.iciba.com/resource/amp3/0/0/86/d8/86d814dba6bed684dc03b57f07fe6a10.mp3','尽最大的努力','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('91530117baeb43539a7ac9c8f27a0818','check in','141','[tʃek in]','http://res.iciba.com/resource/amp3/0/0/cf/94/cf94356230791d87b214dfe333d6a1ef.mp3','报到，登记','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5f90c68c8fce4e30bba57d3f45aa9a68','as long as','141','[æz lɔŋ æz]','http://res.iciba.com/resource/amp3/0/0/a7/e1/a7e1918270b582b7707d5003f2fceee6.mp3','只要','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e0e4f9211e8a4906a49d2d0967c01c3f','as soon as','141','[æz su:n æz]','http://res.iciba.com/resource/amp3/0/0/24/f1/24f13ed38651c85860749d97dfe308e8.mp3','一……就……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('bcabfd6897cf425494341cb35a6e3e43','from now on','141','[frɔm nau ɔn]','http://res.iciba.com/resource/amp3/0/0/fa/ad/faad5ad56b8c73bce5eaebf02142edf5.mp3','从今以后，今后','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('17be11f65a8b4a62bc7be4733fea5da0','sooner or lat...','141','[ˈsu:nə ɔ: ˈleitə]','http://res-tts.iciba.com/a/0/c/a0c95377df42ebdde1d92e75882c9f45.mp3','迟早，早晚','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3eeec269c51d4d9e92e8dac6dd4aff8d','so long as','141','[səʊ lɔŋ æz]','http://res.iciba.com/resource/amp3/0/0/f4/67/f467d6a633756249c727674c59bfee3c.mp3','只要','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a800a655c9934e6e9f8264b94db88938','as a result','141','[æz ə riˈzʌlt]','http://res.iciba.com/resource/amp3/0/0/a8/af/a8af6a2a396546732e6a8f2f80ee9662.mp3','（作为）结果','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4d446065779f42a48dcc53a7755be86f','carry on','141','[ˈkæri ɔn]','http://res.iciba.com/resource/amp3/0/0/4a/0e/4a0e02c055688cce77335f7f2c41e58b.mp3','继续下去; 继续开展','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3ccb0bd82ef04cbabd860098c111aff0','next to','141','[nekst tu:]','http://res.iciba.com/resource/amp3/0/0/c9/e2/c9e244f799835714073e72b1921a8704.mp3','紧接着，相邻，次于','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4cf0e89ac53e48b0bc8b76d590277b3e','break away fr...','141','[breik əˈwei frɔm]','http://res-tts.iciba.com/f/d/6/fd66575b05175e2ad2102658ebda931e.mp3','脱离……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6b4b7364d1464807a0e7f32ca3e227fd','break in','141','[breik in]','http://res.iciba.com/resource/amp3/0/0/0e/24/0e24b1d22f59c9440ea7133eed842750.mp3','闯入，强行进入，插嘴，打断','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('dc2c30e766f942fa83e333137be98254','fill ... with...','141','[breik in]','','用……填充','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5ab69ff14e56447cb22f9f4be105d306','from then on','141','[frɔm ðen ɔn]','http://res.iciba.com/resource/amp3/0/0/eb/9f/eb9fd3016d12557bdca4e2e199a61499.mp3','从那时起','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9fa1bf3fba7a4567a72a28aebe5ef0f6','regard... as','141','[frɔm ðen ɔn]','','把……看作','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e3a6f5c85c994c74bc8acfdf543ec00a','face to face','141','[feis tu: feis]','http://res.iciba.com/resource/amp3/0/0/d3/88/d388edf5afa5fd99c68be208c8595cfa.mp3','面对面','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9899af77b96a4bcf9b493e1c61d5ee84','not so...as','141','[feis tu: feis]','','不像，不如','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('647d28a5e8a6476e817760bf4509b4fa','come up with','141','[kʌm ʌp wið]','http://res.iciba.com/resource/amp3/0/0/b0/59/b059a9afa191519f6bf63bd3c4669fa8.mp3','追上，赶上；想出（主意）；找出（答案） ...','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a30427d037f3493fbe2cc4137de328f4','put off','141','[put ɔf]','http://res.iciba.com/resource/amp3/0/0/44/ad/44adabc905dfefc327bc915f31262499.mp3','推迟','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('67ad7b5544e64b27b67ecf221ee27ce7','help...out','141','[put ɔf]','','帮助某人解决困难','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('975e0e809d934ff4ab8b6c166a770f01','hear from','141','[hiə frɔm]','http://res.iciba.com/resource/amp3/0/0/60/cb/60cb29239d2a7de5159605c75ae38c25.mp3','收到……的来信','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('35955d9f1056445caa19027b31131796','even though','141','[ˈi:vən ðəu]','http://res-tts.iciba.com/e/5/8/e5866395d694695aa637d925e97ffb5a.mp3','即使，尽管','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('79f0d4f6e02949d1953e527eac0b5984','by air','141','[bai eə(r)]','http://res.iciba.com/resource/amp3/0/0/49/a9/49a98b981d2e5dab9b9b7d4158256c01.mp3','乘飞机','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d36dfe1229f44cd9ac12dc41baf5d6dd','get back','141','[ɡet bæk]','http://res.iciba.com/resource/amp3/0/0/84/57/84578ce6cf9960f8e409f4911fe947da.mp3','返回; 回来; 回家','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4cf5293851064600a4eefa56e8a49e07','change into','141','[tʃeindʒ ˈɪntuː]','http://res.iciba.com/resource/amp3/0/0/27/05/2705ca40b2ea0e391db7131182b8cfed.mp3','转换成，把…变成','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('21590ec2d9bb4cecbc4045b72ead0341','due to','141','[dju: tu:]','http://res-tts.iciba.com/5/2/2/52240cd4b527c97395eacc1291cb9c26.mp3','由于，因为','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b656468fab5d47889e37f19256dd7b18','take the plac...','141','[teik ðə pleis ɔv]','http://res.iciba.com/resource/amp3/0/0/26/e6/26e6f1953748ad7993bec2742e995964.mp3','取代，代替','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fc8c9a6bb26545eb8b159a277f37a214','put down','141','[put daun]','http://res.iciba.com/resource/amp3/0/0/e4/c5/e4c5be348abc4b35771019e2bffbccbc.mp3','记下','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('00e1b03a68964d61bb4eed00cfcba1b6','turn up','141','[tə:n ʌp]','http://res.iciba.com/resource/amp3/1/0/05/52/05527875cf4aae455370251f7c802001.mp3','到达，来到；开大（声音）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b018c3c71128433fa9a8631bdaa93d0d','go for','141','[ɡəu fɔ:]','http://res.iciba.com/resource/amp3/0/0/93/87/9387151f8677a651ad0d6fb40111837f.mp3','主张','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('17f634ef362544f9849a55e39ea1a225','in public','141','[in ˈpʌblik]','http://res.iciba.com/resource/amp3/0/0/09/26/0926b816624b02dc24677af90e917e90.mp3','当众；公开','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('185c0f9fb87a4ebb993f993a133df4e0','come down','141','[kʌm daun]','http://res.iciba.com/resource/amp3/0/0/85/6e/856eb24f8deb24806b0e0347313eba1b.mp3','落，下来','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5c49be9996d44960b5c0b5a271e6836a','pay back','141','[pei bæk]','http://res.iciba.com/resource/amp3/0/0/a1/56/a1563907f99b050a167186f34885fe6e.mp3','偿还（借款等）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('83f8c83160f443bfbe2dc3e34d50a6a5','more or less','141','[mɔ: ɔ: les]','http://res.iciba.com/resource/amp3/0/0/41/dd/41dd4bb13058a0040c57baae65050137.mp3','或多或少','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fe74d14f245d4ac8acffafb29e0a6499','a kind of','141','[ə kaind ɔv]','http://res-tts.iciba.com/5/e/e/5ee16c6f899d372bb3a5d800f2a8e0c9.mp3','一种，一类','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4390c54a550a4c34897a257e56b26f91','pay attention...','141','[pei əˈtenʃən tu:]','http://res.iciba.com/resource/amp3/0/0/31/5b/315b8d3e829b92b88756600b865fabcf.mp3','注意','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1fbcd9792e5e41349f27c72dc12f66ff','different fro...','141','[ˈdifərənt frɔm]','http://res-tts.iciba.com/6/5/4/65439ed619063e1287aa60b756c9eaf3.mp3','与……不同','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a9fc69f275f141ab8ce6350556ff9be7','knock at','141','[nɔk æt]','http://res-tts.iciba.com/c/3/b/c3bf14aa5630ab67a282cd597862c8ef.mp3','敲','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ce4e3f28ddc04dba8c22f0601a45d448','in order to','141','[in ˈɔ:də tu:]','http://res.iciba.com/resource/amp3/0/0/a3/13/a3138ab4fdbfb1e7a02598d3b004dcc3.mp3','为了','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('60a7ecf199514b1fb6381aa1d4a76b0c','all right','141','[ɔ:l rait]','http://res.iciba.com/resource/amp3/0/0/67/78/67787c5a3a7b3a7cea96d77aa1f6d338.mp3','行,好吧，（病）好了','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3d4a6daa1e904324b384473ca4d3caab','pick up','141','[pik ʌp]','http://res.iciba.com/resource/amp3/0/0/e3/cf/e3cf48bb1f3593ae49166794aded6d73.mp3','拾起，捡起, 接收；开车去接……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('444ab4382fd5490cbfe0e14ca77cbfcc','set up settle...','141','','','建立创立 定居，平静下来','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6afaaf8390034a67bd18c351a26f6314','come out','141','[kʌm aut]','http://res.iciba.com/resource/amp3/0/0/3f/1b/3f1bd609c8d6081876afedfe0e952b3a.mp3','出来,(书)出版，发行','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('af0d326825cf4c05bd70c0be7f85be8a','a piece of','141','[ə pi:s ɔv]','http://res-tts.iciba.com/7/a/c/7acb053eaebfd283d43b5b1d08613e8d.mp3','一块(张，根，片)','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('00a8bbf24b6a4d47b62d490f5063fa6a','talk of','141','[tɔ:k ɔv]','http://res-tts.iciba.com/0/a/a/0aaeea5185c4918f18c270f42f62fe84.mp3','谈论，议论','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d1511cb5cac641cba8eb4be3a23ed29f','divide...into...','141','','http://res-tts.iciba.com/f/0/b/f0bc6839bcf9dda4682bd03294b5bac7.mp3','把……分成……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4ab6fcfbe7694afea93589af4ee41b77','agree to do s...','141','','','同意做某事','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('2fcf40661f9c48b18ac99581f7e902bf','a pair of','141','[ə pɛə ɔv]','http://res-tts.iciba.com/1/a/4/1a4e0b4d7f0550f20c8551c339e84694.mp3','一双，一副','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('24a8a197e5f54c1b8b4302fc731dbd8a','find out','141','[faind aut]','http://res.iciba.com/resource/amp3/0/0/5a/d2/5ad2c5b490a54c67c04e0f5b9780a35f.mp3','查明，发现，了解','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d1eb729423e1428cadf5db70ab0c41d0','knock into sb...','141','','','撞上','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b3254a82f6dc4bfb84b8e150fa79909c','give in','141','[ɡiv in]','http://res.iciba.com/resource/amp3/0/0/50/65/506577a183061a715d54a6ce4307ad36.mp3','屈服，让步','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('13ba685bb605401babdd51c5f7fb2e1e','by accident','141','[bai ˈæksidənt]','http://res.iciba.com/resource/amp3/0/0/e4/f1/e4f13d1238b751c94c365b611bc5af53.mp3','偶然','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ca7b31e340e14d15b939ada07401fffa','bring on','141','[briŋ ɔn]','http://res.iciba.com/resource/amp3/0/0/41/52/4152ff948163297b0bfc9c385c8f2c1f.mp3','引起，导致，使前进','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e58326f5537a4dda9f48af79b86f427c','have to','141','[ˈhæv tə]','http://res.iciba.com/resource/amp3/oxford/0/5c/7f/5c7f422788b4b656a9b487eb387d8ed0.mp3','不得不；必须','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9817024630d84a63bb4f35b7d1ca4778','a few','141','[ə fju:]','http://res-tts.iciba.com/d/3/2/d32356ae23a439134548ebfa140807d0.mp3','一些，少量','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c4e51014c89a4946900127dbeacf5b5c','on time','141','[ɔn taim]','http://res.iciba.com/resource/amp3/0/0/f8/62/f862d2178ec3e62f06ca531fcdfb5abf.mp3','准时','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('eba8a551016c4172af170fa159451803','go over','141','[ɡəu ˈəuvə]','http://res.iciba.com/resource/amp3/0/0/4d/ea/4deabe70a30da612c00f421964c15ca4.mp3','仔细检查，复习','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('082053e7ea85413ea28b3e6afc944bca','keep up','141','[ki:p ʌp]','http://res.iciba.com/resource/amp3/0/0/ea/80/ea8021151b3ead7b373e4d21970e8c4a.mp3','保持; 维持; 继续','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('241183a0624e4692b1603ad124ef27a3','a lot of','141','[ə lɔt ɔv]','http://res-tts.iciba.com/6/3/a/63af6f4b77006e73ac28fdfac900cb4c.mp3','许多，大量','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('241a0bb6085844818146d3c51149070f','prevent ... f...','141','[ə lɔt ɔv]','','妨碍,,防止,,预防','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b3a2b6fc987e43ffa7c06dbe519f05b4','add up to','141','[æd ʌp tu:]','http://res.iciba.com/resource/amp3/0/0/d8/72/d8721479e748ca3e2e13ac994909c339.mp3','合计达……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5771950275594c2e8125d643b417bad0','get through','141','[ɡet θru:]','http://res.iciba.com/resource/amp3/0/0/36/7a/367ac5fe6beadc1db90aac6dc9fa3f84.mp3','通过，拨通（电话）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c82b1126d1dc48d59c74ac1574207618','put on','141','[put ɔn]','http://res.iciba.com/resource/amp3/0/0/eb/d3/ebd3e097113faefd1925035941e048f0.mp3','穿，戴上，上演','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('0f8a87dfbb51430eb2cdb7bd4cd20cbb','out of work','141','[aut ɔv wə:k]','http://res.iciba.com/resource/amp3/0/0/c3/c2/c3c2d8a855e45f490928e17d0e8065c6.mp3','失业','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e3275802406b494bbb663e7759d10c6a','such as','141','[sʌtʃ æz]','http://res.iciba.com/resource/amp3/0/0/0b/be/0bbe6fca13f94373a18a92d9d72eaa1e.mp3','例如','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('39948a147c49422690d2246c71979897','live on','141','[liv ɔn]','http://res.iciba.com/resource/amp3/0/0/93/24/93242002069b2adf658ee1d716b3a0a1.mp3','以…为主食，靠…为生','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1e97e78721834d31b0f2d610abda64aa','used to sth.','141','','','习惯于','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('f12625ae61b34f25ab9193ac6ccb4281','take sb. in t...','141','','','搂抱','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('89cda457f3dc40199788fa965ab7ebe0','have a gift f...','141','[hæv ə ɡift fɔ:]','http://res.iciba.com/resource/amp3/0/0/8c/93/8c931faaf34907e63671692a8ef1949c.mp3','对……有天赋','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1a609299a6df4d498825df55a0ff7191','connect with','141','[kəˈnekt wið]','http://res.iciba.com/resource/amp3/0/0/cf/49/cf498faab75ee066b07a546cbaf34aa6.mp3','与……相连','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('20cb0a40d6d84fab8b1a3824229b9ecd','hold up','141','[həuld ʌp]','http://res.iciba.com/resource/amp3/0/0/d9/29/d929c03cb73b773897e1be72d46241fa.mp3','阻挡，使停顿','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b2faa1041dd8414581f7e909fb0ad637','so...that','141','','http://res-tts.iciba.com/7/3/8/738a74d88fcad66a03e90cc106179e82.mp3','太……以至于……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('7a0391926d834687ad71da7b70c3f3a5','run out of','141','[rʌn aut ɔv]','http://res.iciba.com/resource/amp3/0/0/22/de/22de1402f5c516aa56a7b4b03d967d56.mp3','用完','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('433407c648d24e0db301e7fd2d916565','once again','141','[wʌns əˈɡen]','http://res.iciba.com/resource/amp3/0/0/d8/53/d8531b3941d19ac2fe920c503d3d3d4e.mp3','再一次','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1dc01a8136c14cc4a4d15fdca1e3eb6b','over and over...','141','','http://res.iciba.com/resource/amp3/0/0/e0/21/e021c7e63887ff4bf77a827929fe7589.mp3','反复，多次重复','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('7f3cf874521b4019b97c1c48fd080ac5','have classes','141','','','上课','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('f7e04b251dc441acb49a5eb458595719','point to','141','[pɔint tu:]','http://res.iciba.com/resource/amp3/0/0/99/a1/99a1815243a7c4d9f534c9ed7f0a1634.mp3','指向','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('f1237a7c83da4da49ef3a0f151631a92','as...as','141','','http://res-tts.iciba.com/8/5/d/85d1b82309997b057945da1916bfdbad.mp3','像，如同','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('52ea8ea1ba6249aa8888233bd3ea41b5','do some clean...','141','','','做扫除（买东西）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('98ecfb4a5c8e463fb4b9fdb4dd521cfd','come off','141','[kʌm ɔf]','http://res.iciba.com/resource/amp3/0/0/73/de/73de03fccc931d0c805cc1f80b4da222.mp3','从…离开，脱落','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('eaf9827b46874b3eaf226f93003e9fa2','struggle agai...','141','[ˈstrʌɡl əˈɡenst]','http://res-tts.iciba.com/7/8/b/78b6da010d48b46c7ad344d7a214f226.mp3','同……作斗争','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8fbd0e26f44d4fa9b913207c44588592','look out','141','[luk aut]','http://res.iciba.com/resource/amp3/0/0/fc/22/fc221f09a3353c9ff905d5cae86f4a0a.mp3','留神，当心','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9aa55a2a114e48c491cdc75f5eac84bb','call for','141','[kɔ:l fɔ:]','http://res.iciba.com/resource/amp3/0/0/88/bd/88bd4d0ec2ebb751d1f6b2891891aa1f.mp3','提倡，号召, 需要','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('2925af04cfd04be5ac7c03e67a744509','out of breath...','141','[aut ɔv breθ]','http://res.iciba.com/resource/amp3/0/0/39/93/3993f0a15439f30c62fbe29ee8ab336f.mp3','上气不接下气','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8046381af9c04361b80d60460612a9b0','ahead of','141','[əˈhed ɔv]','http://res.iciba.com/resource/amp3/0/0/97/92/9792c3e1358b1040a5152a28f54bc3eb.mp3','在……之前','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('46d97e84ac4243b18831cd44b5d19bba','all the best','141','[ɔ:l ðə best]','http://res.iciba.com/resource/amp3/0/0/39/f8/39f8775a67429e4476fd9339431472dc.mp3','一切顺利，万事如意','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('84d002258e614c8e96ba5667b3c79f37','sell out','141','[sel aut]','http://res.iciba.com/resource/amp3/0/0/f7/91/f7913e55dedd60cb934feb79eadda8b6.mp3','卖完, 出卖','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('2510a6b1cb1b47a0bf548a88460752d1','by the way','141','[bai ðə wei]','http://res.iciba.com/resource/amp3/0/0/ca/d9/cad97f3383c232b08a510ea0fdf75750.mp3','顺便说','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('76ea6a01d3514f9fbbeceb2728bb7f35','look through','141','[luk θru:]','http://res.iciba.com/resource/amp3/0/0/54/0f/540f7b46d806304b8c4f9cdf3ba2ac82.mp3','看穿, 浏览','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ef306072a52f4790b514ee7cae9d55d0','far from','141','[fɑ: frɔm]','http://res.iciba.com/resource/amp3/0/0/b9/ad/b9ad79d9bbb99dc4e851d00328bf783e.mp3','远离','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8f15ebb28f3943c6a83d2d15fbf75a7e','as though','141','[æz ðəu]','http://res.iciba.com/resource/amp3/0/0/2f/af/2faf0cbe7df7b94dcce70a1ffa24ae58.mp3','好像，仿佛','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4bdbdff511204e569d4b22bf60f565a5','side by side','141','[said bai said]','http://res.iciba.com/resource/amp3/0/0/41/15/41159e627c3a65cf4a9aeba8b762e6d0.mp3','肩并肩，一起','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c78f00bdca09401b90974d5ad4988fec','help sb. with...','141','','http://res-tts.iciba.com/8/f/3/8f3af8889abadb6891993031a0e760fd.mp3','帮助某人做某事','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9d2272d3f72b4049bb798dd219d384b5','far away','141','[fɑ: əˈwei]','http://res.iciba.com/resource/amp3/0/0/65/f2/65f2aa14acc55b118fd0bc08cc1b7459.mp3','遥远的','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('be1e16fd4ac043ca9571d28495f812a4','point out','141','[pɔint aut]','http://res.iciba.com/resource/amp3/0/0/5a/24/5a241a357f672a0a8728d94e25b67d96.mp3','指出','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c7a5d4b800104c26a5a2a5c6c539a7c5','go off','141','[ɡəu ɔf]','http://res.iciba.com/resource/amp3/0/0/ac/71/ac7111fb2708b55432a8f06f79ee38c2.mp3','走开','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('029fbdd62d44485b9a1ff25a370bb801','take place','141','[teik pleis]','http://res.iciba.com/resource/amp3/0/0/a4/08/a408ac81cfbc1ed758a18b36a3e725e6.mp3','发生','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('58f909c25eff4bcab93dd7833eafb3b8','wake up','141','[weik ʌp]','http://res.iciba.com/resource/amp3/1/0/4e/60/4e604e908ec2a7de01330cccef6aebf1.mp3','醒来','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('06c0759da52342ba8ebb77d3cbc29ede','set off','141','[set ɔf]','http://res.iciba.com/resource/amp3/0/0/fa/3d/fa3d30cea53d70ad4a1445c2b2dfc4dd.mp3','动身，起程；使爆发','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('de7e7d82dd22443287bc370443e00c9c','cut down','141','[kʌt daun]','http://res.iciba.com/resource/amp3/1/0/18/22/1822414142adf64fe1cec4969b8bf7d2.mp3','砍倒','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('bb13551404ab44e8a7a0462fbe0ea464','give away','141','[ɡiv əˈwei]','http://res.iciba.com/resource/amp3/0/0/34/fe/34fe2733c679d1bf71aafe2d028109e3.mp3','分发','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('2fece7a8212d45788942b94ecbd875a6','lots of','141','','http://res-tts.iciba.com/f/2/3/f23ab6c89fc92b69431c6e0bd83449b8.mp3','许多，大量','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('78f2f4e1cb074af5b8ddc12c177f48d4','ever since','141','[ˈevə sins]','http://res-tts.iciba.com/7/6/4/7646a57320ea0fc383cce850644da8fd.mp3','自那时起直到现在','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('baad4cc45c0e4e15a1cae0cc9eca993a','break out','141','[breik aut]','http://res.iciba.com/resource/amp3/0/0/48/f0/48f03593b0812e6c3d5f20e2d45b9af9.mp3','（战争、火灾等）突然发生，爆发','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6958a981757d4effbf84f87dcde82b10','a bit (of)','141','[breik aut]','','有一点，一会儿','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3ca1d6c40db543e89c70784e8378fa38','no doubt','141','','http://res.iciba.com/resource/amp3/0/0/7d/c8/7dc82bcd2b458b0a9fca5528c6672d60.mp3','无疑地','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('43a4e1f526e74cfc8d575cc8b77060a9','throw away','141','[θrəu əˈwei]','http://res.iciba.com/resource/amp3/1/0/47/07/4707cd69d39a4acad59aef79a15775ae.mp3','扔掉','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1b10a1bba1d241b8ab0b78ce9bbe74c9','have got to','141','[hæv gɔt tu:]','http://res-tts.iciba.com/1/b/0/1b0b026d163c8a18e889e73fbdeac5ff.mp3','不得不；必须','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b4bf6d7e94794a1da7927e9b7d078cb5','either...or','141','','http://res-tts.iciba.com/3/7/8/378fb3e0b8de2103b19be40aaca6c218.mp3','或者……或者……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b0d8dc84c2c44824b6908e9adf4540ad','give out','141','[ɡiv aut]','http://res.iciba.com/resource/amp3/0/0/2d/6e/2d6ea4238eebbb080e08da91499301cc.mp3','分发','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('50acd2b5a13948a6a903605acd83e2c3','the day befor...','141','','http://res.iciba.com/resource/amp3/0/0/86/62/8662dbb265603f8b9efaf78b93b1d088.mp3','前天','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d258044bf84047f38e5af973f873210b','not until','141','[nɔt ənˈtil]','http://res-tts.iciba.com/0/b/6/0b6acf926ae27ff3ab89575078d90700.mp3','直到……才','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('56f88d73efaa41dab184c3c93ac73a2d','make up','141','[meik ʌp]','http://res.iciba.com/resource/amp3/0/0/2e/9d/2e9d335be8c5d384ed7b6df0a31c9696.mp3','和解，化装','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e5e31f1471cd4b6689409353d15efd25','belong to','141','[biˈlɔŋ tu:]','http://res.iciba.com/resource/amp3/0/0/6d/e6/6de67cdcae9555b3e7908d4bd29290bd.mp3','属于','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6b500990b55343d6a7c0e8035450348e','hang on','141','[hæŋ ɔn]','http://res.iciba.com/resource/amp3/0/0/20/df/20df2fb162ce67d279eb0ecef66ae6a3.mp3','（打电话时）不挂断，等待片刻','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('de98d321905e406ba865345eaa4fe1a9','of course','141','[ɔv kɔː(r)s]','http://res.iciba.com/resource/amp3/0/0/0c/a9/0ca964bb74251fce6bb741c97e1cb4b8.mp3','当然','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4ffc5390e6e34804bbdb2eadc1c7cc79','catch up with...','141','[kætʃ ʌp wið]','http://res.iciba.com/resource/amp3/0/0/ae/6d/ae6d4336f407e7c76e9884e62e3b60bf.mp3','赶上（或超过）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9496e27ce0d247869cd2cf31257fe918','set free','141','[set fri:]','http://res.iciba.com/resource/amp3/0/0/68/f1/68f16fcf7b18ef04b552377b0abb4f9b.mp3','释放，解放','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c4921709bb99434496248fefe4fd71d7','answer for','141','[ˈɑ:nsə fɔ:]','http://res.iciba.com/resource/amp3/0/0/44/43/444320f7d80371a413041df96e96d0c5.mp3','对……负责','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3cc6b9bfb17444ec9dff65c021b8c979','put on weight...','141','[put ɔn weit]','http://res.iciba.com/resource/amp3/0/0/36/93/3693047ecfef9960be2bcb7c14abb8c6.mp3','发福，增加体重','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('f35fe3e8aeea48f2af014a22abd8d86f','look up','141','[luk ʌp]','http://res.iciba.com/resource/amp3/0/0/b1/d2/b1d2bfafc04edf0032e087d532e03f40.mp3','查找','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c2c92068745d417bb8e614f56dd91ae2','keep off','141','[ki:p ɔf]','http://res.iciba.com/resource/amp3/0/0/a4/ad/a4ad8f6ddb62584ef754a2a23d29918c.mp3','勿踏; 勿踩','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('71d149941f6e4cf487f585d83a5736d8','fall ill','141','[fɔ:l il]','http://res.iciba.com/resource/amp3/0/0/8b/b2/8bb22ec4d0ba3acde4c6123236507a76.mp3','患病，病倒','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1e9752458a614f66ba0740f0ad2ba951','as a matter o...','141','[æz ə ˈmætə ɔv fækt]','http://res.iciba.com/resource/amp3/0/0/e0/8e/e08e1c5605b12e9b0b6b771930742ab6.mp3','事实上，其实','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('f235a580d89b4dfea36a2b34301c9c1d','call up','141','[kɔ:l ʌp]','http://res.iciba.com/resource/amp3/0/0/ff/cb/ffcb47b23fb50d501b74f1dd808c0571.mp3','号召，打电话','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('24a06cf0f1214e16a2e622b12704e1cf','come true','141','[kʌm truː]','http://res.iciba.com/resource/amp3/0/0/e2/c0/e2c0016a803ace116df92b858854159f.mp3','变为现实，成为事实','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d64dfa62ccf1483dbc98c6722a51008f','ring back','141','[riŋ bæk]','http://res.iciba.com/resource/amp3/0/0/ff/c3/ffc351e2a96c7c7fb17cc6f06c064af5.mp3','回电话','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('82749cc3fd804a8c9f0a15e95ad8bb51','pay off','141','[pei ɔf]','http://res.iciba.com/resource/amp3/0/0/dd/1c/dd1c1db317165e5c585d7dbd318c3536.mp3','偿清(欠款等)','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('01cd06ff9b104a60b362873e87632220','turn off','141','[tə:n ɔf]','http://res.iciba.com/resource/amp3/1/0/54/6f/546fa8c1eeaa45d4f018b8f53d64bb10.mp3','关掉（水、电、电视、收音机等）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('dbbc20670f184fa79e5a04c4127db222','neither...nor...','141','','http://res-tts.iciba.com/c/4/7/c4714351d0944a6d311802ff78c52582.mp3','既不……也不……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d00cf0bd92354da380eaea5f7a76a393','put out','141','[put aut]','http://res.iciba.com/resource/amp3/0/0/58/82/5882efa990a1c83ed0037a4fe3d54fd4.mp3','扑灭，关熄','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c3448ea8947044a0abdac41b66a1cdb5','enjoy oneself...','141','[inˈdʒɔi wʌnˈself]','http://res-tts.iciba.com/d/f/8/df8495bd1a9c3145c280348844de74b2.mp3','过得愉快','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('68209e22862e4c2099182ed75c944f76','over the radi...','141','[inˈdʒɔi wʌnˈself]','','通过收音机','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('29b2b75b2d984a7db49951e314902446','so as to','141','[səʊ æz tu:]','http://res.iciba.com/resource/amp3/0/0/db/2f/db2f8c1913705fe4f9287f4d953742cd.mp3','以便，为的是','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4fb916fba04f42f19e27d54b72dd7b91','pick out','141','[pik aut]','http://res.iciba.com/resource/amp3/0/0/3f/86/3f863d9c2a8a55a8b695ac80f4a28f80.mp3','选出','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('fb65111c072745e092e57ae93fe52495','first of all','141','[fə:st ɔv ɔ:l]','http://res.iciba.com/resource/amp3/0/0/e3/e2/e3e26e5b7350bb89a4449424dbcead7f.mp3','首先','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('45e0eec177ec47aeacac69c934499958','up and down','141','[ʌp ænd daun]','http://res-tts.iciba.com/1/b/7/1b75533ed5a869ff6f3ae0336d0c3320.mp3','上下，来回','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3700afd256e245bea7cfbfdaf0e760b6','not any more','141','[nɔt ˈeni mɔ:]','http://res.iciba.com/resource/amp3/0/0/da/5f/da5f5e7f141e89b7d040d01495996af8.mp3','不再','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('82278b76c352454ca7827848ed5ab8ff','used to do st...','141','[nɔt ˈeni mɔ:]','','过去常常','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('2b6c5c2a812e425f8f09121bb1d60ba0','had better (d...','141','[nɔt ˈeni mɔ:]','','最好（做）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d7645bf836c04117abda364f508637d5','look after','141','[luk ˈɑ:ftə]','http://res.iciba.com/resource/amp3/0/0/50/d5/50d5b9b739ca88d298d2badd660d3f45.mp3','照顾','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('65ca5600ba0741208a338fe147c97590','scores of','141','[skɔ:z ɔv]','http://res-tts.iciba.com/7/9/0/79097afe4c108b3ae8225ed54ed8856c.mp3','许多，大量','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d0de4e74c3914d1ba0be44629eee2ef1','cut up','141','[kʌt ʌp]','http://res.iciba.com/resource/amp3/1/0/b7/0b/b70bc6b2750b9076a03645246696d286.mp3','齐根割掉，切碎','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8d50300bdf0c461f9ce3ff1d3f4bfeca','separate...fr...','141','','http://res-tts.iciba.com/d/b/0/db0f3a90557b5a63bc31a9a5a77f8f64.mp3','分开','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b8f2bdba9a1a4e6595cef48b890548ee','ring off','141','[riŋ ɔf]','http://res.iciba.com/resource/amp3/0/0/18/9f/189f83252e11d0a4e9787f09bcb31374.mp3','挂断电话，停止讲话','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d58db1b276a6443b8e4f26215b6fe684','look forward ...','141','[luk ˈfɔ:wəd tu:]','http://res.iciba.com/resource/amp3/0/0/7e/64/7e640ae8ee37aa9b36d9f697834edd48.mp3','盼望','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('910401bb84d54349851f5e828a4523f9','now that','141','[nau ðæt]','http://res.iciba.com/resource/amp3/0/0/e7/d4/e7d4d861dd506fa668f62035468743dc.mp3','既然','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('944d25f1476546c7a1af899ba22d20d7','congratulate....','141','[nau ðæt]','','祝贺……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('d59af93dda0c40a9b92e9cb4f293fef6','as far as','141','[æz fɑ: æz]','http://res.iciba.com/resource/amp3/0/0/26/45/2645890eaf982b0dc222673fc86d8ef3.mp3','（表示程度，范围）就……；尽……','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8f28371dc3d74ef6aef68c52b7e0b014','for ever','141','[fɔ: ˈevə]','http://res.iciba.com/resource/amp3/0/0/ce/e2/cee2bad6bc2cc0fa3ae882677315fcba.mp3','永远','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('e66d5df586a7495db5057d7d36dc3a3a','in common','141','[in ˈkɔmən]','http://res.iciba.com/resource/amp3/0/0/2d/44/2d44f214137994bdec8e8fa142f78ff2.mp3','共同，共有','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4d8571ed937c4b11a4236eadeea0f430','look ahead','141','[luk əˈhed]','http://res.iciba.com/resource/amp3/0/0/13/22/1322749cc7376eb4fbad645af54c0a1a.mp3','向前看，展望未来','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('93ba3acd821f4361a4024bb0e090f96f','have a cold','141','[hæv ə kəuld]','http://res.iciba.com/resource/amp3/0/0/f1/bd/f1bdc43e23d9671e610e5f5676c73f1a.mp3','患感冒','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('27bd3a800d6c47e99f8e5bf561325eae','as well','141','[æz wel]','http://res-tts.iciba.com/a/b/2/ab256241aac70f922e45e2936a5a4770.mp3','也，还有','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4b28d54ab9ca40eaaae4aa7cbdbbe66a','break down','141','[breik daun]','http://res.iciba.com/resource/amp3/0/0/a1/7a/a17ab636cff45318af41533e570a1396.mp3','损坏; (把化合物等) 分解，（汽车）抛...','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('6d90f7e9f41c4fcf99152c589515eed5','drop in','141','[drɔp in]','http://res.iciba.com/resource/amp3/1/0/83/d7/83d776cb280d1dafb6a624b0c776190b.mp3','顺便走访（某人）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4e3b60bf61bc4f99a61ef24b15c0beb2','hear of','141','[hiə ɔv]','http://res.iciba.com/resource/amp3/0/0/5a/18/5a18dca446a07defdc8fcae673400e5c.mp3','听说，知道','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9ebbeb18922a479b81087a7d499a8c51','call on','141','[kɔ:l ɔn]','http://res.iciba.com/resource/amp3/0/0/f6/a7/f6a7b7e2a8e576a926855b7e45007c70.mp3','拜访，访问','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('18696005ffcb45debe43001368d612a1','tick to','141','[kɔ:l ɔn]','','坚持','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('2c9f3322c29c4c97906a3db72b6419fd','get close (to...','141','[kɔ:l ɔn]','','接近','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('575e3ab8a91b442a9cefd35baf1782bc','speed up','141','[spi:d ʌp]','http://res.iciba.com/resource/amp3/0/0/e1/59/e15919e9f3dda8070015df3a70e233ea.mp3','加快速度','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5d92240534254c4bb43d433dcc6e5710','get away','141','[ɡet əˈwei]','http://res.iciba.com/resource/amp3/0/0/a0/9f/a09fd686300157ba8e45e2fb4c6429d3.mp3','逃; 离','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5747f7cc0c404bb29f10d14ab0af23dd','go on with','141','[ɡəu ɔn wið]','http://res-tts.iciba.com/8/0/2/802c1bd0bdeb94b2e25c7885785a394d.mp3','继续','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('86f1f79b76874b8190dd2e38700330be','go away','141','[ɡəu əˈwei]','http://res.iciba.com/resource/amp3/0/0/15/8e/158ee90f12f717dcbf3ad71e0f41cdb3.mp3','走开，离去','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('a5e9541f6b5c44b393a31bdf1c9a39ce','all over','141','[ɔ:l ˈəuvə]','http://res.iciba.com/resource/amp3/0/0/28/42/2842c2a9ef530c2fe7633572c62043d9.mp3','到处，遍及，结束','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('8a990e0201bf4228af9a54942c2cf8bc','as well as','141','[æz wel æz]','http://res.iciba.com/resource/amp3/0/0/75/6f/756fc496c55892dc274ded063136d1c3.mp3','除……之外（也）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ff3cb1ccc0f540fcbb41cd030617e8e9','right away','141','[rait əˈwei]','http://res.iciba.com/resource/amp3/0/0/51/13/511375d0e0766e9e8743def6a16df949.mp3','立即，马上','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('0ac65d2123a147aabd728c2fa4e0b393','take one''s ti...','141','[teik wʌnz taim]','http://res.iciba.com/resource/amp3/0/0/c6/73/c67339faf2eb58430158d29c3c0b2305.mp3','从容，慢慢行动','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9542b34e2df04863b9d68e661aa3f034','apart from','141','[əˈpɑ:t frɔm]','http://res.iciba.com/resource/amp3/0/0/e6/c4/e6c46c7575220104419485f01e0e7ce0.mp3','除去，除了','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c03feaab6d2b49ef84b55d7c896f59c0','join in','141','[dʒɔin in]','http://res.iciba.com/resource/amp3/0/0/4d/1d/4d1d8ce3255d178b543d1edc8c8c3bcd.mp3','参加，加入','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('c5dc684cc72a4148be53e71c1ba28047','come to','141','[kʌm tu:]','http://res.iciba.com/resource/amp3/0/0/1f/6b/1f6ba5325095ab494dfad9c1897cf8cd.mp3','共计，达到','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4211976068db48c884035f094a1c5be0','once upon a t...','141','[wʌns əˈpɔn ə taim]','http://res.iciba.com/resource/amp3/0/0/ea/36/ea36fcd25d96821e1455adec6e5d9a3a.mp3','从前，很久以前','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('cb3646fbad6d435ba03ba04e754a322f','above all','141','[əˈbʌv ɔ:l]','http://res.iciba.com/resource/amp3/0/0/17/f9/17f96e133412f7b2ce96939665006e8f.mp3','首先，首要','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ae595f7872f3436c828bbfdc0da4a605','instead of','141','[inˈsted ɔv]','http://res.iciba.com/resource/amp3/0/0/7b/b6/7bb63c7de5a5ee79356083a12f21e1e8.mp3','代替，而不是','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9ed47811cf094464af7abe3ea3604132','carry out','141','[ˈkæri aut]','http://res.iciba.com/resource/amp3/0/0/a8/f3/a8f3fbc8209b6608d2cb431ab23f5c34.mp3','开展，执行','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('b232aba816804f3e847fa38b32935d06','look into','141','[luk ˈɪntuː]','http://res.iciba.com/resource/amp3/0/0/ca/5e/ca5e430b5c386a10fa1555654bca4711.mp3','向…里面看去; 调查','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('7bf3e1fbbb444447a7eb963ab4d6b05f','get on with s...','141','[luk ˈɪntuː]','','与……相处','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('98bc9fc0c0194982b3caeb666138ca6d','not at all','141','[nɔt æt ɔ:l]','http://res.iciba.com/resource/amp3/0/0/06/95/06951a076c8f062e7009da6709f26c39.mp3','一点也不，绝非','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4248fadc44c24ecb90ddd22a8241dd53','go by','141','[ɡəu bai]','http://res.iciba.com/resource/amp3/0/0/09/8f/098f3f04eecb8bf1c481c00528d838f3.mp3','走过; 经过; 过去','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('ee279ccb7e1143afac96f883aad14ce0','show off','141','[ʃəu ɔf]','http://res.iciba.com/resource/amp3/0/0/5c/a7/5ca7be6015d17b7ca5b876e01e91c892.mp3','炫耀','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1644281a257c4883907d4ef8c2d07548','hang up','141','[hæŋ ʌp]','http://res.iciba.com/resource/amp3/0/0/cc/61/cc6145b2f3c30b5214a7a2e86d739f68.mp3','挂断电话','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('1eef81cad15847258c40e50ce73c09e2','in order that...','141','[in ˈɔ:də ðæt]','http://res-tts.iciba.com/8/1/6/816f4441379eace0087407690e59a317.mp3','为了','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9631549623254a5c87b17382c8fd1b42','clear up','141','[kliə ʌp]','http://res.iciba.com/resource/amp3/0/0/80/ed/80edc311f2d4742023e99a3db0e02917.mp3','整理，收拾, (天气)放晴','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('129ef33c06e64aefbd85df96c22204d7','keep on','141','[ki:p ɔn]','http://res.iciba.com/resource/amp3/0/0/dc/4e/dc4e3dde75057e242c16a57f6352ad30.mp3','继续（进行）','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('3cdfaa727bc44353961b95fc89b7f2c2','think of','141','[θiŋk ɔv]','http://res-tts.iciba.com/e/f/f/eff6cf09810856479d918b0874cf3b14.mp3','想起,考虑,认为,看法','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('4d59012fd0c8449ab64f65f1d4612d65','for good','141','[fɔ: ɡud]','http://res.iciba.com/resource/amp3/0/0/4a/00/4a00dd7fb7008456bce24800beef5417.mp3','永远','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('9d7f5bb86a5c4ad4bbaebaa29f3ca880','break up','141','[breik ʌp]','http://res.iciba.com/resource/amp3/0/0/bf/f2/bff2be32210454ea1b271f09f9dceb37.mp3','分解；分裂','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('5290fba4d85448309c48d0378fd464af','compare to','141','[kəmˈpɛə tu:]','http://res.iciba.com/resource/amp3/0/0/21/2d/212d0f442da20ddc6412cb33a6c93950.mp3','与……相比','','')--B3WmSQL--
INSERT INTO word_141 VALUES ('71ab0fa91cef4cd0b9641ec38a31fdf4','keep one''s wo...','141','[ki:p wʌnz wə:d]','http://res.iciba.com/resource/amp3/0/0/ab/5a/ab5a8daed81231d8e8897ede5f3194de.mp3','守信','','')
